﻿using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Parking.Controller
{
    public class ConfiguracionController
    {
        readonly ConexionBD conexionBD = new ConexionBD();

        #region guardar_informacion_empresa
        public async Task<bool> AgregarInformacionEmpresa(string razon_social, string direccion, string telefono, string consecutivo_recibo, string horario, string responsable, string nit, string regimen, string iva, string numero_resolucion, string fecha_resolucion, string nombre_ticket, string CantidadCeros, string ValorInicial, string ticket, string srcImage, string IdUsuarioLogin)
        {
            bool b = false;
            try
            {
                string strSQL = "";

                byte[] imagenBytes = null;
                // --- VALIDACIÓN: ¿Viene vacía o nula la ruta? ---
                if (string.IsNullOrEmpty(srcImage))
                {
                    // Si no hay ruta, enviamos NULL a la base de datos
                    imagenBytes = null;
                }
                else
                {
                    // Si hay ruta, verificamos que el archivo exista realmente para evitar errores
                    if (File.Exists(srcImage))
                    {
                        Library clsLibrary = new Library();
                        imagenBytes = clsLibrary.ProcesarImagenDesdeRuta(srcImage);
                    }
                }
                // Preparamos los parámetros para un nuevo usuario
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@razon_social", razon_social),
                    new KeyValuePair<string, object>("@direccion", direccion),
                    new KeyValuePair<string, object>("@telefono", telefono),
                    new KeyValuePair<string, object>("@consecutivo_recibo", consecutivo_recibo),
                    new KeyValuePair<string, object>("@horario", horario),
                    new KeyValuePair<string, object>("@responsable", responsable),
                    new KeyValuePair<string, object>("@nit", nit),
                    new KeyValuePair<string, object>("@regimen", regimen),
                    new KeyValuePair<string, object>("@iva", iva),
                    new KeyValuePair<string, object>("@numero_resolucion", numero_resolucion),
                    new KeyValuePair<string, object>("@fecha_resolucion", fecha_resolucion),
                    new KeyValuePair<string, object>("@nombre_ticket", nombre_ticket),
                    new KeyValuePair<string, object>("@CantidadCeros", CantidadCeros),
                    new KeyValuePair<string, object>("@ValorInicial", ValorInicial),
                    new KeyValuePair<string, object>("@imagen", imagenBytes ?? (object)DBNull.Value),
                    new KeyValuePair<string, object>("@ticket", ticket),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", IdUsuarioLogin),
                };

                // Abrimos conexión
                if (await conexionBD.Connection())
                {
                    // Ejecutamos el método insert para rgistrar usuario nuevo
                    strSQL = @"begin try
                               begin transaction
                               DECLARE @informacion NVARCHAR(MAX);
                               SET @informacion = 'Razón social: '+@razon_social+' Dirección:'+@direccion+' Teléfono: '+@telefono+' Consecutivo: '+@consecutivo_recibo+' Horario: '+@horario+' Responsable: '+@responsable+' NIT: '+@nit+' Regimen: '+@regimen+' IVA: '+@iva+' Número resolución: '+@numero_resolucion+' Fecha resaolución: '+@fecha_resolucion+' Ticket: '+@nombre_ticket+' Cantidad ceros: '+CAST(@CantidadCeros AS NVARCHAR)+' Número inicial ticket: '+CAST(@ValorInicial AS NVARCHAR);
                               IF EXISTS (SELECT 1 FROM Configuracion WHERE Valor = 'Informacion_Empresa')
                               BEGIN
                                   DELETE FROM Configuracion WHERE Valor = 'Informacion_Empresa';
                               END
                               INSERT INTO Configuracion (Valor,DatosJson)
                                    SELECT 'Informacion_Empresa',(
                                        SELECT 
                                            @razon_social AS razon_social,
                                            @direccion AS direccion,
                                            @telefono AS telefono,
                                            @consecutivo_recibo AS consecutivo_recibo,
                                            @horario AS horario,
                                            @responsable AS responsable,
                                            @nit AS nit,
                                            @regimen AS regimen,
                                            @iva AS iva,
                                            @numero_resolucion AS numero_resolucion,
                                            @fecha_resolucion AS fecha_resolucion,
                                            @nombre_ticket AS nombre_ticket,
                                            @CantidadCeros AS CantidadCeros,
                                            @ValorInicial AS ValorInicial,
                                            @ticket AS ticket,
                                            -- Si manejas la imagen como Base64 dentro del JSON:
                                            (SELECT @imagen FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)') AS imagen_base64
                                        FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
                               -- Registra en Auditoria que se agregó un usuario
                               INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                               VALUES(@IdUsuarioLogin, N'Agrego Información Empresa', GETDATE(), @informacion);
                               commit transaction
                               end try
                               begin catch
                               rollback transaction
                               DECLARE @numeroDeError INT = ERROR_NUMBER();
                               THROW  -- Relanza el error
                               end catch";
                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        // Lanzamos una excepción manualmente usando el error guardado
                        throw new Exception();
                    }
                }
            }
            catch (Exception error)
            {
                // Si hubo error, divide el mensaje en código y descripción separados por '-'
                string[] partes = conexionBD.StrError.Split('-');
                string codigoError = partes[0]; // Obtiene el código de error (ej. "2627")
                // Si el mensaje tiene más partes, une las restantes como descripción
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)) : string.Empty;

                // Para cualquier otro error, muestra el mensaje completo
                MessageBox.Show($"Error al guardar información de la empresa.\n{partes[1]}\n{error.Message}", "Información", MessageBoxButton.OK, MessageBoxImage.Error);

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return b;
        }
        #endregion

        #region ver_informacion_empresa
        public async Task<DataTable> ObtenerInformacionEmpresaAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT 
                                j.razon_social,
                                j.direccion,
                                j.telefono,
                                j.consecutivo_recibo,
                                j.horario,
                                j.responsable,
                                j.nit,
                                j.iva,
                                j.regimen,
                                j.numero_resolucion,
                                j.fecha_resolucion,
                                j.nombre_ticket,
                                j.CantidadCeros,
                                j.ValorInicial,
                                j.ticket,
                                -- Convierte la cadena almacenada en el JSON a un tipo binario (VARBINARY) real
                                --CAST(j.imagen_base64 AS VARBINARY(MAX)) AS Imagen
                                j.imagen_base64 AS Imagen
                            FROM Configuracion
                            OUTER APPLY OPENJSON(DatosJson)
                            WITH (
                                razon_social       NVARCHAR(150)  '$.razon_social',
                                direccion          NVARCHAR(200)  '$.direccion',
                                telefono           NVARCHAR(50)   '$.telefono',
                                consecutivo_recibo NVARCHAR(50)   '$.consecutivo_recibo',
                                horario            NVARCHAR(50)   '$.horario',
                                responsable        NVARCHAR(50)   '$.responsable',
                                nit                VARCHAR(20)    '$.nit',
                                iva                NVARCHAR(20)   '$.iva',
                                regimen            NVARCHAR(50)   '$.regimen',
                                numero_resolucion  NVARCHAR(100)  '$.numero_resolucion',
                                fecha_resolucion   NVARCHAR(100)  '$.fecha_resolucion',
                                nombre_ticket      NVARCHAR(100)  '$.nombre_ticket',
                                CantidadCeros      NVARCHAR(100)  '$.CantidadCeros',
                                ValorInicial       NVARCHAR(100)  '$.ValorInicial',
                                ticket             NVARCHAR(100)  '$.ticket',
                                --imagen_base64    NVARCHAR(MAX)  '$.imagen_base64'
                                imagen_base64      VARCHAR(MAX)   '$.imagen_base64'
                            ) AS j
                            WHERE Valor = 'Informacion_Empresa';";
                    // Preparamos la lista de parámetros para tu método dataSet_
                    var parametros = new List<KeyValuePair<string, object>>
                    {
                        new KeyValuePair<string, object>("@Valor", "Informacion_Empresa")
                    };
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet.Tables[0];
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al consultar información de la empresa.\n{conexionBD.StrError}\n{error.Message}", "Información", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region guardar_configuracion_ticket
        public async Task<bool> GuardarConfiguracionTicket(string strTicket, string IdUsuarioLogin, string strValor, string strConfiguracionID = "")
        {
            bool b = false;
            try
            {
                string strSQL = "";

                // Preparamos los parámetros para un nuevo usuario
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@strValor", strValor),
                    new KeyValuePair<string, object>("@strConfiguracionID", strConfiguracionID == "" ? (object)DBNull.Value : (object)strConfiguracionID),
                    new KeyValuePair<string, object>("@strTicket", strTicket),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", IdUsuarioLogin),
                };

                // Abrimos conexión
                if (await conexionBD.Connection())
                {
                    // Ejecutamos el método insert para rgistrar usuario nuevo
                    strSQL = @"begin try
                               begin transaction
                               DECLARE @TICKETTIPO NVARCHAR(50);
                               DECLARE @Nombre NVARCHAR(50);
                               DECLARE @Tipo NVARCHAR(50);
                               -- Obtener las posiciones del ':' y del '-'
                               DECLARE @PosDosPuntos INT = CHARINDEX(':', @strValor);
                               DECLARE @PosGuion INT = CHARINDEX('-', @strValor);

                               -- Extraer el Nombre (lo que está entre los dos puntos y el guion)
                               SET @Nombre = SUBSTRING(@strValor, @PosDosPuntos + 1, @PosGuion - @PosDosPuntos - 1);

                               -- Extraer el Tipo (lo que está después del guion)
                               SET @Tipo = SUBSTRING(@strValor, @PosGuion + 1, LEN(@strValor));
                               IF @strConfiguracionID IS NOT NULL
                               BEGIN
                                   UPDATE Configuracion SET Valor = @strValor, DatosJson = @strTicket WHERE ConfiguracionID = @strConfiguracionID;
                                   SET @TICKETTIPO = N'Actualizo Ticket';
                               END
                               ELSE
                               BEGIN
                                   INSERT INTO Configuracion (Valor,DatosJson)
                                   VALUES (@strValor, @strTicket)
                                   SET @TICKETTIPO = N'Nuevo Ticket';
                               END

                               -- Registra en Auditoria que se agregó un usuario
                               INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                               VALUES(@IdUsuarioLogin, @TICKETTIPO, GETDATE(), 'Nombre: '+@Nombre+' Tipo: '+@Tipo);
                               commit transaction
                               end try
                               begin catch
                               -- Verificamos si hay una transacción activa antes de hacer rollback
                               if @@TRANCOUNT > 0
                               rollback transaction;
                               THROW; -- Relanza el error hacia C#
                               end catch";
                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        // Lanzamos una excepción manualmente usando el error guardado
                        throw new Exception();
                    }
                }
            }
            catch (Exception error)
            {
                // Obtenemos el código de error que viene de SQL Server
                string codigoError = "";
                if (!string.IsNullOrEmpty(conexionBD.StrError))
                {
                    string[] partes = conexionBD.StrError.Split('-');
                    codigoError = partes[0].Trim();
                }

                string mensajeCompleto = error.Message + " " + conexionBD.StrError;

                // Si el error es por clave duplicada (2627 o 2601) o afecta a nuestra restricción UNIQUE
                if (codigoError == "2627" || codigoError == "2601" || mensajeCompleto.Contains("UQ_Configuracion_Identificador"))
                {
                    // Aquí mostramos exactamente el mensaje que solicitaste
                    MessageBox.Show("Ya existe un ticket registrado con ese mismo nombre", "Ticket Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    // Para cualquier otro error diferente
                    MessageBox.Show($"Error al guardar ticket.\n{error.Message}", "Nuevo Ticket", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return b;
        }
        #endregion

        #region cargar_configuracion_ticket_seleccionado
        public async Task<DataSet> CargarConfiguracionTicket(string ConfiguracionID)
        {
            try
            {
                // Preparamos la lista de parámetros para tu método dataSet_
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@ConfiguracionID", ConfiguracionID)
                };
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT DatosJson FROM Configuracion WHERE ConfiguracionID = @ConfiguracionID";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener usuarios.\n{conexionBD.StrError}\n{error.Message}", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region tickets_existentes
        public async Task<DataSet> TicketsAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT ConfiguracionID, Valor,
                                        SUBSTRING(Valor, CHARINDEX(':', Valor) + 1, CHARINDEX('-', Valor) - CHARINDEX(':', Valor) - 1) AS Ticket,
                                        SUBSTRING(Valor, CHARINDEX('-', Valor) + 1, LEN(Valor)) AS Tipo
                                    FROM Configuracion 
                                    WHERE Valor LIKE '%TICKET:%';";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener usuarios.\n{conexionBD.StrError}\n{error.Message}", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }

        #endregion

        #region eliminar_ticket
        public async Task<bool> DeleteTicketAsync(string ConfiguracionID, string ticket, string IdUsuarioLogin)
        {
            bool b = false;
            try
            {


                var listUsuarioUpdate = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@ConfiguracionID", ConfiguracionID),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", IdUsuarioLogin),
                    new KeyValuePair<string, object>("@detalle", $"{ticket}")
                };

                if (await conexionBD.Connection())
                {
                    string strSQL = @" begin try
                                       begin transaction
                                       -- Eliminar usuario seleccionado
                                       DELETE FROM Configuracion WHERE ConfiguracionID = @ConfiguracionID;
                                       -- Registra en Auditoria que se elimino un usuario
                                       INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                       VALUES(@IdUsuarioLogin, N'Eliminó Ticket', GETDATE(), @detalle);
                                       commit transaction
                                       end try
                                       begin catch
                                       rollback transaction
                                       DECLARE @numeroDeError INT = ERROR_NUMBER();
                                       THROW  -- Relanza el error
                                       end catch";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, listUsuarioUpdate))
                    {
                        b = true;
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Error al eliminar usuario.\n{conexionBD.StrError}\n{error.Message}", "Eliminar Usuario", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally { await conexionBD.CloseConnection(); }
            return b;
        }
        #endregion
    }
}