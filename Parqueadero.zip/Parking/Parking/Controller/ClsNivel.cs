﻿using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;

namespace Parking.Controller
{
    public class Nivel
    {
        private readonly ConexionBD conexionBD = new ConexionBD();

        #region listado_niveles
        public async Task<DataSet> NivelesAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT
                                    n.IdNivel,
                                    n.Nombre AS Nivel,
                                    en.Nombre AS EstadoNivel,
                                    n.Descripcion,
                                    COUNT(c.IdCelda) AS TotalCeldas,
    
                                    -- Libres: Solo si el nivel está activo, la celda está libre y NO tiene un vehículo activo
                                    CASE WHEN n.IdEstadoNivel = 1 THEN
                                        SUM(CASE WHEN c.IdEstadoCelda = 1 AND o.IdOcupacion IS NULL THEN 1 ELSE 0 END)
                                    ELSE 0 END AS Libres,
    
                                    -- Ocupadas: Si tiene una ocupación activa (FechaSalida IS NULL) o su estado es Ocupada (2)
                                    SUM(CASE WHEN o.IdOcupacion IS NOT NULL OR c.IdEstadoCelda = 2 THEN 1 ELSE 0 END) AS Ocupadas,
    
                                    -- No Disponibles: Si el nivel está inactivo o la celda es 3, y NO está ocupada por un vehículo
                                    SUM(CASE WHEN o.IdOcupacion IS NULL AND (n.IdEstadoNivel = 2 OR c.IdEstadoCelda = 3) THEN 1 ELSE 0 END) AS NoDisponibles,
    
                                    n.IdEstadoNivel,
                                    CAST(
                                        CASE 
                                            WHEN COUNT(c.IdCelda) = 0 OR n.IdEstadoNivel = 2 THEN 0
                                            ELSE (SUM(CASE WHEN c.IdEstadoCelda = 1 AND o.IdOcupacion IS NULL THEN 1 ELSE 0 END) * 100.0) / COUNT(c.IdCelda) 
                                        END AS INT
                                    ) AS Disponibilidad
                                FROM Nivel AS n
                                INNER JOIN EstadoNivel AS en
                                    ON en.IdEstadoNivel = n.IdEstadoNivel
                                LEFT JOIN Celda AS c
                                    ON c.IdNivel = n.IdNivel
                                -- Unimos con la tabla de ocupaciones para detectar vehículos activos en la celda
                                LEFT JOIN OcupacionCelda AS o 
                                    ON o.IdCelda = c.IdCelda AND o.FechaSalida IS NULL
                                GROUP BY
                                    n.IdNivel,
                                    n.Nombre,
                                    en.Nombre,
                                    n.Descripcion,
                                    n.IdEstadoNivel
                                ORDER BY n.IdNivel;
                                    /*SELECT
                                    n.IdNivel,
                                    n.Nombre AS Nivel,
                                    en.Nombre AS EstadoNivel,
                                    n.Descripcion,
                                    COUNT(c.IdCelda) AS TotalCeldas,
                                    --SUM(CASE WHEN c.IdEstadoCelda = 1 THEN 1 ELSE 0 END) AS Libres,
                                    CASE WHEN n.IdEstadoNivel = 1 THEN
                                    SUM(CASE WHEN c.IdEstadoCelda = 1 THEN 1 ELSE 0 END)
                                    ELSE 0 END AS Libres,
                                    SUM(CASE WHEN c.IdEstadoCelda = 2 THEN 1 ELSE 0 END) AS Ocupadas,
                                    SUM(CASE WHEN c.IdEstadoCelda = 3 THEN 1 ELSE 0 END) AS NoDisponibles,
                                    n.IdEstadoNivel,
                                    CAST(
                                    CASE 
                                        --WHEN COUNT(c.IdCelda) = 0 THEN 0
                                        WHEN COUNT(c.IdCelda) = 0 OR n.IdEstadoNivel = 2 THEN 0
                                        ELSE (SUM(CASE WHEN c.IdEstadoCelda = 1 THEN 1 ELSE 0 END) * 100.0) / COUNT(c.IdCelda) 
                                    END AS INT
                                ) 
                                -- Concatena el símbolo de porcentaje al final
                                AS Disponibilidad
                                FROM Nivel AS n
                                INNER JOIN EstadoNivel AS en
                                    ON en.IdEstadoNivel = n.IdEstadoNivel
                                LEFT JOIN Celda AS c
                                    ON c.IdNivel = n.IdNivel
                                GROUP BY
                                    n.IdNivel,
                                    n.Nombre,
                                    en.Nombre,
                                    n.Descripcion,
                                    n.IdEstadoNivel
                                ORDER BY
                                    n.Nombre;*/";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener nivele(s).\n{conexionBD.StrError}\n{error.Message}", "Niveles", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region nivel_nuevo
        public async Task<bool> NuevoNivel(string Nombre, string Descripcion, string IdUsuarioLogin)
        {
            bool b = false;
            try
            {
                string strSQL = "";

                // Preparamos los parámetros para un nuevo nivel
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Nombre", Nombre),
                    new KeyValuePair<string, object>("@Descripcion", Descripcion),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", IdUsuarioLogin),
                    new KeyValuePair<string, object>("@detalle", $"Creó el nivel: '{Nombre}' descripción: {Descripcion}"),
                };

                // Abrimos conexión
                if (await conexionBD.Connection())
                {
                    // Ejecutamos el método insert para rgistrar usuario nuevo
                    strSQL = @"DECLARE @lastID INT
                               begin try
                               begin transaction
                               -- Obtiene el último ID de nivel
                               SELECT @lastID = MAX(IdNivel) FROM Nivel;
                               IF @lastID IS NULL
                               BEGIN
                               SET @lastID = 0
                               END
                               SET IDENTITY_INSERT Nivel ON;
                               -- Inserta en la tabla Nivel con ID manual (lastID+1)
                               insert into Nivel (IdNivel, Nombre, Descripcion) 
                               values(@lastID+1, @Nombre, @Descripcion);
                               SET IDENTITY_INSERT Nivel OFF;
                               -- Registra en Auditoria que se agregó un Nivel
                               INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                               VALUES(@IdUsuarioLogin, N'Agrego Nuevo Nivel', GETDATE(), @detalle);
                               commit transaction
                               end try
                               begin catch
                               rollback transaction
                               SET IDENTITY_INSERT Nivel OFF;
                               DECLARE @numeroDeError INT = ERROR_NUMBER();
                               THROW  -- Relanza el error
                               end catch";
                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        // Lanzamos una excepción manualmente usando el error guardado
                        throw new Exception();
                    }
                }
            }
            catch (Exception error)
            {
                // Si hubo error, divide el mensaje en código y descripción separados por '-'
                string[] partes = conexionBD.StrError.Split('-');
                string codigoError = partes[0]; // Obtiene el código de error (ej. "2627")
                // Si el mensaje tiene más partes, une las restantes como descripción
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)) : string.Empty;

                // Si el código de error es 2627 (violación de clave única)
                if (codigoError == "2627")
                {
                    // Patrón regex para extraer el valor entre paréntesis del mensaje de SQL Server
                    string pattern = @"\((.*?)\)";
                    string result = "";
                    MatchCollection matches = Regex.Matches(mensaje, pattern);
                    // Recorre las coincidencias y obtiene la primera (última) captura
                    foreach (Match match in matches)
                    {
                        result = match.Groups[1].Value.ToLower();
                    }
                    // Si el valor duplicado coincide con el usuario enviado, muestra mensaje específico
                    MessageBox.Show($"El nombre de nivel '{result}' ya se encuentra registrado", "Nuevo Nivel", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    // Para cualquier otro error, muestra el mensaje completo
                    MessageBox.Show($"Error al guardar nivel.\n{partes[1]}\n{error.Message}", "Nuevo Nivel", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return b;
        }
        #endregion

        #region actualizar_nivel

        public async Task<bool> UpdateNivelAsync(string IdNivel, string Nombre, string Descripcion, string IdUsuarioLog)
        {
            bool b = false;
            try
            {
                var listNivelUpdate = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdNivel", IdNivel),
                    new KeyValuePair<string, object>("@Nombre", Nombre), // Se actualiza siempre
                    new KeyValuePair<string, object>("@Descripcion", Descripcion),
                    new KeyValuePair<string, object>("@IdUsuarioLog", IdUsuarioLog),
                    new KeyValuePair<string, object>("@detalle", $"Actualizo el nivel: '{Nombre}' - descripción: {Descripcion}"),
                };

                if (await conexionBD.Connection())
                {
                    // SQL: Solo PasswordHash y PasswordSalt tienen el "escudo" ISNULL
                    string strSQL = @"begin try
                                    begin transaction
                                    UPDATE Nivel 
                                    SET 
                                        Nombre      = @Nombre,
                                        Descripcion = @Descripcion
                                    WHERE IdNivel = @IdNivel;
                                    -- Registra en Auditoria que se actualizo NIVEL
                                    INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                    VALUES(@IdUsuarioLog, N'Actualizo Nivel', GETDATE(), @detalle);
                                    commit transaction
                                    end try
                                    begin catch
                                    rollback transaction
                                    SET IDENTITY_INSERT Nivel OFF;
                                    DECLARE @numeroDeError INT = ERROR_NUMBER();
                                    THROW  -- Relanza el error
                                    end catch";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, listNivelUpdate))
                    {
                        b = true;
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Error: {error.Message}", "Editar Nivel", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally { await conexionBD.CloseConnection(); }
            return b;
        }
        #endregion

        #region eliminar_nivel
        public async Task<bool> DeleteNivelAsync(string IdNivel, string Nombre, string IdUsuarioLogin)
        {
            bool b = false;
            try
            {
                var listEliminarNivel = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdNivel", IdNivel),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", IdUsuarioLogin),
                    new KeyValuePair<string, object>("@detalle", $"Eliminó nivel: '{Nombre}'")
                };

                if (await conexionBD.Connection())
                {
                    string strSQL = @"BEGIN TRY
                                        BEGIN TRANSACTION;

                                        -- Validar si el nivel existe
                                        IF NOT EXISTS (SELECT 1 FROM Nivel WHERE IdNivel = @IdNivel)
                                        BEGIN
                                            RAISERROR('El nivel especificado no existe.', 16, 1);
                                            RETURN;
                                        END

                                        -- Restricción: Verificar si tiene al menos una celda ocupada (IdEstadoCelda = 2)
                                        IF EXISTS (
                                            SELECT 1 
                                            FROM Celda 
                                            WHERE IdNivel = @IdNivel AND IdEstadoCelda = 2
                                        )
                                        BEGIN
                                            RAISERROR('No se puede eliminar el nivel porque contiene una o más celdas ocupadas.', 16, 1);
                                            RETURN;
                                        END

                                        -- Limpieza: Eliminar el historial de ocupaciones de las celdas de este nivel
                                        DELETE FROM OcupacionCelda 
                                        WHERE IdCelda IN (SELECT IdCelda FROM Celda WHERE IdNivel = @IdNivel);

                                        -- Limpieza: Eliminar las celdas del nivel
                                        DELETE FROM Celda 
                                        WHERE IdNivel = @IdNivel;

                                        -- Proceder con la eliminación del nivel
                                        DELETE FROM Nivel 
                                        WHERE IdNivel = @IdNivel;

                                        -- Registrar en Auditoria que se eliminó un nivel
                                        INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                        VALUES (@IdUsuarioLogin, N'Eliminó Nivel', GETDATE(), @detalle);

                                        COMMIT TRANSACTION;
                                    END TRY
                                    BEGIN CATCH
                                        IF @@TRANCOUNT > 0
                                            ROLLBACK TRANSACTION;
                    
                                        THROW;
                                    END CATCH;";

                    // Ejecución de la operación
                    bool resultado = await conexionBD.UpdateAsync(strSQL, CommandType.Text, listEliminarNivel);

                    if (resultado)
                    {
                        b = true;
                    }
                    else
                    {
                        // Si la capa de datos devuelve falso pero no lanzó excepción, leemos StrError
                        string mensajeBd = !string.IsNullOrEmpty(conexionBD.StrError)
                            ? conexionBD.StrError
                            : "No se pudo procesar la solicitud";

                        MessageBox.Show(mensajeBd, "Eliminar Nivel", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                // AQUÍ SE CAPTURA EL MENSAJE DE SQL (RAISERROR / THROW)
                // sqlEx.Message contendrá exactamente el texto definido en el procedimiento SQL.
                MessageBox.Show(sqlEx.Message, "Eliminar Nivel", MessageBoxButton.OK, MessageBoxImage.Warning);
                b = false;
            }
            catch (Exception error)
            {
                // Captura para errores generales de la aplicación o conexión
                MessageBox.Show($"Ocurrió un error inesperado:\n{error.Message}", "Error del Sistema", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region listado_niveles
        public async Task<DataSet> EstadoNivelesAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT * FROM EstadoNivel ORDER BY NOMBRE";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener estado nivel.\n{conexionBD.StrError}\n{error.Message}", "Estado Nivel", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region cambiar_estado_nivel

        public async Task<bool> UpdateEstadoNivelAsync(string IdNivel, string Nivel, string IdEstadoNivel, string IdUsuarioLog)
        {
            bool b = false;
            try
            {
                var listNivelUpdate = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdNivel", IdNivel),
                    new KeyValuePair<string, object>("@IdEstadoNivel", IdEstadoNivel),
                    new KeyValuePair<string, object>("@IdUsuarioLog", IdUsuarioLog),
                    new KeyValuePair<string, object>("@Nivel", Nivel),
                };

                if (await conexionBD.Connection())
                {
                    string strSQL = @"begin try
                                    begin transaction
                                    DECLARE @estadoActualNivel INT;
                                    DECLARE @nombre nvarchar(50);
                                    DECLARE @detalle nvarchar(100);
                                    DECLARE @EstadoActual TINYINT;
                                    SELECT @estadoActualNivel = IdEstadoNivel, @nombre = Nombre FROM EstadoNivel WHERE IdEstadoNivel <> @IdEstadoNivel;
                                    
                                    -- Obtener el estado actual del nivel
                                    SELECT @EstadoActual = IdEstadoNivel 
                                    FROM Nivel 
                                    WHERE IdNivel = @IdNivel;

                                    IF @EstadoActual IS NULL
                                    BEGIN
                                        RAISERROR('El nivel especificado no existe.', 16, 1);
                                        ROLLBACK TRANSACTION;
                                        RETURN;
                                    END

                                    -- Si está Disponible (1), lo pasamos a Fuera de servicio (2) y las celdas a No disponible (3)
                                    IF @EstadoActual = 1
                                    BEGIN
                                        UPDATE Nivel
                                        SET IdEstadoNivel = 2
                                        WHERE IdNivel = @IdNivel;

                                        UPDATE Celda
                                        SET IdEstadoCelda = 3 -- 'No disponible'
                                        WHERE IdNivel = @IdNivel;
                                    END
                                    -- Si está Fuera de servicio (2) u otro, lo pasamos a Disponible (1) y las celdas a Libre (1)
                                    ELSE
                                    BEGIN
                                        UPDATE Nivel
                                        SET IdEstadoNivel = 1
                                        WHERE IdNivel = @IdNivel;

                                        UPDATE Celda
                                        SET IdEstadoCelda = 1 -- 'Libre'
                                        WHERE IdNivel = @IdNivel;
                                    END

                                    -- Registra en Auditoria que se actualizo NIVEL
                                    SET @detalle = CONCAT('Cambio estado nivel:', @Nivel, ' Estado: ',@nombre);
                                    INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                    VALUES(@IdUsuarioLog, N'Cambio Estado Nivel', GETDATE(), @detalle);
                                    commit transaction
                                    end try
                                    begin catch
                                    rollback transaction
                                    SET IDENTITY_INSERT Nivel OFF;
                                    DECLARE @numeroDeError INT = ERROR_NUMBER();
                                    THROW  -- Relanza el error
                                    end catch";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, listNivelUpdate))
                    {
                        b = true;
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Error: {error.Message}", "Editar Nivel", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally { await conexionBD.CloseConnection(); }
            return b;
        }
        #endregion

        #region seleccionar_nivel
        public async Task<DataSet> SeleccionarNivelAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT * FROM Nivel ORDER BY NOMBRE";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener estado nivel.\n{conexionBD.StrError}\n{error.Message}", "Estado Nivel", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion
    }
}