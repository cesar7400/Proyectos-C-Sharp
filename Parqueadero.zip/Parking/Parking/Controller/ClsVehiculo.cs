﻿using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;

namespace Parking.Controller
{
    public class Vehiculo
    {
        private readonly ConexionBD conexionBD = new ConexionBD();

        #region Tipos_vehiculos

        public async Task<DataTable> TiposVehiculosAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT IdTipoVehiculo, Nombre, Descripcion FROM TipoVehiculo";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet.Tables[0];
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener tipos de vehículos.\n{conexionBD.StrError}\n{error.Message}", "Tipos de Vehículos", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region Categoria_vehiculos

        public async Task<DataTable> CategoriaVehiculosAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT IdCategoriaVehiculo, Nombre, Descripcion FROM CategoriaVehiculo";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet.Tables[0];
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener categorías de vehículos.\n{conexionBD.StrError}\n{error.Message}", "Categorías de Vehículos", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region vehiculos

        public async Task<DataTable> ListaVehiculosAsync(string Idcliente)
        {
            try
            {
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Idcliente", Idcliente),
                };

                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT 
                                    Vehiculo.Idvehiculo, 
                                    TipoVehiculo.idtipovehiculo AS IdTipoVehiculo, 
                                    CategoriaVehiculo.IdCategoriaVehiculo, 
                                    Vehiculo.Placa, 
                                    TipoVehiculo.Nombre AS TipoVehiculo, 
                                    TipoVehiculo.Descripcion AS DescripcionTipo, 
                                    CategoriaVehiculo.Nombre AS CategoriaVehiculo, 
                                    CategoriaVehiculo.Descripcion AS CategoriaTipo, 
                                    Vehiculo.Activo, 
                                    UltimoPlan.EstadoContrato
                                FROM Vehiculo 
                                INNER JOIN CategoriaVehiculo ON dbo.CategoriaVehiculo.IdCategoriaVehiculo = dbo.Vehiculo.IdCategoriaVehiculo 
                                INNER JOIN TipoVehiculo ON Vehiculo.idtipovehiculo = TipoVehiculo.IdTipoVehiculo 
                                OUTER APPLY (
                                    SELECT TOP 1 EstadoContrato, FechaInicio
                                    FROM VehiculoPlan
                                    WHERE VehiculoPlan.IdVehiculo = Vehiculo.Idvehiculo
                                    ORDER BY FechaInicio DESC
                                ) AS UltimoPlan
                                WHERE Vehiculo.Idcliente = @Idcliente
                                ORDER BY UltimoPlan.FechaInicio ASC;";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet.Tables[0];
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener vehículos.\n{conexionBD.StrError}\n{error.Message}", "Error de Vehículos", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region vehiculo_nuevo
        public async Task<bool> UpsertVehiculoAsync(string idtipovehiculo, string IdCategoriaVehiculo, string Idcliente, string NombreCliente, string Placa, string IdUsuarioLogin)
        {
            bool resultado = false;
            try
            {
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@idtipovehiculo", idtipovehiculo),
                    new KeyValuePair<string, object>("@IdCategoriaVehiculo", IdCategoriaVehiculo),
                    new KeyValuePair<string, object>("@Idcliente", Idcliente),
                    new KeyValuePair<string, object>("@Placa", Placa),
                    new KeyValuePair<string, object>("@NombreCliente", NombreCliente),
                    new KeyValuePair<string, object>("@IdUsuarioLog", IdUsuarioLogin),
                    new KeyValuePair<string, object>("@detalle", $"Agrego Vehiculo placa: '{Placa}', cliente: '{NombreCliente}'"),
                };

                if (await conexionBD.Connection())
                {
                    // Ejecutamos el método insert para rgistrar usuario nuevo
                    var strSQL = @"BEGIN TRY
                                    SET NOCOUNT ON;
                                    BEGIN TRANSACTION;

                                    -- Utilizamos MERGE para comparar la Placa
                                    MERGE dbo.Vehiculo AS target
                                    USING (SELECT @Placa AS Placa, @idtipovehiculo AS id_tipo, @IdCategoriaVehiculo AS id_Categoria, @Idcliente AS Idcliente) AS source
                                    ON (target.Placa = source.Placa)
    
                                    -- Si existe, actualizamos
                                    WHEN MATCHED THEN
                                        UPDATE SET 
                                            idtipovehiculo = source.id_tipo,
                                            IdCategoriaVehiculo = source.id_Categoria,                    
                                            Idcliente = source.Idcliente,
                                            activo = 1 -- Reactivamos si estaba inactivo

                                    -- Si no existe, insertamos
                                    WHEN NOT MATCHED THEN
                                        INSERT (idtipovehiculo, IdCategoriaVehiculo, Idcliente, Placa, activo)
                                        VALUES (source.id_tipo, source.id_Categoria, source.Idcliente, source.Placa, 1);

                                    -- Registramos la auditoría
                                    INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                    VALUES(@IdUsuarioLog, N'Agrego Vehículo', GETDATE(), @detalle);

                                    COMMIT TRANSACTION;
                                    RAISERROR('EXITO: Vehículo con placa %s del cliente %s procesado correctamente.', 16, 1, @Placa, @NombreCliente);
                                END TRY
                                BEGIN CATCH
                                    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
                                    DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
                                    RAISERROR(@ErrorMessage, 16, 1);
                                END CATCH;";
                    // Aquí pegas el bloque SQL anterior en la variable strSQL
                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, parametros))
                    {
                        resultado = true;
                    }
                }
            }
            catch (SqlException ex)
            {
                // SQL Server suele devolver el código de error en la propiedad 'Number'
                if (ex.Number == 2627)
                {
                    // Extraer el valor entre paréntesis usando Regex
                    var match = Regex.Match(ex.Message, @"\(([^)]*)\)");
                    string valorDuplicado = match.Success ? match.Groups[1].Value : "el registro";

                    MessageBox.Show($"La placa '{valorDuplicado}' ya se encuentra registrada.", "Duplicado detectado", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else if (ex.Message.StartsWith("ERROR:"))
                {
                    string mensajeLimpio = ex.Message.Replace("ERROR:", "").Trim();
                    MessageBox.Show(mensajeLimpio, "Validación de Datos", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else if (ex.Message.StartsWith("EXITO:"))
                {
                    string mensajeLimpio = ex.Message.Replace("EXITO:", "").Trim();
                    MessageBox.Show(mensajeLimpio, "Registro Exitoso", MessageBoxButton.OK, MessageBoxImage.Information);
                    resultado = true; // Si es éxito, marcamos como true
                    return resultado; // Retornamos inmediatamente
                }
                else
                {
                    MessageBox.Show($"Error crítico en el servidor de base de datos:\n{ex.Message}", "Error Crítico", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                resultado = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return resultado;
        }
        #endregion

        #region actualizar_vehiculo
        public async Task<bool> ActualizarVehiculoAsync(string idvehiculo, string idtipovehiculo, string idCategoriaVehiculo, string nombreCliente, string placa, string idUsuarioLogin)
        {
            bool b = false;

            try
            {
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Idvehiculo", Convert.ToInt32(idvehiculo)),
                    new KeyValuePair<string, object>("@idtipovehiculo", Convert.ToInt32(idtipovehiculo)),
                    new KeyValuePair<string, object>("@IdCategoriaVehiculo", Convert.ToInt32(idCategoriaVehiculo)),
                    new KeyValuePair<string, object>("@Placa", placa.Trim().ToUpper()),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(idUsuarioLogin)),
                    new KeyValuePair<string, object>("@detalle", $"Modificó Vehículo placa: '{placa}', cliente: '{nombreCliente}'")
                };

                if (await conexionBD.Connection())
                {
                    var strSQL = @"
                SET XACT_ABORT ON;
                
                BEGIN TRY
                    BEGIN TRANSACTION;

                    DECLARE @TipoVehiculoActual INT;
                    DECLARE @CategoriaVehiculoActual INT;
                    DECLARE @PlacaActual VARCHAR(10);

                    /* =====================================================
                       1. OBTENER VEHÍCULO ACTUAL Y BLOQUEAR REGISTRO
                       ===================================================== */
                    SELECT
                        @TipoVehiculoActual = V.idtipovehiculo,
                        @CategoriaVehiculoActual = V.IdCategoriaVehiculo,
                        @PlacaActual = V.Placa
                    FROM Vehiculo V WITH (UPDLOCK, HOLDLOCK)
                    WHERE V.Idvehiculo = @Idvehiculo;

                    IF @TipoVehiculoActual IS NULL
                    BEGIN
                        THROW 55001, 'El vehículo no existe.', 1;
                    END;

                    /* =====================================================
                       2. SI TIPO/CATEGORÍA NO CAMBIAN,
                          NO ES NECESARIO VALIDAR CONTRATACIONES
                       ===================================================== */
                    IF (
                        ISNULL(@TipoVehiculoActual, 0) <> ISNULL(@idtipovehiculo, 0)
                        OR
                        ISNULL(@CategoriaVehiculoActual, 0) <> ISNULL(@IdCategoriaVehiculo, 0)
                    )
                    BEGIN
                        /* =================================================
                           3. VALIDAR MEMBRESÍA/MENSUALIDAD
                              Se bloquea si existe un período:
                              - Vigente hoy
                              - O futuro/programado
                           ================================================= */
                        IF EXISTS
                        (
                            SELECT 1
                            FROM VehiculoPlan VP
                            INNER JOIN PlanTarifa PT ON PT.IdPlanTarifa = VP.IdPlanTarifa
                            INNER JOIN [Plan] P ON P.IdPlan = PT.IdPlan
                            INNER JOIN TipoPlan TP ON TP.IdTipoPlan = P.IdTipoPlan
                            WHERE VP.IdVehiculo = @Idvehiculo
                              AND TP.Nombre IN (N'Membresía', N'Mensualidad')
                              AND VP.EstadoContrato <> 'Cancelada'
                              AND VP.FechaFin >= CAST(GETDATE() AS DATE)
                        )
                        BEGIN
                            THROW 55002, 'No se puede cambiar el tipo o categoría del vehículo porque tiene una membresía o mensualidad vigente o programada.', 1;
                        END;
                    END;

                    /* =====================================================
                       4. ACTUALIZAR VEHÍCULO
                       ===================================================== */
                    UPDATE Vehiculo
                    SET
                        idtipovehiculo = @idtipovehiculo,
                        IdCategoriaVehiculo = @IdCategoriaVehiculo,
                        Placa = @Placa
                    WHERE Idvehiculo = @Idvehiculo;

                    IF @@ROWCOUNT = 0
                    BEGIN
                        THROW 55003, 'No se pudo actualizar el vehículo.', 1;
                    END;

                    /* =====================================================
                       5. AUDITORÍA
                       ===================================================== */
                    INSERT INTO AuditoriaLog
                    (
                        UsuarioID,
                        Accion,
                        Fecha,
                        Detalle
                    )
                    VALUES
                    (
                        @IdUsuarioLogin,
                        N'Modificó Vehículo',
                        GETDATE(),
                        @detalle
                    );

                    COMMIT TRANSACTION;
                END TRY
                BEGIN CATCH
                    IF @@TRANCOUNT > 0
                        ROLLBACK TRANSACTION;

                    THROW;
                END CATCH;
            ";

                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo ejecutar la actualización del vehículo en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string codigoError = string.Empty;
                string mensajeSql = string.Empty;

                if (!string.IsNullOrEmpty(conexionBD.StrError))
                {
                    string[] partes = conexionBD.StrError.Split('-');

                    codigoError = partes[0].Trim();

                    mensajeSql = partes.Length > 1
                        ? string.Join("-", partes.Skip(1)).Trim()
                        : conexionBD.StrError;
                }

                switch (codigoError)
                {
                    case "55001":
                        MessageBox.Show("El vehículo no existe.", "Actualizar Vehículo", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "55002":
                        MessageBox.Show("No se puede cambiar el tipo o categoría del vehículo porque tiene una membresía o mensualidad vigente o programada.\nLa contratación actual conserva la tarifa contratada.", "Actualizar Vehículo", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "55003":
                        MessageBox.Show("No se pudo actualizar el vehículo.", "Actualizar Vehículo", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                    case "2627":
                    case "2601":
                        if (mensajeSql.Contains("UQ_Vehiculo_Placa"))
                        {
                            MessageBox.Show($"La placa '{placa}' ya se encuentra registrada por otro vehículo.", "Placa Duplicada", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                        else
                        {
                            MessageBox.Show("Ya existe otro registro con la misma placa.", "Registro Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                        break;
                    default:
                        if (mensajeSql.Contains("CK_Vehiculo_Placa_Formato"))
                        {
                            MessageBox.Show("El formato de la placa no es válido. Debe cumplir con el formato estándar (ej. ABC 123).", "Formato Inválido", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                        else
                        {
                            string detalleError = !string.IsNullOrEmpty(mensajeSql) ? mensajeSql : error.Message;
                            MessageBox.Show($"Error al actualizar vehículo.\n{detalleError}", "Error del Sistema", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                        break;
                }

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region historial_vehiculo
        public async Task<DataSet> HistorialVeHiculos(string Idcliente)
        {
            try
            {
                // Preparamos los parámetros para un nuevo nivel
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Idcliente", Idcliente)
                };

                if (await conexionBD.Connection())
                {
                    string sql = $@"/* =========================================================
                                       HISTORIAL DE VEHÍCULOS Y PLANES POR CLIENTE
                                       ========================================================= */

                                    SELECT

                                        /* =========================
                                           VEHÍCULO
                                           ========================= */

                                        V.Placa,

                                        TV.Nombre AS TipoVehiculo,

                                        CV.Nombre AS CategoriaVehiculo,

                                        CASE
                                            WHEN V.EsVIP = 1 THEN N'Sí'
                                            ELSE N'No'
                                        END AS EsVIP,

                                        V.Activo AS VehiculoActivo,


                                        /* =========================
                                           PLAN CONTRATADO
                                           ========================= */


                                        P.Nombre AS [Plan],

                                        TP.Nombre AS TipoPlan,

                                        ISNULL(FORMAT(VP.FechaInicio, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + 
                                               UPPER(FORMAT(VP.FechaInicio, 'hh:mm tt', 'en-US')), ''
                                        ) AS FechaInicio,

                                        ISNULL(FORMAT(VP.FechaFin, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + 
                                               UPPER(FORMAT(VP.FechaFin, 'hh:mm tt', 'en-US')), ''
                                        ) AS FechaFin,

                                        CONCAT ('$ ',FORMAT(VP.PrecioContratado, 'N0', 'es-ES')) AS PrecioContratado,

                                        VP.EstadoContrato,

                                        VP.EstadoPago,

                                        ISNULL(FORMAT(VP.FechaPago, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + 
                                               UPPER(FORMAT(VP.FechaPago, 'hh:mm tt', 'en-US')), ''
                                        ) AS FechaPago,

                                        ISNULL(FORMAT(VP.FechaRegistro, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + 
                                               UPPER(FORMAT(VP.FechaRegistro, 'hh:mm tt', 'en-US')), ''
                                        ) AS FechaRegistro


                                    FROM Cliente C

                                    INNER JOIN Vehiculo V
                                        ON V.Idcliente = C.Idcliente

                                    LEFT JOIN TipoVehiculo TV
                                        ON TV.IdTipoVehiculo = V.idtipovehiculo

                                    LEFT JOIN CategoriaVehiculo CV
                                        ON CV.IdCategoriaVehiculo = V.IdCategoriaVehiculo

                                    LEFT JOIN VehiculoPlan VP
                                        ON VP.IdVehiculo = V.Idvehiculo

                                    LEFT JOIN [Plan] P
                                        ON P.IdPlan = VP.IdPlan

                                    LEFT JOIN TipoPlan TP
                                        ON TP.IdTipoPlan = P.IdTipoPlan


                                    WHERE C.Idcliente = @Idcliente


                                    ORDER BY
                                        V.Placa,
                                        VP.FechaInicio DESC,
                                        VP.IdVehiculoPlan DESC;";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener historial.\n{conexionBD.StrError}\n{error.Message}", "Error Historial", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion
    }
}