﻿using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Parking.Controller
{
    public class Celda
    {
        private readonly ConexionBD conexionBD = new ConexionBD();

        #region crear_celdas
        public async Task<bool> CrearCeldas(int IdNivel, string prefijo, string inicio, string fin, string IdUsuarioLogin)
        {
            bool b = false;
            try
            {
                int nInicio = int.Parse(inicio);
                int nFin = int.Parse(fin);
                var listCeldas = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdNivel", IdNivel),
                    new KeyValuePair<string, object>("@Prefijo", prefijo),
                    new KeyValuePair<string, object>("@Inicio", nInicio),
                    new KeyValuePair<string, object>("@Fin", nFin),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", IdUsuarioLogin)
                };

                if (await conexionBD.Connection())
                {
                    string strSQL = $@"DECLARE @i INT;
                                        DECLARE @Codigo NVARCHAR(10);
                                        DECLARE @detalle NVARCHAR(MAX);
                                        DECLARE @Creadas INT = 0;
                                        DECLARE @Existentes INT = 0;
                                        DECLARE @ListaExistentes NVARCHAR(MAX) = N'';

                                        BEGIN TRY
                                            BEGIN TRAN;

                                            IF @Inicio > @Fin
                                            BEGIN
                                                RAISERROR('El número inicial no puede ser mayor que el número final.', 16, 1);
                                                ROLLBACK TRAN;
                                                RETURN;
                                            END

                                            SET @i = @Inicio;

                                            WHILE @i <= @Fin
                                            BEGIN
                                                SET @Codigo = UPPER(LTRIM(RTRIM(@Prefijo))) + CAST(@i AS NVARCHAR(10));

                                                IF EXISTS (
                                                    SELECT 1
                                                    FROM Celda
                                                    WHERE IdNivel = @IdNivel
                                                      AND Codigo = @Codigo
                                                )
                                                BEGIN
                                                    SET @Existentes = @Existentes + 1;

                                                    IF @ListaExistentes = N''
                                                        SET @ListaExistentes = @Codigo;
                                                    ELSE
                                                        SET @ListaExistentes = @ListaExistentes + N', ' + @Codigo;
                                                END
                                                ELSE
                                                BEGIN
                                                    INSERT INTO Celda
                                                    (
                                                        IdNivel,
                                                        Codigo,
                                                        FechaCreacion
                                                    )
                                                    VALUES
                                                    (
                                                        @IdNivel,
                                                        @Codigo,
                                                        GETDATE()
                                                    );

                                                    SET @Creadas = @Creadas + 1;
                                                END

                                                SET @i = @i + 1;
                                            END

                                            IF @Creadas > 0
                                            BEGIN
                                                SET @detalle =
                                                    N'Se crearon ' + CAST(@Creadas AS NVARCHAR(10)) +
                                                    N' celda(s) en el nivel ' + CAST((SELECT Nombre FROM Nivel WHERE IdNivel = @IdNivel) AS NVARCHAR(100)) +
                                                    N' con prefijo ' + @Prefijo +
                                                    N' entre ' + CAST(@Inicio AS NVARCHAR(100)) +
                                                    N' y ' + CAST(@Fin AS NVARCHAR(10)) + N'.';

                                                INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                                VALUES (@IdUsuarioLogin, 'Creo Celda(s)', GETDATE(), @detalle);
                                            END

                                            COMMIT TRAN;

                                            SELECT
                                                @Creadas AS CeldasCreadas,
                                                @Existentes AS CeldasExistentes,
                                                CASE
                                                    WHEN @Existentes = 0 AND @Creadas > 0
                                                        THEN CONCAT('Se crearon ', @Creadas, ' celda(s) correctamente.')
                                                    WHEN @Creadas = 0 AND @Existentes > 0
                                                        THEN CONCAT('No se creó ninguna celda. Ya existían ', @Existentes, ' celda(s).')
                                                    WHEN @Creadas > 0 AND @Existentes > 0
                                                        THEN CONCAT('Se crearon ', @Creadas, ' celda(s) y ', @Existentes, ' ya existían.')
                                                    ELSE
                                                        'No se realizó ninguna creación.'
                                                END AS Mensaje,
                                                @ListaExistentes AS CeldasYaExistian;

                                        END TRY
                                        BEGIN CATCH
                                            IF @@TRANCOUNT > 0
                                                ROLLBACK TRAN;

                                            SELECT
                                                ERROR_NUMBER() AS NumeroError,
                                                ERROR_MESSAGE() AS MensajeError;
                                        END CATCH;";

                    if (await conexionBD.ReadAsync(strSQL, CommandType.Text, listCeldas))
                    {
                        if (conexionBD.SqlDataReader != null && await conexionBD.SqlDataReader.ReadAsync())
                        {
                            // Verificamos si SQL nos devolvió un error (si entró al CATCH)
                            bool tieneError = Enumerable.Range(0, conexionBD.SqlDataReader.FieldCount)
                                                        .Any(i => conexionBD.SqlDataReader.GetName(i) == "MensajeError");

                            if (tieneError)
                            {
                                // Leemos el mensaje de error real de SQL
                                string errorSQL = conexionBD.SqlDataReader["MensajeError"].ToString();
                                MessageBox.Show($"Falló la ejecución en SQL:\n{errorSQL}", "Error de BD", MessageBoxButton.OK, MessageBoxImage.Error);
                                return false; // Detenemos la ejecución
                            }

                            // Si no hubo error, leemos las columnas normalmente
                            string mensaje = conexionBD.SqlDataReader["Mensaje"].ToString();
                            int creadas = Convert.ToInt32(conexionBD.SqlDataReader["CeldasCreadas"]);
                            int existentes = Convert.ToInt32(conexionBD.SqlDataReader["CeldasExistentes"]);

                            // Uso de condicional ternario para el valor DBNull
                            string yaExistian = conexionBD.SqlDataReader["CeldasYaExistian"] == DBNull.Value
                                ? ""
                                : conexionBD.SqlDataReader["CeldasYaExistian"].ToString();

                            string mensajeFinal = $"{mensaje}{Environment.NewLine}Creadas: {creadas}{Environment.NewLine}Existentes: {existentes}";

                            if (!string.IsNullOrWhiteSpace(yaExistian))
                            {
                                mensajeFinal += $"{Environment.NewLine}Ya existían: {yaExistian}";
                            }

                            MessageBox.Show(mensajeFinal, "Resultado", MessageBoxButton.OK, MessageBoxImage.Information);

                            // Asignación directa del booleano (más limpio que el if/else)
                            b = creadas > 0;
                        }
                    }
                    else
                    {
                        // Lanzamos una excepción manualmente usando el error guardado
                        throw new Exception();
                    }
                }
            }
            catch (Exception error)
            {
                // Para cualquier otro error, muestra el mensaje completo
                MessageBox.Show($"Error al guardar celdas.\n{conexionBD.StrError}\n{error.Message}", "Agregar Celdas", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally { await conexionBD.CloseConnection(); }
            return b;
        }
        #endregion

        #region cargar_celdas

        public async Task<DataSet> ObtenerCeldasPorNivelAsync(int idNivel)
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT Celda.IdCelda, Celda.Codigo, Celda.IdNivel, EstadoCelda.Nombre AS Estado, EstadoCelda.IdEstadoCelda
                                    FROM Celda
                                    INNER JOIN EstadoCelda ON EstadoCelda.IdEstadoCelda = Celda.IdEstadoCelda
                                    WHERE (@IdNivel = 0 OR Celda.IdNivel = @IdNivel)
                                    ORDER BY 
                                        LEFT(Celda.Codigo, 1),  -- Primero ordena por la letra (A, H, etc.)
                                        LEN(Celda.Codigo),      -- Luego por el largo (para que A2 vaya antes que A10)
                                        Celda.Codigo;
                                    SELECT Celda.IdCelda, ISNULL(FORMAT(OcupacionCelda.FechaEntrada, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + UPPER(FORMAT(OcupacionCelda.FechaEntrada, 'hh:mm tt', 'en-US')), '') AS FechaEntrada, OcupacionCelda.Estado, 
                                           Vehiculo.Placa, TipoVehiculo.Nombre
                                    FROM   OcupacionCelda INNER JOIN
                                           Vehiculo ON OcupacionCelda.IdVehiculo = Vehiculo.Idvehiculo INNER JOIN
                                           TipoVehiculo ON Vehiculo.idtipovehiculo = TipoVehiculo.idtipovehiculo INNER JOIN
                                           Celda ON OcupacionCelda.IdCelda = Celda.IdCelda INNER JOIN
                                           Nivel ON Celda.IdNivel = dbo.Nivel.IdNivel
                                    WHERE (@IdNivel = 0 OR Celda.IdNivel = @IdNivel)";
                    var parametros = new List<KeyValuePair<string, object>>
                    {
                        new KeyValuePair<string, object>("@IdNivel", idNivel)
                    };
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener celdas.\n{conexionBD.StrError}\n{error.Message}", "Celdas", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region historial_ocupacion_celda
        public async Task<DataSet> HistorialOcupacionesCeldas(int pageNumber, int pageSize)
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"DECLARE @RowsPerPage INT = {pageSize};
                                    DECLARE @PageNumber INT = {pageNumber};

                                    SELECT ISNULL(
                                            FORMAT(OcupacionCelda.FechaEntrada, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + 
                                            UPPER(FORMAT(OcupacionCelda.FechaEntrada, 'hh:mm tt', 'en-US')), 
                                        ''
                                        ) AS FechaEntrada, Celda.Codigo, Nivel.Nombre AS Nivel, Vehiculo.Placa, TipoVehiculo.Nombre, OcupacionCelda.Estado
                                    FROM   Celda INNER JOIN
                                           Nivel ON Celda.IdNivel = Nivel.IdNivel INNER JOIN
                                           OcupacionCelda ON Celda.IdCelda = OcupacionCelda.IdCelda INNER JOIN
                                           Vehiculo ON OcupacionCelda.IdVehiculo = Vehiculo.Idvehiculo INNER JOIN
                                           TipoVehiculo ON Vehiculo.idtipovehiculo = TipoVehiculo.idtipovehiculo
                                    ORDER BY OcupacionCelda.FechaEntrada DESC
                                    OFFSET (@PageNumber - 1) * @RowsPerPage ROWS
                                    FETCH NEXT @RowsPerPage ROWS ONLY;
                                    --cantidad de registros
                                    SELECT COUNT(*) FROM OcupacionCelda;";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al consultar auditoría.\n{conexionBD.StrError}\n{error.Message}", "Auditoría", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region estado_celdas
        public async Task<DataSet> EstadoCeldasAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT * FROM EstadoCelda WHERE Nombre IN('Libre','No disponible') ORDER BY NOMBRE";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener estado celda.\n{conexionBD.StrError}\n{error.Message}", "Estado Celda", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region cambiar_estado_celda

        public async Task<bool> UpdateEstadoCeldaAsync(string IdCelda, string Nombre, string IdEstadoCelda, string Estado, string IdUsuarioLog)
        {
            bool b = false;
            try
            {
                var listNivelUpdate = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdCelda", IdCelda),
                    new KeyValuePair<string, object>("@IdEstadoCelda", IdEstadoCelda),
                    new KeyValuePair<string, object>("@IdUsuarioLog", IdUsuarioLog),
                    new KeyValuePair<string, object>("@detalle", $"Cambio estado Celda: '{Nombre}' estado: {Estado}"),
                };

                if (await conexionBD.Connection())
                {
                    string strSQL = @"begin try
                                    begin transaction
                                    UPDATE Celda 
                                    SET 
                                        IdEstadoCelda = @IdEstadoCelda
                                    WHERE IdCelda = @IdCelda;
                                    -- Registra en Auditoria que se actualizo la CELDA
                                    INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                    VALUES(@IdUsuarioLog, N'Cambio Estado Celda', GETDATE(), @detalle);
                                    commit transaction
                                    end try
                                    begin catch
                                    rollback transaction
                                    SET IDENTITY_INSERT Celda OFF;
                                    DECLARE @numeroDeError INT = ERROR_NUMBER();
                                    THROW  -- Relanza el error
                                    end catch";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, listNivelUpdate))
                    {
                        b = true;
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Error: {error.Message}", "Editar Nivel", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally { await conexionBD.CloseConnection(); }
            return b;
        }
        #endregion
    }
}