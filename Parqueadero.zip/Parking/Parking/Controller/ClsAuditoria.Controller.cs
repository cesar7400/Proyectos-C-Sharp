﻿using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows;

namespace Parking.Controller
{
    public class AuditoriaController
    {
        readonly ConexionBD conexionBD = new ConexionBD();

        #region verAuditoria
        public async Task<DataSet> ObtenerAuditoriaFiltradaAsync(int pageNumber, int pageSize, int? UsuarioID, DateTime? fechaInicio, DateTime? fechaFin)
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"DECLARE @RowsPerPage INT = {pageSize};
                                    DECLARE @PageNumber INT = {pageNumber};

                                    SELECT 
                                        l.IdLog,
                                        ISNULL(u.NombreCompleto, u.Usuario) AS Usuario,
                                        l.Accion,
                                        ISNULL(
                                            FORMAT(l.Fecha, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + 
                                            UPPER(FORMAT(l.Fecha, 'hh:mm tt', 'en-US')), 
                                        ''
                                        ) AS Fecha,
                                        l.Detalle
                                    FROM AuditoriaLog l
                                    LEFT JOIN Usuarios u ON u.UsuarioID = l.UsuarioID
                                    WHERE (@UsuarioID IS NULL OR l.UsuarioID = @UsuarioID)
                                      AND (@FechaInicio IS NULL OR l.Fecha >= @FechaInicio)
                                      AND (@FechaFin IS NULL OR l.Fecha < DATEADD(DAY, 1, @FechaFin))
                                    ORDER BY l.Fecha DESC
                                    OFFSET (@PageNumber - 1) * @RowsPerPage ROWS
                                    FETCH NEXT @RowsPerPage ROWS ONLY;

                                    -- Totales
                                    SELECT  COUNT(*) FROM AuditoriaLog l
                                    LEFT JOIN Usuarios u ON u.UsuarioID = l.UsuarioID
                                    WHERE (@UsuarioID IS NULL OR l.UsuarioID = @UsuarioID)
                                      AND (@FechaInicio IS NULL OR l.Fecha >= @FechaInicio)
                                      AND (@FechaFin IS NULL OR l.Fecha < DATEADD(DAY, 1, @FechaFin));
                
                                    SELECT COUNT(*) FROM AuditoriaLog l
                                    LEFT JOIN Usuarios u ON u.UsuarioID = l.UsuarioID";
                    // Preparamos la lista de parámetros para tu método dataSet_
                    var parametros = new List<KeyValuePair<string, object>>
                    {
                        new KeyValuePair<string, object>("@UsuarioID", (object)UsuarioID ?? DBNull.Value),
                        new KeyValuePair<string, object>("@FechaInicio", (object)fechaInicio ?? DBNull.Value),
                        new KeyValuePair<string, object>("@FechaFin", (object)fechaFin ?? DBNull.Value)
                    };
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al consultar auditoría.\n{conexionBD.StrError}\n{error.Message}", "Auditoría", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region eliminar_auditoria
        public async Task<bool> DeleteAuditoriaAsync(string UsuarioID)
        {
            bool b = false;
            try
            {

                if (await conexionBD.Connection())
                {
                    string strSQL = $@" begin try
                                       begin transaction
                                       -- Elimina toda la auditoría
                                       TRUNCATE TABLE AuditoriaLog;
                                       --reinicia secuencia
                                       ALTER SEQUENCE SecuenciaLog
                                       RESTART WITH 1;
                                       -- Registra en Auditoria que se agregó un usuario
                                       INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                       VALUES({UsuarioID}, N'Elimino Auditoría', GETDATE(), 'Elimino Auditoría');
                                       commit transaction
                                       end try
                                       begin catch
                                       rollback transaction
                                       DECLARE @numeroDeError INT = ERROR_NUMBER();
                                       THROW  -- Relanza el error
                                       end catch";

                    if (await conexionBD.DeleteAsync(strSQL, CommandType.Text))
                    {
                        b = true;
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Error al eliminar auditoría.\n{conexionBD.StrError}\n{error.Message}", "Auditoría", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally { await conexionBD.CloseConnection(); }
            return b;
        }
        #endregion
    }
}