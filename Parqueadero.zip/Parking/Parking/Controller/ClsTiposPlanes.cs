﻿using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Parking.Controller
{
    public class TiposPlanes
    {
        private readonly ConexionBD conexionBD = new ConexionBD();

        /*resumen: Planes, tipos´planes(membresía, mensualidad, tiempo por demanda), total tarifas*/
        #region listado_resumen_planes
        public async Task<DataSet> ResumenTrifasAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT 
                                (SELECT COUNT(*) FROM dbo.TipoPlan) AS TotalTipoPlanes,
                                (SELECT COUNT(IdTipoPlan) FROM dbo.[Plan]) AS TotalPlanes,
                                (SELECT COUNT(pt.IdPlanTarifa) FROM dbo.PlanTarifa pt INNER JOIN dbo.[Plan] p ON pt.IdPlan = p.IdPlan INNER JOIN dbo.TipoPlan tp ON p.IdTipoPlan = tp.IdTipoPlan WHERE tp.Nombre = 'Membresía') AS TotalTarifaMembresia,
                                (SELECT COUNT(pt.IdPlanTarifa) FROM dbo.PlanTarifa pt INNER JOIN dbo.[Plan] p ON pt.IdPlan = p.IdPlan INNER JOIN dbo.TipoPlan tp ON p.IdTipoPlan = tp.IdTipoPlan WHERE tp.Nombre = 'Mensualidad') AS TotalTarifaMensualidad,
                                (SELECT COUNT(pt.IdPlanTarifa) FROM dbo.PlanTarifa pt INNER JOIN dbo.[Plan] p ON pt.IdPlan = p.IdPlan INNER JOIN dbo.TipoPlan tp ON p.IdTipoPlan = tp.IdTipoPlan WHERE tp.Nombre = 'Tiempo por demanda') AS TotalTarifaTiempoPorDemanda,
                                (SELECT COUNT(*) FROM dbo.PlanTarifa) AS TotalPlanTarifa;";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al resumen obtener planes.\n{conexionBD.StrError}\n{error.Message}", "Planes", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        /*Planes (membresía, mensualidad, tiempo por demanda)*/
        #region listado_tipos_planes
        public async Task<DataSet> PlanesTiposTarifaAsync(string IdTipoPlan, int pageNumber, int pageSize)
        {
            try
            {
                // Preparamos los parámetros para un nuevo nivel
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdTipoPlan", IdTipoPlan)
                };

                if (await conexionBD.Connection())
                {
                    string sql = $@"DECLARE @RowsPerPage INT = {pageSize};
                                    DECLARE @PageNumber INT = {pageNumber};
                                    
                                    IF @IdTipoPlan = 0
                                    BEGIN
                                        SELECT 
                                            [Plan].IdTipoPlan,
                                            [Plan].IdPlan,
                                            [Plan].Nombre,
                                            TipoPlan.Nombre AS NombreTipoPlan,
                                            [Plan].Descripcion,
                                            [Plan].Estado,
                                            [Plan].IdTipoVehiculo,
                                            [Plan].IdCategoriaVehiculo,
                                            CategoriaVehiculo.Nombre AS CategoriaVehiculo,
                                            CategoriaVehiculo.Descripcion AS CategoriaVehiculoDescripcion,
                                            TipoVehiculo.Nombre AS TipoVehiculo,
                                            TipoVehiculo.Descripcion AS TipoVehiculoDescripcion
                                        FROM [Plan]
                                        LEFT JOIN CategoriaVehiculo ON CategoriaVehiculo.IdCategoriaVehiculo = [Plan].IdCategoriaVehiculo
                                        LEFT JOIN TipoVehiculo ON [Plan].IdTipoVehiculo = TipoVehiculo.IdTipoVehiculo
                                        LEFT JOIN TipoPlan ON [Plan].IdTipoPlan = TipoPlan.IdTipoPlan
                                        ORDER BY [Plan].Nombre
                                        OFFSET (@PageNumber - 1) * @RowsPerPage ROWS
                                        FETCH NEXT @RowsPerPage ROWS ONLY;
                                    END
                                    ELSE
                                    BEGIN
                                        SELECT 
                                            [Plan].IdTipoPlan,
                                            [Plan].IdPlan,
                                            [Plan].Nombre,
                                            TipoPlan.Nombre AS NombreTipoPlan,
                                            [Plan].Descripcion,
                                            [Plan].Estado,
                                            [Plan].IdTipoVehiculo,
                                            [Plan].IdCategoriaVehiculo,
                                            CategoriaVehiculo.Nombre AS CategoriaVehiculo,
                                            CategoriaVehiculo.Descripcion AS CategoriaVehiculoDescripcion,
                                            TipoVehiculo.Nombre AS TipoVehiculo,
                                            TipoVehiculo.Descripcion AS TipoVehiculoDescripcion
                                        FROM [Plan]
                                        LEFT JOIN CategoriaVehiculo ON CategoriaVehiculo.IdCategoriaVehiculo = [Plan].IdCategoriaVehiculo
                                        LEFT JOIN TipoVehiculo ON [Plan].IdTipoVehiculo = TipoVehiculo.IdTipoVehiculo
                                        LEFT JOIN TipoPlan ON [Plan].IdTipoPlan = TipoPlan.IdTipoPlan
                                        WHERE TipoPlan.IdTipoPlan = @IdTipoPlan
                                        ORDER BY dbo.[Plan].Nombre
                                        OFFSET (@PageNumber - 1) * @RowsPerPage ROWS
                                        FETCH NEXT @RowsPerPage ROWS ONLY;
                                    END

                                    SELECT COUNT(*)
                                    FROM [Plan]
                                    INNER JOIN TipoPlan
                                    ON TipoPlan.IdTipoPlan = [Plan].IdTipoPlan";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener planes.\n{conexionBD.StrError}\n{error.Message}", "Planes", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region nuevo_tipo_plan
        public async Task<bool> NuevoTipoPlan(string IdTipoPlan, string Nombre, string TipoPlan, string Descripcion, string Estado, string DescripcionTipoVehiculo, string DescripcionCategoriaVehiculo, string TipoVehiculo, string Categoria, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdTipoPlan", IdTipoPlan),
                    new KeyValuePair<string, object>("@Nombre", Nombre),
                    new KeyValuePair<string, object>("@Descripcion", Descripcion),
                    new KeyValuePair<string, object>("@Estado", Estado == "Activo" ? 1 : 0),

                    new KeyValuePair<string, object>("@TipoVehiculo", TipoVehiculo),
                    new KeyValuePair<string, object>("@Categoria", Categoria),
                    new KeyValuePair<string, object>("@DescripcionTipoVehiculo", DescripcionTipoVehiculo),
                    new KeyValuePair<string, object>("@DescripcionCategoria", DescripcionCategoriaVehiculo),

                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin)),
                    new KeyValuePair<string, object>("@Detalle", $"Agregó plan: {Nombre}, tipo de plan: {TipoPlan}")
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"
                        SET XACT_ABORT ON;

                        BEGIN TRY
                            BEGIN TRANSACTION;
                            DECLARE @IdTipoVehiculo INT;
                            DECLARE @IdCategoriaVehiculo INT;
                            DECLARE @IdPlan INT;
                            
                            /* =====================================================
                               1. VERIFICAR / INSERTAR TIPO DE VEHÍCULO
                             ===================================================== */
                            IF NOT EXISTS (SELECT 1 FROM TipoVehiculo WHERE Nombre = @TipoVehiculo)
                            BEGIN
                                INSERT INTO TipoVehiculo (Nombre, Descripcion, Fecha_creacion)
                                VALUES (@TipoVehiculo, @DescripcionTipoVehiculo, GETDATE());
    
                                SET @IdTipoVehiculo = SCOPE_IDENTITY();
                            END
                            ELSE
                            BEGIN
                                SELECT @IdTipoVehiculo = IdTipoVehiculo FROM TipoVehiculo WHERE Nombre = @TipoVehiculo;
                            END

                            /* =====================================================
                               2.1 VERIFICAR / INSERTAR CATEGORÍA
                               ===================================================== */
                            IF NOT EXISTS (SELECT 1 FROM CategoriaVehiculo WHERE Nombre = @Categoria)
                            BEGIN
                                INSERT INTO CategoriaVehiculo (Nombre, Descripcion, Fecha_creacion)
                                VALUES (@Categoria, @DescripcionCategoria, GETDATE());
    
                                SET @IdCategoriaVehiculo = SCOPE_IDENTITY();
                            END
                            ELSE
                            BEGIN
                                SELECT @IdCategoriaVehiculo = IdCategoriaVehiculo FROM CategoriaVehiculo WHERE Nombre = @Categoria;
                            END
                            
                            /* =====================================================
                               2. INSERTAR TIPO DE PLAN
                               ===================================================== */
                            INSERT INTO [Plan]
                            (
                                IdTipoPlan,
                                IdTipoVehiculo,
                                IdCategoriaVehiculo,
                                Nombre,
                                Descripcion,
                                FechaInicioVigencia,
                                FechaFinVigencia,
                                Estado
                            )
                            VALUES
                            (
                                @IdTipoPlan,
                                @IdTipoVehiculo,
                                @IdCategoriaVehiculo,
                                @Nombre,
                                @Descripcion,
                                CAST(GETDATE() AS DATE),
                                NULL,
                                @Estado
                            );
                            
                            --SET @IdPlan = SCOPE_IDENTITY();
                            /*
                            /* =====================================================
                               3. INSERTAR TARIFA
                               ===================================================== */
                            INSERT INTO PlanTarifa
                            (
                                IdPlan,
                                FechaInicioVigencia,
                                Estado
                            )
                            VALUES
                            (
                                @IdPlan,
                                CAST(GETDATE() AS DATE),
                                @Estado
                            );*/
                            /* =====================================================
                               4. AUDITORÍA
                               ===================================================== */
                            INSERT INTO AuditoriaLog
                            (
                                UsuarioId,
                                Accion,
                                Fecha,
                                Detalle
                            )
                            VALUES
                            (
                                @IdUsuarioLogin,
                                N'Nuevo Plan',
                                GETDATE(),
                                @Detalle
                            );

                            COMMIT TRANSACTION;
                        END TRY
                        BEGIN CATCH
                            IF @@TRANCOUNT > 0
                                ROLLBACK TRANSACTION;

                            THROW;
                        END CATCH;";

                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo registrar el tipo plan en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');
                string codigoError = partes.Length > 0 ? partes[0].Trim() : "";
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                if (codigoError == "2627")
                {
                    MessageBox.Show($"El tipo de plan '{Nombre}' ya se encuentra registrado.", "Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else if (codigoError == "547")
                {
                    MessageBox.Show("No se pudo guardar el tipo plan porque uno de los datos relacionados no existe o viola una regla de validación.", "Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    MessageBox.Show($"Error al guardar el tipo de plan.\n\n{mensaje}\n\n{error.Message}", "Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Error);
                }

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region Actualizar_tipo_plan
        public async Task<bool> ActualizarTipoPlan(string IdPlan, string Nombre, string TipoPlan, string Descripcion, string Estado, string DescripcionTipoVehiculo, string DescripcionCategoriaVehiculo, string TipoVehiculo, string Categoria, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdPlan", IdPlan),
                    new KeyValuePair<string, object>("@Nombre", Nombre),
                    new KeyValuePair<string, object>("@Descripcion", Descripcion),
                    new KeyValuePair<string, object>("@Estado", Estado == "Activo" ? 1 : 0),

                    new KeyValuePair<string, object>("@TipoVehiculo", TipoVehiculo),
                    new KeyValuePair<string, object>("@Categoria", Categoria),
                    new KeyValuePair<string, object>("@DescripcionTipoVehiculo", DescripcionTipoVehiculo),
                    new KeyValuePair<string, object>("@DescripcionCategoria", DescripcionCategoriaVehiculo),

                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin)),
                    new KeyValuePair<string, object>("@Detalle", $"Actualizo plan {Nombre}, tipo de plan: {TipoPlan}")
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"
                        SET XACT_ABORT ON;

                        BEGIN TRY
                            DECLARE @IdTipoVehiculo INT;
                            DECLARE @IdCategoriaVehiculo INT;

                            BEGIN TRANSACTION;
                            
                            /* =====================================================                       
                               1. VERIFICAR / INSERTAR / ACTUALIZAR TIPO DE VEHÍCULO                       
                               ===================================================== */                    
                            IF NOT EXISTS (SELECT 1 FROM TipoVehiculo WHERE Nombre = @TipoVehiculo)                    
                            BEGIN                        
                                INSERT INTO TipoVehiculo (Nombre, Descripcion, Fecha_creacion)                        
                                VALUES (@TipoVehiculo, @DescripcionTipoVehiculo, GETDATE());                            
                                SET @IdTipoVehiculo = SCOPE_IDENTITY();                    
                            END                    
                            ELSE                    
                            BEGIN                        
                                SELECT @IdTipoVehiculo = IdTipoVehiculo FROM TipoVehiculo WHERE Nombre = @TipoVehiculo;                        
                                UPDATE TipoVehiculo SET Descripcion = @DescripcionTipoVehiculo WHERE IdTipoVehiculo = @IdTipoVehiculo;                    
                            END                    

                            /* =====================================================                       
                               1.1 VERIFICAR / INSERTAR / ACTUALIZAR CATEGORÍA                       
                               ===================================================== */                    
                            IF NOT EXISTS (SELECT 1 FROM CategoriaVehiculo WHERE Nombre = @Categoria)                    
                            BEGIN                        
                                INSERT INTO CategoriaVehiculo (Nombre, Descripcion, Fecha_creacion)                        
                                VALUES (@Categoria, @DescripcionCategoria, GETDATE());                            
                                SET @IdCategoriaVehiculo = SCOPE_IDENTITY();                    
                            END                    
                            ELSE                    
                            BEGIN                        
                                SELECT @IdCategoriaVehiculo = IdCategoriaVehiculo FROM CategoriaVehiculo WHERE Nombre = @Categoria;                        
                                UPDATE CategoriaVehiculo SET Descripcion = @DescripcionCategoria WHERE IdCategoriaVehiculo = @IdCategoriaVehiculo;                    
                            END

                            /* =====================================================
                               1.2 VERIFICAR / INSERTAR CATEGORÍA
                               ===================================================== */
                            IF NOT EXISTS (SELECT 1 FROM CategoriaVehiculo WHERE Nombre = @Categoria)
                            BEGIN
                                INSERT INTO CategoriaVehiculo (Nombre, Descripcion, Fecha_creacion)
                                VALUES (@Categoria, @DescripcionCategoria, GETDATE());
    
                                SET @IdCategoriaVehiculo = SCOPE_IDENTITY();
                            END
                            ELSE
                            BEGIN
                                SELECT @IdCategoriaVehiculo = IdCategoriaVehiculo FROM CategoriaVehiculo WHERE Nombre = @Categoria;
                            END

                           
                            /* =====================================================
                               2. ACTUALIZAR TIPO DE PLAN
                               ===================================================== */
                            UPDATE [Plan] SET IdTipoVehiculo = @IdTipoVehiculo, IdCategoriaVehiculo = @IdCategoriaVehiculo, Nombre = @Nombre, Descripcion = @Descripcion, Estado = @Estado WHERE IdPlan = @IdPlan;

                            /* =====================================================
                               3. AUDITORÍA
                               ===================================================== */
                            INSERT INTO AuditoriaLog
                            (
                                UsuarioId,
                                Accion,
                                Fecha,
                                Detalle
                            )
                            VALUES
                            (
                                @IdUsuarioLogin,
                                N'Actualizo Plan',
                                GETDATE(),
                                @Detalle
                            );

                            COMMIT TRANSACTION;
                        END TRY
                        BEGIN CATCH
                            IF @@TRANCOUNT > 0
                                ROLLBACK TRANSACTION;

                            THROW;
                        END CATCH;";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo actualizar el tipo plan en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');
                string codigoError = partes.Length > 0 ? partes[0].Trim() : "";
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                if (codigoError == "2627")
                {
                    MessageBox.Show($"El tipo de plan '{Nombre}' ya se encuentra registrado.", "Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else if (codigoError == "547")
                {
                    MessageBox.Show("No se pudo guardar el tipo plan porque uno de los datos relacionados no existe o viola una regla de validación.", "Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    MessageBox.Show($"Error al guardar el tipo de plan.\n\n{mensaje}\n\n{error.Message}", "Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Error);
                }

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region Eliminar_tipo_plan
        public async Task<bool> EliminarTipoPlan(string IdPlan, string Nombre, string TipoPlan, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdPlan", IdPlan),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin)),
                    new KeyValuePair<string, object>("@Detalle", $"Eliminó plan {Nombre} de tipo de plan:{TipoPlan}")
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"SET XACT_ABORT ON;
                                BEGIN TRY
                                    BEGIN TRANSACTION;

                                    /* =====================================================
                                       0. VALIDAR SI LAS TARIFAS TIENEN INFORMACIÓN
                                       ===================================================== */
                                    IF EXISTS (
                                        SELECT 1 
                                        FROM PlanTarifa 
                                        WHERE IdPlan = @IdPlan 
                                          AND (
                                               ValorTarifa IS NOT NULL 
                                            OR ValorMinuto IS NOT NULL 
                                            OR ValorHora IS NOT NULL 
                                            OR Valor12Horas IS NOT NULL 
                                            OR Valor24Horas IS NOT NULL
                                          )
                                    )
                                    BEGIN
                                        RAISERROR('No se puede eliminar el plan porque las tarifas asociadas contienen información registrada.', 16, 1);
                                    END

                                    /* =====================================================
                                       1. ELIMINAR DEPENDENCIAS Y EL PLAN
                                       ===================================================== */

                                    -- Eliminar los días asociados a los horarios del plan
                                    DELETE PHD     
                                    FROM PlanHorarioDia PHD
                                    INNER JOIN PlanHorario PH ON PHD.IdPlanHorario = PH.IdPlanHorario
                                    WHERE PH.IdPlan = @IdPlan;

                                    -- Eliminar los horarios del plan
                                    DELETE FROM PlanHorario     
                                    WHERE IdPlan = @IdPlan;

                                    -- Eliminar las reglas de cobro del plan
                                    DELETE FROM PlanReglaCobro     
                                    WHERE IdPlan = @IdPlan;

                                    -- Eliminar las tarifas del plan (permitido si están en NULL)
                                    DELETE FROM PlanTarifa     
                                    WHERE IdPlan = @IdPlan;

                                    -- Finalmente, eliminar el registro principal de la tabla Plan
                                    DELETE FROM [Plan]     
                                    WHERE IdPlan = @IdPlan;                                

                                    /* =====================================================
                                       2. AUDITORÍA
                                       ===================================================== */
                                    INSERT INTO AuditoriaLog
                                    (
                                        UsuarioId,
                                        Accion,
                                        Fecha,
                                        Detalle
                                    )
                                    VALUES
                                    (
                                        @IdUsuarioLogin,
                                        N'Eliminó Plan',
                                        GETDATE(),
                                        @Detalle
                                    );

                                    COMMIT TRANSACTION;
                                END TRY
                                BEGIN CATCH
                                    IF @@TRANCOUNT > 0
                                        ROLLBACK TRANSACTION;
                                    THROW;
                                END CATCH;";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo eliminar el tipo plan en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                MessageBox.Show($"Error al eliminar tipo de plan.\n{error.Message}", "EError Eliminiar Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Error);

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region tipo_de_planes
        public async Task<DataTable> TiposPlanesAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT * FROM TipoPlan ORDER BY IdTipoPlan";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet.Tables[0];
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener tipo de planes.\n{conexionBD.StrError}\n{error.Message}", "Tipos de Planes", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion
        
        /*Tiempo por demanda*/
        #region listado_Tiempo_por_demanda
        public async Task<DataSet> ListadoTiempoPorDemandaAsync(string IdPlan, int pageNumber, int pageSize)
        {
            try
            {
                // Preparamos los parámetros para un nuevo nivel
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdPlan", IdPlan == "" ? (object)DBNull.Value : (object)IdPlan)
                };

                if (await conexionBD.Connection())
                {
                    string sql = $@"DECLARE @RowsPerPage INT = {pageSize};
                                    DECLARE @PageNumber INT = {pageNumber};
                                WITH RankedTarifas AS (
                                        SELECT 
                                            IdPlan, IdPlanTarifa, --IdTipoVehiculo, IdCategoriaVehiculo,
                                            ValorMinuto, ValorHora, Valor12Horas, Valor24Horas,
                                            FechaInicioVigencia, FechaFinVigencia, Estado AS EstadoPlanTarifa,
                                            ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanTarifa) AS RowIdx
                                        FROM PlanTarifa
                                    ),
                                    RankedHorarios AS (
                                        SELECT 
                                            IdPlan, IdPlanHorario, Nombre AS NombrePlanHorario,
                                            HoraInicio, HoraFin, CruzaMedianoche, Estado AS EstadoPlanHorario,
                                            ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanHorario) AS RowIdx
                                        FROM PlanHorario
                                    ),
                                    RankedReglas AS (
                                        SELECT 
                                            IdPlan, IdPlanReglaCobro, UnidadCobro, MinutosFraccion, MinutosGracia,
                                            ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanReglaCobro) AS RowIdx
                                        FROM PlanReglaCobro
                                    ),
                                    AllIndices AS (
                                        SELECT IdPlan, RowIdx FROM RankedTarifas
                                        UNION
                                        SELECT IdPlan, RowIdx FROM RankedHorarios
                                        UNION
                                        SELECT IdPlan, RowIdx FROM RankedReglas
                                    ),
                                    CombinedPlanChildren AS (
                                        SELECT 
                                            AI.IdPlan,
                                            AI.RowIdx,
                                            T.IdPlanTarifa, --T.IdTipoVehiculo, T.IdCategoriaVehiculo,
                                            T.ValorMinuto, T.ValorHora, T.Valor12Horas, T.Valor24Horas,
                                            T.FechaInicioVigencia, T.FechaFinVigencia, T.EstadoPlanTarifa,
                                            H.IdPlanHorario, H.NombrePlanHorario, H.HoraInicio, H.HoraFin, 
                                            H.CruzaMedianoche, H.EstadoPlanHorario,
                                            R.IdPlanReglaCobro, R.UnidadCobro, R.MinutosFraccion, R.MinutosGracia
                                        FROM AllIndices AI
                                        LEFT JOIN RankedTarifas T ON AI.IdPlan = T.IdPlan AND AI.RowIdx = T.RowIdx
                                        LEFT JOIN RankedHorarios H ON AI.IdPlan = H.IdPlan AND AI.RowIdx = H.RowIdx
                                        LEFT JOIN RankedReglas R ON AI.IdPlan = R.IdPlan AND AI.RowIdx = R.RowIdx
                                    )
                                    SELECT 
                                        [Plan].IdPlan,
                                        [Plan].IdTipoPlan,
                                        [Plan].Nombre AS NombrePlan,
                                        [Plan].Descripcion AS DescripcionPlan,
                                        [Plan].Estado AS EstadoPlan,
                                        TipoPlan.IdTipoPlan AS IdTipoPlanTp,
                                        TipoPlan.Nombre AS NombreTipoPlan,
                                        TipoPlan.Descripcion AS DescripcionTipoPlan,
                                        TipoPlan.Estado AS EstadoTipoPlan,
                                        Cp.IdPlanTarifa,
                                        Cp.IdPlan AS IdPlanPlanTarifa,
                                        [Plan].IdTipoVehiculo,
                                        [Plan].IdCategoriaVehiculo,
                                        CONCAT ('$ ',FORMAT(Cp.ValorMinuto, 'N0', 'es-ES')) AS ValorMinuto,
                                        CONCAT ('$ ',FORMAT(Cp.ValorHora, 'N0', 'es-ES')) AS ValorHora,
                                        CONCAT ('$ ',FORMAT(Cp.Valor12Horas, 'N0', 'es-ES')) AS Valor12Horas,
                                        CONCAT ('$ ',FORMAT(Cp.Valor24Horas, 'N0', 'es-ES')) AS Valor24Horas,
                                        Cp.FechaInicioVigencia,
                                        Cp.FechaFinVigencia,
                                        Cp.EstadoPlanTarifa,
                                        CategoriaVehiculo.IdCategoriaVehiculo AS IdCatVehiculo,
                                        CategoriaVehiculo.Nombre AS NombreCategoriaVehiculo,
                                        CategoriaVehiculo.Descripcion AS DescripcionCategoriaVehiculo,
                                        TipoVehiculo.IdTipoVehiculo AS IdTipoVehiculoTv,
                                        TipoVehiculo.Nombre AS NombreTipoVehiculo,
                                        TipoVehiculo.Descripcion AS DescripcionTipoVehiculo,
                                        Cp.IdPlanHorario,
                                        Cp.IdPlan AS IdPlanPlanHorario,
                                        Cp.NombrePlanHorario,
                                        Cp.HoraInicio,
                                        Cp.HoraFin,
                                        Cp.CruzaMedianoche,
                                        Cp.EstadoPlanHorario,
                                        Cp.IdPlanReglaCobro,
                                        Cp.IdPlan AS IdPlanPlanReglaCobro,
                                        Cp.UnidadCobro,
                                        Cp.MinutosFraccion,
                                        Cp.MinutosGracia,
                                        Dias.DiasSemana
                                    FROM CombinedPlanChildren Cp
                                    INNER JOIN [Plan] ON [Plan].IdPlan = Cp.IdPlan
                                    INNER JOIN TipoPlan ON TipoPlan.IdTipoPlan = [Plan].IdTipoPlan 
                                    LEFT JOIN CategoriaVehiculo ON [Plan].IdCategoriaVehiculo = CategoriaVehiculo.IdCategoriaVehiculo 
                                    LEFT JOIN TipoVehiculo ON [Plan].IdTipoVehiculo = TipoVehiculo.IdTipoVehiculo 
                                    OUTER APPLY (
                                        SELECT STRING_AGG(
                                            CASE PHD.DiaSemana        
                                                WHEN 1 THEN N'Lunes'        
                                                WHEN 2 THEN N'Martes'        
                                                WHEN 3 THEN N'Miércoles'        
                                                WHEN 4 THEN N'Jueves'        
                                                WHEN 5 THEN N'Viernes'        
                                                WHEN 6 THEN N'Sábado'        
                                                WHEN 7 THEN N'Domingo'    
                                            END,    
                                            N', '
                                        ) AS DiasSemana 
                                        FROM PlanHorarioDia PHD
                                        WHERE PHD.IdPlanHorario = Cp.IdPlanHorario
                                    ) Dias
                                WHERE TipoPlan.Nombre = N'Tiempo por demanda' --AND [Plan].IdPlan = @IdPlan
                                AND (@IdPlan IS NULL OR [Plan].IdPlan = @IdPlan) AND Dias.DiasSemana is not null
                                ORDER BY [Plan].IdPlan, Cp.RowIdx
                        
                            OFFSET (@PageNumber - 1) * @RowsPerPage ROWS
                            FETCH NEXT @RowsPerPage ROWS ONLY;
                            WITH RankedTarifas AS (
                                SELECT 
                                    IdPlan, IdPlanTarifa, --IdTipoVehiculo, IdCategoriaVehiculo,
                                    ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanTarifa) AS RowIdx
                                FROM PlanTarifa
                            ),
                            RankedHorarios AS (
                                SELECT 
                                    IdPlan, IdPlanHorario,
                                    ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanHorario) AS RowIdx
                                FROM PlanHorario
                            ),
                            CombinedPlanChildren AS (
                                SELECT 
                                    COALESCE(T.IdPlan, H.IdPlan) AS IdPlan,
                                    COALESCE(T.RowIdx, H.RowIdx) AS RowIdx,
                                    --T.IdPlanTarifa, T.IdTipoVehiculo, T.IdCategoriaVehiculo,
                                    H.IdPlanHorario
                                FROM RankedTarifas T
                                FULL OUTER JOIN RankedHorarios H ON T.IdPlan = H.IdPlan AND T.RowIdx = H.RowIdx
                            )
                            SELECT COUNT(*) AS TotalRegistros
                            FROM CombinedPlanChildren Cp
                            INNER JOIN [Plan] ON [Plan].IdPlan = Cp.IdPlan
                            INNER JOIN TipoPlan ON TipoPlan.IdTipoPlan = [Plan].IdTipoPlan 
                            LEFT JOIN CategoriaVehiculo ON [Plan].IdCategoriaVehiculo = CategoriaVehiculo.IdCategoriaVehiculo 
                            LEFT JOIN TipoVehiculo ON [Plan].IdTipoVehiculo = TipoVehiculo.IdTipoVehiculo 
                            OUTER APPLY (
                                SELECT TOP 1 * FROM PlanReglaCobro WHERE PlanReglaCobro.IdPlan = [Plan].IdPlan
                            ) Prc
                            WHERE TipoPlan.Nombre = N'Tiempo por demanda' AND [Plan].IdPlan = @IdPlan AND IdPlanHorario is not null;
                            SELECT GETDATE() AS FechaHoraActual;";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener planes.\n{conexionBD.StrError}\n{error.Message}", "Planes", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region plan_nuevo_tiempo_demanda
        public async Task<bool> NuevoPlanTiempoDemanda(string Plan,
                                string IdPlan, string Estado, string NombreHorario,
                                TimeSpan HoraInicio, TimeSpan HoraFin, bool CruzaMedianoche,
                                string Dias,
                                string ValorMinuto, string ValorHora, string Valor12Horas, string Valor24Horas, string UnidadCobro, string MinutosFraccion, string MinutosGracia, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdPlan", Convert.ToInt32(IdPlan)),
                    new KeyValuePair<string, object>("@Estado", Estado == "Activo" ? 1 : 0),
                    new KeyValuePair<string, object>("@NombreHorario", NombreHorario),
                    new KeyValuePair<string, object>("@HoraInicio", HoraInicio),
                    new KeyValuePair<string, object>("@HoraFin", HoraFin),
                    new KeyValuePair<string, object>("@CruzaMedianoche", CruzaMedianoche ? 1 : 0),
                    new KeyValuePair<string, object>("@EstadoPlanHorario", Estado == "Activo" ? 1 : 0),
                    new KeyValuePair<string, object>("@Dias", Dias),
                    new KeyValuePair<string, object>("@ValorMinuto", string.IsNullOrWhiteSpace(ValorMinuto) ? 0 : Convert.ToDecimal(ValorMinuto)),
                    new KeyValuePair<string, object>("@ValorHora", string.IsNullOrWhiteSpace(ValorHora) ? 0 : Convert.ToDecimal(ValorHora)),
                    new KeyValuePair<string, object>("@Valor12Horas", string.IsNullOrWhiteSpace(Valor12Horas) ? 0 : Convert.ToDecimal(Valor12Horas)),
                    new KeyValuePair<string, object>("@Valor24Horas", string.IsNullOrWhiteSpace(Valor24Horas) ? 0 : Convert.ToDecimal(Valor24Horas)),
                    new KeyValuePair<string, object>("@UnidadCobro", UnidadCobro),
                    new KeyValuePair<string, object>("@MinutosFraccion", string.IsNullOrWhiteSpace(MinutosFraccion) ? (object)DBNull.Value : Convert.ToInt32(MinutosFraccion)),
                    new KeyValuePair<string, object>("@MinutosGracia", string.IsNullOrWhiteSpace(UnidadCobro == "Hora" ? MinutosGracia: "0") ? 0 : Convert.ToInt32(UnidadCobro == "Hora" ? MinutosGracia: "0")),
                    new KeyValuePair<string, object>("@EstadoPlanTarifa", Estado == "Activo" ? 1 : 0),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin)),
                    new KeyValuePair<string, object>("@Detalle", $"Agregó nuevo plan:'{Plan}' de Tiempo por Demanda, regla de cobro: {(UnidadCobro == "Hora" ? $"fracción tiempo: {(Convert.ToInt32(MinutosFraccion) > 1 ? $"{MinutosFraccion} minutos" : $"{MinutosFraccion} minuto")}, {(Convert.ToInt32(MinutosGracia) > 1 ? $"{MinutosGracia} minutos gratis" : $"{MinutosGracia} minuto gratis")}" : $"{(Convert.ToInt32(MinutosFraccion) > 1 ? $"{MinutosFraccion} minutos" : $"{MinutosFraccion} minuto")}")}, valor minuto: {ValorMinuto}, valor hora: {ValorHora}, valor 12 horas: {Valor12Horas}, valor 24 horas: {Valor24Horas}")
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"
                        SET XACT_ABORT ON;

                        BEGIN TRY
                            BEGIN TRANSACTION;

                            DECLARE @IdPlanHorario INT;

                            /* =====================================================
                               3. INSERTAR TARIFA
                               ===================================================== */
                            INSERT INTO PlanTarifa
                            (
                                IdPlan,
                                ValorMinuto,
                                ValorHora,
                                Valor12Horas,
                                Valor24Horas,
                                FechaInicioVigencia,
                                FechaFinVigencia,
                                Estado
                            )
                            VALUES
                            (
                                @IdPlan,
                                @ValorMinuto,
                                @ValorHora,
                                @Valor12Horas,
                                @Valor24Horas,
                                CAST(GETDATE() AS DATE),
                                NULL,
                                @EstadoPlanTarifa
                            );

                            /* =====================================================
                               4. INSERTAR REGLA DE COBRO
                               ===================================================== */
                            INSERT INTO PlanReglaCobro
                            (
                                IdPlan,
                                UnidadCobro,
                                MinutosFraccion,
                                MinutosGracia
                            )
                            VALUES
                            (
                                @IdPlan,
                                @UnidadCobro,
                                @MinutosFraccion,
                                @MinutosGracia
                            );

                            /* =====================================================
                               5. INSERTAR HORARIO
                               ===================================================== */
                            INSERT INTO PlanHorario
                            (
                                IdPlan,
                                Nombre,
                                HoraInicio,
                                HoraFin,
                                CruzaMedianoche,
                                Estado
                            )
                            VALUES
                            (
                                @IdPlan,
                                @NombreHorario,
                                CAST(@HoraInicio AS TIME(0)),
                                CAST(@HoraFin AS TIME(0)),
                                @CruzaMedianoche,
                                @EstadoPlanHorario
                            );

                            SET @IdPlanHorario = SCOPE_IDENTITY();

                            /* =====================================================
                               6. INSERTAR DÍAS
                               ===================================================== */
                            INSERT INTO PlanHorarioDia
                            (
                                IdPlanHorario,
                                DiaSemana
                            )
                            SELECT
                                @IdPlanHorario,
                                TRY_CAST(value AS TINYINT)
                            FROM STRING_SPLIT(@Dias, ',')
                            WHERE TRY_CAST(value AS TINYINT) BETWEEN 1 AND 7;

                            /* =====================================================
                               7. AUDITORÍA
                               ===================================================== */
                            INSERT INTO AuditoriaLog
                            (
                                UsuarioId,
                                Accion,
                                Fecha,
                                Detalle
                            )
                            VALUES
                            (
                                @IdUsuarioLogin,
                                N'Nuevo Plan Tiempo por Demanda',
                                GETDATE(),
                                @Detalle
                            );

                            COMMIT TRANSACTION;
                        END TRY
                        BEGIN CATCH
                            IF @@TRANCOUNT > 0
                                ROLLBACK TRANSACTION;

                            THROW;
                        END CATCH;";

                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo registrar el plan en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                MessageBox.Show($"Error al guardar el plan.\n\n{mensaje}\n\n{error.Message}", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Error);

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region plan_actualizar_tiempo_demanda 
        public async Task<bool> ActualizarPlanTiempoDemanda(string Plan, string IdPlanHorario,
                                string IdPlan, string IdPlanReglaCobro, string IdPlanTarifa, string Estado, string NombreHorario,
                                TimeSpan HoraInicio, TimeSpan HoraFin, bool CruzaMedianoche,
                                string Dias,
                                string ValorMinuto, string ValorHora, string Valor12Horas, string Valor24Horas, string UnidadCobro, string MinutosFraccion, string MinutosGracia, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdPlan", Convert.ToInt32(IdPlan)),
                    new KeyValuePair<string, object>("@IdPlanHorario", Convert.ToInt32(IdPlanHorario)),
                    new KeyValuePair<string, object>("@IdPlanReglaCobro", string.IsNullOrWhiteSpace(IdPlanReglaCobro) ? 0 : Convert.ToInt32(IdPlanReglaCobro)),
                    new KeyValuePair<string, object>("@IdPlanTarifa", string.IsNullOrWhiteSpace(IdPlanTarifa) ? 0 : Convert.ToInt32(IdPlanTarifa)),
                    new KeyValuePair<string, object>("@NombreHorario", NombreHorario),
                    new KeyValuePair<string, object>("@HoraInicio", HoraInicio),
                    new KeyValuePair<string, object>("@HoraFin", HoraFin),
                    new KeyValuePair<string, object>("@CruzaMedianoche", CruzaMedianoche ? 1 : 0),
                    new KeyValuePair<string, object>("@EstadoPlanHorario", Estado == "Activo" ? 1 : 0),
                    new KeyValuePair<string, object>("@Dias", Dias),
                    new KeyValuePair<string, object>("@ValorMinuto", string.IsNullOrWhiteSpace(ValorMinuto) ? 0 : Convert.ToDecimal(ValorMinuto)),
                    new KeyValuePair<string, object>("@ValorHora", string.IsNullOrWhiteSpace(ValorHora) ? 0 : Convert.ToDecimal(ValorHora)),
                    new KeyValuePair<string, object>("@Valor12Horas", string.IsNullOrWhiteSpace(Valor12Horas) ? 0 : Convert.ToDecimal(Valor12Horas)),
                    new KeyValuePair<string, object>("@Valor24Horas", string.IsNullOrWhiteSpace(Valor24Horas) ? 0 : Convert.ToDecimal(Valor24Horas)),
                    new KeyValuePair<string, object>("@UnidadCobro", UnidadCobro),
                    new KeyValuePair<string, object>("@MinutosFraccion", string.IsNullOrWhiteSpace(MinutosFraccion) ? (object)DBNull.Value : Convert.ToInt32(MinutosFraccion)),
                    new KeyValuePair<string, object>("@MinutosGracia", string.IsNullOrWhiteSpace(UnidadCobro == "Hora" ? MinutosGracia: "0") ? 0 : Convert.ToInt32(UnidadCobro == "Hora" ? MinutosGracia: "0")),
                    new KeyValuePair<string, object>("@EstadoPlanTarifa", Estado == "Activo" ? 1 : 0),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin)),
                    new KeyValuePair<string, object>("@Detalle", $"Actualizo plan:'{Plan}' de Tiempo por Demanda, regla de cobro: {(UnidadCobro == "Hora" ? $"fracción tiempo: {(Convert.ToInt32(MinutosFraccion) > 1 ? $"{MinutosFraccion} minutos" : $"{MinutosFraccion} minuto")}, {(Convert.ToInt32(MinutosGracia) > 1 ? $"{MinutosGracia} minutos gratis" : $"{MinutosGracia} minuto gratis")}" : $"{(Convert.ToInt32(MinutosFraccion) > 1 ? $"{MinutosFraccion} minutos" : $"{MinutosFraccion} minuto")}")}, valor minuto: {ValorMinuto}, valor hora: {ValorHora}, valor 12 horas: {Valor12Horas}, valor 24 horas: {Valor24Horas}")
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"
                            SET XACT_ABORT ON;                
                              BEGIN TRY                    
                                BEGIN TRANSACTION;
                    /* =====================================================                       
                       1. ACTUALIZAR TARIFA                       
                       ===================================================== */                    
                    UPDATE PlanTarifa                        
                        SET                           
                            ValorMinuto = @ValorMinuto,                            
                            ValorHora = @ValorHora,                                                      
                            Valor12Horas = @Valor12Horas,                            
                            Valor24Horas = @Valor24Horas,                            
                            Estado = @EstadoPlanTarifa                        
                        WHERE IdPlanTarifa = @IdPlanTarifa;                    

                    /* =====================================================                       
                       4. ACTUALIZAR O INSERTAR REGLA DE COBRO                       
                       ===================================================== */                    
                    UPDATE PlanReglaCobro                        
                        SET UnidadCobro = @UnidadCobro,                            
                            MinutosFraccion = @MinutosFraccion,                            
                            MinutosGracia = @MinutosGracia                        
                        WHERE IdPlanReglaCobro = @IdPlanReglaCobro;                   

                    /* =====================================================                       
                       5. ACTUALIZAR O INSERTAR HORARIO                       
                       ===================================================== */                    
                    IF EXISTS (SELECT 1 FROM PlanHorario WHERE IdPlanHorario = @IdPlanHorario)                    
                    BEGIN                        
                        --SELECT TOP 1 @IdPlanHorario = IdPlanHorario FROM PlanHorario WHERE IdPlan = @IdPlan;                        
                        UPDATE PlanHorario                        
                        SET Nombre = @NombreHorario,                            
                            HoraInicio = CAST(@HoraInicio AS TIME(0)),                            
                            HoraFin = CAST(@HoraFin AS TIME(0)),                            
                            CruzaMedianoche = @CruzaMedianoche,                            
                            Estado = @EstadoPlanHorario                        
                        WHERE IdPlanHorario = @IdPlanHorario;                    
                    END                    
                    ELSE                    
                    BEGIN                        
                        INSERT INTO PlanHorario (IdPlan, Nombre, HoraInicio, HoraFin, CruzaMedianoche, Estado)                        
                        VALUES (@IdPlan, @NombreHorario, CAST(@HoraInicio AS TIME(0)), CAST(@HoraFin AS TIME(0)), @CruzaMedianoche, @EstadoPlanHorario);                        
                        --SET @IdPlanHorario_insert = SCOPE_IDENTITY();                    
                    END                    

                    /* =====================================================                       
                       6. ACTUALIZAR DÍAS (BORRAR E INSERTAR)                       
                       ===================================================== */                    
                    DELETE FROM PlanHorarioDia WHERE IdPlanHorario = @IdPlanHorario;                    
                    INSERT INTO PlanHorarioDia (IdPlanHorario, DiaSemana)                    
                    SELECT @IdPlanHorario, TRY_CAST(value AS TINYINT)                    
                    FROM STRING_SPLIT(@Dias, ',')                    
                    WHERE TRY_CAST(value AS TINYINT) BETWEEN 1 AND 7;                    

                    /* =====================================================                       
                       7. AUDITORÍA                       
                    ===================================================== */                    
                    INSERT INTO AuditoriaLog (UsuarioId, Accion, Fecha, Detalle)                    
                    VALUES (@IdUsuarioLogin, N'Actualizar Plan Tiempo por Demanda', GETDATE(), @Detalle);                    

                    COMMIT TRANSACTION;                
                    END TRY                
                    BEGIN CATCH                    
                        IF @@TRANCOUNT > 0                        
                            ROLLBACK TRANSACTION;                    
                        THROW;                
                    END CATCH;";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo actualizar el plan en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                MessageBox.Show($"Error al actualizar el plan.\n\n{mensaje}\n\n{error.Message}", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Error);

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region plan_eliminar_tiempo_demanda_detalle
        public async Task<bool> EliminarPlanTiempoDemandaDetalle(
            string IdPlan, string IdPlanTarifa, string IdPlanHorario, string IdPlanReglaCobro,
            string Plan, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdPlan", Convert.ToInt32(IdPlan)),
                    new KeyValuePair<string, object>("@IdPlanTarifa", Convert.ToInt32(IdPlanTarifa)),
                    new KeyValuePair<string, object>("@IdPlanHorario", Convert.ToInt32(IdPlanHorario)),
                    new KeyValuePair<string, object>("@IdPlanReglaCobro", Convert.ToInt32(IdPlanReglaCobro)),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin)),
                    new KeyValuePair<string, object>("@Detalle", $"Eliminó el registro específico del plan:'{Plan}' de Tiempo por Demanda")
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"SET XACT_ABORT ON;                
                BEGIN TRY                    
                    BEGIN TRANSACTION;                    

                    /* =====================================================                       
                       1. ELIMINAR DÍAS DEL HORARIO                       
                       ===================================================== */                    
                    DELETE FROM PlanHorarioDia WHERE IdPlanHorario = @IdPlanHorario;                    

                    /* =====================================================                       
                       2. ELIMINAR HORARIO                       
                       ===================================================== */                    
                    DELETE FROM PlanHorario WHERE IdPlanHorario = @IdPlanHorario;                    

                    /* =====================================================                       
                       3. ELIMINAR TARIFA                       
                       ===================================================== */                    
                    DELETE FROM PlanTarifa WHERE IdPlanTarifa = @IdPlanTarifa;                    

                    /* =====================================================                       
                       4. ELIMINAR REGLA DE COBRO                       
                       ===================================================== */                    
                    DELETE FROM PlanReglaCobro WHERE IdPlanReglaCobro = @IdPlanReglaCobro;                    

                    /* =====================================================                       
                       5. AUDITORÍA                       
                       ===================================================== */                    
                    INSERT INTO AuditoriaLog (UsuarioId, Accion, Fecha, Detalle)                    
                    VALUES (@IdUsuarioLogin, N'Eliminar Detalle Plan Tiempo por Demanda', GETDATE(), @Detalle);                    

                    COMMIT TRANSACTION;                
                END TRY                
                BEGIN CATCH                    
                    IF @@TRANCOUNT > 0                        
                        ROLLBACK TRANSACTION;                    
                    THROW;                
                END CATCH;";

                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo eliminar el registro en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                MessageBox.Show($"Error al eliminar el registro.\n\n{mensaje}\n\n{error.Message}", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Error);

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        /*Tarifas membresía - mensualidad*/
        #region listado_membresia_mensualidad
        public async Task<DataSet> TarifasMemnbresiaMensualidadAsync(string IdPlan, int pageNumber, int pageSize)
        {
            try
            {
                // Preparamos los parámetros para un nuevo nivel
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdPlan", IdPlan)
                };

                if (await conexionBD.Connection())
                {
                    string sql = $@"DECLARE @RowsPerPage INT = {pageSize};
                                    DECLARE @PageNumber INT = {pageNumber};
                                    
                                    SELECT [Plan].IdPlan,
                                       [Plan].Nombre AS NombrePlan,
                                       [Plan].Descripcion AS DescripcionPlan,
                                       [Plan].FechaInicioVigencia,
                                       [Plan].FechaFinVigencia,
                                       [Plan].Estado AS EstadoEstado,
                                       TipoPlan.Nombre AS Nombre,
                                       TipoPlan.Descripcion, 
                                       TipoPlan.Estado AS TipoPlanEstado, 
                                       CategoriaVehiculo.Nombre AS NombreCategoriaVehiculo,
                                       CategoriaVehiculo.Descripcion AS CategoriaVehiculoDescripcion,
                                       TipoVehiculo.Nombre AS NombreTipoVehiculo,
                                       TipoVehiculo.Descripcion AS DescripcionTipoVehiculo,
                                       PlanTarifa.IdPlanTarifa,
                                       [Plan].IdTipoVehiculo, 
                                       [Plan].IdCategoriaVehiculo,
                                       CONCAT ('$ ',FORMAT(PlanTarifa.ValorTarifa, 'N0', 'es-ES')) AS ValorTarifa,
                                       PlanTarifa.Estado AS EstadoPlanTarifa,
                                       PlanVigencia.Unidad,
                                       PlanVigencia.Cantidad,
                                        CASE
                                                WHEN PlanVigencia.Unidad = 'Día' 
                                                    THEN CAST(PlanVigencia.Cantidad AS VARCHAR(10)) 
                                                         + CASE 
                                                             WHEN PlanVigencia.Cantidad = 1 THEN ' Día'
                                                             ELSE ' Días'
                                                           END

                                                WHEN PlanVigencia.Unidad = 'Mes' 
                                                    THEN CAST(PlanVigencia.Cantidad AS VARCHAR(10)) 
                                                         + CASE 
                                                             WHEN PlanVigencia.Cantidad = 1 THEN ' Mes'
                                                             ELSE ' Meses'
                                                           END

                                                ELSE CAST(PlanVigencia.Cantidad AS VARCHAR(10)) 
                                                     + ' ' + PlanVigencia.Unidad
                                            END AS Vigencia
                                FROM [Plan] INNER JOIN
                                   TipoPlan ON [Plan].IdTipoPlan = TipoPlan.IdTipoPlan INNER JOIN
                                   PlanTarifa ON [Plan].IdPlan = PlanTarifa.IdPlan INNER JOIN
                                   PlanVigencia ON PlanTarifa.IdPlanTarifa = PlanVigencia.IdPlanTarifa INNER JOIN
                                   CategoriaVehiculo ON [Plan].IdCategoriaVehiculo = CategoriaVehiculo.IdCategoriaVehiculo INNER JOIN
                                   TipoVehiculo ON [Plan].IdTipoVehiculo = TipoVehiculo.IdTipoVehiculo
                                WHERE [PLAN].IdPlan = @IdPlan
                                ORDER BY [PLAN].Nombre
                                        OFFSET (@PageNumber - 1) * @RowsPerPage ROWS
                                        FETCH NEXT @RowsPerPage ROWS ONLY;

                                    SELECT COUNT(*)
                                    FROM [Plan] INNER JOIN
                                       TipoPlan ON [Plan].IdTipoPlan = TipoPlan.IdTipoPlan INNER JOIN
                                       PlanTarifa ON [Plan].IdPlan = PlanTarifa.IdPlan INNER JOIN
                                       PlanVigencia ON PlanTarifa.IdPlanTarifa = PlanVigencia.IdPlanTarifa INNER JOIN
                                       CategoriaVehiculo ON [Plan].IdCategoriaVehiculo = CategoriaVehiculo.IdCategoriaVehiculo INNER JOIN
                                       TipoVehiculo ON [Plan].IdTipoVehiculo = TipoVehiculo.IdTipoVehiculo
                                       WHERE [PLAN].IdPlan = @IdPlan";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener planes.\n{conexionBD.StrError}\n{error.Message}", "Planes", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region nuevo_tarifa
        public async Task<bool> NuevoTarifa(string Tarifa, string IdPlan, string ValorTarifa, string Unidad, string Cantidad, string Estado, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdPlan", IdPlan),

                    new KeyValuePair<string, object>("@ValorTarifa", string.IsNullOrWhiteSpace(ValorTarifa) ? 0 : Convert.ToDecimal(ValorTarifa)),
                    new KeyValuePair<string, object>("@Estado", Estado == "Activo" ? 1 : 0),

                    new KeyValuePair<string, object>("@Unidad", Unidad),
                    new KeyValuePair<string, object>("@Cantidad", string.IsNullOrWhiteSpace(Cantidad) ? 0 : Convert.ToDecimal(Cantidad)),

                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin)),
                    new KeyValuePair<string, object>("@Detalle", $"Agregó {Tarifa}, Vigencia: {(Unidad == "Día" ? (Convert.ToDecimal(Cantidad) > 1 ? (Cantidad + " Días") : Cantidad +" Día") : (Convert.ToDecimal(Cantidad) > 1 ? Cantidad + " Meses" : Cantidad + "Mes"))}, valor: {ValorTarifa}")
                    //new KeyValuePair<string, object>("@Detalle", $"Agregó {Tarifa}, Vigencia: {(Unidad == "Día" ? (Convert.ToDecimal(Cantidad) > 1 ? (Cantidad + " Días") : Cantidad +" Día") : (Convert.ToDecimal(Cantidad) > 1 ? Cantidad + " Meses" : Cantidad + "Mes"))} tipo vehículo: {TipoVehiculo}, categoría: {Categoria}, valor: {ValorTarifa}")
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"
                        SET XACT_ABORT ON;

                        BEGIN TRY
                            BEGIN TRANSACTION;

                            DECLARE @IdTipoVehiculo INT;
                            DECLARE @IdPlanTarifa INT;


                            /* =====================================================
                               3. INSERTAR TARIFA
                               ===================================================== */
                            INSERT INTO PlanTarifa
                            (
                                IdPlan,
                                ValorTarifa,
                                FechaInicioVigencia,
                                Estado
                            )
                            VALUES
                            (
                                @IdPlan,
                                @ValorTarifa,
                                CAST(GETDATE() AS DATE),
                                @Estado
                            );
                            
                            SET @IdPlanTarifa = SCOPE_IDENTITY();

                            /* =====================================================
                               4. INSERTAR VIGENCIA
                               ===================================================== */
                            INSERT INTO PlanVigencia
                            (
                                IdPlanTarifa,
                                Unidad,
                                Cantidad
                            )
                            VALUES
                            (
                                @IdPlanTarifa,
                                @Unidad,
                                @Cantidad
                            );

                            /* =====================================================
                               5. AUDITORÍA
                               ===================================================== */
                            INSERT INTO AuditoriaLog
                            (
                                UsuarioId,
                                Accion,
                                Fecha,
                                Detalle
                            )
                            VALUES
                            (
                                @IdUsuarioLogin,
                                N'Nueva Tarifa',
                                GETDATE(),
                                @Detalle
                            );

                            COMMIT TRANSACTION;
                        END TRY
                        BEGIN CATCH
                            IF @@TRANCOUNT > 0
                                ROLLBACK TRANSACTION;

                            THROW;
                        END CATCH;";

                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo registrar tarifa en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');
                string codigoError = partes.Length > 0 ? partes[0].Trim() : "";
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                MessageBox.Show($"Error al guardar tarifa.\n{mensaje}", "Tarifa", MessageBoxButton.OK, MessageBoxImage.Error);

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region actualizar_tarifa
        public async Task<bool> ActualizarTarifa(string IdPlanTarifa, string Tarifa, string ValorTarifa, string Unidad, string Cantidad, string Estado, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdPlanTarifa", Convert.ToInt32(IdPlanTarifa)),

                    new KeyValuePair<string, object>("@ValorTarifa", string.IsNullOrWhiteSpace(ValorTarifa) ? 0 : Convert.ToDecimal(ValorTarifa)),
                    new KeyValuePair<string, object>("@Estado", Estado == "Activo" ? 1 : 0),

                    new KeyValuePair<string, object>("@Unidad", Unidad),
                    new KeyValuePair<string, object>("@Cantidad", string.IsNullOrWhiteSpace(Cantidad) ? 0 : Convert.ToDecimal(Cantidad)),

                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin)),
                    new KeyValuePair<string, object>("@Detalle", $"Actualizó {Tarifa}, Vigencia: {(Unidad == "Día" ? (Convert.ToDecimal(Cantidad) > 1 ? (Cantidad + " Días") : Cantidad + " Día") : (Convert.ToDecimal(Cantidad) > 1 ? Cantidad + " Meses" : Cantidad + " Mes"))}")
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"SET XACT_ABORT ON;                
                                BEGIN TRY                    
                                    BEGIN TRANSACTION;                                     

                                    /* =====================================================                       
                                       3. ACTUALIZAR TARIFA                       
                                       ===================================================== */                    
                                    UPDATE PlanTarifa                    
                                    SET                       
                                        ValorTarifa = @ValorTarifa,                        
                                        Estado = @Estado                    
                                    WHERE IdPlanTarifa = @IdPlanTarifa;                                                

                                    /* =====================================================                       
                                       4. ACTUALIZAR VIGENCIA                       
                                       ===================================================== */                    
                                    UPDATE PlanVigencia
                                        SET Unidad = @Unidad,
                                            Cantidad = @Cantidad
                                        WHERE IdPlanTarifa = @IdPlanTarifa;

                                    /* =====================================================                       
                                       5. AUDITORÍA                       
                                       ===================================================== */                    
                                    INSERT INTO AuditoriaLog (UsuarioId, Accion, Fecha, Detalle)                    
                                    VALUES (@IdUsuarioLogin, N'ActualizO Tarifa', GETDATE(), @Detalle);                    

                                    COMMIT TRANSACTION;                
                                END TRY                
                                BEGIN CATCH                    
                                    IF @@TRANCOUNT > 0                        
                                        ROLLBACK TRANSACTION;                    
                                    THROW;                
                                END CATCH;";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo actualizar la tarifa en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                MessageBox.Show($"Error al actualizar tarifa.\n{mensaje}", "Tarifa Error", MessageBoxButton.OK, MessageBoxImage.Error);

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region eliminar_tarifa
        public async Task<bool> EliminarTarifa(string IdPlanTarifa, string Tarifa, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdPlanTarifa", Convert.ToInt32(IdPlanTarifa)),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin)),
                    new KeyValuePair<string, object>("@Detalle", $"Eliminó la tarifa: {Tarifa}")
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"SET XACT_ABORT ON;                
                            BEGIN TRY                    
                                BEGIN TRANSACTION;                    

                                /* =====================================================                       
                                   1. ELIMINAR VIGENCIA ASOCIADA                       
                                   ===================================================== */                    
                                DELETE FROM PlanVigencia 
                                WHERE IdPlanTarifa = @IdPlanTarifa;                    

                                /* =====================================================                       
                                   2. ELIMINAR TARIFA                       
                                   ===================================================== */                    
                                DELETE FROM PlanTarifa 
                                WHERE IdPlanTarifa = @IdPlanTarifa;                    

                                /* =====================================================                       
                                   3. AUDITORÍA                       
                                   ===================================================== */                    
                                INSERT INTO AuditoriaLog (UsuarioId, Accion, Fecha, Detalle)                    
                                VALUES (@IdUsuarioLogin, N'Eliminar Tarifa', GETDATE(), @Detalle);                    

                                COMMIT TRANSACTION;                
                            END TRY                
                            BEGIN CATCH                    
                                IF @@TRANCOUNT > 0                        
                                    ROLLBACK TRANSACTION;                    
                                THROW;                
                            END CATCH;";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo eliminar la tarifa en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                MessageBox.Show($"Error al eliminar la tarifa.\n\n{mensaje}\n\n{error.Message}", "Tarifa", MessageBoxButton.OK, MessageBoxImage.Error);

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        /*Seleccionar plan vehiculo del cliente*/

        #region seleccionar_vehiculo_cliente
        public async Task<DataSet> SeleccionarTipoPlan(string idtipovehiculo, string IdCategoriaVehiculo)
        {
            try
            {
                // Preparamos los parámetros para un nuevo nivel
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@idtipovehiculo", idtipovehiculo),
                    new KeyValuePair<string, object>("@IdCategoriaVehiculo", IdCategoriaVehiculo)
                };

                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT [Plan].IdTipoPlan,
                                           PlanTarifa.IdPlanTarifa,
                                           CategoriaVehiculo.Nombre AS CategoriaVehiculo,
                                           CategoriaVehiculo.Descripcion AS DescripcionCategoriaVehiculo,
                                           TipoVehiculo.Nombre AS TipoVehiculo, 
                                           TipoVehiculo.Descripcion AS DescripcionTipoVehiculo,
                                           CONCAT ('$ ',FORMAT(PlanTarifa.ValorTarifa, 'N0', 'es-ES')) AS ValorTarifa,
                                           PlanTarifa.FechaInicioVigencia,
                                           PlanTarifa.FechaFinVigencia,
                                           PlanTarifa.Estado, 
                                           [Plan].Nombre AS NombrePlan,
                                           [Plan].IdPlan,
                                           [Plan].Descripcion AS DescripcionPlan,
                                           [Plan].FechaInicioVigencia AS FechaInicioVigenciaPlan,
                                           [Plan].FechaFinVigencia AS FechaFinVigenciaPlan,
                                           PlanVigencia.Unidad,
                                           PlanVigencia.Cantidad
                                    FROM   PlanTarifa INNER JOIN
                                           [Plan] ON PlanTarifa.IdPlan = [Plan].IdPlan INNER JOIN
                                           TipoVehiculo ON [Plan].IdTipoVehiculo = TipoVehiculo.IdTipoVehiculo INNER JOIN
                                           CategoriaVehiculo ON [Plan].IdCategoriaVehiculo = CategoriaVehiculo.IdCategoriaVehiculo INNER JOIN
                                           PlanVigencia ON PlanTarifa.IdPlanTarifa = PlanVigencia.IdPlanTarifa
                                    WHERE [Plan].IdTipoPlan IN (1,2) 
                                    AND [Plan].IdTipoVehiculo = @idtipovehiculo AND [Plan].IdCategoriaVehiculo = @IdCategoriaVehiculo";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener planes.\n{conexionBD.StrError}\n{error.Message}", "Planes", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region seleccionar_plan_vehiculo
        public async Task<DataSet> SeleccionarPlanVehiculo(string IdVehiculo)
        {
            try
            {
                // Preparamos los parámetros para un nuevo nivel
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdVehiculo", IdVehiculo)
                };

                if (await conexionBD.Connection())
                {
                    string sql = $@"
                                    /* =====================================================
                                       NORMALIZAR ESTADOS DE CONTRATACIONES
                                       ===================================================== */

                                        UPDATE VehiculoPlan
                                        SET EstadoContrato =
                                            CASE
                                                WHEN EstadoContrato = 'Cancelada'
                                                    THEN 'Cancelada'

                                                WHEN FechaFin < CAST(GETDATE() AS DATE)
                                                    THEN 'Vencida'

                                                WHEN FechaInicio > CAST(GETDATE() AS DATE)
                                                    THEN 'Programada'

                                                WHEN CAST(GETDATE() AS DATE)
                                                     BETWEEN FechaInicio AND FechaFin
                                                    THEN 'Activa'

                                                ELSE EstadoContrato
                                            END
                                        WHERE EstadoContrato <> 'Cancelada' AND IdVehiculo = @IdVehiculo;

                                      SELECT TOP 12 
                                        VehiculoPlan.IdVehiculoPlan,
                                        CategoriaVehiculo.Nombre AS CategoriaVehiculo,
                                        TipoVehiculo.Nombre AS TipoVehiculo,
                                        Vehiculo.Placa,
                                        TipoPlan.Nombre AS TipoPlan,
                                        [Plan].Nombre AS DescripcionPlan,
                                        ISNULL(FORMAT(VehiculoPlan.FechaInicio, 'dddd, dd \de MMMM \de yyyy', 'es-ES'), '') AS FechaInicio,
                                        ISNULL(FORMAT(VehiculoPlan.FechaFin, 'dddd, dd \de MMMM \de yyyy', 'es-ES'), '') AS FechaFin,

                                        -- Vigencia única obtenida de forma segura
                                        ISNULL(
                                            CASE 
                                                WHEN PlanVigencia.Unidad = 'Mes' THEN CAST(PlanVigencia.Cantidad AS VARCHAR(10)) + CASE WHEN PlanVigencia.Cantidad = 1 THEN ' Mes' ELSE ' Meses' END
                                                WHEN PlanVigencia.Unidad = 'Día' THEN CAST(PlanVigencia.Cantidad AS VARCHAR(10)) + CASE WHEN PlanVigencia.Cantidad = 1 THEN ' Día' ELSE ' Días' END
                                                ELSE CAST(PlanVigencia.Cantidad AS VARCHAR(10)) + ' ' + PlanVigencia.Unidad
                                            END, 
                                        '') AS Vigencia,

                                        -- Precio contratado formateado
                                        CASE 
                                            WHEN VehiculoPlan.PrecioContratado IS NOT NULL 
                                            THEN CONCAT('$ ', FORMAT(VehiculoPlan.PrecioContratado, 'N0', 'es-ES')) 
                                            ELSE '' 
                                        END AS PrecioContratado,

                                        VehiculoPlan.EstadoPago, 
                                        VehiculoPlan.EstadoContrato, 
                                        MetodoPago.Nombre AS MetodoPago

                                    FROM Vehiculo
                                    LEFT JOIN CategoriaVehiculo ON Vehiculo.IdCategoriaVehiculo = CategoriaVehiculo.IdCategoriaVehiculo
                                    LEFT JOIN TipoVehiculo ON Vehiculo.idtipovehiculo = TipoVehiculo.IdTipoVehiculo
                                    LEFT JOIN VehiculoPlan ON Vehiculo.IdVehiculo = VehiculoPlan.IdVehiculo

                                    -- Relación correcta siguiendo el diagrama: VehiculoPlan -> PlanTarifa -> Plan -> TipoPlan
                                    LEFT JOIN PlanTarifa ON VehiculoPlan.IdPlanTarifa = PlanTarifa.IdPlanTarifa
                                    LEFT JOIN [Plan] ON PlanTarifa.IdPlan = [Plan].IdPlan
                                    LEFT JOIN TipoPlan ON [Plan].IdTipoPlan = TipoPlan.IdTipoPlan

                                    -- OUTER APPLY para asegurar que PlanVigencia no genere duplicados
                                    OUTER APPLY (
                                        SELECT TOP 1 pv.Unidad, pv.Cantidad
                                        FROM PlanVigencia pv
                                        WHERE pv.IdPlanTarifa = PlanTarifa.IdPlanTarifa
                                    ) AS PlanVigencia

                                    -- OUTER APPLY para evitar duplicados si hay múltiples pagos registrados
                                    OUTER APPLY (
                                        SELECT TOP 1 p.IdMetodoPago
                                        FROM Pago p
                                        WHERE p.IdVehiculoPlan = VehiculoPlan.IdVehiculoPlan
                                    ) AS PagoFiltrado

                                    LEFT JOIN MetodoPago ON MetodoPago.IdMetodoPago = PagoFiltrado.IdMetodoPago

                                    WHERE Vehiculo.IdVehiculo = @IdVehiculo 
                                      AND (VehiculoPlan.EstadoPago = 'Pendiente' OR VehiculoPlan.EstadoPago = 'Pagado')
                                    ORDER BY VehiculoPlan.FechaInicio DESC;";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener planes.\n{conexionBD.StrError}\n{error.Message}", "Planes", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        /*Seleccionar membresia-mensualidad*/

        #region nueva_memnbresia
        public async Task<bool> NuevaMembresia(string IdVehiculo, string IdPlan, string IdPlanTarifa, string FechaInicio, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                if (!DateTime.TryParse(FechaInicio, new System.Globalization.CultureInfo("es-CO"), System.Globalization.DateTimeStyles.None, out DateTime fechaInicioDate))
                {
                    MessageBox.Show("La fecha de inicio de la membresía no es válida.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdVehiculo", Convert.ToInt32(IdVehiculo)),
                    new KeyValuePair<string, object>("@IdPlan", Convert.ToInt32(IdPlan)),
                    new KeyValuePair<string, object>("@IdPlanTarifa", Convert.ToInt32(IdPlanTarifa)),
                    new KeyValuePair<string, object>("@FechaInicio", fechaInicioDate.Date),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin))
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"
                SET XACT_ABORT ON;

                BEGIN TRY

                    BEGIN TRANSACTION;

                    DECLARE @IdTipoPlan INT;
                    DECLARE @NombreTipoPlan NVARCHAR(50);

                    DECLARE @IdTipoVehiculo INT;
                    DECLARE @IdCategoriaVehiculo INT;

                    DECLARE @EsVIP BIT;
                    DECLARE @EstadoVehiculo BIT;

                    -- (NOTA: @IdPlanTarifa ya viene como parámetro desde C#, no se declara aquí)

                    DECLARE @Unidad NVARCHAR(20);
                    DECLARE @Cantidad INT;

                    DECLARE @ValorTarifa DECIMAL(18,2);

                    DECLARE @FechaFin DATE;
                    DECLARE @EstadoContrato VARCHAR(20);


                    /* =====================================================
                       1. VALIDAR VEHÍCULO
                       ===================================================== */

                    SELECT
                        @IdTipoVehiculo = V.idtipovehiculo,
                        @IdCategoriaVehiculo = V.IdCategoriaVehiculo,
                        @EsVIP = V.EsVIP,
                        @EstadoVehiculo = V.Activo
                    FROM Vehiculo V
                    WHERE V.Idvehiculo = @IdVehiculo;


                    IF @IdTipoVehiculo IS NULL
                    BEGIN
                        THROW 50001, 'El vehículo no existe o no tiene tipo de vehículo configurado.', 1;
                    END;


                    IF @IdCategoriaVehiculo IS NULL
                    BEGIN
                        THROW 50002, 'El vehículo no tiene categoría de vehículo configurada.', 1;
                    END;


                    IF @EstadoVehiculo = 0
                    BEGIN
                        THROW 50003, 'El vehículo se encuentra inactivo.', 1;
                    END;


                    /* =====================================================
                       2. VALIDAR VEHÍCULO VIP
                       ===================================================== */

                    IF @EsVIP = 1
                    BEGIN
                        THROW 50004, 'No se puede registrar una membresía para un vehículo VIP.', 1;
                    END;


                    /* =====================================================
                       3. VALIDAR PLAN
                       ===================================================== */

                    SELECT
                        @IdTipoPlan = P.IdTipoPlan,
                        @NombreTipoPlan = TP.Nombre
                    FROM [Plan] P
                    INNER JOIN TipoPlan TP
                        ON TP.IdTipoPlan = P.IdTipoPlan
                    WHERE P.IdPlan = @IdPlan
                      AND P.Estado = 1;


                    IF @IdTipoPlan IS NULL
                    BEGIN
                        THROW 50005, 'El plan no existe o se encuentra inactivo.', 1;
                    END;


                    IF @NombreTipoPlan <> N'Membresía'
                    BEGIN
                        THROW 50006, 'El plan seleccionado no corresponde a una membresía.', 1;
                    END;


                    /* =====================================================
                       4. OBTENER TARIFA Y VIGENCIA DIRECTA DESDE EL IDPLANTARIFA
                       ===================================================== */

                    SELECT TOP 1
                        @ValorTarifa = PT.ValorTarifa,
                        @Unidad = PV.Unidad,
                        @Cantidad = PV.Cantidad
                    FROM PlanTarifa PT
                    INNER JOIN PlanVigencia PV
                        ON PV.IdPlanTarifa = PT.IdPlanTarifa
                    WHERE PT.IdPlanTarifa = @IdPlanTarifa
                      AND PT.Estado = 1;


                    /* =====================================================
                       5. VALIDAR QUE EXISTA TARIFA
                       ===================================================== */

                    IF @ValorTarifa IS NULL
                    BEGIN
                        THROW 50007, 'No existe una tarifa activa para el identificador seleccionado.', 1;
                    END;


                    /* =====================================================
                       6. VALIDAR VIGENCIA
                       ===================================================== */

                    IF @Unidad IS NULL
                    BEGIN
                        THROW 50008, 'La tarifa seleccionada no tiene una vigencia configurada.', 1;
                    END;


                    IF @Cantidad IS NULL OR @Cantidad <= 0
                    BEGIN
                        THROW 50009, 'La cantidad de la vigencia de la membresía no es válida.', 1;
                    END;


                    /* =====================================================
                       7. CALCULAR FECHA FIN
                       ===================================================== */

                    IF @Unidad = N'Día'
                    BEGIN
                        SET @FechaFin = DATEADD(DAY, @Cantidad, @FechaInicio);
                    END
                    ELSE IF @Unidad = N'Mes'
                    BEGIN
                        SET @FechaFin = DATEADD(MONTH, @Cantidad, @FechaInicio);
                    END
                    ELSE
                    BEGIN
                        THROW 50010, 'La unidad de vigencia de una membresía debe ser Día o Mes.', 1;
                    END;


                    /* =====================================================
                       8. VALIDAR SOLAPAMIENTO
                       ===================================================== */

                    IF EXISTS
                    (
                        SELECT 1
                        FROM VehiculoPlan VP
                        INNER JOIN PlanTarifa PT2 ON PT2.IdPlanTarifa = VP.IdPlanTarifa
                        INNER JOIN [Plan] P2 ON P2.IdPlan = PT2.IdPlan
                        INNER JOIN TipoPlan TP2 ON TP2.IdTipoPlan = P2.IdTipoPlan
                        WHERE VP.IdVehiculo = @IdVehiculo
                          AND VP.EstadoContrato IN ('Activa', 'Programada')
                          AND TP2.Nombre IN (N'Membresía', N'Mensualidad')
                          AND VP.FechaFin >= CAST(GETDATE() AS DATE)
                          AND @FechaInicio <= VP.FechaFin
                          AND @FechaFin >= VP.FechaInicio
                    )
                    BEGIN
                        THROW 50011, 'El período de la nueva membresía se solapa con una membresía o mensualidad existente.', 1;
                    END;


                    /* =====================================================
                       9. DETERMINAR ESTADO DEL CONTRATO
                       ===================================================== */

                    IF @FechaInicio > CAST(GETDATE() AS DATE)
                    BEGIN
                        SET @EstadoContrato = 'Programada';
                    END
                    ELSE
                    BEGIN
                        SET @EstadoContrato = 'Activa';
                    END;


                    /* =====================================================
                       10. INSERTAR VEHICULOPLAN
                       ===================================================== */

                    INSERT INTO VehiculoPlan
                    (
                        IdVehiculo,
                        IdPlanTarifa,
                        FechaInicio,
                        FechaFin,
                        PrecioContratado,
                        EstadoContrato,
                        EstadoPago,
                        FechaPago,
                        FechaRegistro
                    )
                    VALUES
                    (
                        @IdVehiculo,
                        @IdPlanTarifa,
                        @FechaInicio,
                        @FechaFin,
                        @ValorTarifa,
                        @EstadoContrato,
                        'Pendiente',
                        NULL,
                        GETDATE()
                    );


                    /* =====================================================
                       11. AUDITORÍA
                       ===================================================== */

                    INSERT INTO AuditoriaLog
                    (
                        UsuarioID,
                        Accion,
                        Fecha,
                        Detalle
                    )
                    VALUES
                    (
                        @IdUsuarioLogin,
                        N'Nueva Membresía',
                        GETDATE(),
                        CONCAT(
                            N'Vehículo: ', @IdVehiculo,
                            N' | Plan: ', @IdPlan,
                            N' | PlanTarifa: ', @IdPlanTarifa,
                            N' | Inicio: ', CONVERT(VARCHAR(10), @FechaInicio, 103),
                            N' | Fin: ', CONVERT(VARCHAR(10), @FechaFin, 103),
                            N' | Valor tarifa: $', CONVERT(VARCHAR(30), @ValorTarifa),
                            N' | Unidad: ', @Unidad,
                            N' | Cantidad: ', @Cantidad,
                            N' | Estado contrato: ', @EstadoContrato,
                            N' | Estado pago: Pendiente'
                        )
                    );


                    COMMIT TRANSACTION;

                END TRY
                BEGIN CATCH
                    IF @@TRANCOUNT > 0
                        ROLLBACK TRANSACTION;

                    THROW;
                END CATCH;
                ";

                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No fue posible registrar la membresía.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');

                string codigoError = partes.Length > 0 ? partes[0].Trim() : string.Empty;
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                switch (codigoError)
                {
                    case "50001":
                        MessageBox.Show("El vehículo no existe o no tiene tipo de vehículo configurado.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "50002":
                        MessageBox.Show("El vehículo no tiene categoría de vehículo configurada.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "50003":
                        MessageBox.Show("El vehículo se encuentra inactivo.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "50004":
                        MessageBox.Show("El vehículo es VIP y no puede tener membresía.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    case "50005":
                        MessageBox.Show("El plan no existe o se encuentra inactivo.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "50006":
                        MessageBox.Show("El plan seleccionado no corresponde a una membresía.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "50007":
                        MessageBox.Show("No existe una tarifa para el identificador seleccionado.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "50008":
                        MessageBox.Show("La tarifa seleccionada no tiene una vigencia configurada.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "50009":
                        MessageBox.Show("La cantidad de vigencia de la membresía no es válida.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "50010":
                        MessageBox.Show("La vigencia de la membresía debe estar configurada en días o meses.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "50011":
                        MessageBox.Show("El nuevo período de la membresía se solapa con una membresía o mensualidad existente.", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    default:
                        MessageBox.Show("Error al registrar la membresía.\n\n" + error.Message, "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                }

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region nueva_mensualidad
        public async Task<bool> NuevaMensualidad(string IdVehiculo, string IdPlanMemsualidad, string IdPlanTarifaMensualidad, string FechaInicio, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                if (!DateTime.TryParse(FechaInicio, new System.Globalization.CultureInfo("es-CO"), System.Globalization.DateTimeStyles.None, out DateTime fechaInicioDate))
                {
                    MessageBox.Show("La fecha de inicio de la mensualidad no es válida.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdVehiculo", Convert.ToInt32(IdVehiculo)),
                    new KeyValuePair<string, object>("@IdPlan", Convert.ToInt32(IdPlanMemsualidad)),
                    new KeyValuePair<string, object>("@IdPlanTarifaMensualidad", Convert.ToInt32(IdPlanTarifaMensualidad)),
                    new KeyValuePair<string, object>("@FechaInicio", fechaInicioDate.Date),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin))
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"
                        SET XACT_ABORT ON;

                        BEGIN TRY

                            BEGIN TRANSACTION;

                            DECLARE @IdTipoPlan INT;
                            DECLARE @NombreTipoPlan NVARCHAR(50);

                            DECLARE @IdTipoVehiculo INT;
                            DECLARE @IdCategoriaVehiculo INT;

                            DECLARE @EsVIP BIT;
                            DECLARE @EstadoVehiculo BIT;

                            DECLARE @Unidad NVARCHAR(30);
                            DECLARE @UnidadNormalizada VARCHAR(30);
                            DECLARE @Cantidad INT;

                            DECLARE @ValorTarifa DECIMAL(18,2);
                            DECLARE @FechaFin DATE;
                            DECLARE @EstadoContrato VARCHAR(20);


                            /* =====================================================
                               1. VALIDAR VEHÍCULO
                               ===================================================== */

                            SELECT
                                @IdTipoVehiculo = V.idtipovehiculo,
                                @IdCategoriaVehiculo = V.IdCategoriaVehiculo,
                                @EsVIP = V.EsVIP,
                                @EstadoVehiculo = V.Activo
                            FROM Vehiculo V
                            WHERE V.Idvehiculo = @IdVehiculo;


                            IF @IdTipoVehiculo IS NULL
                            BEGIN
                                THROW 51001, 'El vehículo no existe o no tiene tipo de vehículo configurado.', 1;
                            END;


                            IF @IdCategoriaVehiculo IS NULL
                            BEGIN
                                THROW 51002, 'El vehículo no tiene categoría de vehículo configurada.', 1;
                            END;


                            IF @EstadoVehiculo = 0
                            BEGIN
                                THROW 51003, 'El vehículo se encuentra inactivo.', 1;
                            END;


                            /* =====================================================
                               2. VALIDAR VIP
                               ===================================================== */

                            IF @EsVIP = 1
                            BEGIN
                                THROW 51004, 'No se puede registrar una mensualidad para un vehículo VIP.', 1;
                            END;


                            /* =====================================================
                               3. VALIDAR PLAN
                               ===================================================== */

                            SELECT
                                @IdTipoPlan = P.IdTipoPlan,
                                @NombreTipoPlan = TP.Nombre
                            FROM [Plan] P
                            INNER JOIN TipoPlan TP
                                ON TP.IdTipoPlan = P.IdTipoPlan
                            WHERE P.IdPlan = @IdPlan
                              AND P.Estado = 1;


                            IF @IdTipoPlan IS NULL
                            BEGIN
                                THROW 51005, 'El plan no existe o se encuentra inactivo.', 1;
                            END;


                            IF @NombreTipoPlan <> N'Mensualidad'
                            BEGIN
                                THROW 51006, 'El plan seleccionado no corresponde a una mensualidad.', 1;
                            END;


                            /* =====================================================
                               4. OBTENER TARIFA + VIGENCIA DIRECTA DESDE @IdPlanTarifaMensualidad
                               ===================================================== */

                            SELECT TOP 1
                                @ValorTarifa = PT.ValorTarifa,
                                @Unidad = PV.Unidad,
                                @Cantidad = PV.Cantidad
                            FROM PlanTarifa PT
                            INNER JOIN PlanVigencia PV
                                ON PV.IdPlanTarifa = PT.IdPlanTarifa
                            WHERE PT.IdPlanTarifa = @IdPlanTarifaMensualidad
                              AND PT.Estado = 1;


                            /* =====================================================
                               5. VALIDAR TARIFA
                               ===================================================== */

                            IF @ValorTarifa IS NULL
                            BEGIN
                                THROW 51008, 'La tarifa de la mensualidad no tiene un valor configurado o no existe.', 1;
                            END;


                            /* =====================================================
                               6. VALIDAR UNIDAD DE VIGENCIA
                               ===================================================== */

                            SET @UnidadNormalizada =
                                UPPER(
                                    LTRIM(
                                        RTRIM(
                                            REPLACE(
                                                REPLACE(
                                                    REPLACE(
                                                        REPLACE(
                                                            @Unidad,
                                                            N'Á', N'A'
                                                        ),
                                                        N'É', N'E'
                                                    ),
                                                    N'Í', N'I'
                                                ),
                                                N'Ó', N'O'
                                            )
                                        )
                                    )
                                );


                            IF @UnidadNormalizada IS NULL
                            BEGIN
                                THROW 51009, 'La mensualidad no tiene una unidad de vigencia configurada.', 1;
                            END;


                            IF @UnidadNormalizada NOT LIKE 'MES%'
                               AND @UnidadNormalizada <> 'CALENDARIO'
                            BEGIN
                                THROW 51010, 'La mensualidad debe tener una vigencia de uno o más meses.', 1;
                            END;


                            /* =====================================================
                               7. VALIDAR CANTIDAD
                               ===================================================== */

                            IF @Cantidad IS NULL OR @Cantidad < 1
                            BEGIN
                                THROW 51011, 'La cantidad de meses debe ser igual o superior a 1.', 1;
                            END;


                            /* =====================================================
                               8. CALCULAR FECHA FIN
                               ===================================================== */

                            IF @UnidadNormalizada LIKE 'MES%'
                            BEGIN
                                SET @FechaFin = DATEADD(MONTH, @Cantidad, @FechaInicio);
                            END
                            ELSE IF @UnidadNormalizada = 'CALENDARIO'
                            BEGIN
                                IF DAY(@FechaInicio) <> 1
                                BEGIN
                                    THROW 51012, 'Una mensualidad por mes calendario debe iniciar el primer día del mes.', 1;
                                END;

                                SET @FechaFin = EOMONTH(DATEADD(MONTH, @Cantidad - 1, @FechaInicio));
                            END
                            ELSE
                            BEGIN
                                THROW 51013, 'La modalidad de vigencia de la mensualidad no es válida.', 1;
                            END;


                            /* =====================================================
                               9. VALIDAR SOLAPAMIENTO
                               ===================================================== */

                            IF EXISTS
                            (
                                SELECT 1
                                FROM VehiculoPlan VP
                                INNER JOIN PlanTarifa PT2 ON PT2.IdPlanTarifa = VP.IdPlanTarifa
                                INNER JOIN [Plan] P2 ON P2.IdPlan = PT2.IdPlan
                                INNER JOIN TipoPlan TP2 ON TP2.IdTipoPlan = P2.IdTipoPlan
                                WHERE VP.IdVehiculo = @IdVehiculo
                                  AND VP.EstadoContrato IN ('Activa', 'Programada')
                                  AND TP2.Nombre IN (N'Membresía', N'Mensualidad')
                                  AND VP.FechaFin >= CAST(GETDATE() AS DATE)
                                  AND @FechaInicio <= VP.FechaFin
                                  AND @FechaFin >= VP.FechaInicio
                            )
                            BEGIN
                                THROW 51014, 'El período de la nueva mensualidad se solapa con una membresía o mensualidad existente.', 1;
                            END;


                            /* =====================================================
                               10. DETERMINAR ESTADO DEL CONTRATO
                               ===================================================== */

                            IF @FechaInicio > CAST(GETDATE() AS DATE)
                            BEGIN
                                SET @EstadoContrato = 'Programada';
                            END
                            ELSE
                            BEGIN
                                SET @EstadoContrato = 'Activa';
                            END;


                            /* =====================================================
                               11. INSERTAR VEHICULOPLAN (Usando IdPlanTarifa en lugar de IdPlan)
                               ===================================================== */

                            INSERT INTO VehiculoPlan
                            (
                                IdVehiculo,
                                IdPlanTarifa,
                                FechaInicio,
                                FechaFin,
                                PrecioContratado,
                                EstadoContrato,
                                EstadoPago,
                                FechaPago,
                                FechaRegistro
                            )
                            VALUES
                            (
                                @IdVehiculo,
                                @IdPlanTarifaMensualidad,
                                @FechaInicio,
                                @FechaFin,
                                @ValorTarifa,
                                @EstadoContrato,
                                'Pendiente',
                                NULL,
                                GETDATE()
                            );


                            /* =====================================================
                               12. AUDITORÍA (Usando IdUsuario en lugar de UsuarioID)
                               ===================================================== */

                            INSERT INTO AuditoriaLog
                            (
                                UsuarioID,
                                Accion,
                                Fecha,
                                Detalle
                            )
                            VALUES
                            (
                                @IdUsuarioLogin,
                                N'Nueva Mensualidad',
                                GETDATE(),
                                CONCAT(
                                    N'Vehículo: ', @IdVehiculo,
                                    N' | Tipo vehículo: ', @IdTipoVehiculo,
                                    N' | Categoría: ', @IdCategoriaVehiculo,
                                    N' | Plan: ', @IdPlan,
                                    N' | PlanTarifa: ', @IdPlanTarifaMensualidad,
                                    N' | Inicio: ', CONVERT(VARCHAR(10), @FechaInicio, 103),
                                    N' | Fin: ', CONVERT(VARCHAR(10), @FechaFin, 103),
                                    N' | Valor tarifa: $', CONVERT(VARCHAR(30), @ValorTarifa),
                                    N' | Unidad: ', @Unidad,
                                    N' | Cantidad: ', @Cantidad,
                                    N' | Estado contrato: ', @EstadoContrato,
                                    N' | Estado pago: Pendiente'
                                )
                            );


                            COMMIT TRANSACTION;

                        END TRY
                        BEGIN CATCH
                            IF @@TRANCOUNT > 0
                                ROLLBACK TRANSACTION;

                            THROW;
                        END CATCH;
                        ";

                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No fue posible registrar la mensualidad.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');

                string codigoError = partes.Length > 0 ? partes[0].Trim() : string.Empty;
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                switch (codigoError)
                {
                    case "51001":
                        MessageBox.Show("El vehículo no existe o no tiene tipo de vehículo configurado.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51002":
                        MessageBox.Show("El vehículo no tiene categoría de vehículo configurada.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51003":
                        MessageBox.Show("El vehículo se encuentra inactivo.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51004":
                        MessageBox.Show("El vehículo es VIP y no puede tener mensualidad.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    case "51005":
                        MessageBox.Show("El plan no existe o se encuentra inactivo.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51006":
                        MessageBox.Show("El plan seleccionado no corresponde a una mensualidad.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51007":
                        MessageBox.Show("No existe una tarifa activa para el plan seleccionado.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51008":
                        MessageBox.Show("La tarifa de la mensualidad no tiene un valor configurado.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51009":
                        MessageBox.Show("La mensualidad no tiene una unidad de vigencia configurada.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51010":
                        MessageBox.Show("La mensualidad debe tener una vigencia de uno o más meses.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51011":
                        MessageBox.Show("La cantidad de meses debe ser igual o superior a 1.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51012":
                        MessageBox.Show("Una mensualidad por mes calendario debe iniciar el primer día del mes.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51013":
                        MessageBox.Show("La modalidad de vigencia de la mensualidad no es válida.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "51014":
                        MessageBox.Show("El período de la nueva mensualidad se solapa con una membresía o mensualidad existente.", "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    default:
                        MessageBox.Show("Error al registrar la mensualidad.\n" + mensaje, "Nueva Mensualidad", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                }

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        /*recibir pago membresía - mensualidad*/

        #region pago_membresia_mensualidad
        public async Task<bool> RecibirPagoMembresiaMensualidad(string IdVehiculoPlan, string IdMetodoPago, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdVehiculoPlan", Convert.ToInt32(IdVehiculoPlan)),
                    new KeyValuePair<string, object>("@IdMetodoPago", Convert.ToInt32(IdMetodoPago)),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin))
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"
                SET XACT_ABORT ON;

                BEGIN TRY

                    BEGIN TRANSACTION;

                    DECLARE @IdVehiculo INT;
                    DECLARE @IdPlanTarifa INT;

                    DECLARE @PrecioContratado DECIMAL(18,2);

                    DECLARE @FechaInicio DATE;
                    DECLARE @FechaFin DATE;

                    DECLARE @EstadoContrato VARCHAR(20);
                    DECLARE @EstadoPago VARCHAR(20);

                    DECLARE @TipoPlan NVARCHAR(50);
                    DECLARE @EsVIP BIT;

                    DECLARE @IdCobro INT;
                    DECLARE @IdPago INT;

                    DECLARE @FechaActual DATE;

                    SET @FechaActual = CAST(GETDATE() AS DATE);


                    /* =====================================================
                       1. OBTENER CONTRATACIÓN (Siguiendo la relación correcta)
                       ===================================================== */

                    SELECT
                        @IdVehiculo = VP.IdVehiculo,
                        @IdPlanTarifa = VP.IdPlanTarifa,
                        @PrecioContratado = VP.PrecioContratado,
                        @FechaInicio = VP.FechaInicio,
                        @FechaFin = VP.FechaFin,
                        @EstadoContrato = VP.EstadoContrato,
                        @EstadoPago = VP.EstadoPago,
                        @EsVIP = V.EsVIP,
                        @TipoPlan = TP.Nombre

                    FROM VehiculoPlan VP

                    INNER JOIN Vehiculo V
                        ON V.Idvehiculo = VP.IdVehiculo

                    INNER JOIN PlanTarifa PT
                        ON PT.IdPlanTarifa = VP.IdPlanTarifa

                    INNER JOIN [Plan] P
                        ON P.IdPlan = PT.IdPlan

                    INNER JOIN TipoPlan TP
                        ON TP.IdTipoPlan = P.IdTipoPlan

                    WHERE VP.IdVehiculoPlan = @IdVehiculoPlan;


                    /* =====================================================
                       2. VALIDAR QUE EXISTA
                       ===================================================== */

                    IF @IdVehiculo IS NULL
                    BEGIN
                        THROW 52001, 'La membresía o mensualidad no existe.', 1;
                    END;


                    /* =====================================================
                       3. VALIDAR TIPO DE PLAN
                       ===================================================== */

                    IF @TipoPlan NOT IN (N'Membresía', N'Mensualidad')
                    BEGIN
                        THROW 52002, 'La contratación seleccionada no corresponde a una membresía o mensualidad.', 1;
                    END;


                    /* =====================================================
                       4. VALIDAR VEHÍCULO VIP
                       ===================================================== */

                    IF @EsVIP = 1
                    BEGIN
                        THROW 52003, 'El vehículo es VIP. Los vehículos VIP no pagan membresía ni mensualidad.', 1;
                    END;


                    /* =====================================================
                       5. VALIDAR CONTRATO CANCELADO
                       ===================================================== */

                    IF @EstadoContrato = 'Cancelada'
                    BEGIN
                        THROW 52004, 'No se puede recibir el pago de una contratación cancelada.', 1;
                    END;


                    /* =====================================================
                       6. VALIDAR SI YA ESTÁ PAGADO
                       ===================================================== */

                    IF @EstadoPago = 'Pagado'
                    BEGIN
                        THROW 52005, 'La membresía o mensualidad ya se encuentra pagada.', 1;
                    END;


                    /* =====================================================
                       7. VALIDAR FECHAS
                       ===================================================== */

                    IF @FechaInicio IS NULL OR @FechaFin IS NULL
                    BEGIN
                        THROW 52006, 'La contratación não tiene correctamente configurada su vigencia.', 1;
                    END;


                    IF @FechaFin < @FechaInicio
                    BEGIN
                        THROW 52007, 'La fecha final de la contratación no puede ser menor que la fecha inicial.', 1;
                    END;


                    /* =====================================================
                       8. VALIDAR SI YA ESTÁ VENCIDA
                       ===================================================== */

                    IF @FechaActual > @FechaFin
                    BEGIN
                        THROW 52008, 'La contratación ya se encuentra vencida y no puede recibir pago. Debe crear una nueva contratación.', 1;
                    END;


                    /* =====================================================
                       9. VALIDAR MÉTODO DE PAGO
                       ===================================================== */

                    IF NOT EXISTS
                    (
                        SELECT 1
                        FROM MetodoPago
                        WHERE IdMetodoPago = @IdMetodoPago
                          AND Estado = 1
                    )
                    BEGIN
                        THROW 52009, 'El método de pago no existe o se encuentra inactivo.', 1;
                    END;


                    /* =====================================================
                       10. DETERMINAR ESTADO DEL CONTRATO DESPUÉS DEL PAGO
                       ===================================================== */

                    IF @FechaActual >= @FechaInicio AND @FechaActual <= @FechaFin
                    BEGIN
                        SET @EstadoContrato = 'Activa';
                    END
                    ELSE IF @FechaActual < @FechaInicio
                    BEGIN
                        SET @EstadoContrato = 'Programada';
                    END
                    ELSE
                    BEGIN
                        THROW 52010, 'No se puede activar una contratación cuyo período ya terminó.', 1;
                    END;


                    /* =====================================================
                       11. ACTUALIZAR VEHICULOPLAN
                       ===================================================== */

                    UPDATE VehiculoPlan
                    SET
                        EstadoPago = 'Pagado',
                        FechaPago = GETDATE(),
                        EstadoContrato = @EstadoContrato
                    WHERE IdVehiculoPlan = @IdVehiculoPlan;


                    IF @@ROWCOUNT = 0
                    BEGIN
                        THROW 52011, 'No fue posible actualizar la contratación.', 1;
                    END;


                    /* =====================================================
                       12. CREAR COBRO
                       ===================================================== */

                    INSERT INTO Cobro
                    (
                        IdVehiculo,
                        IdVehiculoPlan,
                        FechaCobro,
                        Subtotal,
                        Descuento,
                        Total,
                        Estado,
                        IdUsuario
                    )
                    VALUES
                    (
                        @IdVehiculo,
                        @IdVehiculoPlan,
                        GETDATE(),
                        @PrecioContratado,
                        0,
                        @PrecioContratado,
                        'Pagado',
                        @IdUsuarioLogin
                    );

                    SET @IdCobro = CONVERT(INT, SCOPE_IDENTITY());


                    /* =====================================================
                       13. CREAR DETALLE DEL COBRO
                       ===================================================== */

                    INSERT INTO CobroDetalle
                    (
                        IdCobro,
                        Concepto,
                        IdPlanTarifa,
                        FechaHoraInicio,
                        FechaHoraFin,
                        Minutos,
                        Cantidad,
                        PrecioUnitario,
                        Total
                    )
                    VALUES
                    (
                        @IdCobro,
                        CASE
                            WHEN @TipoPlan = N'Membresía' THEN 'Membresia'
                            WHEN @TipoPlan = N'Mensualidad' THEN 'Mensualidad'
                        END,
                        @IdPlanTarifa,
                        CAST(@FechaInicio AS DATETIME2(0)),
                        DATEADD(SECOND, -1, DATEADD(DAY, 1, CAST(@FechaFin AS DATETIME2(0)))),
                        NULL,
                        1,
                        @PrecioContratado,
                        @PrecioContratado
                    );


                    /* =====================================================
                       14. REGISTRAR PAGO
                       ===================================================== */

                    INSERT INTO Pago
                    (
                        IdCobro,
                        IdVehiculoPlan,
                        FechaPago,
                        IdMetodoPago,
                        ValorPagado,
                        Estado,
                        UsuarioID
                    )
                    VALUES
                    (
                        @IdCobro,
                        @IdVehiculoPlan,
                        GETDATE(),
                        @IdMetodoPago,
                        @PrecioContratado,
                        'Pagado',
                        @IdUsuarioLogin
                    );

                    SET @IdPago = CONVERT(INT, SCOPE_IDENTITY());


                    /* =====================================================
                       15. AUDITORÍA
                       ===================================================== */

                    INSERT INTO AuditoriaLog
                    (
                        UsuarioID,
                        Accion,
                        Fecha,
                        Detalle
                    )
                    VALUES
                    (
                        @IdUsuarioLogin,
                        CASE
                            WHEN @TipoPlan = N'Membresía' THEN N'Pago Membresía'
                            ELSE N'Pago Mensualidad'
                        END,
                        GETDATE(),
                        CONCAT(
                            N'Vehículo: ', @IdVehiculo,
                            N' | VehiculoPlan: ', @IdVehiculoPlan,
                            N' | Tipo: ', @TipoPlan,
                            N' | Inicio: ', CONVERT(VARCHAR(10), @FechaInicio, 103),
                            N' | Fin: ', CONVERT(VARCHAR(10), @FechaFin, 103),
                            N' | Valor pagado: $', CONVERT(VARCHAR(30), @PrecioContratado),
                            N' | Método pago: ', @IdMetodoPago,
                            N' | IdCobro: ', @IdCobro,
                            N' | IdPago: ', @IdPago,
                            N' | Estado contrato: ', @EstadoContrato
                        )
                    );


                    COMMIT TRANSACTION;

                END TRY
                BEGIN CATCH
                    IF @@TRANCOUNT > 0
                        ROLLBACK TRANSACTION;

                    THROW;
                END CATCH;
                ";

                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No fue posible registrar el pago.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');

                string codigoError = partes.Length > 0 ? partes[0].Trim() : string.Empty;
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)).Trim() : mensajeError;

                switch (codigoError)
                {
                    case "52001":
                        MessageBox.Show("La membresía o mensualidad no existe.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "52002":
                        MessageBox.Show("La contratación seleccionada no corresponde a una membresía o mensualidad.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "52003":
                        MessageBox.Show("El vehículo es VIP. Los vehículos VIP no pagan membresía ni mensualidad.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    case "52004":
                        MessageBox.Show("No se puede recibir el pago porque la contratación está cancelada.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "52005":
                        MessageBox.Show("La membresía o mensualidad ya se encuentra pagada.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    case "52006":
                        MessageBox.Show("La contratación no tiene correctamente configurada su vigencia.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "52007":
                        MessageBox.Show("La fecha final no puede ser menor que la fecha inicial.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "52008":
                        MessageBox.Show("La contratación ya está vencida. Debe crear una nueva contratación.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "52009":
                        MessageBox.Show("El método de pago no existe o está inactivo.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "52010":
                        MessageBox.Show("No se puede activar una contratación cuyo período ya terminó.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "52011":
                        MessageBox.Show("No fue posible actualizar la contratación.", "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                    default:
                        MessageBox.Show("Error al registrar el pago.\n\n" + mensaje, "Registrar Pago", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                }

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region eliminar_plan
        public async Task<bool> EliminarMembresiaMensualidad(string IdVehiculoPlan, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdVehiculoPlan", Convert.ToInt32(IdVehiculoPlan)),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin))
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"
                    SET XACT_ABORT ON;

                    BEGIN TRY

                        BEGIN TRANSACTION;

                        DECLARE @IdVehiculo INT;
                        DECLARE @IdPlan INT;

                        DECLARE @FechaInicio DATE;
                        DECLARE @FechaFin DATE;

                        DECLARE @PrecioContratado DECIMAL(18,2);

                        DECLARE @EstadoContrato VARCHAR(20);
                        DECLARE @EstadoPago VARCHAR(20);

                        DECLARE @NombrePlan NVARCHAR(100);
                        DECLARE @Placa VARCHAR(10);

                        DECLARE @TipoPlan NVARCHAR(50);

                        DECLARE @TieneCobro BIT = 0;
                        DECLARE @TienePago BIT = 0;


                        /* =====================================================
                           1. OBTENER Y BLOQUEAR LA CONTRATACIÓN
                           ===================================================== */

                        SELECT
                            @IdVehiculo = VP.IdVehiculo,
                            @IdPlan = P.IdPlan,
                            @FechaInicio = VP.FechaInicio,
                            @FechaFin = VP.FechaFin,
                            @PrecioContratado = VP.PrecioContratado,
                            @EstadoContrato = VP.EstadoContrato,
                            @EstadoPago = VP.EstadoPago,
                            @NombrePlan = P.Nombre,
                            @TipoPlan = TP.Nombre,
                            @Placa = V.Placa

                        FROM VehiculoPlan VP WITH (UPDLOCK, HOLDLOCK)

                        INNER JOIN Vehiculo V
                            ON V.Idvehiculo = VP.IdVehiculo

                        INNER JOIN PlanTarifa PT
                            ON PT.IdPlanTarifa = VP.IdPlanTarifa

                        INNER JOIN [Plan] P
                            ON P.IdPlan = PT.IdPlan

                        INNER JOIN TipoPlan TP
                            ON TP.IdTipoPlan = P.IdTipoPlan

                        WHERE VP.IdVehiculoPlan = @IdVehiculoPlan;


                        /* =====================================================
                           2. VALIDAR QUE EXISTA
                           ===================================================== */

                        IF @IdVehiculo IS NULL
                        BEGIN
                            THROW 53001,
                                'La membresía o mensualidad no existe.',
                                1;
                        END;


                        /* =====================================================
                           3. VALIDAR TIPO DE CONTRATACIÓN
                           ===================================================== */

                        IF @TipoPlan NOT IN
                        (
                            N'Membresía',
                            N'Mensualidad'
                        )
                        BEGIN
                            THROW 53002,
                                'La contratación seleccionada no corresponde a una membresía o mensualidad.',
                                1;
                        END;


                        /* =====================================================
                           4. VALIDAR ESTADO DE PAGO
                           ===================================================== */

                        IF @EstadoPago <> 'Pendiente'
                        BEGIN

                            IF @EstadoPago = 'Pagado'
                            BEGIN
                                THROW 53003,
                                    'No se puede eliminar la contratación porque ya fue pagada. Debe realizarse un proceso de cancelación y reverso.',
                                    1;
                            END;

                            IF @EstadoPago = 'Anulado'
                            BEGIN
                                THROW 53004,
                                    'La contratación tiene un pago anulado y no debe eliminarse físicamente.',
                                    1;
                            END;

                            THROW 53005,
                                'La contratación no está en un estado permitido para eliminación.',
                                1;
                        END;


                        /* =====================================================
                           5. VALIDAR ESTADO DEL CONTRATO
                           ===================================================== */

                        IF @EstadoContrato = 'Vencida'
                        BEGIN
                            THROW 53006,
                                'La contratación ya está vencida. No se puede eliminar el historial.',
                                1;
                        END;


                        IF @EstadoContrato = 'Cancelada'
                        BEGIN
                            THROW 53007,
                                'La contratación ya está cancelada.',
                                1;
                        END;


                        IF @EstadoContrato NOT IN
                        (
                            'Programada',
                            'Activa'
                        )
                        BEGIN
                            THROW 53008,
                                'El estado actual de la contratación no permite su eliminación.',
                                1;
                        END;


                        /* =====================================================
                           6. COMPROBAR COBROS
                           ===================================================== */

                        IF EXISTS
                        (
                            SELECT 1
                            FROM Cobro
                            WHERE IdVehiculoPlan = @IdVehiculoPlan
                        )
                        BEGIN
                            SET @TieneCobro = 1;
                        END;


                        IF @TieneCobro = 1
                        BEGIN
                            THROW 53009,
                                'No se puede eliminar la contratación porque ya tiene un cobro asociado.',
                                1;
                        END;


                        /* =====================================================
                           7. COMPROBAR PAGOS
                           ===================================================== */

                        IF EXISTS
                        (
                            SELECT 1
                            FROM Pago
                            WHERE IdVehiculoPlan = @IdVehiculoPlan
                        )
                        BEGIN
                            SET @TienePago = 1;
                        END;


                        IF @TienePago = 1
                        BEGIN
                            THROW 53010,
                                'No se puede eliminar la contratación porque ya tiene un pago asociado.',
                                1;
                        END;


                        /* =====================================================
                           8. REGISTRAR AUDITORÍA ANTES DEL DELETE
                           ===================================================== */

                        INSERT INTO AuditoriaLog
                        (
                            UsuarioID,
                            Accion,
                            Fecha,
                            Detalle
                        )
                        VALUES
                        (
                            @IdUsuarioLogin,
                            N'Eliminó Membresía/Mensualidad',
                            GETDATE(),
                            LEFT(
                                CONCAT(
                                    N'VehiculoPlan: ', @IdVehiculoPlan,
                                    N' | Vehículo: ', @IdVehiculo,
                                    N' | Placa: ', @Placa,
                                    N' | Plan: ', @NombrePlan,
                                    N' | Tipo: ', @TipoPlan,
                                    N' | Fecha inicio: ',
                                    CONVERT(VARCHAR(10), @FechaInicio, 103),
                                    N' | Fecha fin: ',
                                    CONVERT(VARCHAR(10), @FechaFin, 103),
                                    N' | Precio contratado: $',
                                    CONVERT(VARCHAR(30), @PrecioContratado),
                                    N' | Estado contrato: ',
                                    @EstadoContrato,
                                    N' | Estado pago: ',
                                    @EstadoPago
                                ),
                                400
                            )
                        );


                        /* =====================================================
                           9. ELIMINAR CONTRATACIÓN
                           ===================================================== */

                        DELETE FROM VehiculoPlan
                        WHERE IdVehiculoPlan = @IdVehiculoPlan;


                        IF @@ROWCOUNT = 0
                        BEGIN
                            THROW 53011,
                                'No fue posible eliminar la contratación.',
                                1;
                        END;


                        COMMIT TRANSACTION;

                    END TRY
                    BEGIN CATCH
                        IF @@TRANCOUNT > 0
                            ROLLBACK TRANSACTION;

                        THROW;
                    END CATCH;
                    ";

                    if (await conexionBD.InsertAsync(
                        strSQL,
                        CommandType.Text,
                        parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No fue posible eliminar la membresía o mensualidad.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');

                string codigoError =
                    partes.Length > 0
                        ? partes[0].Trim()
                        : string.Empty;

                string mensaje =
                    partes.Length > 1
                        ? string.Join("-", partes.Skip(1)).Trim()
                        : mensajeError;


                switch (codigoError)
                {
                    case "53001":
                        MessageBox.Show("La membresía o mensualidad seleccionada no existe.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "53002":
                        MessageBox.Show("La contratación seleccionada no corresponde a una membresía o mensualidad.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "53003":
                        MessageBox.Show("No se puede eliminar porque la contratación ya fue pagada.\n\nDebe utilizar el proceso de cancelación y reverso del pago.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "53004":
                        MessageBox.Show("La contratación tiene un pago anulado y debe conservarse como historial.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "53005":
                        MessageBox.Show("La contratación no se encuentra en un estado permitido para eliminación.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "53006":
                        MessageBox.Show("La contratación está vencida y debe conservarse como historial.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    case "53007":
                        MessageBox.Show("La contratación ya está cancelada.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    case "53008":
                        MessageBox.Show("El estado de la contratación no permite su eliminación.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "53009":
                        MessageBox.Show("No se puede eliminar porque la contratación ya tiene un cobro asociado.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "53010":
                        MessageBox.Show("No se puede eliminar porque la contratación ya tiene un pago asociado.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Warning);
                        break;
                    case "53011":
                        MessageBox.Show("No fue posible eliminar la contratación.", "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                    default:
                        MessageBox.Show("Error al eliminar la membresía o mensualidad.\n" + mensaje, "Eliminar Membresía / Mensualidad", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                }

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        /*resumen: *total clientes *total vehículos registrados *vehículos vip *vehículos con membresía *vehículos con mensualidad*/
        #region listado_resumen_planes_cliente
        public async Task<DataSet> ResumenPlanesClienteAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"/* =========================================================
                                       RESUMEN GENERAL DE CLIENTES Y VEHÍCULOS
                                       ========================================================= */
                                    SELECT 
                                        /* ==========================================
                                           TOTAL CLIENTES ACTIVOS
                                           ========================================== */
                                        (
                                            SELECT COUNT(*)
                                            FROM Cliente C
                                            WHERE C.Activo = 1
                                        ) AS TotalClientes,

                                        /* ==========================================
                                           TOTAL VEHÍCULOS ACTIVOS
                                           ========================================== */
                                        (
                                            SELECT COUNT(*)
                                            FROM Vehiculo V
                                            WHERE V.Activo = 1
                                        ) AS TotalVehiculos,

                                        /* ==========================================
                                           VEHÍCULOS VIP ACTIVOS
                                           ========================================== */
                                        (
                                            SELECT COUNT(*)
                                            FROM Vehiculo V
                                            WHERE V.Activo = 1
                                              AND V.EsVIP = 1
                                        ) AS VehiculosVIP,

                                        /* ==========================================
                                           VEHÍCULOS CON MEMBRESÍA VIGENTE
                                           ========================================== */
                                        (
                                            SELECT COUNT(DISTINCT VP.IdVehiculo)
                                            FROM VehiculoPlan VP
                                            INNER JOIN PlanTarifa PT 
                                                ON PT.IdPlanTarifa = VP.IdPlanTarifa
                                            INNER JOIN [Plan] P
                                                ON P.IdPlan = PT.IdPlan
                                            INNER JOIN TipoPlan TP
                                                ON TP.IdTipoPlan = P.IdTipoPlan
                                            INNER JOIN Vehiculo V
                                                ON V.IdVehiculo = VP.IdVehiculo
                                            WHERE V.Activo = 1
                                              AND TP.Nombre = N'Membresía'
                                              AND VP.EstadoPago IN ('Pagado', 'Pendiente') -- <-- Permitir ambos estados
                                              AND VP.EstadoContrato <> 'Cancelada'
                                              AND CAST(GETDATE() AS DATE) BETWEEN VP.FechaInicio AND VP.FechaFin
                                        ) AS VehiculosMembresia,

                                        /* ==========================================
                                           VEHÍCULOS CON MENSUALIDAD VIGENTE
                                           ========================================== */
                                        (
                                            SELECT COUNT(DISTINCT VP.IdVehiculo)
                                            FROM VehiculoPlan VP
                                            INNER JOIN PlanTarifa PT 
                                                ON PT.IdPlanTarifa = VP.IdPlanTarifa
                                            INNER JOIN [Plan] P
                                                ON P.IdPlan = PT.IdPlan
                                            INNER JOIN TipoPlan TP
                                                ON TP.IdTipoPlan = P.IdTipoPlan
                                            INNER JOIN Vehiculo V
                                                ON V.IdVehiculo = VP.IdVehiculo
                                            WHERE V.Activo = 1
                                              AND TP.Nombre = N'Mensualidad'
                                              AND VP.EstadoPago = 'Pagado'
                                              AND VP.EstadoContrato <> 'Cancelada'
                                              AND CAST(GETDATE() AS DATE) BETWEEN VP.FechaInicio AND VP.FechaFin
                                        ) AS VehiculosMensualidad;";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al resumen obtener planes.\n{conexionBD.StrError}\n{error.Message}", "Planes", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion
    }
}