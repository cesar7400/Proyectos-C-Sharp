﻿using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Parking.Controller
{
    public class Clientes_
    {
        private readonly ConexionBD conexionBD = new ConexionBD();

        #region cliente_nuevo
        public async Task<bool> NuevoCliente(string Documentoid, string Nombre, string tipoDocumento, string Documento, string Celular, string email, string IdUsuarioLogin)
        {
            bool b = false;
            try
            {
                // Validar si el email está vacío o solo tiene espacios y convertirlo a NULL
                object emailValor = string.IsNullOrWhiteSpace(email) ? DBNull.Value : (object)email;
                object celularValor = string.IsNullOrWhiteSpace(Celular) ? DBNull.Value : (object)Celular;

                List<KeyValuePair<string, object>> parametros = null;
                // Preparamos los parámetros para un nuevo usuario
                parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Documentoid", Documentoid),
                    new KeyValuePair<string, object>("@Nombre", Nombre),
                    new KeyValuePair<string, object>("@Documento", Documento),
                    new KeyValuePair<string, object>("@Celular", celularValor),
                    new KeyValuePair<string, object>("@email", emailValor),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", IdUsuarioLogin),
                    new KeyValuePair<string, object>("@detalle", $"Agrego Cliente: '{Nombre}' - Documento: {tipoDocumento} {Documento}"),
                };

                // Abrimos conexión
                if (await conexionBD.Connection())
                {
                    // Ejecutamos el método insert para rgistrar usuario nuevo
                    var strSQL = @"DECLARE @lastID INT
                                   begin try
                                   begin transaction
                                   IF EXISTS (SELECT * FROM Cliente WHERE Documento = @Documento)
                                    BEGIN
	                                    UPDATE Cliente SET Documentoid = @Documentoid, Nombre = @Nombre, Documento = @Documento, Celular = @Celular, email = @email, Activo = 1 WHERE Documento = @Documento;
                                    END
                                    ELSE
                                    BEGIN
                                    -- Obtiene el último ID de Cliente
                                    SELECT @lastID = MAX(Idcliente) FROM Cliente;
                                    IF @lastID IS NULL
                                    BEGIN
                                    SET @lastID = 0
                                    END
                                    SET IDENTITY_INSERT Cliente ON;
                                    -- Inserta en la tabla Cliente con ID manual (lastID+1)
                                    insert into Cliente (Idcliente, Documentoid, Nombre, Documento, Celular, email) 
                                    values(@lastID+1, @Documentoid, @Nombre, @Documento, @Celular, @email);
                                    SET IDENTITY_INSERT Cliente OFF;
                                    -- Registra en Auditoria que se agregó un Cliente
                                    END 
                                    INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                    VALUES(@IdUsuarioLogin, N'Agrego Nuevo Cliente', GETDATE(), @detalle);
                                    commit transaction
                                    end try
                                   begin catch
                                   rollback transaction
                                   SET IDENTITY_INSERT Cliente OFF;
                                   DECLARE @numeroDeError INT = ERROR_NUMBER();
                                   THROW  -- Relanza el error
                                   end catch";
                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        // Lanzamos una excepción manualmente usando el error guardado
                        throw new Exception();
                    }
                }
            }
            catch (Exception error)
            {
                string codigoError = string.Empty;
                string mensajeSql = string.Empty;

                if (!string.IsNullOrEmpty(conexionBD.StrError))
                {
                    string[] partes = conexionBD.StrError.Split('-');
                    codigoError = partes[0].Trim();
                    mensajeSql = partes.Length > 1 ? string.Join("-", partes.Skip(1)) : conexionBD.StrError;
                }

                if (codigoError == "2627" || codigoError == "2601")
                {
                    if (mensajeSql.Contains("UQ_Clientea_Tipo_Documento"))
                    {
                        MessageBox.Show($"El tipo y número de documento '{Documento}' ya se encuentran registrados.", "Documento Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    else if (mensajeSql.Contains("UX_Cliente_Email"))
                    {
                        MessageBox.Show($"El correo electrónico '{email}' ya se encuentra registrado.", "Correo Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    else
                    {
                        MessageBox.Show("Ya existe un registro con los mismos datos únicos.", "Registro Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                else
                {
                    string detalleError = !string.IsNullOrEmpty(mensajeSql) ? mensajeSql : error.Message;
                    MessageBox.Show($"Error al guardar cliente.\n{detalleError}", "Error del Sistema", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return b;
        }
        #endregion

        #region listado_clientes
        public async Task<DataSet> ObtenerClientesAsync(string strValue, int pageNumber, int pageSize)
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"DECLARE @RowsPerPage INT = {pageSize};
                                    DECLARE @PageNumber INT = {pageNumber};
                                    DECLARE @filtro NVARCHAR(50) = '%{strValue}%';

                                    SELECT 
                                        Cliente.Idcliente, 
                                        Cliente.Nombre, 
                                        Tipo_Documento.Documentoid, 
                                        Tipo_Documento.Tipo, 
                                        Cliente.Documento, 
                                        Cliente.Celular, 
                                        Cliente.email, 
                                        ISNULL(
                                            FORMAT(Cliente.fecha_registro, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + 
                                            UPPER(FORMAT(Cliente.fecha_registro, 'hh:mm tt', 'en-US')), 
                                            ''
                                        ) AS fecha_registro
                                    FROM Cliente 
                                    INNER JOIN Tipo_Documento ON Cliente.Documentoid = Tipo_Documento.Documentoid
                                    WHERE CONCAT(Cliente.Nombre, ' ', Cliente.Documento, ' ', Cliente.email) COLLATE Latin1_General_CI_AI LIKE @filtro 
                                      AND Cliente.Activo = 1
                                    ORDER BY Cliente.Nombre ASC
                                    OFFSET (@PageNumber - 1) * @RowsPerPage ROWS
                                    FETCH NEXT @RowsPerPage ROWS ONLY;

                                    -- Totales
                                    SELECT COUNT(*)
                                    FROM  Cliente INNER JOIN Tipo_Documento ON Cliente.Documentoid = Tipo_Documento.Documentoid
                                    WHERE CONCAT(Cliente.Nombre, ' ', Cliente.Documento, ' ', Cliente.email) COLLATE Latin1_General_CI_AI LIKE @filtro AND Cliente.Activo = 1;
                
                                    SELECT COUNT(*)
                                    FROM  Cliente INNER JOIN Tipo_Documento ON Cliente.Documentoid = Tipo_Documento.Documentoid AND Cliente.Activo = 1;";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener usuarios.\n{conexionBD.StrError}\n{error.Message}", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region editar_cliente
        public async Task<bool> ActualizarCliente(string idcliente, string documentoid, string nombre, string documento, string celular, string email, string antes, string despues, string idUsuarioLogin)
        {
            bool b = false;
            try
            {
                // Validación para convertir cadenas vacías o en blanco en DBNull para evitar conflictos con UNIQUE
                object emailValor = string.IsNullOrWhiteSpace(email) ? DBNull.Value : (object)email;
                object celularValor = string.IsNullOrWhiteSpace(celular) ? DBNull.Value : (object)celular;

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Idcliente", idcliente),
                    new KeyValuePair<string, object>("@Documentoid", documentoid),
                    new KeyValuePair<string, object>("@Nombre", nombre),
                    new KeyValuePair<string, object>("@Documento", documento),
                    new KeyValuePair<string, object>("@Celular", celularValor),
                    new KeyValuePair<string, object>("@email", emailValor),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", idUsuarioLogin),
                    new KeyValuePair<string, object>("@detalle", $"Modifico Cliente: Antes:{antes}, Despues: {despues}"),
                };

                if (await conexionBD.Connection())
                {
                    var strSQL = @"
                            BEGIN TRY
                                BEGIN TRANSACTION;
                    
                                UPDATE Cliente 
                                SET Documentoid = @Documentoid, 
                                    Nombre = @Nombre, 
                                    Documento = @Documento, 
                                    Celular = @Celular, 
                                    email = @email 
                                WHERE Idcliente = @Idcliente;
                    
                                INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                VALUES (@IdUsuarioLogin, N'Modifico Cliente', GETDATE(), @detalle);
                    
                                COMMIT TRANSACTION;
                            END TRY
                            BEGIN CATCH
                                ROLLBACK TRANSACTION;
                                THROW;
                            END CATCH";

                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No se pudo ejecutar la actualización en la base de datos.");
                    }
                }
            }
            catch (Exception error)
            {
                string codigoError = string.Empty;
                string mensajeSql = string.Empty;

                if (!string.IsNullOrEmpty(conexionBD.StrError))
                {
                    string[] partes = conexionBD.StrError.Split('-');
                    codigoError = partes[0].Trim();
                    mensajeSql = partes.Length > 1 ? string.Join("-", partes.Skip(1)) : conexionBD.StrError;
                }

                if (codigoError == "2627" || codigoError == "2601")
                {
                    if (mensajeSql.Contains("UQ_Cliente_Email"))
                    {
                        MessageBox.Show($"El correo electrónico '{email}' ya se encuentra registrado por otro cliente.", "Correo Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    else if (mensajeSql.Contains("UQ_Clientea_Tipo_Documento"))
                    {
                        MessageBox.Show($"El tipo y número de documento '{documento}' ya se encuentran registrados por otro cliente.", "Documento Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    else
                    {
                        MessageBox.Show("Ya existe otro registro con los mismos datos únicos.", "Registro Duplicado", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                else
                {
                    string detalleError = !string.IsNullOrEmpty(mensajeSql) ? mensajeSql : error.Message;
                    MessageBox.Show($"Error al actualizar cliente.\n{detalleError}", "Error del Sistema", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return b;
        }
        #endregion

        #region inactivar_cliente
        public async Task<bool> InactivarCliente(string IdCliente, string IdUsuarioLogin)
        {
            bool b = false;

            try
            {
                string strSQL = "";

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdCliente", Convert.ToInt32(IdCliente)),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", Convert.ToInt32(IdUsuarioLogin))
                };

                if (await conexionBD.Connection())
                {
                    strSQL = @"
                        SET XACT_ABORT ON;

                        BEGIN TRY

                            BEGIN TRANSACTION;

                            DECLARE @NombreCliente VARCHAR(150);
                            DECLARE @Activo BIT;


                            /* =====================================================
                               1. OBTENER CLIENTE
                               ===================================================== */

                            SELECT
                                @NombreCliente = Nombre,
                                @Activo = Activo
                            FROM Cliente
                            WHERE Idcliente = @IdCliente;


                            IF @NombreCliente IS NULL
                            BEGIN
                                THROW 54001,
                                      'El cliente no existe.',
                                      1;
                            END;


                            /* =====================================================
                               2. VALIDAR ESTADO
                               ===================================================== */

                            IF @Activo = 0
                            BEGIN
                                THROW 54002,
                                      'El cliente ya se encuentra inactivo.',
                                      1;
                            END;


                            /* =====================================================
                               3. INACTIVAR CLIENTE

                               NO SE ELIMINAN:
                               - Vehiculos
                               - VehiculoPlan
                               - Cobros
                               - Pagos
                               ===================================================== */

                            UPDATE Cliente
                            SET
                                Activo = 0
                            WHERE Idcliente = @IdCliente;


                            IF @@ROWCOUNT = 0
                            BEGIN
                                THROW 54003,
                                      'No fue posible inactivar el cliente.',
                                      1;
                            END;


                            /* =====================================================
                               4. AUDITORÍA
                               ===================================================== */

                            INSERT INTO AuditoriaLog
                            (
                                UsuarioID,
                                Accion,
                                Fecha,
                                Detalle
                            )
                            VALUES
                            (
                                @IdUsuarioLogin,
                                N'Inactivó Cliente',
                                GETDATE(),

                                LEFT(
                                    CONCAT(
                                        N'Cliente: ', @IdCliente,
                                        N' | Nombre: ', @NombreCliente
                                    ),
                                    400
                                )
                            );


                            COMMIT TRANSACTION;

                        END TRY

                        BEGIN CATCH

                            IF @@TRANCOUNT > 0
                                ROLLBACK TRANSACTION;

                            THROW;

                        END CATCH;
                        ";

                    if (await conexionBD.InsertAsync(
                        strSQL,
                        CommandType.Text,
                        parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception("No fue posible inactivar el cliente.");
                    }
                }
            }
            catch (Exception error)
            {
                string mensajeError = conexionBD.StrError;

                if (string.IsNullOrWhiteSpace(mensajeError))
                {
                    mensajeError = error.Message;
                }

                string[] partes = mensajeError.Split('-');

                string codigoError =
                    partes.Length > 0
                        ? partes[0].Trim()
                        : string.Empty;

                string mensaje =
                    partes.Length > 1
                        ? string.Join("-", partes.Skip(1)).Trim()
                        : mensajeError;


                switch (codigoError)
                {
                    case "54001":

                        MessageBox.Show(
                            "El cliente no existe.",
                            "Eliminar Cliente",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);

                        break;

                    case "54002":

                        MessageBox.Show(
                            "El cliente ya se encuentra inactivo.",
                            "Eliminar Cliente",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);

                        break;

                    case "54003":

                        MessageBox.Show(
                            "No fue posible inactivar el cliente.",
                            "Eliminar Cliente",
                            MessageBoxButton.OK,
                            MessageBoxImage.Error);

                        break;

                    default:

                        MessageBox.Show(
                            "Error al inactivar el cliente.\n\n" +
                            mensaje +
                            "\n\n" +
                            error.Message,
                            "Eliminar Cliente",
                            MessageBoxButton.OK,
                            MessageBoxImage.Error);

                        break;
                }

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion
    }
}