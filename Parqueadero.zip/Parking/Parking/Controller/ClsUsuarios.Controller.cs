﻿using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using static Parking.Models.UsuariosModel;

namespace Parking.Controller
{
    public class UsuariosController
    {
        #region usuario_nuevo
        public async Task<bool> NuevoUsuario(string Usuario, string NombreCompleto, string Password, byte DiasPermitidos, string Estado, string IdUsuarioLogin)
        {
            bool b = false;
            try
            {
                string strSQL = "";

                PasswordHasher.Create(Password, out byte[] hash, out byte[] salt);

                // Preparamos los parámetros para un nuevo usuario
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Usuario", Usuario),
                    new KeyValuePair<string, object>("@NombreCompleto", NombreCompleto),
                    new KeyValuePair<string, object>("@PasswordHash", hash),
                    new KeyValuePair<string, object>("@PasswordSalt", salt),
                    new KeyValuePair<string, object>("@DiasPermitidos", DiasPermitidos),
                    new KeyValuePair<string, object>("@Estado", Estado),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", IdUsuarioLogin),
                    new KeyValuePair<string, object>("@detalle", $"Se creó el usuario: '{Usuario}' - {NombreCompleto}"),
                };

                // Abrimos conexión
                if (await conexionBD.Connection())
                {
                    // Ejecutamos el método insert para rgistrar usuario nuevo
                    strSQL = @"DECLARE @lastID INT
                               begin try
                               begin transaction
                               -- Obtiene el último ID de usuario
                               SELECT @lastID = MAX(UsuarioID) FROM Usuarios;
                               IF @lastID IS NULL
                               BEGIN
                               SET @lastID = 0
                               END
                               SET IDENTITY_INSERT Usuarios ON;
                               -- Inserta en la tabla Usuarios con ID manual (lastID+1)
                               insert into Usuarios (UsuarioID, Usuario, NombreCompleto, PasswordHash, PasswordSalt, DiasPermitidos, Estado) 
                               values(@lastID+1, @Usuario, @NombreCompleto, @PasswordHash, @PasswordSalt, @DiasPermitidos, @Estado);
                               SET IDENTITY_INSERT Usuarios OFF;
                               -- Registra en Auditoria que se agregó un usuario
                               INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                               VALUES(@IdUsuarioLogin, N'Agrego Nuevo Usuario', GETDATE(), @detalle);
                               commit transaction
                               end try
                               begin catch
                               rollback transaction
                               SET IDENTITY_INSERT Usuarios OFF;
                               DECLARE @numeroDeError INT = ERROR_NUMBER();
                               THROW  -- Relanza el error
                               end catch";
                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        // Lanzamos una excepción manualmente usando el error guardado
                        throw new Exception();
                    }
                }
            }
            catch (Exception error)
            {
                // Si hubo error, divide el mensaje en código y descripción separados por '-'
                string[] partes = conexionBD.StrError.Split('-');
                string codigoError = partes[0]; // Obtiene el código de error (ej. "2627")
                // Si el mensaje tiene más partes, une las restantes como descripción
                string mensaje = partes.Length > 1 ? string.Join("-", partes.Skip(1)) : string.Empty;

                // Si el código de error es 2627 (violación de clave única)
                if (codigoError == "2627")
                {
                    // Patrón regex para extraer el valor entre paréntesis del mensaje de SQL Server
                    string pattern = @"\((.*?)\)";
                    string result = "";
                    MatchCollection matches = Regex.Matches(mensaje, pattern);
                    // Recorre las coincidencias y obtiene la primera (última) captura
                    foreach (Match match in matches)
                    {
                        result = match.Groups[1].Value.ToLower();
                    }
                    // Si el valor duplicado coincide con el usuario enviado, muestra mensaje específico
                    MessageBox.Show($"El nombre de usuario '{result}' ya se encuentra registrado", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    // Para cualquier otro error, muestra el mensaje completo
                    MessageBox.Show($"Error al guardar usuario.\n{partes[1]}\n{error.Message}", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return b;
        }
        #endregion

        #region listado_usuarios
        public async Task<DataSet> ObtenerUsuariosAsync(string strValue, int pageNumber, int pageSize)
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"DECLARE @RowsPerPage INT = {pageSize};
                                    DECLARE @PageNumber INT = {pageNumber};
                                    DECLARE @filtro NVARCHAR(50) = '%{strValue}%';

                                    SELECT UsuarioID, Usuario, NombreCompleto, DiasPermitidos, CambioPassword, Estado, 
                                    ISNULL(
                                       FORMAT(UltimoAcceso, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + 
                                       UPPER(FORMAT(UltimoAcceso, 'hh:mm tt', 'en-US')), 
                                       ''
                                    ) AS FechaUltimoAcceso,
                                    Permisos
                                    FROM Usuarios
                                    WHERE (Usuario + ' ' + NombreCompleto) COLLATE Latin1_General_CI_AI LIKE @filtro
                                    ORDER BY 
                                        -- Si es el ID 1, le asigna 0 (va primero), a los demás les asigna 1
                                        CASE WHEN UsuarioID = 1 THEN 0 ELSE 1 END, 
                                        NombreCompleto ASC
                                    OFFSET (@PageNumber - 1) * @RowsPerPage ROWS
                                    FETCH NEXT @RowsPerPage ROWS ONLY;

                                    -- Totales
                                    SELECT COUNT(*) FROM Usuarios 
                                    WHERE (Usuario + ' ' + NombreCompleto) COLLATE Latin1_General_CI_AI LIKE @filtro;
                
                                    SELECT COUNT(*) FROM Usuarios;";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener usuarios.\n{conexionBD.StrError}\n{error.Message}", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        public string ConvertirDias(byte dias)
        {
            List<string> lista = new List<string>();

            if ((dias & 1) != 0) lista.Add("Lunes");
            if ((dias & 2) != 0) lista.Add("Martes");
            if ((dias & 4) != 0) lista.Add("Miércoles");
            if ((dias & 8) != 0) lista.Add("Jueves");
            if ((dias & 16) != 0) lista.Add("Viernes");
            if ((dias & 32) != 0) lista.Add("Sábado");
            if ((dias & 64) != 0) lista.Add("Domigo");

            return string.Join(", ", lista);
        }
        #endregion

        #region inicio_sesion

        private readonly ConexionBD conexionBD = new ConexionBD();
        public async Task<LoginUsuarios> IniciarSesion(string nombreUsuario)
        {
            LoginUsuarios usuarioEncontrado = null; // Variable local para guardar el resultado
            try
            {
                // Preparamos los parámetros para el procedimiento almacenado
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@UsuarioIngresado", nombreUsuario)
                };

                // Abrimos conexión
                if (await conexionBD.Connection())
                {
                    // Ejecutamos el método read que ya tienes
                    // IMPORTANTE: Asegúrate de que devuelva la columna 'DiaPermitidoHoy'
                    string strSQL = @"SET NOCOUNT ON;
                                        SET DATEFIRST 1; -- Lunes = 1, Martes = 2, ..., Domingo = 7

                                        DECLARE @UsuarioID INT;
                                        DECLARE @Usuario NVARCHAR(50);
                                        DECLARE @NombreCompleto NVARCHAR(120);
                                        DECLARE @PasswordHash VARBINARY(32);
                                        DECLARE @PasswordSalt VARBINARY(16);
                                        DECLARE @DiasPermitidos TINYINT;
                                        DECLARE @cambioPassword BIT;
                                        DECLARE @Estado BIT;
                                        DECLARE @UltimoAcceso DATETIME;

                                        DECLARE @DiaActual INT;
                                        DECLARE @BitDia TINYINT;
                                        DECLARE @detalle NVARCHAR(100);
                                        DECLARE @Permisos NVARCHAR(MAX);
                                        BEGIN TRY
                                            BEGIN TRANSACTION;
                                            IF NOT EXISTS (SELECT 1 FROM Usuarios WHERE Usuario = @UsuarioIngresado)
                                            BEGIN
                                                ROLLBACK TRANSACTION;

                                                SELECT
                                                    0 AS LoginExitoso,
                                                    N'Usuario no válido.' AS Mensaje;
                                                RETURN;
                                            END
                                            -- Buscar usuario
                                            SELECT TOP 1
                                                @UsuarioID = UsuarioID,
                                                @Usuario = Usuario,
                                                @NombreCompleto = NombreCompleto,
                                                @PasswordHash = PasswordHash,
                                                @PasswordSalt = PasswordSalt,
                                                @DiasPermitidos = DiasPermitidos,
                                                @cambioPassword = cambioPassword,
                                                @Estado = Estado,
                                                @UltimoAcceso = UltimoAcceso,
                                                @Permisos = Permisos
                                            FROM Usuarios
                                            WHERE Usuario = @UsuarioIngresado;

                                            -- Validar estado
                                            IF @Estado = 0
                                            BEGIN
                                                ROLLBACK TRANSACTION;

                                                SELECT
                                                    0 AS LoginExitoso,
                                                    N'Usuario inactivo.' AS Mensaje;
                                                RETURN;
                                            END

                                            -- Validar día permitido
                                            SET @DiaActual = DATEPART(WEEKDAY, GETDATE());

                                            SET @BitDia = CASE @DiaActual
                                                WHEN 1 THEN 1   -- Lunes
                                                WHEN 2 THEN 2   -- Martes
                                                WHEN 3 THEN 4   -- Miércoles
                                                WHEN 4 THEN 8   -- Jueves
                                                WHEN 5 THEN 16  -- Viernes
                                                WHEN 6 THEN 32  -- Sábado
                                                WHEN 7 THEN 64  -- Domingo
                                            END;

                                            IF (@DiasPermitidos & @BitDia) = 0
                                            BEGIN
                                                -- Creamos una variable para armar la lista de días
                                                DECLARE @ListaDias NVARCHAR(MAX) = '';

                                                -- Evaluamos cada bit para concatenar el nombre del día
                                                IF (@DiasPermitidos & 1)  <> 0 SET @ListaDias += 'Lunes, ';
                                                IF (@DiasPermitidos & 2)  <> 0 SET @ListaDias += 'Martes, ';
                                                IF (@DiasPermitidos & 4)  <> 0 SET @ListaDias += 'Miércoles, ';
                                                IF (@DiasPermitidos & 8)  <> 0 SET @ListaDias += 'Jueves, ';
                                                IF (@DiasPermitidos & 16) <> 0 SET @ListaDias += 'Viernes, ';
                                                IF (@DiasPermitidos & 32) <> 0 SET @ListaDias += 'Sábado, ';
                                                IF (@DiasPermitidos & 64) <> 0 SET @ListaDias += 'Domingo, ';

                                                -- Limpiamos la última coma y espacio si hay días
                                                IF LEN(@ListaDias) > 0 
                                                    SET @ListaDias = LEFT(@ListaDias, LEN(@ListaDias) - 1);
                                                ELSE
                                                    SET @ListaDias = 'Ninguno (Consulte al administrador)';

                                                ROLLBACK TRANSACTION;
    
                                                -- Devolvemos el mensaje detallado
                                                SELECT 
                                                    0 AS LoginExitoso, 
                                                    N'Acceso denegado. Sus días permitidos son: ' + @ListaDias AS Mensaje;
                                                RETURN;
                                            END

                                            IF (@DiasPermitidos & @BitDia) <> 0 
                                            BEGIN
                                                SET @detalle = 'Usuario: ''' + @Usuario + ''' - ' + @NombreCompleto;
                                                -- Si todo está correcto, actualizar último acceso
                                                UPDATE Usuarios SET UltimoAcceso = GETDATE() WHERE UsuarioID = @UsuarioID;
                                                /* =====================================================
                                                   NORMALIZAR ESTADOS DE CONTRATACIONES
                                                   ===================================================== */

                                                    UPDATE VehiculoPlan
                                                    SET EstadoContrato =
                                                        CASE
                                                            WHEN EstadoContrato = 'Cancelada'
                                                                THEN 'Cancelada'

                                                            WHEN FechaFin < CAST(GETDATE() AS DATE)
                                                                THEN 'Vencida'

                                                            WHEN FechaInicio > CAST(GETDATE() AS DATE)
                                                                THEN 'Programada'

                                                            WHEN CAST(GETDATE() AS DATE)
                                                                 BETWEEN FechaInicio AND FechaFin
                                                                THEN 'Activa'

                                                            ELSE EstadoContrato
                                                        END
                                                    WHERE EstadoContrato <> 'Cancelada'
                                                -- Registra en Auditoria que se agregó un usuario
                                                INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                                VALUES(@UsuarioID, N'Inicio Sesión', GETDATE(), @detalle);
                                            END

                                            COMMIT TRANSACTION;

                                            -- Respuesta exitosa
                                            SELECT
                                                @UsuarioID AS UsuarioID,
                                                @Usuario AS Usuario,
                                                @NombreCompleto AS NombreCompleto,
                                                @PasswordHash AS PasswordHash,
                                                @PasswordSalt AS PasswordSalt,
                                                @DiasPermitidos AS DiasPermitidos,
                                                @cambioPassword AS cambioPassword,
                                                @Estado AS Estado,
                                                @Permisos AS Permisos,
                                                @UltimoAcceso AS UltimoAcceso
                                        END TRY
                                        BEGIN CATCH
                                            IF @@TRANCOUNT > 0
                                                ROLLBACK TRANSACTION;

                                            SELECT
                                                0 AS LoginExitoso,
                                                ERROR_MESSAGE() AS Mensaje;
                                        END CATCH;";
                    if (await conexionBD.ReadAsync(strSQL, CommandType.Text, parametros))
                    {
                        if (conexionBD.SqlDataReader != null && await conexionBD.SqlDataReader.ReadAsync())
                        {
                            // Verificamos si existe la columna "Mensaje" (esto indica un error de lógica en el SQL)
                            // Usamos un método para verificar si la columna existe antes de pedirla
                            bool tieneMensaje = Enumerable.Range(0, conexionBD.SqlDataReader.FieldCount).Any(i => conexionBD.SqlDataReader.GetName(i) == "Mensaje");

                            if (tieneMensaje)
                            {
                                usuarioEncontrado = new LoginUsuarios
                                {
                                    LoginUsuario = conexionBD.SqlDataReader["LoginExitoso"].ToString(),
                                    Mensaje = conexionBD.SqlDataReader["Mensaje"].ToString()
                                };
                            }
                            else
                            {
                                usuarioEncontrado = new LoginUsuarios
                                {
                                    IdUsuario = (int)conexionBD.SqlDataReader["UsuarioID"],
                                    UsuarioLogin = conexionBD.SqlDataReader["Usuario"].ToString(),
                                    NombreCompleto = conexionBD.SqlDataReader["NombreCompleto"].ToString(),
                                    PasswordHash = (byte[])conexionBD.SqlDataReader["PasswordHash"],
                                    PasswordSalt = (byte[])conexionBD.SqlDataReader["PasswordSalt"],
                                    DiasPermitidos = (byte)conexionBD.SqlDataReader["DiasPermitidos"],
                                    CambioPassword = (bool)conexionBD.SqlDataReader["cambioPassword"],
                                    Permisos = (string)conexionBD.SqlDataReader["Permisos"],
                                    Estado = (bool)conexionBD.SqlDataReader["Estado"]
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Error al obtener usuario.\n{conexionBD.StrError}\n{error.Message}", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                // Ahora el finally cierra el reader con seguridad
                // Se simplifica la comprobación utilizando el operador null-conditional
                conexionBD.SqlDataReader?.Close();
                await conexionBD.CloseConnection();
            }
            return usuarioEncontrado; // Devolvemos la variable
        }

        public bool EsDiaPermitido(byte diasPermitidos, DayOfWeek diaServidor)
        {
            int bit = 1 << (int)diaServidor;
            return (diasPermitidos & bit) != 0;
        }
        #endregion

        #region actualizar_usuario

        public async Task<bool> UpdateUsuarioAsync(string UsuarioID, string NombreCompleto, string Password, byte DiasPermitidos, string cambioPassword, string Estado, string IdUsuarioLog, string Usuario)
        {
            bool b = false;
            try
            {
                byte[] hash = null;
                byte[] salt = null;

                // Si la contraseña tiene texto, generamos el hash. Si no, se quedan en null.
                if (!string.IsNullOrWhiteSpace(Password))
                {
                    PasswordHasher.Create(Password, out hash, out salt);
                }

                var listUsuarioUpdate = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@UsuarioID", UsuarioID),
                    new KeyValuePair<string, object>("@NombreCompleto", NombreCompleto), // Se actualiza siempre
                    new KeyValuePair<string, object>("@PasswordHash", (object)hash ?? DBNull.Value), // Solo cambia si no es nulo
                    new KeyValuePair<string, object>("@PasswordSalt", (object)salt ?? DBNull.Value), // Solo cambia si no es nulo
                    new KeyValuePair<string, object>("@DiasPermitidos", DiasPermitidos),
                    new KeyValuePair<string, object>("@cambioPassword", cambioPassword),
                    new KeyValuePair<string, object>("@IdUsuarioLog", IdUsuarioLog),
                    new KeyValuePair<string, object>("@detalle", $"Se actualizo el usuario: '{Usuario}' - {NombreCompleto}"),
                    new KeyValuePair<string, object>("@Estado", Estado)
                };

                if (await conexionBD.Connection())
                {
                    // SQL: Solo PasswordHash y PasswordSalt tienen el "escudo" ISNULL
                    string strSQL = @"begin try
                                    begin transaction
                                    UPDATE Usuarios 
                                    SET 
                                        NombreCompleto = @NombreCompleto,
                                        PasswordHash   = ISNULL(CAST(@PasswordHash AS VARBINARY(MAX)), PasswordHash),
                                        PasswordSalt   = ISNULL(CAST(@PasswordSalt AS VARBINARY(MAX)), PasswordSalt),
                                        DiasPermitidos = @DiasPermitidos,
                                        cambioPassword = @cambioPassword,
                                        Estado         = @Estado
                                    WHERE UsuarioID = @UsuarioID;
                                    -- Registra en Auditoria que se actualizo un usuario
                                    INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                    VALUES(@IdUsuarioLog, N'Actualizo Usuario', GETDATE(), @detalle);
                                    commit transaction
                                    end try
                                    begin catch
                                    rollback transaction
                                    SET IDENTITY_INSERT Usuarios OFF;
                                    DECLARE @numeroDeError INT = ERROR_NUMBER();
                                    THROW  -- Relanza el error
                                    end catch";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, listUsuarioUpdate))
                    {
                        b = true;
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Error: {error.Message}", "Editar Usuario", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally { await conexionBD.CloseConnection(); }
            return b;
        }
        #endregion

        #region Actualizar_contraseña
        public async Task<bool> UpdatePasswdAsync(string IdUsuario, string Password, string Usuario, string NombreCompleto)
        {
            bool b = false;
            try
            {
                string strSQL = "";

                PasswordHasher.Create(Password, out byte[] hash, out byte[] salt);

                // Preparamos los parámetros para actualizar usuario
                var listUsuarioUpdate = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@UsuarioID", IdUsuario),
                    new KeyValuePair<string, object>("@PasswordHash", (object)hash),
                    new KeyValuePair<string, object>("@PasswordSalt", (object)salt),
                    new KeyValuePair<string, object>("@detalle", $"Cambio contraseña: '{Usuario}' - {NombreCompleto}"),
                };
                // Abrimos conexión
                if (await conexionBD.Connection())
                {
                    // Ejecutamos el método insert para rgistrar usuario nuevo
                    strSQL = @"DECLARE @lastID INT
                               begin try
                               begin transaction
                               
                               UPDATE Usuarios 
                               SET 
                                    PasswordHash   =  @PasswordHash,
                                    PasswordSalt   =  @PasswordSalt,
                                    cambioPassword = 0
                               WHERE UsuarioID = @UsuarioID;
                               -- Registra en AuditoriaLog que se actualizo contraseña
                               INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                               VALUES(@UsuarioID, N'Cambio Contraseña', GETDATE(), @detalle);
                               commit transaction
                               end try
                               begin catch
                               rollback transaction
                               DECLARE @numeroDeError INT = ERROR_NUMBER();
                               THROW  -- Relanza el error
                               end catch";
                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, listUsuarioUpdate))
                    {
                        b = true;
                    }
                    else
                    {
                        // Lanzamos una excepción manualmente usando el error guardado
                        throw new Exception();
                    }
                }
            }
            catch (Exception error)
            {
                // Si el código de error es 2627 (violación de clave única por correo)
                MessageBox.Show($"Error al cambiar contraseña.\n{conexionBD.StrError}\n{error.Message}", "Cambiar Contraseña", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return b;
        }
        #endregion

        #region usuarios
        public async Task<DataSet> UsuariosAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT 
                                    UsuarioID,
                                    CONCAT(NombreCompleto,' (',Usuario,')' ) AS Usuario
                                FROM Usuarios
                                WHERE Estado = 1
                                ORDER BY NombreCompleto";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener usuarios.\n{conexionBD.StrError}\n{error.Message}", "Usuarios", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region eliminar_usuario
        public async Task<bool> DeleteUsuarioAsync(string UsuarioID, string Usuario, string NombreCompleto, string IdUsuarioLogin)
        {
            bool b = false;
            try
            {


                var listUsuarioUpdate = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@UsuarioID", UsuarioID),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", IdUsuarioLogin),
                    new KeyValuePair<string, object>("@detalle", $"Eliminó usuario: '{Usuario}' - {NombreCompleto}")
                };

                if (await conexionBD.Connection())
                {
                    string strSQL = @" begin try
                                       begin transaction
                                       -- Eliminar usuario seleccionado
                                       DELETE FROM Usuarios WHERE UsuarioID = @UsuarioID;
                                       -- Registra en Auditoria que se elimino un usuario
                                       INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                       VALUES(@IdUsuarioLogin, N'Eliminó Usuario', GETDATE(), @detalle);
                                       commit transaction
                                       end try
                                       begin catch
                                       rollback transaction
                                       DECLARE @numeroDeError INT = ERROR_NUMBER();
                                       THROW  -- Relanza el error
                                       end catch";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, listUsuarioUpdate))
                    {
                        b = true;
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Error al eliminar usuario.\n{conexionBD.StrError}\n{error.Message}", "Eliminar Usuario", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally { await conexionBD.CloseConnection(); }
            return b;
        }
        #endregion

        #region actualizar_permisos

        public async Task<bool> UpdatePermisosAsync(string UsuarioID, string NombreCompleto, string jsonPermisos, string mensajeAuditoria, string IdUsuarioLog)
        {
            bool b = false;
            try
            {
                var listUsuarioUpdate = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@UsuarioID", UsuarioID),
                    new KeyValuePair<string, object>("@Permisos", jsonPermisos),
                    new KeyValuePair<string, object>("@IdUsuarioLog", IdUsuarioLog),
                    new KeyValuePair<string, object>("@detalle", $"{NombreCompleto} - {mensajeAuditoria}")
                };

                if (await conexionBD.Connection())
                {
                    // SQL: Solo PasswordHash y PasswordSalt tienen el "escudo" ISNULL
                    string strSQL = @"begin try
                                    begin transaction
                                    UPDATE Usuarios 
                                    SET 
                                        Permisos = @Permisos
                                    WHERE UsuarioID = @UsuarioID;
                                    -- Registra en Auditoria que se asignaron permisos a un usuario selecionado
                                    INSERT INTO AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                    VALUES(@IdUsuarioLog, N'Asigno Permisos', GETDATE(), @detalle);
                                    commit transaction
                                    end try
                                    begin catch
                                    rollback transaction
                                    SET IDENTITY_INSERT Usuarios OFF;
                                    DECLARE @numeroDeError INT = ERROR_NUMBER();
                                    THROW  -- Relanza el error
                                    end catch";

                    if (await conexionBD.UpdateAsync(strSQL, CommandType.Text, listUsuarioUpdate))
                    {
                        b = true;
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show($"Error: {error.Message}", "Error de Permisos de Usuario", MessageBoxButton.OK, MessageBoxImage.Error);
                b = false;
            }
            finally { await conexionBD.CloseConnection(); }
            return b;
        }
        #endregion
    }
}