﻿using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Parking.Controller
{
    public class Movimientos
    {
        private readonly ConexionBD conexionBD = new ConexionBD();

        #region movimientos_vehículos(entrada y salida)
        public async Task<DataSet> MovimientosVehiculoslAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT 
                                    -- Vehículo y Ubicación
                                    m.IdMovimiento,
                                    v.Placa,
                                    v.idtipovehiculo,
                                    v.IdCategoriaVehiculo,
                                    v.EsVIP,
                                    n.Nombre AS NombreNivel, 
                                    c.Codigo AS CodigoCelda, 

                                    -- Tiempos del Movimiento
                                    ISNULL(FORMAT(m.FechaHoraEntrada, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + 
                                           UPPER(FORMAT(m.FechaHoraEntrada, 'hh:mm tt', 'en-US')), ''
                                    ) AS FechaHoraEntrada, 
                                    ISNULL(FORMAT(m.FechaHoraSalida, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + 
                                           UPPER(FORMAT(m.FechaHoraSalida, 'hh:mm tt', 'en-US')), ''
                                    ) AS FechaHoraSalida, 
                                    m.Estado,
                                    m.MinutosPermanencia, 
                                    m.MinutosCobrados, 

                                    -- Cobros y Usuarios
                                    m.ValorCalculado, 
                                    m.ValorPagado, 
                                    m.IdUsuarioEntrada, 
                                    m.IdUsuarioSalida, 

                                    -- Datos de VehiculoPlan (Contrato - Solo si el movimiento usa plan activo)
                                    ISNULL(FORMAT(vp.FechaInicio, 'dddd, dd \de MMMM \de yyyy', 'es-ES'), '') AS VehiculoPlan_FechaInicio,
                                    ISNULL(FORMAT(vp.FechaFin, 'dddd, dd \de MMMM \de yyyy', 'es-ES'), '') AS VehiculoPlan_FechaFin,
                                    CONCAT('$ ', FORMAT(vp.PrecioContratado, 'N0', 'es-ES')) AS PrecioContratado,
                                    vp.EstadoContrato, 
                                    vp.EstadoPago,
                                    ISNULL(FORMAT(vp.FechaPago, 'dddd, dd \de MMMM \de yyyy', 'es-ES'), '') AS FechaPago, 

                                    -- Plan y Tipo de Plan (Condicionado estrictamente al tipo de cobro actual del movimiento)
                                    p.Nombre AS NombrePlan, 
                                    p.Descripcion AS DescripcionPlan, 
                                    tp.Nombre AS NombreTipoPlan, 
                                    tp.Descripcion AS DescripcionTipoPlan,

                                    -- Tarifas Aplicadas
                                    CONCAT('$ ', FORMAT(COALESCE(pt_vp.ValorTarifa, pt_demanda.ValorTarifa, pt.ValorTarifa), 'N0', 'es-ES')) AS ValorTarifa, 
                                    CONCAT('$ ', FORMAT(COALESCE(pt_vp.ValorMinuto, pt_demanda.ValorMinuto, pt.ValorMinuto), 'N0', 'es-ES')) AS ValorMinuto, 
                                    CONCAT('$ ', FORMAT(COALESCE(pt_vp.ValorHora, pt_demanda.ValorHora, pt.ValorHora), 'N0', 'es-ES')) AS ValorHora, 
                                    CONCAT('$ ', FORMAT(COALESCE(pt_vp.Valor12Horas, pt_demanda.Valor12Horas, pt.Valor12Horas), 'N0', 'es-ES')) AS Valor12Horas, 
                                    CONCAT('$ ', FORMAT(COALESCE(pt_vp.Valor24Horas, pt_demanda.Valor24Horas, pt.Valor24Horas), 'N0', 'es-ES')) AS Valor24Horas, 

                                    -- Clasificación del Vehículo
                                    cv.Nombre AS NombreCategoriaVehiculo, 
                                    tv.Nombre AS NombreTipoVehiculo, 

                                    -- Horarios del Plan
                                    hor.NombrePlanHorario, 
                                    hor.HoraInicio, 
                                    hor.HoraFin, 
                                    hor.DiaSemana,
                                    p.IdTipoPlan,
                                    p.IdPlan

                                FROM dbo.MovimientoParqueadero m
                                -- Tablas obligatorias
                                INNER JOIN dbo.Vehiculo v ON m.IdVehiculo = v.Idvehiculo
                                INNER JOIN dbo.Celda c ON m.IdCelda = c.IdCelda
                                INNER JOIN dbo.Nivel n ON c.IdNivel = n.IdNivel

                                -- Relaciones opcionales
                                LEFT JOIN dbo.CategoriaVehiculo cv ON v.IdCategoriaVehiculo = cv.IdCategoriaVehiculo
                                LEFT JOIN dbo.TipoVehiculo tv ON v.idtipovehiculo = tv.IdTipoVehiculo

                                -- 1. Contrato explícito unícamente si el movimiento tiene un IdVehiculoPlan asignado
                                LEFT JOIN dbo.VehiculoPlan vp ON m.IdVehiculoPlan = vp.IdVehiculoPlan
                                LEFT JOIN dbo.PlanTarifa pt_vp ON vp.IdPlanTarifa = pt_vp.IdPlanTarifa

                                -- 2. Tarifa registrada directamente en el movimiento
                                LEFT JOIN dbo.PlanTarifa pt ON m.IdPlanTarifa = pt.IdPlanTarifa

                                -- 3. Resguardo automático por Demanda (Se activa si el movimiento es TiempoDemanda o VIP)
                                OUTER APPLY (
                                    SELECT TOP 1 pt_dem.* 
                                    FROM dbo.[Plan] p_dem
                                    INNER JOIN dbo.PlanTarifa pt_dem ON p_dem.IdPlan = pt_dem.IdPlan
                                    WHERE p_dem.IdTipoPlan = 3 -- 3 = Tiempo por demanda
                                      AND p_dem.IdTipoVehiculo = v.idtipovehiculo
                                      AND p_dem.IdCategoriaVehiculo = v.IdCategoriaVehiculo
                                      AND p_dem.Estado = 1
                                      AND pt_dem.Estado = 1
                                    ORDER BY pt_dem.FechaInicioVigencia DESC, pt_dem.IdPlanTarifa DESC
                                ) pt_demanda

                                -- 5. Plan y Tipo de Plan unificados (Prioriza el contrato del movimiento o la demanda según corresponda)
                                LEFT JOIN dbo.[Plan] p ON p.IdPlan = CASE 
                                    WHEN m.TipoCobro IN ('Membresia', 'Mensualidad') THEN COALESCE(pt_vp.IdPlan, pt.IdPlan)
                                    ELSE COALESCE(pt_demanda.IdPlan, pt.IdPlan)
                                END
                                LEFT JOIN dbo.TipoPlan tp ON p.IdTipoPlan = tp.IdTipoPlan

                                -- 6. Agrupación de días de la semana
                                OUTER APPLY (
                                    SELECT TOP 1 
                                        ph.Nombre AS NombrePlanHorario,
                                        ph.HoraInicio,
                                        ph.HoraFin,
                                        STRING_AGG( 
                                            CASE phd.DiaSemana 
                                                WHEN 1 THEN 'Lunes'
                                                WHEN 2 THEN 'Martes'
                                                WHEN 3 THEN 'Miércoles'
                                                WHEN 4 THEN 'Jueves'
                                                WHEN 5 THEN 'Viernes'
                                                WHEN 6 THEN 'Sábado'
                                                WHEN 7 THEN 'Domingo'
                                                ELSE 'Día ' + CAST(phd.DiaSemana AS VARCHAR(2))
                                            END, ', '
                                        ) WITHIN GROUP (ORDER BY phd.DiaSemana) AS DiaSemana
                                    FROM dbo.PlanHorario ph
                                    LEFT JOIN dbo.PlanHorarioDia phd ON ph.IdPlanHorario = phd.IdPlanHorario
                                    WHERE ph.IdPlan = p.IdPlan
                                    GROUP BY ph.IdPlanHorario, ph.Nombre, ph.HoraInicio, ph.HoraFin
                                ) hor

                                -- Solo vehículos actualmente parqueados
                                WHERE m.FechaHoraSalida IS NULL;";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch
            {
                MessageBox.Show($"Error al obtener movimientos de vehículos.\n{conexionBD.StrError}", "Movimiento Vehículo", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region estado vehiculo
        public async Task<bool> VehiculoEstaDentroAsync(string placa)
        {
            bool dentro = false;

            string placaNormalizada = string.IsNullOrWhiteSpace(placa)
                    ? string.Empty
                    : placa.Trim().ToUpper();
            try
            {
                if (string.IsNullOrWhiteSpace(placaNormalizada))
                {
                    MessageBox.Show("Debe ingresar la placa del vehículo.", "Consultar vehículo", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Placa", placaNormalizada)
                };

                if (await conexionBD.Connection())
                {
                    string strSQL = @"SELECT TOP (1)
                                        CAST(1 AS BIT) AS EstaDentro
                                    FROM MovimientoParqueadero MP
                                    INNER JOIN Vehiculo V
                                        ON V.Idvehiculo = MP.IdVehiculo
                                    WHERE V.Placa = @Placa
                                      AND MP.Estado = 'Dentro'
                                      AND MP.FechaHoraSalida IS NULL
                                    ORDER BY MP.FechaHoraEntrada DESC;";
                    if (await conexionBD.DataSetAsync(strSQL, CommandType.Text, parametros))
                    {
                        if (conexionBD.DataSet != null && conexionBD.DataSet.Tables.Count > 0 && conexionBD.DataSet.Tables[0].Rows.Count > 0)
                        {
                            dentro = Convert.ToBoolean(conexionBD.DataSet.Tables[0].Rows[0]["EstaDentro"]);
                        }
                    }
                }
                else
                {
                    throw new Exception("No fue posible establecer la conexión con la base de datos.");
                }
            }
            catch (Exception error)
            {
                string detalleError =
                    !string.IsNullOrWhiteSpace(conexionBD.StrError)
                        ? conexionBD.StrError
                        : error.Message;

                MessageBox.Show("Error al consultar el estado del vehículo.\n" + detalleError, "Consultar vehículo", MessageBoxButton.OK, MessageBoxImage.Error);

                dentro = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return dentro;
        }
        #endregion

        #region tipo_vehículo
        public async Task<DataSet> TipoVehiculolAsync(string IdTipoPlan)
        {
            try
            {
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@IdTipoPlan", IdTipoPlan),
                };
                if (await conexionBD.Connection())
                {
                    string sql = $@"WITH RankedTarifas AS (
                                        SELECT 
                                            IdPlan, IdPlanTarifa, --IdTipoVehiculo, IdCategoriaVehiculo,
                                            ValorMinuto, ValorHora, Valor12Horas, Valor24Horas,
                                            FechaInicioVigencia, FechaFinVigencia, Estado AS EstadoPlanTarifa,
                                            ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanTarifa) AS RowIdx
                                        FROM PlanTarifa
                                    ),
                                    RankedHorarios AS (
                                        SELECT 
                                            IdPlan, IdPlanHorario, Nombre AS NombrePlanHorario,
                                            HoraInicio, HoraFin, CruzaMedianoche, Estado AS EstadoPlanHorario,
                                            ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanHorario) AS RowIdx
                                        FROM PlanHorario
                                    ),
                                    RankedReglas AS (
                                        SELECT 
                                            IdPlan, IdPlanReglaCobro, UnidadCobro, MinutosFraccion, MinutosGracia,
                                            ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanReglaCobro) AS RowIdx
                                        FROM PlanReglaCobro
                                    ),
                                    AllIndices AS (
                                        SELECT IdPlan, RowIdx FROM RankedTarifas
                                        UNION
                                        SELECT IdPlan, RowIdx FROM RankedHorarios
                                        UNION
                                        SELECT IdPlan, RowIdx FROM RankedReglas
                                    ),
                                    CombinedPlanChildren AS (
                                        SELECT 
                                            AI.IdPlan,
                                            AI.RowIdx,
                                            T.IdPlanTarifa, --T.IdTipoVehiculo, T.IdCategoriaVehiculo,
                                            T.ValorMinuto, T.ValorHora, T.Valor12Horas, T.Valor24Horas,
                                            T.FechaInicioVigencia, T.FechaFinVigencia, T.EstadoPlanTarifa,
                                            H.IdPlanHorario, H.NombrePlanHorario, H.HoraInicio, H.HoraFin, 
                                            H.CruzaMedianoche, H.EstadoPlanHorario,
                                            R.IdPlanReglaCobro, R.UnidadCobro, R.MinutosFraccion, R.MinutosGracia
                                        FROM AllIndices AI
                                        LEFT JOIN RankedTarifas T ON AI.IdPlan = T.IdPlan AND AI.RowIdx = T.RowIdx
                                        LEFT JOIN RankedHorarios H ON AI.IdPlan = H.IdPlan AND AI.RowIdx = H.RowIdx
                                        LEFT JOIN RankedReglas R ON AI.IdPlan = R.IdPlan AND AI.RowIdx = R.RowIdx
                                    )
                                    SELECT 
                                        [Plan].IdPlan,
                                        [Plan].IdTipoPlan,
                                        [Plan].Nombre AS NombrePlan,
                                        [Plan].Descripcion AS DescripcionPlan,
                                        [Plan].Estado AS EstadoPlan,
                                        TipoPlan.IdTipoPlan AS IdTipoPlanTp,
                                        TipoPlan.Nombre AS NombreTipoPlan,
                                        TipoPlan.Descripcion AS DescripcionTipoPlan,
                                        TipoPlan.Estado AS EstadoTipoPlan,
                                        Cp.IdPlanTarifa,
                                        Cp.IdPlan AS IdPlanPlanTarifa,
                                        [Plan].IdTipoVehiculo,
                                        [Plan].IdCategoriaVehiculo,
                                        CONCAT ('$ ',FORMAT(Cp.ValorMinuto, 'N0', 'es-ES')) AS ValorMinuto,
                                        CONCAT ('$ ',FORMAT(Cp.ValorHora, 'N0', 'es-ES')) AS ValorHora,
                                        CONCAT ('$ ',FORMAT(Cp.Valor12Horas, 'N0', 'es-ES')) AS Valor12Horas,
                                        CONCAT ('$ ',FORMAT(Cp.Valor24Horas, 'N0', 'es-ES')) AS Valor24Horas,
                                        Cp.FechaInicioVigencia,
                                        Cp.FechaFinVigencia,
                                        Cp.EstadoPlanTarifa,
                                        CategoriaVehiculo.IdCategoriaVehiculo AS IdCatVehiculo,
                                        CategoriaVehiculo.Nombre AS NombreCategoriaVehiculo,
                                        CategoriaVehiculo.Descripcion AS DescripcionCategoriaVehiculo,
                                        TipoVehiculo.IdTipoVehiculo AS IdTipoVehiculoTv,
                                        TipoVehiculo.Nombre AS NombreTipoVehiculo,
                                        TipoVehiculo.Descripcion AS DescripcionTipoVehiculo,
                                        Cp.IdPlanHorario,
                                        Cp.IdPlan AS IdPlanPlanHorario,
                                        Cp.NombrePlanHorario,
                                        Cp.HoraInicio,
                                        Cp.HoraFin,
                                        Cp.CruzaMedianoche,
                                        Cp.EstadoPlanHorario,
                                        Cp.IdPlanReglaCobro,
                                        Cp.IdPlan AS IdPlanPlanReglaCobro,
                                        Cp.UnidadCobro,
                                        Cp.MinutosFraccion,
                                        Cp.MinutosGracia,
                                        Dias.DiasSemana
                                    FROM CombinedPlanChildren Cp
                                    INNER JOIN [Plan] ON [Plan].IdPlan = Cp.IdPlan
                                    INNER JOIN TipoPlan ON TipoPlan.IdTipoPlan = [Plan].IdTipoPlan 
                                    LEFT JOIN CategoriaVehiculo ON [Plan].IdCategoriaVehiculo = CategoriaVehiculo.IdCategoriaVehiculo 
                                    LEFT JOIN TipoVehiculo ON [Plan].IdTipoVehiculo = TipoVehiculo.IdTipoVehiculo 
                                    OUTER APPLY (
                                        SELECT STRING_AGG(
                                            CASE PHD.DiaSemana        
                                                WHEN 1 THEN N'Lunes'        
                                                WHEN 2 THEN N'Martes'        
                                                WHEN 3 THEN N'Miércoles'        
                                                WHEN 4 THEN N'Jueves'        
                                                WHEN 5 THEN N'Viernes'        
                                                WHEN 6 THEN N'Sábado'        
                                                WHEN 7 THEN N'Domingo'    
                                            END,    
                                            N', '
                                        ) AS DiasSemana 
                                        FROM PlanHorarioDia PHD
                                        WHERE PHD.IdPlanHorario = Cp.IdPlanHorario
                                    ) Dias
                                WHERE [Plan].IdTipoPlan = @IdTipoPlan
                                ORDER BY [Plan].IdPlan, Cp.RowIdx";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch
            {
                MessageBox.Show($"Error al obtener movimientos de vehículos.\n{conexionBD.StrError}", "Movimiento Vehículo", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region tipo_vehículo_membresia_mensualidad
        public async Task<DataSet> TipoVehiculoMembresiaMensualidadlAsync(string Placa, string IdTipoVehiculo, string IdCategoriaVehiculo)
        {
            try
            {
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Placa", Placa)
                };
                if (await conexionBD.Connection())
                {
                    string sql = $@"DECLARE @EstadoContrato NVARCHAR(50);
                                    DECLARE @IdTipoVehiculo INT;
                                    DECLARE @IdCategoriaVehiculo INT;
                                    DECLARE @FechaFinPlan DATE;

                                    -- Obtener los datos base del vehículo, la fecha fin del plan y evaluar el estado real
                                    SELECT TOP 1
                                        @IdTipoVehiculo = V.idtipovehiculo,
                                        @IdCategoriaVehiculo = V.IdCategoriaVehiculo,
                                        @FechaFinPlan = VP.FechaFin,
                                        @EstadoContrato = CASE 
                                            WHEN VP.FechaFin IS NOT NULL AND CAST(SYSDATETIME() AS DATE) > VP.FechaFin THEN 'Vencida'
                                            ELSE ISNULL(VP.EstadoContrato, 'Sin Plan')
                                        END
                                    FROM Vehiculo V
                                    LEFT JOIN VehiculoPlan VP ON V.Idvehiculo = VP.Idvehiculo
                                    WHERE V.Placa = @Placa;


                                    /****************************************************************************************************************************/
                                    -- 1. PRIMERA CONSULTA: SE MUESTRA SIEMPRE POR OBLIGACIÓN (Datos del Cliente y Plan)
                                    /****************************************************************************************************************************/
                                    SELECT 
                                        Cliente.Nombre, 
                                        Cliente.Documento,
                                        ISNULL(FORMAT(VehiculoPlan.FechaInicio, 'dddd, dd \de MMMM \de yyyy', 'es-ES'), '') AS FechaInicio,
                                        ISNULL(FORMAT(VehiculoPlan.FechaFin, 'dddd, dd \de MMMM \de yyyy', 'es-ES'), '') AS FechaFin,
                                        CASE 
                                            WHEN DATEDIFF(DAY, CAST(SYSDATETIME() AS DATE), VehiculoPlan.FechaFin) < 0 THEN 0
                                            ELSE DATEDIFF(DAY, CAST(SYSDATETIME() AS DATE), VehiculoPlan.FechaFin)
                                        END AS DiasRestantes,
                                        CONCAT('$ ', FORMAT(VehiculoPlan.PrecioContratado, 'N0', 'es-ES')) AS PrecioContratado,
                                        @EstadoContrato AS EstadoContrato
                                    FROM Vehiculo 
                                    INNER JOIN VehiculoPlan ON Vehiculo.Idvehiculo = VehiculoPlan.Idvehiculo 
                                    INNER JOIN Cliente ON Vehiculo.Idcliente = Cliente.Idcliente
                                    WHERE Vehiculo.Placa = @Placa;


                                    /****************************************************************************************************************************/
                                    -- 2. SEGUNDA CONSULTA: SE MUESTRA SIEMPRE POR OBLIGACIÓN (Detalle de Planes / Tarifas asociadas)
                                    /****************************************************************************************************************************/
                                    WITH RankedTarifas AS (
                                        SELECT 
                                            IdPlan, IdPlanTarifa, 
                                            ValorMinuto, ValorHora, Valor12Horas, Valor24Horas,
                                            FechaInicioVigencia, FechaFinVigencia, Estado AS EstadoPlanTarifa,
                                            ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanTarifa) AS RowIdx
                                        FROM PlanTarifa
                                    ),
                                    RankedHorarios AS (
                                        SELECT 
                                            IdPlan, IdPlanHorario, Nombre AS NombrePlanHorario,
                                            HoraInicio, HoraFin, CruzaMedianoche, Estado AS EstadoPlanHorario,
                                            ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanHorario) AS RowIdx
                                        FROM PlanHorario
                                        WHERE Estado = 1
                                    ),
                                    RankedReglas AS (
                                        SELECT 
                                            IdPlan, IdPlanReglaCobro, UnidadCobro, MinutosFraccion, MinutosGracia,
                                            ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanReglaCobro) AS RowIdx
                                        FROM PlanReglaCobro
                                    ),
                                    AllIndices AS (
                                        SELECT IdPlan, RowIdx FROM RankedTarifas
                                        UNION
                                        SELECT IdPlan, RowIdx FROM RankedHorarios
                                        UNION
                                        SELECT IdPlan, RowIdx FROM RankedReglas
                                    ),
                                    CombinedPlanChildren AS (
                                        SELECT 
                                            AI.IdPlan,
                                            AI.RowIdx,
                                            T.IdPlanTarifa, 
                                            T.ValorMinuto, T.ValorHora, T.Valor12Horas, T.Valor24Horas,
                                            T.FechaInicioVigencia, T.FechaFinVigencia, T.EstadoPlanTarifa,
                                            H.IdPlanHorario, H.NombrePlanHorario, H.HoraInicio, H.HoraFin, 
                                            H.CruzaMedianoche, H.EstadoPlanHorario,
                                            R.IdPlanReglaCobro, R.UnidadCobro, R.MinutosFraccion, R.MinutosGracia
                                        FROM AllIndices AI
                                        LEFT JOIN RankedTarifas T ON AI.IdPlan = T.IdPlan AND AI.RowIdx = T.RowIdx
                                        LEFT JOIN RankedHorarios H ON AI.IdPlan = H.IdPlan AND AI.RowIdx = H.RowIdx
                                        LEFT JOIN RankedReglas R ON AI.IdPlan = R.IdPlan AND AI.RowIdx = R.RowIdx
                                    )
                                    SELECT 
                                        [Plan].IdPlan,
                                        [Plan].IdTipoPlan,
                                        [Plan].Nombre AS NombrePlan,
                                        [Plan].Descripcion AS DescripcionPlan,
                                        [Plan].Estado AS EstadoPlan,
                                        TipoPlan.IdTipoPlan AS IdTipoPlanTp,
                                        TipoPlan.Nombre AS NombreTipoPlan,
                                        TipoPlan.Descripcion AS DescripcionTipoPlan,
                                        TipoPlan.Estado AS EstadoTipoPlan,
                                        Cp.IdPlanTarifa,
                                        Cp.IdPlan AS IdPlanPlanTarifa,
                                        [Plan].IdTipoVehiculo,
                                        [Plan].IdCategoriaVehiculo,
                                        CONCAT ('$ ',FORMAT(Cp.ValorMinuto, 'N0', 'es-ES')) AS ValorMinuto,
                                        CONCAT ('$ ',FORMAT(Cp.ValorHora, 'N0', 'es-ES')) AS ValorHora,
                                        CONCAT ('$ ',FORMAT(Cp.Valor12Horas, 'N0', 'es-ES')) AS Valor12Horas,
                                        CONCAT ('$ ',FORMAT(Cp.Valor24Horas, 'N0', 'es-ES')) AS Valor24Horas,
                                        Cp.FechaInicioVigencia,
                                        Cp.FechaFinVigencia,
                                        Cp.EstadoPlanTarifa,
                                        CategoriaVehiculo.IdCategoriaVehiculo AS IdCatVehiculo,
                                        CategoriaVehiculo.Nombre AS NombreCategoriaVehiculo,
                                        CategoriaVehiculo.Descripcion AS DescripcionCategoriaVehiculo,
                                        TipoVehiculo.IdTipoVehiculo AS IdTipoVehiculoTv,
                                        TipoVehiculo.Nombre AS NombreTipoVehiculo,
                                        TipoVehiculo.Descripcion AS DescripcionTipoVehiculo,
                                        Cp.IdPlanHorario,
                                        Cp.IdPlan AS IdPlanPlanHorario,
                                        Cp.NombrePlanHorario,
                                        Cp.HoraInicio,
                                        Cp.HoraFin,
                                        Cp.CruzaMedianoche,
                                        Cp.EstadoPlanHorario,
                                        Cp.IdPlanReglaCobro,
                                        Cp.IdPlan AS IdPlanPlanReglaCobro,
                                        Cp.UnidadCobro,
                                        Cp.MinutosFraccion,
                                        Cp.MinutosGracia,
                                        Dias.DiasSemana
                                    FROM CombinedPlanChildren Cp
                                    INNER JOIN [Plan] ON [Plan].IdPlan = Cp.IdPlan
                                    INNER JOIN TipoPlan ON TipoPlan.IdTipoPlan = [Plan].IdTipoPlan 
                                    LEFT JOIN CategoriaVehiculo ON [Plan].IdCategoriaVehiculo = CategoriaVehiculo.IdCategoriaVehiculo 
                                    LEFT JOIN TipoVehiculo ON [Plan].IdTipoVehiculo = TipoVehiculo.IdTipoVehiculo 
                                    OUTER APPLY (
                                        SELECT STRING_AGG(
                                            CASE PHD.DiaSemana        
                                                WHEN 1 THEN N'Lunes'        
                                                WHEN 2 THEN N'Martes'        
                                                WHEN 3 THEN N'Miércoles'        
                                                WHEN 4 THEN N'Jueves'        
                                                WHEN 5 THEN N'Viernes'        
                                                WHEN 6 THEN N'Sábado'        
                                                WHEN 7 THEN N'Domingo'    
                                            END,    
                                            N', '
                                        ) AS DiasSemana 
                                        FROM PlanHorarioDia PHD
                                        WHERE PHD.IdPlanHorario = Cp.IdPlanHorario
                                    ) Dias
                                    WHERE [Plan].IdTipoPlan = 1 AND CategoriaVehiculo.IdCategoriaVehiculo = @IdCategoriaVehiculo AND TipoVehiculo.IdTipoVehiculo = @IdTipoVehiculo
                                    ORDER BY [Plan].IdPlan, Cp.RowIdx;


                                    /****************************************************************************************************************************/
                                    -- 3. TERCERA CONSULTA: SE MUESTRA ÚNICAMENTE SI EL ESTADO DEL CONTRATO ESTÁ EN 'Vencida'
                                    /****************************************************************************************************************************/
                                    IF @EstadoContrato = 'Vencida'
                                    BEGIN
                                        IF NOT EXISTS (
                                            SELECT 1 
                                            FROM [Plan] P
                                            INNER JOIN TipoPlan TP ON TP.IdTipoPlan = P.IdTipoPlan
                                            WHERE (TP.IdTipoPlan = 3)
                                              AND P.Estado = 1
                                              AND P.IdTipoVehiculo = @IdTipoVehiculo
                                              AND (P.IdCategoriaVehiculo = @IdCategoriaVehiculo OR P.IdCategoriaVehiculo IS NULL)
                                        )
                                        BEGIN
                                            SELECT N'Asignar tiempo por demanda para este tipo y categoría de vehículo' AS MensajeAlerta;
                                        END
                                        ELSE
                                        BEGIN
                                            IF OBJECT_ID('tempdb..#Tarifas') IS NOT NULL DROP TABLE #Tarifas;
                                            IF OBJECT_ID('tempdb..#TarifaAplicada') IS NOT NULL DROP TABLE #TarifaAplicada;
                                            IF OBJECT_ID('tempdb..#Detalle') IS NOT NULL DROP TABLE #Detalle;
                                            IF OBJECT_ID('tempdb..#Tramos') IS NOT NULL DROP TABLE #Tramos;
                                            IF OBJECT_ID('tempdb..#Puntos') IS NOT NULL DROP TABLE #Puntos;

                                            DECLARE @FechaHoraSalida DATETIME2(0) = CONVERT(DATETIME2(0), SYSDATETIME());
                                            DECLARE @IdMovimiento INT, @IdVehiculo INT, @IdCelda INT;
                                            DECLARE @PlacaConsultada VARCHAR(10), @TipoCobro VARCHAR(20);
                                            DECLARE @TipoVehiculo VARCHAR(60), @CategoriaVehiculo VARCHAR(60);
                                            DECLARE @CodigoCelda NVARCHAR(20), @NombreNivel NVARCHAR(50);
                                            DECLARE @FechaHoraEntrada DATETIME2(0);
                                            DECLARE @MinutosPermanencia INT, @HorasPermanencia DECIMAL(18,2);
                                            DECLARE @Dias INT, @Horas INT, @Minutos INT, @TextoPermanencia NVARCHAR(150);
                                            DECLARE @CobradosDias INT, @CobradosHoras INT, @CobradosMinutos INT, @TextoCobrados NVARCHAR(150);
        
                                            DECLARE @IdPlanTarifa INT, @NombrePlan NVARCHAR(100), @NombreHorario NVARCHAR(100);
                                            DECLARE @UnidadCobro NVARCHAR(20), @MinutosFraccion INT, @MinutosGracia INT;
                                            DECLARE @ValorMinuto DECIMAL(18,2), @ValorHora DECIMAL(18,2), @Valor12Horas DECIMAL(18,2), @Valor24Horas DECIMAL(18,2);
                                            DECLARE @MinutosTramo INT, @MinutosGratisTramo INT, @MinutosCobradosTramo INT;
                                            DECLARE @TxtTramo NVARCHAR(100), @TxtCobradosTramo NVARCHAR(100);
                                            DECLARE @HorasCompletas INT, @MinutosRestantes INT;
                                            DECLARE @ImporteTramo DECIMAL(18,2), @ValorTotal DECIMAL(18,2) = 0;
                                            DECLARE @MinutosGratisTotal INT = 0, @MinutosCobradosTotal INT = 0;
                                            DECLARE @PaquetesAplicados BIT = 0;
                                            DECLARE @FechaInicioCalculo DATETIME2(0);
                                            DECLARE @InicioTramo DATETIME2(0), @FinTramo DATETIME2(0);
                                            DECLARE @FechaIteracion DATE, @FechaFinal DATE, @DiaSemanaIteracion TINYINT;
                                            DECLARE @ModalidadCobro NVARCHAR(150) = N'Cobro por jornadas';

                                            /* 1. BUSCAR EL MOVIMIENTO ABIERTO */
                                            SELECT TOP (1)
                                                @IdMovimiento = MP.IdMovimiento,
                                                @IdVehiculo = MP.IdVehiculo,
                                                @IdCelda = MP.IdCelda,
                                                @FechaHoraEntrada = MP.FechaHoraEntrada,
                                                @TipoCobro = MP.TipoCobro,
                                                @PlacaConsultada = V.Placa,
                                                @TipoVehiculo = TV.Nombre,
                                                @CategoriaVehiculo = CV.Nombre,
                                                @CodigoCelda = C.Codigo,
                                                @NombreNivel = N.Nombre
                                            FROM dbo.MovimientoParqueadero MP
                                            INNER JOIN dbo.Vehiculo V ON V.Idvehiculo = MP.Idvehiculo
                                            INNER JOIN dbo.Celda C ON C.IdCelda = MP.IdCelda
                                            INNER JOIN dbo.Nivel N ON N.IdNivel = C.IdNivel
                                            LEFT JOIN dbo.TipoVehiculo TV ON TV.IdTipoVehiculo = V.idtipovehiculo
                                            LEFT JOIN dbo.CategoriaVehiculo CV ON CV.IdCategoriaVehiculo = V.IdCategoriaVehiculo
                                            WHERE V.Placa = UPPER(LTRIM(RTRIM(@Placa)))
                                              AND MP.Estado = 'Dentro'
                                              AND MP.FechaHoraSalida IS NULL
                                            ORDER BY MP.FechaHoraEntrada DESC;

                                            IF @IdMovimiento IS NULL THROW 56201, 'No existe un movimiento abierto para esta placa.', 1;
                                            IF @IdTipoVehiculo IS NULL OR @IdCategoriaVehiculo IS NULL THROW 56203, 'El vehículo no tiene tipo o categoría configurados.', 1;
                                            IF @FechaHoraSalida < @FechaHoraEntrada THROW 56204, 'La salida no puede ser anterior a la entrada.', 1;

                                            /* 2. DEFINIR INICIO DEL CÁLCULO SEGÚN ESCENARIO 1 Y 2 */
                                            IF @FechaFinPlan IS NOT NULL
                                            BEGIN
                                                DECLARE @InicioVencimientoPlan DATETIME2(0) = DATEADD(DAY, 1, CONVERT(DATETIME2(0), @FechaFinPlan));
            
                                                SET @FechaInicioCalculo = CASE 
                                                    WHEN @FechaHoraEntrada < @InicioVencimientoPlan THEN @InicioVencimientoPlan
                                                    ELSE @FechaHoraEntrada
                                                END;
                                            END
                                            ELSE
                                            BEGIN
                                                SET @FechaInicioCalculo = @FechaHoraEntrada;
                                            END;

                                            /* 3. CALCULAR LA PERMANENCIA TOTAL */
                                            SET @MinutosPermanencia = CONVERT(INT, CEILING(DATEDIFF_BIG(SECOND, @FechaHoraEntrada, @FechaHoraSalida) / 60.0));
                                            SET @HorasPermanencia = CONVERT(DECIMAL(18,2), @MinutosPermanencia / 60.0);

                                            SET @Dias = @MinutosPermanencia / 1440;
                                            SET @Horas = (@MinutosPermanencia % 1440) / 60;
                                            SET @Minutos = @MinutosPermanencia % 60;

                                            IF @Dias > 0
                                                SET @TextoPermanencia = CONCAT(@Dias, N' día(s), ', @Horas, N' hora(s) y ', @Minutos, N' minuto(s)');
                                            ELSE
                                                SET @TextoPermanencia = CONCAT(@Horas, N' hora(s) y ', @Minutos, N' minuto(s)');

                                            /* 4. CARGAR TARIFAS Y REGLAS DE TIEMPO POR DEMANDA */
                                            WITH TarifasRank AS (
                                                SELECT 
                                                    IdPlanTarifa, IdPlan, ValorMinuto, ValorHora, Valor12Horas, Valor24Horas,
                                                    FechaInicioVigencia AS InicioTarifa, FechaFinVigencia AS FinTarifa,
                                                    ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanTarifa ASC) AS RN
                                                FROM dbo.PlanTarifa
                                                WHERE Estado = 1
                                            ),
                                            HorariosRank AS (
                                                SELECT 
                                                    IdPlanHorario, IdPlan, Nombre AS NombreHorario, HoraInicio, HoraFin, CruzaMedianoche,
                                                    ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanHorario ASC) AS RN
                                                FROM dbo.PlanHorario
                                                WHERE Estado = 1
                                            ),
                                            ReglasRank AS (
                                                SELECT 
                                                    IdPlanReglaCobro, IdPlan, UnidadCobro, MinutosFraccion, MinutosGracia,
                                                    ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanReglaCobro ASC) AS RN
                                                FROM dbo.PlanReglaCobro
                                            )
                                            SELECT
                                                P.IdPlan, P.IdTipoVehiculo, P.IdCategoriaVehiculo, P.Nombre AS NombrePlan,
                                                P.FechaInicioVigencia AS InicioPlan, P.FechaFinVigencia AS FinPlan,
                                                PT.IdPlanTarifa, PT.InicioTarifa, PT.FinTarifa,
                                                PT.ValorMinuto, PT.ValorHora, PT.Valor12Horas, PT.Valor24Horas,
                                                RC.UnidadCobro, RC.MinutosFraccion, RC.MinutosGracia,
                                                PH.IdPlanHorario, PH.NombreHorario, PH.HoraInicio, PH.HoraFin, PH.CruzaMedianoche,
                                                PHD.DiaSemana
                                            INTO #Tarifas
                                            FROM dbo.[Plan] P
                                            INNER JOIN dbo.TipoPlan TP ON TP.IdTipoPlan = P.IdTipoPlan
                                            INNER JOIN TarifasRank PT ON PT.IdPlan = P.IdPlan
                                            INNER JOIN HorariosRank PH ON PH.IdPlan = P.IdPlan AND PH.RN = PT.RN
                                            INNER JOIN ReglasRank RC ON RC.IdPlan = P.IdPlan AND RC.RN = PH.RN
                                            INNER JOIN dbo.PlanHorarioDia PHD ON PHD.IdPlanHorario = PH.IdPlanHorario
                                            WHERE (TP.IdTipoPlan = 3 OR TP.Nombre LIKE N'%demanda%')
                                              AND TP.Estado = 1
                                              AND P.Estado = 1
                                              AND P.IdTipoVehiculo = @IdTipoVehiculo
                                              AND P.IdCategoriaVehiculo = @IdCategoriaVehiculo;

                                            SELECT TOP (0) * INTO #TarifaAplicada FROM #Tarifas;

                                            CREATE TABLE #Detalle
                                            (
                                                IdDetalle INT IDENTITY(1,1) PRIMARY KEY,
                                                TipoCalculo NVARCHAR(40) NOT NULL,
                                                FechaHoraInicio DATETIME2(0) NOT NULL,
                                                FechaHoraFin DATETIME2(0) NOT NULL,
                                                IdPlanTarifa INT NOT NULL,
                                                NombrePlan NVARCHAR(100) NOT NULL,
                                                NombreHorario NVARCHAR(100) NULL,
                                                UnidadCobro NVARCHAR(20) NULL,
                                                MinutosTramo INT NOT NULL,
                                                TiempoTramoFormateado NVARCHAR(100) NOT NULL,
                                                MinutosGratis INT NOT NULL,
                                                MinutosCobrados INT NOT NULL,
                                                TiempoCobradoFormateado NVARCHAR(100) NOT NULL,
                                                MinutosFraccion INT NULL,
                                                MinutosGracia INT NOT NULL,
                                                ValorMinuto DECIMAL(18,2) NULL,
                                                ValorHora DECIMAL(18,2) NULL,
                                                Valor12Horas DECIMAL(18,2) NULL,
                                                Valor24Horas DECIMAL(18,2) NULL,
                                                Importe DECIMAL(18,2) NOT NULL
                                            );

                                            -- Obtener si el plan activo tiene configurado algún valor de 12 o 24 horas
                                            DECLARE @TienePaquetes BIT = 0;
                                            IF EXISTS (SELECT 1 FROM #Tarifas WHERE ISNULL(Valor12Horas, 0) > 0 OR ISNULL(Valor24Horas, 0) > 0)
                                                SET @TienePaquetes = 1;

                                            -- Extraer datos base de tarifa para cuando se usa el modo paquetes
                                            SELECT TOP (1)
                                                @IdPlanTarifa = IdPlanTarifa, @NombrePlan = NombrePlan, @NombreHorario = NombreHorario,
                                                @UnidadCobro = UnidadCobro, @MinutosFraccion = MinutosFraccion, @MinutosGracia = ISNULL(MinutosGracia, 0),
                                                @ValorMinuto = ValorMinuto, @ValorHora = ValorHora,
                                                @Valor12Horas = Valor12Horas, @Valor24Horas = Valor24Horas
                                            FROM #Tarifas;

                                            DECLARE @IteracionCalculo DATETIME2(0) = @FechaInicioCalculo;

                                            IF @TienePaquetes = 1
                                            BEGIN
                                                /* -------------------------------------------------------------------------------------------------------
                                                   MODO PAQUETES: SI HAY TRAMOS DE 12 Y 24 HORAS, SE APLICAN PAQUETES Y NUNCA ""Cobro por jornada""
                                                --------------------------------------------------------------------------------------------------------*/
            
                                                -- 5. COBRAR PAQUETES DE 24 HORAS
                                                WHILE DATEADD(HOUR, 24, @IteracionCalculo) <= @FechaHoraSalida AND ISNULL(@Valor24Horas, 0) > 0
                                                BEGIN
                                                    INSERT INTO #Detalle VALUES (
                                                        N'Paquete de 24 horas', @IteracionCalculo, DATEADD(HOUR, 24, @IteracionCalculo),
                                                        @IdPlanTarifa, @NombrePlan, @NombreHorario, @UnidadCobro, 
                                                        1440, N'24 hora(s) y 0 minuto(s)', 0, 1440, N'24 hora(s) y 0 minuto(s)',
                                                        @MinutosFraccion, @MinutosGracia, @ValorMinuto, @ValorHora, @Valor12Horas, @Valor24Horas, @Valor24Horas
                                                    );

                                                    SET @PaquetesAplicados = 1;
                                                    SET @IteracionCalculo = DATEADD(HOUR, 24, @IteracionCalculo);
                                                END;

                                                -- 6. COBRAR PAQUETES DE 12 HORAS
                                                WHILE DATEADD(HOUR, 12, @IteracionCalculo) <= @FechaHoraSalida AND ISNULL(@Valor12Horas, 0) > 0
                                                BEGIN
                                                    INSERT INTO #Detalle VALUES (
                                                        N'Paquete de 12 horas', @IteracionCalculo, DATEADD(HOUR, 12, @IteracionCalculo),
                                                        @IdPlanTarifa, @NombrePlan, @NombreHorario, @UnidadCobro, 
                                                        720, N'12 hora(s) y 0 minuto(s)', 0, 720, N'12 hora(s) y 0 minuto(s)',
                                                        @MinutosFraccion, @MinutosGracia, @ValorMinuto, @ValorHora, @Valor12Horas, @Valor24Horas, @Valor12Horas
                                                    );

                                                    SET @PaquetesAplicados = 1;
                                                    SET @IteracionCalculo = DATEADD(HOUR, 12, @IteracionCalculo);
                                                END;

                                                -- 7. FRACCIÓN RESTANTE (Si queda tiempo tras aplicar paquetes de 12 y 24 horas)
                                                DECLARE @MinutosRestantesPaquete INT = CONVERT(INT, CEILING(DATEDIFF_BIG(SECOND, @IteracionCalculo, @FechaHoraSalida) / 60.0));
                                                IF @MinutosRestantesPaquete > 0
                                                BEGIN
                                                    DECLARE @MinGraciaRem INT = ISNULL(@MinutosGracia, 0);
                                                    DECLARE @MinGratisRem INT = CASE WHEN @MinGraciaRem >= @MinutosRestantesPaquete THEN @MinutosRestantesPaquete ELSE @MinGraciaRem END;
                                                    DECLARE @MinCobRem INT = @MinutosRestantesPaquete - @MinGratisRem;
                                                    DECLARE @ImporteRem DECIMAL(18,2) = 0;

                                                    IF @MinCobRem > 0
                                                    BEGIN
                                                        IF @UnidadCobro = N'MINUTO'
                                                        BEGIN
                                                            SET @ImporteRem = @MinCobRem * ISNULL(@ValorMinuto, 0);
                                                        END
                                                        ELSE -- HORA
                                                        BEGIN
                                                            DECLARE @HC_rem INT = @MinCobRem / 60;
                                                            DECLARE @MR_rem INT = @MinCobRem % 60;
                                                            SET @ImporteRem = @HC_rem * ISNULL(@ValorHora, 0);
                                                            IF @MR_rem > 0
                                                            BEGIN
                                                                IF @MinutosFraccion IS NOT NULL AND @MinutosFraccion > 0 AND @MR_rem >= @MinutosFraccion
                                                                    SET @ImporteRem = @ImporteRem + ISNULL(@ValorHora, 0);
                                                                ELSE IF @ValorMinuto IS NOT NULL
                                                                    SET @ImporteRem = @ImporteRem + (@MR_rem * @ValorMinuto);
                                                                ELSE
                                                                    SET @ImporteRem = @ImporteRem + ISNULL(@ValorHora, 0);
                                                            END
                                                        END
                                                    END;

                                                    SET @ImporteRem = ROUND(@ImporteRem, 2);

                                                    INSERT INTO #Detalle VALUES (
                                                        N'Cobro por jornada', @IteracionCalculo, @FechaHoraSalida,
                                                        @IdPlanTarifa, @NombrePlan, @NombreHorario, @UnidadCobro,
                                                        @MinutosRestantesPaquete, CONCAT(@MinutosRestantesPaquete / 60, N' hora(s) y ', @MinutosRestantesPaquete % 60, N' minuto(s)'),
                                                        @MinGratisRem, @MinCobRem, CONCAT(@MinCobRem / 60, N' hora(s) y ', @MinCobRem % 60, N' minuto(s)'),
                                                        @MinutosFraccion, @MinGraciaRem, @ValorMinuto, @ValorHora, @Valor12Horas, @Valor24Horas, @ImporteRem
                                                    );
                                                END;
                                            END
                                            ELSE
                                            BEGIN
                                                /* -------------------------------------------------------------------------------------------------------
                                                   MODO SIN PAQUETES: EL ""Cobro por jornada"" ES EXCLUSIVAMENTE CUANDO NO HAY TRAMOS DE 12 Y 24 HORAS
                                                --------------------------------------------------------------------------------------------------------*/
                                                CREATE TABLE #Puntos (Punto DATETIME2(0) NOT NULL PRIMARY KEY);
                                                INSERT INTO #Puntos (Punto) VALUES (@IteracionCalculo);
                                                IF @FechaHoraSalida > @IteracionCalculo INSERT INTO #Puntos (Punto) VALUES (@FechaHoraSalida);

                                                SET @FechaIteracion = CONVERT(DATE, @IteracionCalculo);
                                                SET @FechaFinal = CONVERT(DATE, @FechaHoraSalida);

                                                WHILE @FechaIteracion <= @FechaFinal
                                                BEGIN
                                                    SET @DiaSemanaIteracion = CONVERT(TINYINT, (DATEDIFF(DAY, CONVERT(DATE, '19000101'), @FechaIteracion) % 7) + 1);

                                                    ;WITH Limites AS (
                                                        SELECT X.Punto FROM #Tarifas T
                                                        CROSS APPLY (
                                                            VALUES 
                                                            (DATEADD(SECOND, DATEDIFF(SECOND, CONVERT(TIME(0), '00:00:00'), T.HoraInicio), CONVERT(DATETIME2(0), @FechaIteracion))),
                                                            (DATEADD(DAY, CASE WHEN T.CruzaMedianoche = 1 THEN 1 ELSE 0 END, DATEADD(SECOND, DATEDIFF(SECOND, CONVERT(TIME(0), '00:00:00'), T.HoraFin), CONVERT(DATETIME2(0), @FechaIteracion))))
                                                        ) X(Punto)
                                                        WHERE T.DiaSemana = @DiaSemanaIteracion
                                                          AND T.InicioTarifa <= @FechaIteracion AND (T.FinTarifa IS NULL OR T.FinTarifa >= @FechaIteracion)
                                                          AND (T.InicioPlan IS NULL OR T.InicioPlan <= @FechaIteracion) AND (T.FinPlan IS NULL OR T.FinPlan >= @FechaIteracion)
                                                    )
                                                    INSERT INTO #Puntos (Punto)
                                                    SELECT DISTINCT L.Punto FROM Limites L
                                                    WHERE L.Punto > @IteracionCalculo AND L.Punto < @FechaHoraSalida
                                                      AND NOT EXISTS (SELECT 1 FROM #Puntos P WHERE P.Punto = L.Punto);

                                                    SET @FechaIteracion = DATEADD(DAY, 1, @FechaIteracion);
                                                END;

                                                ;WITH OrdenPuntos AS (
                                                    SELECT Punto AS FechaInicio, LEAD(Punto) OVER (ORDER BY Punto) AS FechaFin FROM #Puntos
                                                )
                                                SELECT FechaInicio, FechaFin INTO #Tramos FROM OrdenPuntos WHERE FechaFin IS NOT NULL AND FechaFin > FechaInicio;

                                                DECLARE CursorTramos CURSOR LOCAL FAST_FORWARD FOR SELECT FechaInicio, FechaFin FROM #Tramos ORDER BY FechaInicio;
                                                OPEN CursorTramos;
                                                FETCH NEXT FROM CursorTramos INTO @InicioTramo, @FinTramo;

                                                WHILE @@FETCH_STATUS = 0
                                                BEGIN
                                                    DECLARE @FechaConsultaDateTr DATE = CONVERT(DATE, @InicioTramo);
                                                    DECLARE @HoraConsultaTr TIME(0) = CONVERT(TIME(0), @InicioTramo);
                                                    DECLARE @DiaConsultaTr TINYINT = CONVERT(TINYINT, (DATEDIFF(DAY, CONVERT(DATE, '19000101'), @FechaConsultaDateTr) % 7) + 1);
                                                    DECLARE @DiaAnteriorTr TINYINT = CASE WHEN @DiaConsultaTr = 1 THEN 7 ELSE @DiaConsultaTr - 1 END;

                                                    DELETE FROM #TarifaAplicada;

                                                    INSERT INTO #TarifaAplicada
                                                    SELECT TOP (1) T.* FROM #Tarifas T
                                                    WHERE (T.InicioPlan IS NULL OR T.InicioPlan <= @FechaConsultaDateTr)
                                                      AND (T.FinPlan IS NULL OR T.FinPlan >= @FechaConsultaDateTr)
                                                      AND T.InicioTarifa <= @FechaConsultaDateTr
                                                      AND (T.FinTarifa IS NULL OR T.FinTarifa >= @FechaConsultaDateTr)
                                                      AND ((T.CruzaMedianoche = 0 AND @HoraConsultaTr >= T.HoraInicio AND @HoraConsultaTr < T.HoraFin AND T.DiaSemana = @DiaConsultaTr)
                                                           OR (T.CruzaMedianoche = 1 AND ((@HoraConsultaTr >= T.HoraInicio AND T.DiaSemana = @DiaConsultaTr) OR (@HoraConsultaTr < T.HoraFin AND T.DiaSemana = @DiaAnteriorTr))))
                                                    ORDER BY T.InicioTarifa DESC, T.IdPlanTarifa ASC, T.HoraInicio DESC;

                                                    IF NOT EXISTS (SELECT 1 FROM #TarifaAplicada)
                                                    BEGIN
                                                        INSERT INTO #TarifaAplicada SELECT TOP (1) * FROM #Tarifas;
                                                        IF NOT EXISTS (SELECT 1 FROM #TarifaAplicada)
                                                        BEGIN
                                                            CLOSE CursorTramos; DEALLOCATE CursorTramos;
                                                            THROW 56205, 'No existe una tarifa válida para uno de los tramos del excedente.', 1;
                                                        END;
                                                    END;

                                                    SELECT @IdPlanTarifa = IdPlanTarifa, @NombrePlan = NombrePlan, @NombreHorario = NombreHorario,
                                                           @UnidadCobro = UnidadCobro, @MinutosFraccion = MinutosFraccion, @MinutosGracia = ISNULL(MinutosGracia, 0),
                                                           @ValorMinuto = ValorMinuto, @ValorHora = ValorHora,
                                                           @Valor12Horas = Valor12Horas, @Valor24Horas = Valor24Horas
                                                    FROM #TarifaAplicada;

                                                    SET @MinutosTramo = CONVERT(INT, CEILING(DATEDIFF_BIG(SECOND, @InicioTramo, @FinTramo) / 60.0));
                                                    SET @MinutosGratisTramo = CASE WHEN @MinutosGracia >= @MinutosTramo THEN @MinutosTramo ELSE @MinutosGracia END;
                                                    SET @MinutosCobradosTramo = @MinutosTramo - @MinutosGratisTramo;
                
                                                    SET @TxtTramo = CONCAT(@MinutosTramo / 60, N' hora(s) y ', @MinutosTramo % 60, N' minuto(s)');
                                                    SET @TxtCobradosTramo = CONCAT(@MinutosCobradosTramo / 60, N' hora(s) y ', @MinutosCobradosTramo % 60, N' minuto(s)');

                                                    SET @ImporteTramo = 0;

                                                    IF @MinutosCobradosTramo > 0
                                                    BEGIN
                                                        IF @UnidadCobro = N'MINUTO'
                                                        BEGIN
                                                            IF @ValorMinuto IS NULL SET @ValorMinuto = 0;
                                                            SET @ImporteTramo = @MinutosCobradosTramo * @ValorMinuto;
                                                        END
                                                        ELSE IF @UnidadCobro = N'HORA'
                                                        BEGIN
                                                            IF @ValorHora IS NULL SET @ValorHora = 0;

                                                            SET @HorasCompletas = @MinutosCobradosTramo / 60;
                                                            SET @MinutosRestantes = @MinutosCobradosTramo % 60;
                                                            SET @ImporteTramo = @HorasCompletas * @ValorHora;

                                                            IF @MinutosRestantes > 0
                                                            BEGIN
                                                                IF @MinutosFraccion IS NOT NULL AND @MinutosFraccion > 0 AND @MinutosRestantes >= @MinutosFraccion
                                                                BEGIN
                                                                    SET @ImporteTramo = @ImporteTramo + @ValorHora;
                                                                END
                                                                ELSE IF @ValorMinuto IS NOT NULL
                                                                BEGIN
                                                                    SET @ImporteTramo = @ImporteTramo + (@MinutosRestantes * @ValorMinuto);
                                                                END
                                                                ELSE
                                                                BEGIN
                                                                    SET @ImporteTramo = @ImporteTramo + @ValorHora;
                                                                END;
                                                            END;
                                                        END;
                                                    END;

                                                    SET @ImporteTramo = ROUND(@ImporteTramo, 2);

                                                    INSERT INTO #Detalle VALUES (
                                                        N'Cobro por jornada',
                                                        @InicioTramo, @FinTramo, @IdPlanTarifa, @NombrePlan, @NombreHorario, @UnidadCobro,
                                                        @MinutosTramo, @TxtTramo, @MinutosGratisTramo, @MinutosCobradosTramo, @TxtCobradosTramo,
                                                        @MinutosFraccion, @MinutosGracia, @ValorMinuto, @ValorHora, @Valor12Horas, @Valor24Horas, @ImporteTramo
                                                    );

                                                    FETCH NEXT FROM CursorTramos INTO @InicioTramo, @FinTramo;
                                                END;

                                                CLOSE CursorTramos;
                                                DEALLOCATE CursorTramos;
                                            END

                                            /* 9. TOTALES */
                                            SELECT
                                                @MinutosGratisTotal = ISNULL(SUM(MinutosGratis), 0),
                                                @MinutosCobradosTotal = ISNULL(SUM(MinutosCobrados), 0),
                                                @ValorTotal = ISNULL(SUM(Importe), 0)
                                            FROM #Detalle;

                                            SET @CobradosDias = @MinutosCobradosTotal / 1440;
                                            SET @CobradosHoras = (@MinutosCobradosTotal % 1440) / 60;
                                            SET @CobradosMinutos = @MinutosCobradosTotal % 60;

                                            IF @CobradosDias > 0
                                                SET @TextoCobrados = CONCAT(@CobradosDias, N' día(s), ', @CobradosHoras, N' hora(s) y ', @CobradosMinutos, N' minuto(s)');
                                            ELSE
                                                SET @TextoCobrados = CONCAT(@CobradosHoras, N' hora(s) y ', @CobradosMinutos, N' minuto(s)');

                                            SET @ModalidadCobro = N'Cobro discriminado por jornadas y minutos gratis';

                                            /* 10. INFORME PRINCIPAL (RESULTADO 1) */
                                            SELECT
                                                @PlacaConsultada AS Placa,
                                                ISNULL(FORMAT(@FechaHoraEntrada, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + UPPER(FORMAT(@FechaHoraEntrada, 'hh:mm tt', 'en-US')), '') AS HoraLlegada,
                                                ISNULL(FORMAT(@FechaHoraSalida, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + UPPER(FORMAT(@FechaHoraSalida, 'hh:mm tt', 'en-US')), '') AS HoraSalidaConsultada,
                                                @TextoPermanencia AS TiempoPermanencia, 
                                                @HorasPermanencia AS TotalHorasPermanencia, 
                                                @MinutosPermanencia AS TotalMinutosPermanencia,
                                                @MinutosGratisTotal AS TotalMinutosGratis, 
                                                @MinutosCobradosTotal AS TotalMinutosCobrados,
                                                @TextoCobrados AS TiempoCobradoFormateado,
                                                @TipoVehiculo AS TipoVehiculo, 
                                                @CategoriaVehiculo AS CategoriaVehiculo, 
                                                @CodigoCelda AS Celda, 
                                                @NombreNivel AS Nivel,
                                                @ValorTotal AS SubtotalJornadas, 
                                                @ValorTotal AS TotalPorPagar, 
                                                CONCAT ('$ ',FORMAT(@ValorTotal, 'N0', 'es-ES')) AS TotalPorPagarFormateado, 
                                                @ModalidadCobro AS ModalidadCobro;

                                            /* 11. DETALLE DISCRIMINADO (RESULTADO 2) */
                                            SELECT
                                                IdDetalle AS Numero, 
                                                TipoCalculo,
                                                ISNULL(FORMAT(FechaHoraInicio, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + UPPER(FORMAT(FechaHoraInicio, 'hh:mm tt', 'en-US')), '') AS FechaHoraInicio,
                                                ISNULL(FORMAT(FechaHoraFin, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + UPPER(FORMAT(FechaHoraFin, 'hh:mm tt', 'en-US')), '') AS FechaHoraFin, 
                                                NombrePlan AS PlanTarifario,
                                                NombreHorario AS Jornada, 
                                                MinutosTramo, 
                                                TiempoTramoFormateado,
                                                MinutosGracia AS MinutosGratisConfigurados, 
                                                MinutosGratis AS MinutosGratisAplicados,
                                                MinutosCobrados, 
                                                TiempoCobradoFormateado,
                                                MinutosFraccion, 
                                                ValorMinuto, 
                                                ValorHora, 
                                                Valor12Horas, 
                                                Valor24Horas,
                                                Importe, 
                                                CONCAT ('$ ',FORMAT(Importe, 'N0', 'es-ES')) AS ImporteFormateado
                                            FROM #Detalle
                                            ORDER BY FechaHoraInicio, IdDetalle;
                                        END
                                    END;";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch
            {
                MessageBox.Show($"Error al obtener movimientos de vehículos.\n{conexionBD.StrError}", "Movimiento Vehículo", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region calcular cobro estadia
        public async Task<DataSet> CalcularCobroEstadiaAsync(string placa, string IdTipoVehiculo, string IdCategoriaVehiculo)
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    var parametros = new List<KeyValuePair<string, object>>
                    {
                        new KeyValuePair<string, object>("@Placa", placa),
                    };

                    string sql = $@"SET NOCOUNT ON;

-- Limpiar tablas temporales
IF OBJECT_ID('tempdb..#Tarifas') IS NOT NULL DROP TABLE #Tarifas;
IF OBJECT_ID('tempdb..#TarifaAplicada') IS NOT NULL DROP TABLE #TarifaAplicada;
IF OBJECT_ID('tempdb..#Detalle') IS NOT NULL DROP TABLE #Detalle;
IF OBJECT_ID('tempdb..#Tramos') IS NOT NULL DROP TABLE #Tramos;
IF OBJECT_ID('tempdb..#Puntos') IS NOT NULL DROP TABLE #Puntos;

DECLARE @FechaHoraSalida DATETIME2(0) = CONVERT(DATETIME2(0), SYSDATETIME());

DECLARE @IdMovimiento INT;
DECLARE @IdVehiculo INT;
DECLARE @IdCelda INT;

DECLARE @PlacaConsultada VARCHAR(10);
DECLARE @TipoCobro VARCHAR(20);
DECLARE @TipoVehiculo VARCHAR(60);
DECLARE @CategoriaVehiculo VARCHAR(60);
DECLARE @CodigoCelda NVARCHAR(20);
DECLARE @NombreNivel NVARCHAR(50);
DECLARE @IdTipoVehiculo INT;
DECLARE @IdCategoriaVehiculo INT;

DECLARE @FechaHoraEntrada DATETIME2(0);
DECLARE @FechaInicioCalculo DATETIME2(0);
DECLARE @FechaConsultaDate DATE;
DECLARE @HoraConsulta TIME(0);
DECLARE @DiaConsulta TINYINT;
DECLARE @DiaAnterior TINYINT;

DECLARE @MinutosPermanencia INT;
DECLARE @HorasPermanencia DECIMAL(18,2);
DECLARE @Dias INT;
DECLARE @Horas INT;
DECLARE @Minutos INT;
DECLARE @TextoPermanencia NVARCHAR(150);

DECLARE @CobradosDias INT;
DECLARE @CobradosHoras INT;
DECLARE @CobradosMinutos INT;
DECLARE @TextoCobrados NVARCHAR(150);

DECLARE @IdPlanTarifa INT;
DECLARE @IdPlanHorario INT;
DECLARE @NombrePlan NVARCHAR(100);
DECLARE @NombreHorario NVARCHAR(100);
DECLARE @UnidadCobro NVARCHAR(20);
DECLARE @MinutosFraccion INT;
DECLARE @MinutosGracia INT;

DECLARE @ValorMinuto DECIMAL(18,2);
DECLARE @ValorHora DECIMAL(18,2);
DECLARE @Valor12Horas DECIMAL(18,2);
DECLARE @Valor24Horas DECIMAL(18,2);

DECLARE @MinutosTramo INT;
DECLARE @MinutosGratisTramo INT;
DECLARE @MinutosCobradosTramo INT;
DECLARE @TxtTramo NVARCHAR(100);
DECLARE @TxtCobradosTramo NVARCHAR(100);

DECLARE @HorasCompletas INT;
DECLARE @MinutosRestantes INT;

DECLARE @ImporteTramo DECIMAL(18,2);
DECLARE @ValorTotal DECIMAL(18,2) = 0;
DECLARE @MinutosGratisTotal INT = 0;
DECLARE @MinutosCobradosTotal INT = 0;

DECLARE @PaquetesAplicados BIT = 0;
DECLARE @InicioTramo DATETIME2(0);
DECLARE @FinTramo DATETIME2(0);
DECLARE @FechaIteracion DATE;
DECLARE @FechaFinal DATE;
DECLARE @DiaSemanaIteracion TINYINT;

DECLARE @ModalidadCobro NVARCHAR(150) = N'Cobro por jornadas';

/* 1. BUSCAR EL MOVIMIENTO ABIERTO */
SELECT TOP (1)
    @IdMovimiento = MP.IdMovimiento,
    @IdVehiculo = MP.IdVehiculo,
    @IdCelda = MP.IdCelda,
    @FechaHoraEntrada = MP.FechaHoraEntrada,
    @TipoCobro = MP.TipoCobro,
    @PlacaConsultada = V.Placa,
    @TipoVehiculo = TV.Nombre,
    @CategoriaVehiculo = CV.Nombre,
    @CodigoCelda = C.Codigo,
    @NombreNivel = N.Nombre,
    @IdTipoVehiculo = V.idtipovehiculo,
    @IdCategoriaVehiculo = V.IdCategoriaVehiculo
FROM dbo.MovimientoParqueadero MP
INNER JOIN dbo.Vehiculo V ON V.Idvehiculo = MP.Idvehiculo
INNER JOIN dbo.Celda C ON C.IdCelda = MP.IdCelda
INNER JOIN dbo.Nivel N ON N.IdNivel = C.IdNivel
LEFT JOIN dbo.TipoVehiculo TV ON TV.IdTipoVehiculo = V.idtipovehiculo
LEFT JOIN dbo.CategoriaVehiculo CV ON CV.IdCategoriaVehiculo = V.IdCategoriaVehiculo
WHERE V.Placa = UPPER(LTRIM(RTRIM(@Placa)))
  AND MP.Estado = 'Dentro'
  AND MP.FechaHoraSalida IS NULL
ORDER BY MP.FechaHoraEntrada DESC;

IF @IdMovimiento IS NULL THROW 56201, 'No existe un movimiento abierto para esta placa.', 1;
IF @IdTipoVehiculo IS NULL OR @IdCategoriaVehiculo IS NULL THROW 56203, 'El vehículo no tiene tipo o categoría configurados.', 1;
IF @FechaHoraSalida < @FechaHoraEntrada THROW 56204, 'La salida no puede ser anterior a la entrada.', 1;

/* 2. CALCULAR LA PERMANENCIA */
SET @MinutosPermanencia = CONVERT(INT, CEILING(DATEDIFF_BIG(SECOND, @FechaHoraEntrada, @FechaHoraSalida) / 60.0));
SET @HorasPermanencia = CONVERT(DECIMAL(18,2), @MinutosPermanencia / 60.0);

SET @Dias = @MinutosPermanencia / 1440;
SET @Horas = (@MinutosPermanencia % 1440) / 60;
SET @Minutos = @MinutosPermanencia % 60;

IF @Dias > 0
    SET @TextoPermanencia = CONCAT(@Dias, N' día(s), ', @Horas, N' hora(s) y ', @Minutos, N' minuto(s)');
ELSE
    SET @TextoPermanencia = CONCAT(@Horas, N' hora(s) y ', @Minutos, N' minuto(s)');

/* 3. CARGAR TARIFAS Y REGLAS DE TIEMPO POR DEMANDA */
WITH TarifasRank AS (
    SELECT 
        IdPlanTarifa, IdPlan, ValorMinuto, ValorHora, Valor12Horas, Valor24Horas,
        FechaInicioVigencia AS InicioTarifa, FechaFinVigencia AS FinTarifa,
        ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanTarifa ASC) AS RN
    FROM dbo.PlanTarifa
    WHERE Estado = 1
),
HorariosRank AS (
    SELECT 
        IdPlanHorario, IdPlan, Nombre AS NombreHorario, HoraInicio, HoraFin, CruzaMedianoche,
        ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanHorario ASC) AS RN
    FROM dbo.PlanHorario
    WHERE Estado = 1
),
ReglasRank AS (
    SELECT 
        IdPlanReglaCobro, IdPlan, UnidadCobro, MinutosFraccion, MinutosGracia,
        ROW_NUMBER() OVER (PARTITION BY IdPlan ORDER BY IdPlanReglaCobro ASC) AS RN
    FROM dbo.PlanReglaCobro
)
SELECT
    P.IdPlan, P.IdTipoVehiculo, P.IdCategoriaVehiculo, P.Nombre AS NombrePlan,
    P.FechaInicioVigencia AS InicioPlan, P.FechaFinVigencia AS FinPlan,
    PT.IdPlanTarifa, PT.InicioTarifa, PT.FinTarifa,
    PT.ValorMinuto, PT.ValorHora, PT.Valor12Horas, PT.Valor24Horas,
    RC.UnidadCobro, RC.MinutosFraccion, RC.MinutosGracia,
    PH.IdPlanHorario, PH.NombreHorario, PH.HoraInicio, PH.HoraFin, PH.CruzaMedianoche,
    PHD.DiaSemana
INTO #Tarifas
FROM dbo.[Plan] P
INNER JOIN dbo.TipoPlan TP ON TP.IdTipoPlan = P.IdTipoPlan
INNER JOIN TarifasRank PT ON PT.IdPlan = P.IdPlan
INNER JOIN HorariosRank PH ON PH.IdPlan = P.IdPlan AND PH.RN = PT.RN
INNER JOIN ReglasRank RC ON RC.IdPlan = P.IdPlan AND RC.RN = PH.RN
INNER JOIN dbo.PlanHorarioDia PHD ON PHD.IdPlanHorario = PH.IdPlanHorario
WHERE (TP.IdTipoPlan = 3 OR TP.Nombre LIKE N'%demanda%')
  AND TP.Estado = 1
  AND P.Estado = 1
  AND P.IdTipoVehiculo = @IdTipoVehiculo
  AND P.IdCategoriaVehiculo = @IdCategoriaVehiculo;

SELECT TOP (0) * INTO #TarifaAplicada FROM #Tarifas;

CREATE TABLE #Detalle
(
    IdDetalle INT IDENTITY(1,1) PRIMARY KEY,
    TipoCalculo NVARCHAR(40) NOT NULL,
    FechaHoraInicio DATETIME2(0) NOT NULL,
    FechaHoraFin DATETIME2(0) NOT NULL,
    IdPlanTarifa INT NOT NULL,
    NombrePlan NVARCHAR(100) NOT NULL,
    NombreHorario NVARCHAR(100) NULL,
    UnidadCobro NVARCHAR(20) NULL,
    MinutosTramo INT NOT NULL,
    TiempoTramoFormateado NVARCHAR(100) NOT NULL,
    MinutosGratis INT NOT NULL,
    MinutosCobrados INT NOT NULL,
    TiempoCobradoFormateado NVARCHAR(100) NOT NULL,
    MinutosFraccion INT NULL,
    MinutosGracia INT NOT NULL,
    ValorMinuto DECIMAL(18,2) NULL,
    ValorHora DECIMAL(18,2) NULL,
    Valor12Horas DECIMAL(18,2) NULL,
    Valor24Horas DECIMAL(18,2) NULL,
    Importe DECIMAL(18,2) NOT NULL
);

-- Determinar si el plan tiene tramos o valores de 12 y 24 horas configurados
DECLARE @TienePaquetes BIT = 0;
IF EXISTS (SELECT 1 FROM #Tarifas WHERE ISNULL(Valor12Horas, 0) > 0 OR ISNULL(Valor24Horas, 0) > 0)
    SET @TienePaquetes = 1;

SELECT TOP (1)
    @IdPlanTarifa = IdPlanTarifa, @NombrePlan = NombrePlan, @NombreHorario = NombreHorario,
    @UnidadCobro = UnidadCobro, @MinutosFraccion = MinutosFraccion, @MinutosGracia = ISNULL(MinutosGracia, 0),
    @ValorMinuto = ValorMinuto, @ValorHora = ValorHora,
    @Valor12Horas = Valor12Horas, @Valor24Horas = Valor24Horas
FROM #Tarifas;

SET @FechaInicioCalculo = @FechaHoraEntrada;
DECLARE @IteracionCalculo DATETIME2(0) = @FechaInicioCalculo;

IF @TienePaquetes = 1
BEGIN
    /* -------------------------------------------------------------------------------------------------------
       SI HAY TRAMOS DE 12 Y 24 HORAS: NUNCA SE HACE ""Cobro por jornada""
    --------------------------------------------------------------------------------------------------------*/
    WHILE DATEADD(HOUR, 24, @IteracionCalculo) <= @FechaHoraSalida AND ISNULL(@Valor24Horas, 0) > 0
    BEGIN
        INSERT INTO #Detalle VALUES (
            N'Paquete de 24 horas', @IteracionCalculo, DATEADD(HOUR, 24, @IteracionCalculo),
            @IdPlanTarifa, @NombrePlan, @NombreHorario, @UnidadCobro, 
            1440, N'24 hora(s) y 0 minuto(s)', 0, 1440, N'24 hora(s) y 0 minuto(s)',
            @MinutosFraccion, @MinutosGracia, @ValorMinuto, @ValorHora, @Valor12Horas, @Valor24Horas, @Valor24Horas
        );
        SET @PaquetesAplicados = 1;
        SET @IteracionCalculo = DATEADD(HOUR, 24, @IteracionCalculo);
    END;

    WHILE DATEADD(HOUR, 12, @IteracionCalculo) <= @FechaHoraSalida AND ISNULL(@Valor12Horas, 0) > 0
    BEGIN
        INSERT INTO #Detalle VALUES (
            N'Paquete de 12 horas', @IteracionCalculo, DATEADD(HOUR, 12, @IteracionCalculo),
            @IdPlanTarifa, @NombrePlan, @NombreHorario, @UnidadCobro, 
            720, N'12 hora(s) y 0 minuto(s)', 0, 720, N'12 hora(s) y 0 minuto(s)',
            @MinutosFraccion, @MinutosGracia, @ValorMinuto, @ValorHora, @Valor12Horas, @Valor24Horas, @Valor12Horas
        );
        SET @PaquetesAplicados = 1;
        SET @IteracionCalculo = DATEADD(HOUR, 12, @IteracionCalculo);
    END;

    -- Fracción restante exacta sin jornadas
    DECLARE @MinutosRestantesPaquete INT = CONVERT(INT, CEILING(DATEDIFF_BIG(SECOND, @IteracionCalculo, @FechaHoraSalida) / 60.0));
    IF @MinutosRestantesPaquete > 0
    BEGIN
        DECLARE @MinGraciaRem INT = ISNULL(@MinutosGracia, 0);
        DECLARE @MinGratisRem INT = CASE WHEN @MinGraciaRem >= @MinutosRestantesPaquete THEN @MinutosRestantesPaquete ELSE @MinGraciaRem END;
        DECLARE @MinCobRem INT = @MinutosRestantesPaquete - @MinGratisRem;
        DECLARE @ImporteRem DECIMAL(18,2) = 0;

        IF @MinCobRem > 0
        BEGIN
            IF @UnidadCobro = N'MINUTO'
                SET @ImporteRem = @MinCobRem * ISNULL(@ValorMinuto, 0);
            ELSE
            BEGIN
                DECLARE @HC_rem INT = @MinCobRem / 60;
                DECLARE @MR_rem INT = @MinCobRem % 60;
                SET @ImporteRem = @HC_rem * ISNULL(@ValorHora, 0);
                IF @MR_rem > 0
                BEGIN
                    IF @MinutosFraccion IS NOT NULL AND @MinutosFraccion > 0 AND @MR_rem >= @MinutosFraccion
                        SET @ImporteRem = @ImporteRem + ISNULL(@ValorHora, 0);
                    ELSE IF @ValorMinuto IS NOT NULL
                        SET @ImporteRem = @ImporteRem + (@MR_rem * @ValorMinuto);
                    ELSE
                        SET @ImporteRem = @ImporteRem + ISNULL(@ValorHora, 0);
                END
            END
        END;

        SET @ImporteRem = ROUND(@ImporteRem, 2);

        INSERT INTO #Detalle VALUES (
            N'Fracción', @IteracionCalculo, @FechaHoraSalida,
            @IdPlanTarifa, @NombrePlan, @NombreHorario, @UnidadCobro,
            @MinutosRestantesPaquete, CONCAT(@MinutosRestantesPaquete / 60, N' hora(s) y ', @MinutosRestantesPaquete % 60, N' minuto(s)'),
            @MinGratisRem, @MinCobRem, CONCAT(@MinCobRem / 60, N' hora(s) y ', @MinCobRem % 60, N' minuto(s)'),
            @MinutosFraccion, @MinGraciaRem, @ValorMinuto, @ValorHora, @Valor12Horas, @Valor24Horas, @ImporteRem
        );
    END;
END
ELSE
BEGIN
    /* -------------------------------------------------------------------------------------------------------
       EL ""Cobro por jornada"" ES EXCLUSIVAMENTE CUANDO NO HAY TRAMOS DE 12 Y 24 HORAS
    --------------------------------------------------------------------------------------------------------*/
    CREATE TABLE #Puntos (Punto DATETIME2(0) NOT NULL PRIMARY KEY);
    INSERT INTO #Puntos (Punto) VALUES (@IteracionCalculo);
    IF @FechaHoraSalida > @IteracionCalculo INSERT INTO #Puntos (Punto) VALUES (@FechaHoraSalida);

    SET @FechaIteracion = CONVERT(DATE, @IteracionCalculo);
    SET @FechaFinal = CONVERT(DATE, @FechaHoraSalida);

    WHILE @FechaIteracion <= @FechaFinal
    BEGIN
        SET @DiaSemanaIteracion = CONVERT(TINYINT, (DATEDIFF(DAY, CONVERT(DATE, '19000101'), @FechaIteracion) % 7) + 1);

        ;WITH Limites AS (
            SELECT X.Punto FROM #Tarifas T
            CROSS APPLY (
                VALUES 
                (DATEADD(SECOND, DATEDIFF(SECOND, CONVERT(TIME(0), '00:00:00'), T.HoraInicio), CONVERT(DATETIME2(0), @FechaIteracion))),
                (DATEADD(DAY, CASE WHEN T.CruzaMedianoche = 1 THEN 1 ELSE 0 END, DATEADD(SECOND, DATEDIFF(SECOND, CONVERT(TIME(0), '00:00:00'), T.HoraFin), CONVERT(DATETIME2(0), @FechaIteracion))))
            ) X(Punto)
            WHERE T.DiaSemana = @DiaSemanaIteracion
              AND T.InicioTarifa <= @FechaIteracion AND (T.FinTarifa IS NULL OR T.FinTarifa >= @FechaIteracion)
              AND (T.InicioPlan IS NULL OR T.InicioPlan <= @FechaIteracion) AND (T.FinPlan IS NULL OR T.FinPlan >= @FechaIteracion)
        )
        INSERT INTO #Puntos (Punto)
        SELECT DISTINCT L.Punto FROM Limites L
        WHERE L.Punto > @IteracionCalculo AND L.Punto < @FechaHoraSalida
          AND NOT EXISTS (SELECT 1 FROM #Puntos P WHERE P.Punto = L.Punto);

        SET @FechaIteracion = DATEADD(DAY, 1, @FechaIteracion);
    END;

    ;WITH OrdenPuntos AS (
        SELECT Punto AS FechaInicio, LEAD(Punto) OVER (ORDER BY Punto) AS FechaFin FROM #Puntos
    )
    SELECT FechaInicio, FechaFin INTO #Tramos FROM OrdenPuntos WHERE FechaFin IS NOT NULL AND FechaFin > FechaInicio;

    DECLARE CursorTramos CURSOR LOCAL FAST_FORWARD FOR SELECT FechaInicio, FechaFin FROM #Tramos ORDER BY FechaInicio;
    OPEN CursorTramos;
    FETCH NEXT FROM CursorTramos INTO @InicioTramo, @FinTramo;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @FechaConsultaDate = CONVERT(DATE, @InicioTramo);
        SET @HoraConsulta = CONVERT(TIME(0), @InicioTramo);
        SET @DiaConsulta = CONVERT(TINYINT, (DATEDIFF(DAY, CONVERT(DATE, '19000101'), @FechaConsultaDate) % 7) + 1);
        SET @DiaAnterior = CASE WHEN @DiaConsulta = 1 THEN 7 ELSE @DiaConsulta - 1 END;

        DELETE FROM #TarifaAplicada;

        INSERT INTO #TarifaAplicada
        SELECT TOP (1) T.* FROM #Tarifas T
        WHERE (T.InicioPlan IS NULL OR T.InicioPlan <= @FechaConsultaDate)
          AND (T.FinPlan IS NULL OR T.FinPlan >= @FechaConsultaDate)
          AND T.InicioTarifa <= @FechaConsultaDate
          AND (T.FinTarifa IS NULL OR T.FinTarifa >= @FechaConsultaDate)
          AND ((T.CruzaMedianoche = 0 AND @HoraConsulta >= T.HoraInicio AND @HoraConsulta < T.HoraFin AND T.DiaSemana = @DiaConsulta)
               OR (T.CruzaMedianoche = 1 AND ((@HoraConsulta >= T.HoraInicio AND T.DiaSemana = @DiaConsulta) OR (@HoraConsulta < T.HoraFin AND T.DiaSemana = @DiaAnterior))))
        ORDER BY T.InicioTarifa DESC, T.IdPlanTarifa ASC, T.HoraInicio DESC;

        IF NOT EXISTS (SELECT 1 FROM #TarifaAplicada)
        BEGIN
            INSERT INTO #TarifaAplicada SELECT TOP (1) * FROM #Tarifas;
            IF NOT EXISTS (SELECT 1 FROM #TarifaAplicada)
            BEGIN
                CLOSE CursorTramos; DEALLOCATE CursorTramos;
                THROW 56205, 'No existe una tarifa válida para uno de los tramos del excedente.', 1;
            END;
        END;

        SELECT @IdPlanTarifa = IdPlanTarifa, @NombrePlan = NombrePlan, @NombreHorario = NombreHorario,
               @UnidadCobro = UnidadCobro, @MinutosFraccion = MinutosFraccion, @MinutosGracia = ISNULL(MinutosGracia, 0),
               @ValorMinuto = ValorMinuto, @ValorHora = ValorHora,
               @Valor12Horas = Valor12Horas, @Valor24Horas = Valor24Horas
        FROM #TarifaAplicada;

        SET @MinutosTramo = CONVERT(INT, CEILING(DATEDIFF_BIG(SECOND, @InicioTramo, @FinTramo) / 60.0));
        SET @MinutosGratisTramo = CASE WHEN @MinutosGracia >= @MinutosTramo THEN @MinutosTramo ELSE @MinutosGracia END;
        SET @MinutosCobradosTramo = @MinutosTramo - @MinutosGratisTramo;
        
        SET @TxtTramo = CONCAT(@MinutosTramo / 60, N' hora(s) y ', @MinutosTramo % 60, N' minuto(s)');
        SET @TxtCobradosTramo = CONCAT(@MinutosCobradosTramo / 60, N' hora(s) y ', @MinutosCobradosTramo % 60, N' minuto(s)');

        SET @ImporteTramo = 0;

        IF @MinutosCobradosTramo > 0
        BEGIN
            IF @UnidadCobro = N'MINUTO'
            BEGIN
                IF @ValorMinuto IS NULL SET @ValorMinuto = 0;
                SET @ImporteTramo = @MinutosCobradosTramo * @ValorMinuto;
            END
            ELSE IF @UnidadCobro = N'HORA'
            BEGIN
                IF @ValorHora IS NULL SET @ValorHora = 0;
                SET @HorasCompletas = @MinutosCobradosTramo / 60;
                SET @MinutosRestantes = @MinutosCobradosTramo % 60;
                SET @ImporteTramo = @HorasCompletas * @ValorHora;

                IF @MinutosRestantes > 0
                BEGIN
                    IF @MinutosFraccion IS NOT NULL AND @MinutosFraccion > 0 AND @MinutosRestantes >= @MinutosFraccion
                        SET @ImporteTramo = @ImporteTramo + @ValorHora;
                    ELSE IF @ValorMinuto IS NOT NULL
                        SET @ImporteTramo = @ImporteTramo + (@MinutosRestantes * @ValorMinuto);
                    ELSE
                        SET @ImporteTramo = @ImporteTramo + @ValorHora;
                END;
            END;
        END;

        SET @ImporteTramo = ROUND(@ImporteTramo, 2);

        INSERT INTO #Detalle VALUES (
            N'Cobro por jornada',
            @InicioTramo, @FinTramo, @IdPlanTarifa, @NombrePlan, @NombreHorario, @UnidadCobro,
            @MinutosTramo, @TxtTramo, @MinutosGratisTramo, @MinutosCobradosTramo, @TxtCobradosTramo,
            @MinutosFraccion, @MinutosGracia, @ValorMinuto, @ValorHora, @Valor12Horas, @Valor24Horas, @ImporteTramo
        );

        FETCH NEXT FROM CursorTramos INTO @InicioTramo, @FinTramo;
    END;

    CLOSE CursorTramos;
    DEALLOCATE CursorTramos;
END

/* Totales */
SELECT
    @MinutosGratisTotal = ISNULL(SUM(MinutosGratis), 0),
    @MinutosCobradosTotal = ISNULL(SUM(MinutosCobrados), 0),
    @ValorTotal = ISNULL(SUM(Importe), 0)
FROM #Detalle;

SET @CobradosDias = @MinutosCobradosTotal / 1440;
SET @CobradosHoras = (@MinutosCobradosTotal % 1440) / 60;
SET @CobradosMinutos = @MinutosCobradosTotal % 60;

IF @CobradosDias > 0
    SET @TextoCobrados = CONCAT(@CobradosDias, N' día(s), ', @CobradosHoras, N' hora(s) y ', @CobradosMinutos, N' minuto(s)');
ELSE
    SET @TextoCobrados = CONCAT(@CobradosHoras, N' hora(s) y ', @Minutos, N' minuto(s)');

IF @TienePaquetes = 1
    SET @ModalidadCobro = N'Paquetes completos más fracción';
ELSE
    SET @ModalidadCobro = N'Cobro discriminado por jornadas y minutos gratis';

/* Resultado Principal */
SELECT
    @PlacaConsultada AS Placa,
    ISNULL(FORMAT(@FechaHoraEntrada, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + UPPER(FORMAT(@FechaHoraEntrada, 'hh:mm tt', 'en-US')), '') AS HoraLlegada,
    ISNULL(FORMAT(@FechaHoraSalida, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + UPPER(FORMAT(@FechaHoraSalida, 'hh:mm tt', 'en-US')), '') AS HoraSalidaConsultada,
    @TextoPermanencia AS TiempoPermanencia, 
    @HorasPermanencia AS TotalHorasPermanencia, 
    @MinutosPermanencia AS TotalMinutosPermanencia,
    @MinutosGratisTotal AS TotalMinutosGratis, 
    @MinutosCobradosTotal AS TotalMinutosCobrados,
    @TextoCobrados AS TiempoCobradoFormateado,
    @TipoVehiculo AS TipoVehiculo, 
    @CategoriaVehiculo AS CategoriaVehiculo, 
    @CodigoCelda AS Celda, 
    @NombreNivel AS Nivel,
    @ValorTotal AS SubtotalJornadas, 
    @ValorTotal AS TotalPorPagar, 
    CONCAT ('$ ',FORMAT(@ValorTotal, 'N0', 'es-ES')) AS TotalPorPagarFormateado, 
    @ModalidadCobro AS ModalidadCobro;

/* Detalle Discriminado */
SELECT
    IdDetalle AS Numero, 
    TipoCalculo,
    ISNULL(FORMAT(FechaHoraInicio, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + UPPER(FORMAT(FechaHoraInicio, 'hh:mm tt', 'en-US')), '') AS FechaHoraInicio,
    ISNULL(FORMAT(FechaHoraFin, 'dddd, dd \de MMMM \de yyyy, ', 'es-ES') + UPPER(FORMAT(FechaHoraFin, 'hh:mm tt', 'en-US')), '') AS FechaHoraFin, 
    NombrePlan AS PlanTarifario,
    NombreHorario AS Jornada, 
    MinutosTramo, 
    TiempoTramoFormateado,
    MinutosGracia AS MinutosGratisConfigurados, 
    MinutosGratis AS MinutosGratisAplicados,
    MinutosCobrados, 
    TiempoCobradoFormateado,
    MinutosFraccion, 
    ValorMinuto, 
    ValorHora, 
    Valor12Horas, 
    Valor24Horas,
    Importe, 
    CONCAT ('$ ',FORMAT(Importe, 'N0', 'es-ES')) AS ImporteFormateado
FROM #Detalle
ORDER BY FechaHoraInicio, IdDetalle;";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch (Exception error) // Captura tanto SqlException como cualquier otro error inesperado
            {
                MessageBox.Show($"Error en el motor de cobro.\nDetalle DB: {conexionBD.StrError}\nExcepción: {error.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion

        #region estado_tipo_plan
        public async Task<DataSet> EstadoTipoPlanAsync(string placa)
        {
            string placaNormalizada = string.IsNullOrWhiteSpace(placa) ? string.Empty : placa.Trim().ToUpper();

            try
            {
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Placa", placaNormalizada)
                };

                if (await conexionBD.Connection())
                {
                    string strSQL = @"
                                    DECLARE @Hoy DATE = CONVERT(DATE, GETDATE());

                                    SELECT
                                        V.Idvehiculo,

                                        CASE
                                            WHEN M.IdVehiculoPlan IS NOT NULL
                                                THEN CAST(1 AS BIT)
                                            ELSE CAST(0 AS BIT)
                                        END AS TieneMembresiaActiva,

                                        CASE
                                            WHEN ME.IdVehiculoPlan IS NOT NULL
                                                THEN CAST(1 AS BIT)
                                            ELSE CAST(0 AS BIT)
                                        END AS TieneMensualidadActiva,
                                        
                                        CASE
                                            WHEN V.EsVIP <> 0
                                                THEN CAST(1 AS BIT)
                                            ELSE CAST(0 AS BIT)
                                        END AS Vip,

                                        V.idtipovehiculo,
                                        V.IdCategoriaVehiculo

                                    FROM Vehiculo V

                                    OUTER APPLY
                                    (
                                        SELECT TOP (1)
                                            VP.IdVehiculoPlan

                                        FROM VehiculoPlan VP

                                        INNER JOIN PlanTarifa PT
                                            ON PT.IdPlanTarifa = VP.IdPlanTarifa

                                        INNER JOIN [Plan] P
                                            ON P.IdPlan = PT.IdPlan

                                        INNER JOIN TipoPlan TP
                                            ON TP.IdTipoPlan = P.IdTipoPlan

                                        WHERE VP.IdVehiculo = V.Idvehiculo
                                          AND TP.Nombre = N'Membresía'
                                          AND VP.EstadoPago = 'Pagado'
                                          AND VP.EstadoContrato = 'Activa'
                                          AND VP.FechaInicio <= @Hoy
                                          AND VP.FechaFin >= @Hoy

                                        ORDER BY
                                            VP.FechaFin DESC,
                                            VP.IdVehiculoPlan DESC

                                    ) M

                                    OUTER APPLY
                                    (
                                        SELECT TOP (1)
                                            VP.IdVehiculoPlan

                                        FROM VehiculoPlan VP

                                        INNER JOIN PlanTarifa PT
                                            ON PT.IdPlanTarifa = VP.IdPlanTarifa

                                        INNER JOIN [Plan] P
                                            ON P.IdPlan = PT.IdPlan

                                        INNER JOIN TipoPlan TP
                                            ON TP.IdTipoPlan = P.IdTipoPlan

                                        WHERE VP.IdVehiculo = V.Idvehiculo
                                          AND TP.Nombre = N'Mensualidad'
                                          AND VP.EstadoPago = 'Pagado'
                                          AND VP.EstadoContrato = 'Activa'
                                          AND VP.FechaInicio <= @Hoy
                                          AND VP.FechaFin >= @Hoy

                                        ORDER BY
                                            VP.FechaFin DESC,
                                            VP.IdVehiculoPlan DESC

                                    ) ME

                                    WHERE V.Placa = @Placa;";

                    if (await conexionBD.DataSetAsync(strSQL, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                    else
                    {
                        throw new Exception("No fue posible consultar la información del plan.");
                    }
                }
                else
                {
                    throw new Exception("No fue posible establecer la conexión con la base de datos.");
                }
            }
            catch (Exception error)
            {
                string detalleError = !string.IsNullOrWhiteSpace(conexionBD.StrError) ? conexionBD.StrError : error.Message;

                MessageBox.Show("Error al consultar el estado del vehículo.\n" + detalleError, "Consultar vehículo", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
        }
        #endregion

        #region registrar entrada vehiculo
        public async Task<bool> RegistrarEntradaVehiculoAsync(
                                string placa,
                                string idTipoVehiculo,
                                string idCategoriaVehiculo,
                                string idCelda,
                                string idUsuarioLogin)
        {
            bool b = false;

            // Se declara fuera del try porque también se utiliza en catch.
            string placaNormalizada =
                string.IsNullOrWhiteSpace(placa)
                    ? string.Empty
                    : placa.Trim().ToUpper();

            try
            {

                if (string.IsNullOrWhiteSpace(placaNormalizada))
                {
                    MessageBox.Show(
                        "Debe ingresar la placa del vehículo.",
                        "Registrar Entrada",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return false;
                }

                if (!int.TryParse(idTipoVehiculo, out int tipoVehiculo))
                {
                    MessageBox.Show(
                        "El tipo de vehículo seleccionado no es válido.",
                        "Registrar Entrada",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return false;
                }

                if (!int.TryParse(idCategoriaVehiculo, out int categoriaVehiculo))
                {
                    MessageBox.Show(
                        "La categoría de vehículo seleccionada no es válida.",
                        "Registrar Entrada",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return false;
                }

                if (!int.TryParse(idCelda, out int celda))
                {
                    MessageBox.Show(
                        "La celda seleccionada no es válida.",
                        "Registrar Entrada",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return false;
                }

                if (!int.TryParse(idUsuarioLogin, out int usuarioLogin))
                {
                    MessageBox.Show(
                        "El usuario de sesión no es válido.",
                        "Registrar Entrada",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return false;
                }

                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Placa", placaNormalizada),
                    new KeyValuePair<string, object>("@IdTipoVehiculo", tipoVehiculo),
                    new KeyValuePair<string, object>("@IdCategoriaVehiculo", categoriaVehiculo),
                    new KeyValuePair<string, object>("@IdCelda", celda),
                    new KeyValuePair<string, object>("@IdUsuarioLogin", usuarioLogin),
                    new KeyValuePair<string, object>("@Detalle", $"Entrada de vehículo. Placa: '{placaNormalizada}'.")
                };

                if (await conexionBD.Connection())
                {
                    string strSQL = @"BEGIN TRY
                                    BEGIN TRANSACTION;

                                    /* =====================================================
                                       VARIABLES
                                       ===================================================== */
                                    DECLARE @IdVehiculo INT = NULL;
                                    DECLARE @IdCliente INT = NULL;
                                    DECLARE @IdTipoVehiculoActual INT = NULL;
                                    DECLARE @IdCategoriaVehiculoActual INT = NULL;
                                    DECLARE @EsVIP BIT = 0;
                                    DECLARE @ActivoVehiculo BIT = 1;
                                    DECLARE @VehiculoNuevo BIT = 0;
                                    DECLARE @IdVehiculoPlan INT = NULL;
                                    DECLARE @IdPlanTarifaEncontrado INT = NULL;
                                    DECLARE @TipoCobro VARCHAR(20) = 'TiempoDemanda';
                                    DECLARE @TipoPlan NVARCHAR(50);
                                    DECLARE @EstadoCelda VARCHAR(30);
                                    DECLARE @FechaActual DATE;

                                    SET @FechaActual = CAST(GETDATE() AS DATE);

                                    /* =====================================================
                                       1. NORMALIZAR PLACA
                                       ===================================================== */
                                    SET @Placa = UPPER(LTRIM(RTRIM(@Placa)));

                                    /* =====================================================
                                       2. BUSCAR VEHÍCULO
                                       ===================================================== */
                                    SELECT
                                        @IdVehiculo = V.Idvehiculo,
                                        @IdCliente = V.Idcliente,
                                        @IdTipoVehiculoActual = V.idtipovehiculo,
                                        @IdCategoriaVehiculoActual = V.IdCategoriaVehiculo,
                                        @EsVIP = V.EsVIP,
                                        @ActivoVehiculo = V.Activo
                                    FROM Vehiculo V WITH (UPDLOCK, HOLDLOCK)
                                    WHERE V.Placa = @Placa;

                                    /* =====================================================
                                       3. VEHÍCULO NUEVO
                                       ===================================================== */
                                    IF @IdVehiculo IS NULL
                                    BEGIN
                                        IF NOT EXISTS (SELECT 1 FROM TipoVehiculo WHERE IdTipoVehiculo = @IdTipoVehiculo)
                                        BEGIN
                                            THROW 56001, 'El tipo de vehículo seleccionado no existe.', 1;
                                        END;

                                        IF NOT EXISTS (SELECT 1 FROM CategoriaVehiculo WHERE IdCategoriaVehiculo = @IdCategoriaVehiculo)
                                        BEGIN
                                            THROW 56002, 'La categoría de vehículo seleccionada no existe.', 1;
                                        END;

                                        INSERT INTO Vehiculo
                                        (
                                            idtipovehiculo,
                                            IdCategoriaVehiculo,
                                            Idcliente,
                                            Placa,
                                            EsVIP,
                                            Activo,
                                            fecha_registro
                                        )
                                        VALUES
                                        (
                                            @IdTipoVehiculo,
                                            @IdCategoriaVehiculo,
                                            NULL,
                                            @Placa,
                                            0,
                                            1,
                                            GETDATE()
                                        );

                                        SET @IdVehiculo = CONVERT(INT, SCOPE_IDENTITY());
                                        SET @VehiculoNuevo = 1;
                                        SET @EsVIP = 0;
                                        SET @IdCliente = NULL;
                                        SET @TipoCobro = 'TiempoDemanda';
                                    END
                                    ELSE
                                    BEGIN
                                        /* =================================================
                                           4. VEHÍCULO EXISTENTE
                                           ================================================= */
                                        IF @ActivoVehiculo = 0
                                        BEGIN
                                            THROW 56003, 'El vehículo se encuentra inactivo y no puede ingresar al parqueadero.', 1;
                                        END;

                                        /* =================================================
                                           5. VALIDAR VIP
                                           ================================================= */
                                        IF @EsVIP = 1 AND @IdCliente IS NULL
                                        BEGIN
                                            THROW 56004, 'El vehículo está marcado como VIP pero no tiene un cliente asociado.', 1;
                                        END;
                                        /* =================================================
                                           ACTUALIZAR TIPO Y CATEGORIA DEL VEHÍCULO
                                           ================================================= */
                                        UPDATE Vehiculo
                                        SET idtipovehiculo = @idtipovehiculo, IdCategoriaVehiculo = @IdCategoriaVehiculo
                                        WHERE IdVehiculo = @IdVehiculo;

                                        /* =================================================
                                           6. ACTUALIZAR ESTADOS DE VEHICULOPLAN
                                           ================================================= */
                                        UPDATE VehiculoPlan
                                        SET
                                            EstadoContrato =
                                                CASE
                                                    WHEN FechaFin < @FechaActual THEN 'Vencida'
                                                    WHEN FechaInicio > @FechaActual THEN 'Programada'
                                                    WHEN @FechaActual BETWEEN FechaInicio AND FechaFin THEN 'Activa'
                                                    ELSE EstadoContrato
                                                END
                                        WHERE IdVehiculo = @IdVehiculo
                                          AND EstadoContrato <> 'Cancelada';

                                        /* =================================================
                                           7. DETERMINAR SI TIENE PLAN ACTIVO (MEMBRESÍA/MENSUALIDAD)
                                           ================================================= */
                                        IF @EsVIP = 1
                                        BEGIN
                                            SET @TipoCobro = 'VIP';
                                            SET @IdVehiculoPlan = NULL;
                                            SET @IdPlanTarifaEncontrado = NULL;
                                        END
                                        ELSE
                                        BEGIN
                                            SELECT TOP 1
                                                @IdVehiculoPlan = VP.IdVehiculoPlan,
                                                @TipoPlan = TP.Nombre,
                                                @IdPlanTarifaEncontrado = VP.IdPlanTarifa
                                            FROM VehiculoPlan VP
                                            INNER JOIN PlanTarifa PT ON PT.IdPlanTarifa = VP.IdPlanTarifa
                                            INNER JOIN [Plan] P ON P.IdPlan = PT.IdPlan
                                            INNER JOIN TipoPlan TP ON TP.IdTipoPlan = P.IdTipoPlan
                                            WHERE VP.IdVehiculo = @IdVehiculo
                                              AND VP.EstadoPago = 'Pagado'
                                              AND VP.EstadoContrato = 'Activa'
                                              AND TP.Nombre IN (N'Membresía', N'Mensualidad')
                                              AND @FechaActual BETWEEN VP.FechaInicio AND VP.FechaFin
                                            ORDER BY
                                                VP.FechaInicio DESC,
                                                VP.IdVehiculoPlan DESC;

                                            IF @IdVehiculoPlan IS NOT NULL
                                            BEGIN
                                                IF @TipoPlan = N'Membresía'
                                                    SET @TipoCobro = 'Membresia';
                                                ELSE IF @TipoPlan = N'Mensualidad'
                                                    SET @TipoCobro = 'Mensualidad';
                                            END;
                                        END;
                                    END;

                                    /* =====================================================
                                       8. ASIGNAR IDPLANTARIFA DESDE PlanTarifa SI ES TIEMPO POR DEMANDA
                                       ===================================================== */
                                    IF @IdPlanTarifaEncontrado IS NULL AND @EsVIP = 0
                                    BEGIN
                                        SET @TipoCobro = 'TiempoDemanda';

                                        DECLARE @BusquedaTipo INT = ISNULL(@IdTipoVehiculoActual, @IdTipoVehiculo);
                                        DECLARE @BusquedaCategoria INT = ISNULL(@IdCategoriaVehiculoActual, @IdCategoriaVehiculo);

                                        -- Cruzamos la tabla [Plan] con [PlanTarifa] para obtener el IdPlanTarifa correcto
                                        SELECT TOP 1 
                                            @IdPlanTarifaEncontrado = PT.IdPlanTarifa
                                        FROM PlanTarifa PT
                                        INNER JOIN [Plan] P ON P.IdPlan = PT.IdPlan
                                        WHERE P.IdTipoPlan = 3 -- 3 = Tiempo por demanda
                                          AND P.IdTipoVehiculo = @BusquedaTipo
                                          AND P.IdCategoriaVehiculo = @BusquedaCategoria
                                          AND P.Estado = 1
                                          AND PT.Estado = 1
                                        ORDER BY PT.IdPlanTarifa DESC;
                                    END;

                                    /* =====================================================
                                       9. VALIDAR QUE EL VEHÍCULO NO ESTÉ DENTRO
                                       ===================================================== */
                                    IF EXISTS
                                    (
                                        SELECT 1
                                        FROM MovimientoParqueadero MP WITH (UPDLOCK, HOLDLOCK)
                                        WHERE MP.IdVehiculo = @IdVehiculo
                                          AND MP.Estado = 'Dentro'
                                          AND MP.FechaHoraSalida IS NULL
                                    )
                                    BEGIN
                                        THROW 56005, 'El vehículo ya se encuentra dentro del parqueadero.', 1;
                                    END;

                                    /* =====================================================
                                       10. VALIDAR CELDA
                                       ===================================================== */
                                    SELECT
                                        @EstadoCelda = C.IdEstadoCelda
                                    FROM Celda C WITH (UPDLOCK, HOLDLOCK)
                                    WHERE C.IdCelda = @IdCelda;

                                    IF @EstadoCelda IS NULL
                                    BEGIN
                                        THROW 56006, 'La celda seleccionada no existe.', 1;
                                    END;

                                    IF @EstadoCelda <> '1'
                                    BEGIN
                                        THROW 56007, 'La celda seleccionada no está libre o disponible.', 1;
                                    END;

                                    /* =====================================================
                                       11. REGISTRAR MOVIMIENTO DE ENTRADA
                                       ===================================================== */
                                    INSERT INTO MovimientoParqueadero
                                    (
                                        IdVehiculo,
                                        IdCelda,
                                        FechaHoraEntrada,
                                        FechaHoraSalida,
                                        Estado,
                                        TipoCobro,
                                        IdVehiculoPlan,
                                        IdPlanTarifa,
                                        MinutosPermanencia,
                                        MinutosCobrados,
                                        ValorCalculado,
                                        ValorPagado,
                                        IdUsuarioEntrada,
                                        IdUsuarioSalida,
                                        FechaRegistro
                                    )
                                    VALUES
                                    (
                                        @IdVehiculo,
                                        @IdCelda,
                                        GETDATE(),
                                        NULL,
                                        'Dentro',
                                        @TipoCobro,
                                        @IdVehiculoPlan,
                                        @IdPlanTarifaEncontrado,
                                        NULL,
                                        NULL,
                                        NULL,
                                        NULL,
                                        @IdUsuarioLogin,
                                        NULL,
                                        GETDATE()
                                    );

                                    /* =====================================================
                                       12. OCUPAR CELDA
                                       ===================================================== */
                                    UPDATE Celda
                                    SET IdEstadoCelda = '2'
                                    WHERE IdCelda = @IdCelda
                                      AND IdEstadoCelda = '1';

                                    IF @@ROWCOUNT = 0
                                    BEGIN
                                        THROW 56008, 'La celda dejó de estar disponible durante la operación.', 1;
                                    END;

                                    /* =====================================================
                                       13. AUDITORÍA
                                       ===================================================== */
                                    INSERT INTO AuditoriaLog
                                    (
                                        UsuarioID,
                                        Accion,
                                        Fecha,
                                        Detalle
                                    )
                                    VALUES
                                    (
                                        @IdUsuarioLogin,
                                        N'Entrada de Vehículo',
                                        GETDATE(),
                                        LEFT(
                                            CONCAT(
                                                N'Placa: ', @Placa,
                                                N' | IdVehiculo: ', @IdVehiculo,
                                                N' | IdCliente: ', ISNULL(CONVERT(VARCHAR(20), @IdCliente), 'NULL'),
                                                N' | TipoCobro: ', @TipoCobro,
                                                N' | IdVehiculoPlan: ', ISNULL(CONVERT(VARCHAR(20), @IdVehiculoPlan), 'NULL'),
                                                N' | IdPlanTarifa: ', ISNULL(CONVERT(VARCHAR(20), @IdPlanTarifaEncontrado), 'NULL'),
                                                N' | IdCelda: ', @IdCelda,
                                                N' | VehiculoNuevo: ', CASE WHEN @VehiculoNuevo = 1 THEN 'Sí' ELSE 'No' END,
                                                N' | VIP: ', CASE WHEN @EsVIP = 1 THEN 'Sí' ELSE 'No' END
                                            ),
                                            400
                                        )
                                    );

                                    /* =====================================================
                                       14. CONFIRMAR TRANSACCIÓN
                                       ===================================================== */
                                    COMMIT TRANSACTION;

                                    /* =====================================================
                                       15. RESULTADO
                                       ===================================================== */
                                    SELECT
                                        @IdVehiculo AS IdVehiculo,
                                        @Placa AS Placa,
                                        @IdCliente AS IdCliente,
                                        @IdCelda AS IdCelda,
                                        @TipoCobro AS TipoCobro,
                                        @IdVehiculoPlan AS IdVehiculoPlan,
                                        @IdPlanTarifaEncontrado AS IdPlanTarifa,
                                        @VehiculoNuevo AS VehiculoNuevo,
                                        @EsVIP AS EsVIP;

                                END TRY
                                BEGIN CATCH
                                    IF @@TRANCOUNT > 0
                                        ROLLBACK TRANSACTION;

                                    THROW;
                                END CATCH;";

                    if (await conexionBD.InsertAsync(
                        strSQL,
                        CommandType.Text,
                        parametros))
                    {
                        b = true;
                    }
                    else
                    {
                        throw new Exception(
                            "No fue posible registrar la entrada del vehículo.");
                    }
                }
            }
            catch (Exception error)
            {
                string codigoError = string.Empty;
                string mensajeSql = string.Empty;

                if (!string.IsNullOrWhiteSpace(
                    conexionBD.StrError))
                {
                    string[] partes =
                        conexionBD.StrError.Split('-');

                    codigoError =
                        partes.Length > 0
                            ? partes[0].Trim()
                            : string.Empty;

                    mensajeSql =
                        partes.Length > 1
                            ? string.Join(
                                "-",
                                partes.Skip(1)).Trim()
                            : conexionBD.StrError;
                }

                switch (codigoError)
                {
                    case "56001":

                        MessageBox.Show(
                            "El tipo de vehículo seleccionado no existe.",
                            "Registrar Entrada",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);

                        break;


                    case "56002":

                        MessageBox.Show(
                            "La categoría de vehículo seleccionada no existe.",
                            "Registrar Entrada",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);

                        break;


                    case "56003":

                        MessageBox.Show(
                            "El vehículo se encuentra inactivo y no puede ingresar al parqueadero.",
                            "Registrar Entrada",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);

                        break;


                    case "56004":

                        MessageBox.Show(
                            "El vehículo está marcado como VIP pero no tiene un cliente asociado.\n\n" +
                            "Debe corregir primero la información del vehículo.",
                            "Registrar Entrada",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);

                        break;


                    case "56005":

                        MessageBox.Show(
                            "El vehículo ya se encuentra dentro del parqueadero.",
                            "Registrar Entrada",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);

                        break;


                    case "56006":

                        MessageBox.Show(
                            "La celda seleccionada no existe.",
                            "Registrar Entrada",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);

                        break;


                    case "56007":

                        MessageBox.Show(
                            "La celda seleccionada no está libre.",
                            "Registrar Entrada",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);

                        break;


                    case "56008":

                        MessageBox.Show(
                            "La celda dejó de estar disponible durante la operación.\n\n" +
                            "Actualice las celdas e intente nuevamente.",
                            "Registrar Entrada",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);

                        break;


                    case "2627":
                    case "2601":

                        if (mensajeSql.Contains(
                            "UQ_Vehiculo_Placa"))
                        {
                            MessageBox.Show(
                                $"La placa '{placaNormalizada}' ya se encuentra registrada.",
                                "Placa Duplicada",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
                        }
                        else
                        {
                            MessageBox.Show(
                                "Ya existe un registro con los mismos datos.",
                                "Registro Duplicado",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
                        }

                        break;


                    default:

                        string detalleError =
                            !string.IsNullOrWhiteSpace(
                                mensajeSql)
                                ? mensajeSql
                                : error.Message;

                        MessageBox.Show(
                            "Error al registrar la entrada del vehículo.\n\n" +
                            detalleError,
                            "Error del Sistema",
                            MessageBoxButton.OK,
                            MessageBoxImage.Error);

                        break;
                }

                b = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return b;
        }
        #endregion

        #region registrar salida vehiculo
        public async Task<bool> RegistrarSalidaVehiculoAsync(
                                string placa,
                                string idTipoVehiculo,
                                string idCategoriaVehiculo,
                                string idMovimiento,
                                string idMetodoPago,
                                string idUsuarioSalida)
        {
            bool resultado = false;

            try
            {
                if (!int.TryParse(idMovimiento, out int movimiento) || movimiento <= 0)
                {
                    MessageBox.Show("El movimiento seleccionado no es válido.", "Registrar Salida", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                if (!int.TryParse(idUsuarioSalida, out int usuarioSalida) || usuarioSalida <= 0)
                {
                    MessageBox.Show("El usuario de sesión no es válido.", "Registrar Salida", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                int metodoSeleccionado = 0;
                if (!string.IsNullOrWhiteSpace(idMetodoPago) &&
                    (!int.TryParse(idMetodoPago, out metodoSeleccionado) || metodoSeleccionado <= 0))
                {
                    MessageBox.Show("El método de pago seleccionado no es válido.", "Registrar Salida", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                var parametros = new List<KeyValuePair<string, object>>
        {
            new KeyValuePair<string, object>("@Placa", placa),
            new KeyValuePair<string, object>("@IdMovimiento", movimiento),
            new KeyValuePair<string, object>("@IdMetodoPago", metodoSeleccionado),
            new KeyValuePair<string, object>("@IdUsuarioSalida", usuarioSalida)
        };

                if (await conexionBD.Connection())
                {
                    string strSQL = @"
                            SET NOCOUNT OFF;
                            SET XACT_ABORT ON;

                            BEGIN TRY
                                BEGIN TRANSACTION;

                                DECLARE @FechaHoraSalida DATETIME2(0) = CONVERT(DATETIME2(0), SYSDATETIME());
                                DECLARE @IdVehiculo INT;
                                DECLARE @IdTipoVehiculoBD INT;
                                DECLARE @IdCategoriaVehiculoBD INT;
                                DECLARE @IdCelda INT;
                                DECLARE @IdVehiculoPlan INT;
                                DECLARE @TipoCobro VARCHAR(20);
                                DECLARE @FechaHoraEntrada DATETIME2(0);
                                DECLARE @FechaFinPlan DATE;
                                DECLARE @EstadoPagoPlan VARCHAR(20);

                                DECLARE @MinutosPermanencia INT;
                                DECLARE @MinutosCobradosTotal INT = 0;
                                DECLARE @ValorTotal DECIMAL(18,2) = 0;
                                DECLARE @IdPlanTarifaFinal INT = NULL;
                                DECLARE @FechaInicioCalculo DATETIME2(0);

                                /* 1. OBTENER EL MOVIMIENTO Y DATOS DEL VEHÍCULO */
                                SELECT TOP (1)
                                    @IdMovimiento = MP.IdMovimiento,
                                    @IdVehiculo = MP.IdVehiculo,
                                    @IdTipoVehiculoBD = V.idtipovehiculo,
                                    @IdCategoriaVehiculoBD = V.IdCategoriaVehiculo,
                                    @IdCelda = MP.IdCelda,
                                    @FechaHoraEntrada = MP.FechaHoraEntrada,
                                    @TipoCobro = MP.TipoCobro,
                                    @IdVehiculoPlan = MP.IdVehiculoPlan,
                                    @FechaFinPlan = VP.FechaFin,
                                    @EstadoPagoPlan = VP.EstadoPago,
                                    @IdPlanTarifaFinal = MP.IdPlanTarifa
                                FROM dbo.MovimientoParqueadero MP WITH (UPDLOCK, HOLDLOCK)
                                INNER JOIN dbo.Vehiculo V ON V.Idvehiculo = MP.IdVehiculo
                                LEFT JOIN dbo.VehiculoPlan VP ON VP.IdVehiculoPlan = MP.IdVehiculoPlan
                                WHERE V.Placa = UPPER(LTRIM(RTRIM(@Placa)))
                                  AND MP.IdMovimiento = @IdMovimiento
                                  AND MP.Estado = 'Dentro'
                                  AND MP.FechaHoraSalida IS NULL;

                                IF @IdMovimiento IS NULL THROW 56201, 'No existe un movimiento abierto para esta placa.', 1;
                                IF @FechaHoraSalida < @FechaHoraEntrada THROW 56204, 'La salida no puede ser anterior a la entrada.', 1;

                                /* 2. PERMANENCIA TOTAL */
                                SET @MinutosPermanencia = CONVERT(INT, CEILING(DATEDIFF_BIG(SECOND, @FechaHoraEntrada, @FechaHoraSalida) / 60.0));
                                SET @FechaInicioCalculo = @FechaHoraEntrada;

                                /* 3. EVALUACIÓN Y CAMBIO DE ESTADO SI EXPIRÓ EL PLAN */
                                IF @TipoCobro = 'VIP'
                                BEGIN
                                    SET @ValorTotal = 0;
                                    SET @MinutosCobradosTotal = 0;
                                END
                                ELSE IF @TipoCobro IN ('Membresia', 'Mensualidad')
                                BEGIN
                                    -- Si la salida fue dentro de la vigencia del plan (hasta las 23:59:59 del día de la fecha de fin)
                                    IF @IdVehiculoPlan IS NOT NULL AND @FechaFinPlan IS NOT NULL AND LOWER(@EstadoPagoPlan) = 'pagado' 
                                       AND @FechaHoraSalida < DATEADD(DAY, 1, CONVERT(DATETIME2(0), @FechaFinPlan))
                                    BEGIN
                                        SET @ValorTotal = 0;
                                        SET @MinutosCobradosTotal = 0;
                                    END
                                    ELSE
                                    BEGIN
                                        -- El plan venció: Se reasigna a TiempoDemanda
                                        SET @TipoCobro = 'TiempoDemanda';

                                        -- Actualizar contrato a 'Vencida' en VehiculoPlan
                                        IF @IdVehiculoPlan IS NOT NULL
                                        BEGIN
                                            UPDATE dbo.VehiculoPlan
                                            SET EstadoContrato = 'Vencida'
                                            WHERE IdVehiculoPlan = @IdVehiculoPlan;
                                        END;

                                        SET @IdVehiculoPlan = NULL; -- Desvincular contrato vencido del movimiento

                                        -- El cobro excedente inicia a partir de las 00:00 del día posterior a la fecha fin de la membresía
                                        IF @FechaFinPlan IS NOT NULL
                                        BEGIN
                                            DECLARE @InicioVencimiento DATETIME2(0) = DATEADD(DAY, 1, CONVERT(DATETIME2(0), @FechaFinPlan));
                                            IF @InicioVencimiento > @FechaHoraEntrada
                                            BEGIN
                                                SET @FechaInicioCalculo = @InicioVencimiento;
                                            END;
                                        END;
                                    END;
                                END;

                                /* 4. CALCULAR TARIFA POR DEMANDA SI CORRESPONDE */
                                IF @TipoCobro = 'TiempoDemanda'
                                BEGIN
                                    DECLARE @ValorMinuto DECIMAL(18,2) = 0;
                                    DECLARE @ValorHora DECIMAL(18,2) = 0;
                                    DECLARE @Valor12Horas DECIMAL(18,2) = 0;
                                    DECLARE @Valor24Horas DECIMAL(18,2) = 0;
                                    DECLARE @UnidadCobro VARCHAR(20) = 'HORA';
                                    DECLARE @MinutosFraccion INT = 0;

                                    -- BUSCAR TARIFA EXCLUSIVAMENTE EN PLANES DE TIEMPO POR DEMANDA
                                    SELECT TOP 1
                                        @IdPlanTarifaFinal = PT.IdPlanTarifa,
                                        @ValorMinuto = ISNULL(PT.ValorMinuto, 0),
                                        @ValorHora = ISNULL(PT.ValorHora, 0),
                                        @Valor12Horas = ISNULL(PT.Valor12Horas, 0),
                                        @Valor24Horas = ISNULL(PT.Valor24Horas, 0),
                                        @UnidadCobro = ISNULL(RC.UnidadCobro, 'HORA'),
                                        @MinutosFraccion = ISNULL(RC.MinutosFraccion, 0)
                                    FROM dbo.[Plan] P
                                    INNER JOIN dbo.PlanTarifa PT ON PT.IdPlan = P.IdPlan
                                    INNER JOIN dbo.TipoPlan TP ON TP.IdTipoPlan = P.IdTipoPlan
                                    LEFT JOIN dbo.PlanReglaCobro RC ON RC.IdPlan = P.IdPlan
                                    WHERE P.Estado = 1 AND PT.Estado = 1
                                      AND (TP.IdTipoPlan = 3 OR TP.Nombre LIKE N'%demanda%')
                                      AND (P.IdTipoVehiculo = @IdTipoVehiculoBD OR P.IdTipoVehiculo IS NULL)
                                      AND (PT.ValorHora > 0 OR PT.ValorMinuto > 0 OR PT.Valor24Horas > 0 OR PT.Valor12Horas > 0)
                                    ORDER BY 
                                        CASE WHEN P.IdCategoriaVehiculo = @IdCategoriaVehiculoBD THEN 0 ELSE 1 END,
                                        PT.IdPlanTarifa DESC;

                                    -- Fallback si no encuentra precio en el filtro por categoría/tipo
                                    IF @ValorHora = 0 AND @ValorMinuto = 0 AND @Valor24Horas = 0 AND @Valor12Horas = 0
                                    BEGIN
                                        SELECT TOP 1
                                            @IdPlanTarifaFinal = PT.IdPlanTarifa,
                                            @ValorMinuto = ISNULL(PT.ValorMinuto, 0),
                                            @ValorHora = ISNULL(PT.ValorHora, 0),
                                            @Valor12Horas = ISNULL(PT.Valor12Horas, 0),
                                            @Valor24Horas = ISNULL(PT.Valor24Horas, 0),
                                            @UnidadCobro = ISNULL(RC.UnidadCobro, 'HORA'),
                                            @MinutosFraccion = ISNULL(RC.MinutosFraccion, 0)
                                        FROM dbo.[Plan] P
                                        INNER JOIN dbo.PlanTarifa PT ON PT.IdPlan = P.IdPlan
                                        LEFT JOIN dbo.PlanReglaCobro RC ON RC.IdPlan = P.IdPlan
                                        WHERE P.Estado = 1 AND PT.Estado = 1
                                          AND (PT.ValorHora > 0 OR PT.ValorMinuto > 0 OR PT.Valor24Horas > 0 OR PT.Valor12Horas > 0)
                                        ORDER BY PT.IdPlanTarifa DESC;
                                    END;

                                    -- Minutos reales a cobrar (desde que venció hasta la salida)
                                    SET @MinutosCobradosTotal = CONVERT(INT, CEILING(DATEDIFF_BIG(SECOND, @FechaInicioCalculo, @FechaHoraSalida) / 60.0));

                                    IF @MinutosCobradosTotal > 0
                                    BEGIN
                                        DECLARE @MinutosRestantes INT = @MinutosCobradosTotal;

                                        -- 1. Evaluar Paquetes de 24 Horas
                                        IF @Valor24Horas > 0 AND @MinutosRestantes >= 1440
                                        BEGIN
                                            DECLARE @Cant24 INT = @MinutosRestantes / 1440;
                                            SET @ValorTotal = @ValorTotal + (@Cant24 * @Valor24Horas);
                                            SET @MinutosRestantes = @MinutosRestantes % 1440;
                                        END;

                                        -- 2. Evaluar Paquetes de 12 Horas
                                        IF @Valor12Horas > 0 AND @MinutosRestantes >= 720
                                        BEGIN
                                            DECLARE @Cant12 INT = @MinutosRestantes / 720;
                                            SET @ValorTotal = @ValorTotal + (@Cant12 * @Valor12Horas);
                                            SET @MinutosRestantes = @MinutosRestantes % 720;
                                        END;

                                        -- 3. Evaluar Tiempos/Horas Restantes
                                        IF @MinutosRestantes > 0
                                        BEGIN
                                            IF UPPER(@UnidadCobro) = 'MINUTO' AND @ValorMinuto > 0
                                            BEGIN
                                                SET @ValorTotal = @ValorTotal + (@MinutosRestantes * @ValorMinuto);
                                            END
                                            ELSE -- Cobro por Horas o Fracción
                                            BEGIN
                                                DECLARE @HorasCompletas INT = @MinutosRestantes / 60;
                                                DECLARE @MinutosFrac INT = @MinutosRestantes % 60;

                                                SET @ValorTotal = @ValorTotal + (@HorasCompletas * @ValorHora);

                                                IF @MinutosFrac > 0
                                                BEGIN
                                                    IF @MinutosFraccion > 0 AND @MinutosFrac >= @MinutosFraccion
                                                    BEGIN
                                                        SET @ValorTotal = @ValorTotal + @ValorHora;
                                                    END
                                                    ELSE IF @ValorMinuto > 0
                                                    BEGIN
                                                        SET @ValorTotal = @ValorTotal + (@MinutosFrac * @ValorMinuto);
                                                    END
                                                    ELSE
                                                    BEGIN
                                                        SET @ValorTotal = @ValorTotal + @ValorHora;
                                                    END;
                                                END;
                                            END;
                                        END;
                                    END;
                                END;

                                /* 5. FINALIZAR MOVIMIENTO Y LIBERAR ESPACIO */
                                UPDATE dbo.MovimientoParqueadero
                                SET FechaHoraSalida = @FechaHoraSalida,
                                    Estado = 'Finalizado',
                                    TipoCobro = @TipoCobro,
                                    IdVehiculoPlan = @IdVehiculoPlan,
                                    IdPlanTarifa = COALESCE(@IdPlanTarifaFinal, IdPlanTarifa),
                                    MinutosPermanencia = @MinutosPermanencia,
                                    MinutosCobrados = @MinutosCobradosTotal,
                                    ValorCalculado = ROUND(@ValorTotal, 2),
                                    ValorPagado = ROUND(@ValorTotal, 2),
                                    IdUsuarioSalida = @IdUsuarioSalida
                                WHERE IdMovimiento = @IdMovimiento AND Estado = 'Dentro' AND FechaHoraSalida IS NULL;

                                IF @@ROWCOUNT <> 1 THROW 56515, 'El movimiento ya fue finalizado o no pudo actualizarse.', 1;

                                UPDATE dbo.Celda SET IdEstadoCelda = 1 WHERE IdCelda = @IdCelda AND IdEstadoCelda = 2;
                                IF @@ROWCOUNT <> 1 THROW 56516, 'No fue posible liberar la celda.', 1;

                                UPDATE dbo.OcupacionCelda SET FechaSalida = @FechaHoraSalida, Estado = 0
                                WHERE IdVehiculo = @IdVehiculo AND IdCelda = @IdCelda AND Estado = 1 AND FechaSalida IS NULL;

                                INSERT INTO dbo.AuditoriaLog (UsuarioID, Accion, Fecha, Detalle)
                                VALUES (@IdUsuarioSalida, N'Salida de Vehículo', GETDATE(), LEFT(CONCAT(N'Movimiento: ', @IdMovimiento, N' | Total: ', @ValorTotal), 4000));

                                COMMIT TRANSACTION;
                            END TRY
                            BEGIN CATCH
                                IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
                                THROW;
                            END CATCH;";

                    if (await conexionBD.InsertAsync(strSQL, CommandType.Text, parametros))
                    {
                        resultado = true;
                        MessageBox.Show("La salida del vehículo se registró correctamente.", "Registrar Salida", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        throw new Exception("No fue posible registrar la salida del vehículo.");
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show("Error: " + error.Message, "Error del Sistema", MessageBoxButton.OK, MessageBoxImage.Error);
                resultado = false;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }

            return resultado;
        }
        #endregion

        #region VIP_info
        public async Task<DataSet> VIPInfoAsync(string Placa)
        {
            try
            {
                var parametros = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("@Placa", Placa),
                };
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT TOP 1 
                                        dbo.Cliente.Nombre, 
                                        dbo.Vehiculo.Placa, 
                                        dbo.Vehiculo.EsVIP, 
                                        dbo.TipoVehiculo.Nombre AS TipoVehiculo, 
                                        dbo.CategoriaVehiculo.Nombre AS CategoriaVehiculo
                                    FROM dbo.Cliente
                                    INNER JOIN dbo.Vehiculo ON dbo.Cliente.Idcliente = dbo.Vehiculo.Idcliente
                                    INNER JOIN dbo.TipoVehiculo ON dbo.Vehiculo.idtipovehiculo = dbo.TipoVehiculo.IdTipoVehiculo
                                    INNER JOIN dbo.CategoriaVehiculo ON dbo.Vehiculo.IdCategoriaVehiculo = dbo.CategoriaVehiculo.IdCategoriaVehiculo
                                    WHERE dbo.Vehiculo.Placa = @Placa";

                    if (await conexionBD.DataSetAsync(sql, CommandType.Text, parametros))
                    {
                        return conexionBD.DataSet;
                    }
                }
            }
            catch
            {
                MessageBox.Show($"Error al obtener movimientos de vehículos.\n{conexionBD.StrError}", "Movimiento Vehículo", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion
    }
}