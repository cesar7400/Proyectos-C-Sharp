﻿using Parking.Models;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows;

namespace Parking.Controller
{
    public class TipoDocumento
    {
        private readonly ConexionBD conexionBD = new ConexionBD();

        #region seleccionarTipoDocumeto
        public async Task<DataTable> SelectTipoDocumentoAsync()
        {
            try
            {
                if (await conexionBD.Connection())
                {
                    string sql = $@"SELECT Documentoid, Tipo FROM Tipo_Documento";
                    if (await conexionBD.DataSetAsync(sql, CommandType.Text))
                    {
                        return conexionBD.DataSet.Tables[0];
                    }
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show($"Error al obtener tipo documento.\n{conexionBD.StrError}\n{error.Message}", "Tipo Documento", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }
            finally
            {
                await conexionBD.CloseConnection();
            }
            return null;
        }
        #endregion
    }
}   