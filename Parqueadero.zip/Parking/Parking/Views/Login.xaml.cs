﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using static Parking.Models.UsuariosModel;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        private string _IdUsuario = "";

        public string IdUsuario
        {
            get { return _IdUsuario; }
            set { _IdUsuario = value; }
        }
        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            lblDiaPermitido.Text = "";
            TxtUsuario.Focus();
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void PreviewTextInputTextLetters(object sender, TextCompositionEventArgs e)
        {
            // Crea una instancia de la biblioteca de utilidades
            Library library = new Library();
            // Llama al método que permite solo letras
            library.Letters(sender, e);
        }
        private void TxtEspacio_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Si la tecla presionada es el espacio, cancelamos el evento
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }
        private void ValidarComillas(object sender, TextCompositionEventArgs e)
        {
            // Si el texto que intenta ingresar es una comilla simple o doble
            if (e.Text == "'" || e.Text == "\"")
            {
                e.Handled = true; // Aquí le decimos a WPF: "No proceses esta tecla"
            }
        }
        private void TxtPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            PasswordBox pb = (PasswordBox)sender;
            // Buscamos el TextBlock del placeholder dentro del Template
            var template = pb.Template;
            var placeholder = (TextBlock)template.FindName("placeHolderTextBlock", pb);

            if (placeholder != null)
            {
                // Si hay texto, ocultamos el Tag. Si está vacío, lo mostramos.
                placeholder.Visibility = string.IsNullOrEmpty(pb.Password)
                                         ? Visibility.Visible
                                         : Visibility.Collapsed;
            }
        }
        public interface IFormLogin
        {
            void SetData(List<KeyValuePair<string, string>> dataUsuario);
        }
        private async void BtnIngresar_Click(object sender, RoutedEventArgs e)
        {
            // Cambiar cursor a espera
            Mouse.OverrideCursor = Cursors.Wait;

            UsuariosController usuariosController = new UsuariosController();

            TxtUsuario.Text = "administrador";
            TxtPassword.Password = "11223344";

            string usuario = TxtUsuario.Text.Trim().ToLower().Replace("'", "").Replace("\"", "");
            string password = TxtPassword.Password.Trim().ToLower();

            //await usuariosController.NuevoUsuario("administrador", "Administrador del sistema", "12345678", 127, "1", "1");

            // Validar usuario
            if (string.IsNullOrWhiteSpace(usuario))
            {
                // Cambiar cursor a estado normal
                Mouse.OverrideCursor = null;
                MessageBox.Show("Ingrese usuario.", "Inicio de Sesión", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtUsuario.Focus();
                return;
            }

            // Validar contraseña
            if (string.IsNullOrWhiteSpace(password))
            {
                // Cambiar cursor a estado normal
                Mouse.OverrideCursor = null;
                MessageBox.Show("Ingrese contraseña.", "Inicio de Sesión", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPassword.Focus();
                return;
            }
            // Llamamos al controlador (controller)
            LoginUsuarios u = await usuariosController.IniciarSesion(usuario);

            if (u.LoginUsuario == "0")
            {
                // Cambiar cursor a estado normal
                Mouse.OverrideCursor = null;
                MessageBox.Show(u.Mensaje, "Inicio de Sesión", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtUsuario.Focus();
                return;
            }

            // Validar contraseña
            if (!PasswordHasher.VerifyPassword(password, u.PasswordHash, u.PasswordSalt))
            {
                // Cambiar cursor a estado normal
                Mouse.OverrideCursor = null;
                MessageBox.Show("Contraseña no válida.", "Inicio de Sesión", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPassword.Focus();
                return;
            }
            else
            {
                //Si es verdadero se procede al cambio de contraseña
                if (u.CambioPassword)
                {
                    // Construye una lista de KeyValuePair con los datos del usuario para pasar a la ventana
                    var listUsuario = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("@IdUsuario", u.IdUsuario.ToString()),
                        new KeyValuePair<string, string>("@Usuario", u.UsuarioLogin.ToString()),
                        new KeyValuePair<string, string>("@NombreCompleto", u.NombreCompleto.ToString())
                    };
                    // Cambiar cursor a estado normal
                    Mouse.OverrideCursor = null;
                    CambiarContrasenia cambiarContrasenia = new CambiarContrasenia(this);
                    // Si la ventana implementa la interfaz IFormUsuario, le asigna los datos
                    if (cambiarContrasenia is IFormLogin formdata)
                    {
                        formdata.SetData(listUsuario);
                    }
                    cambiarContrasenia.ShowDialog();
                }
                else
                {
                    IdUsuario = u.IdUsuario.ToString();
                    MainWindow MainWindow = new MainWindow(this)
                    {
                        Width = 800,
                        Height = 600
                    };
                    MainWindow.Permisos = u.Permisos;
                    MainWindow.Show();
                    // Cambiar cursor a estado normal
                    Mouse.OverrideCursor = null;
                    this.Close();
                }
            }
        }
        private void LnkInfoPassword_Click(object sender, RoutedEventArgs e)
        {
            // Mensaje que indica cómo recuperar o restablecer la contraseña
            MessageBox.Show("Si olvido su contraseña, puede acceder con el usuario \"administrador\" y la contraseña. Alternativamente, solicite a algún administrador que le ayude a restablecer su contraseña.", "Inicio sesión", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}