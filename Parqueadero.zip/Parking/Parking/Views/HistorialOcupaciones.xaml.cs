﻿using Parking.Controller;
using System;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para HistorialOcupaciones.xaml
    /// </summary>
    public partial class HistorialOcupaciones : Window
    {
        public HistorialOcupaciones()
        {
            InitializeComponent();
        }

        // Propiedades para manejar la paginación y búsqueda de usuarios
        public int currentPage = 1;    // Página actual (inicia en 1)
        public int pageSize = 30;      // Cantidad de registros por página
        public int totalRecords = 0;   // Total de usuarios que coinciden con la búsqueda
        public int totalPages = 0;     // Total de páginas calculadas
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            HistorialOcupacionCeldas(currentPage, pageSize);
        }

        private async void HistorialOcupacionCeldas(int pageNumber, int pageSize)
        {
            try
            {
                Celda celda = new Celda();
                var dt = await celda.HistorialOcupacionesCeldas(pageNumber, pageSize);

                if (dt != null) // Si hay resultados
                {
                    int maxRowsToShow = 30; // Número máximo de filas a mostrar en pantalla

                    // Obtiene el total de registros de la tabla
                    totalRecords = dt.Tables[0].Rows.Count;

                    // Verifica si la tabla 0 (registros) tiene filas
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        // Obtiene el total de registros de la segunda tabla (índice 1)
                        totalRecords = int.Parse(dt.Tables[1].Rows[0][0].ToString());
                        // Toma hasta maxRowsToShow filas para mostrar (evita cargar más de 30 aunque pageSize sea mayor)
                        var rowsToShow = dt.Tables[0]
                                           .AsEnumerable()
                                           .Take(maxRowsToShow)
                                           .CopyToDataTable();

                        // Asigna la fuente de datos del DataGrid a la vista por defecto del DataTable
                        DgHistorialOcupaciones.ItemsSource = rowsToShow.DefaultView;
                        // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                        DgHistorialOcupaciones.CanUserSortColumns = false;

                        // Habilita o deshabilita los botones de navegación según la página actual
                        BtnAnterior.IsEnabled = currentPage > 1;
                        TxtAnterior.Visibility = (currentPage > 1) ? Visibility.Visible : Visibility.Collapsed;
                        BtnSiguiente.IsEnabled = (currentPage * pageSize) < totalRecords;
                        TxtSiguiente.Visibility = (currentPage * pageSize) < totalRecords ? Visibility.Visible : Visibility.Collapsed;

                        // Muestra u oculta los íconos de flecha según correspondan
                        ImgAnterior.Visibility = (currentPage > 1 ? Visibility.Visible : Visibility.Hidden);
                        ImgSiguiente.Visibility = ((currentPage * pageSize) < totalRecords ? Visibility.Visible : Visibility.Hidden);
                    }
                    else
                    {
                        dt.Clear();
                        DgHistorialOcupaciones.ItemsSource = dt.Tables[0].DefaultView;
                        TxtPagina.Text = "Página 0 de 0";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar auditoría: " + ex.Message);
            }
        }
        private void BtnAnterior_Click(object sender, RoutedEventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--; // Disminuye el número de página
                HistorialOcupacionCeldas(currentPage, pageSize);
                TxtPagina.Text = "Página " + currentPage + " de " + totalPages;
            }
        }

        private void BtnSiguiente_Click(object sender, RoutedEventArgs e)
        {
            if ((currentPage * pageSize) < totalRecords)
            {
                currentPage++; // Aumenta el número de página
                HistorialOcupacionCeldas(currentPage, pageSize);
                TxtPagina.Text = "Página " + currentPage + " de " + totalPages;
            }
        }
    }
}