﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Controls;


namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para Usuarios.xaml
    /// </summary>
    public partial class Usuarios : Page
    {
        public Usuarios()
        {
            InitializeComponent();
        }
        // Propiedades para manejar la paginación y búsqueda de usuarios
        public int currentPage = 1;    // Página actual (inicia en 1)
        public int pageSize = 30;      // Cantidad de registros por página
        public int totalRecords = 0;   // Total de usuarios que coinciden con la búsqueda
        public int totalPages = 0;     // Total de páginas calculadas
        public string strBusquedad = "";// Texto de búsqueda actual
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            CargarUsuarios("", currentPage, pageSize);
            Permisos permisos =  new Permisos();
            // Consultar si el módulo "Usuarios" tiene permitido "Agregar Usuario"
            bool puedeCrear = permisos.TienePermiso("Usuarios", "Agregar Usuario");
            BtnAddUsuario.Visibility = puedeCrear == true ? Visibility.Visible : Visibility.Collapsed;
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Obtiene la ventana que contiene esta página
            var window = Window.GetWindow(this);
            if (window is MainWindow mainWindow)
            {
                // Limpia el contenido del contenedor principal (fContainer)
                mainWindow.ContenedorPrincipal.Content = null;
            }
        }

        private void BtnAddUsuario_Click(object sender, RoutedEventArgs e)
        {
            AgregarUsuario agregarUsuario = new AgregarUsuario(this);
            agregarUsuario.ShowDialog();
        }

        public async void CargarUsuarios(string strUsuario, int pageNumber, int pageSize)
        {
            UsuariosController usuariosController = new UsuariosController();
            try
            {
                var dt = await usuariosController.ObtenerUsuariosAsync(strUsuario, pageNumber, pageSize);

                Permisos permisos = new Permisos();
                // Consultar permisos
                bool puedeEditar = permisos.TienePermiso("Usuarios", "Editar Usuario");
                bool puedeEliminar = permisos.TienePermiso("Usuarios", "Eliminar Usuario");

                // Si TODOS los permisos están en false, ocultamos toda la columna Acciones
                if (!puedeEditar && !puedeEliminar)
                {
                    ColAcciones.Visibility = Visibility.Collapsed;
                }
                else
                {
                    ColAcciones.Visibility = Visibility.Visible;
                }

                if (dt != null) // Si hay resultados
                {
                    // Crear columna si no existe
                    if (!dt.Tables[0].Columns.Contains("DiasTexto"))
                    {
                        dt.Tables[0].Columns.Add("DiasTexto", typeof(string));
                    }
                    // Llenar datos
                    foreach (DataRow row in dt.Tables[0].Rows)
                    {
                        if (row["DiasPermitidos"] != DBNull.Value)
                        {
                            row["DiasTexto"] = usuariosController.ConvertirDias(Convert.ToByte(row["DiasPermitidos"]));
                        }
                    }
                    int maxRowsToShow = 30; // Número máximo de filas a mostrar en pantalla

                    // Verifica si la tabla 0 (registros) tiene filas
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        // Obtiene el total de registros de la segunda tabla (índice 1)
                        totalRecords = int.Parse(dt.Tables[1].Rows[0][0].ToString());
                        //muestra cantidad de registros encontrados
                        TxtRegistro.Text = totalRecords + (totalRecords == 1 ? " Registro" : " Registros");

                        // Calcula el total de páginas
                        totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                        TxtCantidadRegistros.Text = "Cantidad total de registro(s): " + (dt.Tables[2].Rows[0][0].ToString());
                        // Toma hasta maxRowsToShow filas para mostrar (evita cargar más de 30 aunque pageSize sea mayor)
                        var rowsToShow = dt.Tables[0]
                                           .AsEnumerable()
                                           .Take(maxRowsToShow)
                                           .CopyToDataTable();

                        // Asigna la fuente de datos del DataGrid a la vista por defecto del DataTable
                        DgUsuarios.ItemsSource = rowsToShow.DefaultView;
                        // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                        DgUsuarios.CanUserSortColumns = false;

                        // Habilita o deshabilita los botones de navegación según la página actual
                        BtnAnterior.IsEnabled = currentPage > 1;
                        TxtAnterior.Visibility = (currentPage > 1) ? Visibility.Visible : Visibility.Collapsed;
                        BtnSiguiente.IsEnabled = (currentPage * pageSize) < totalRecords;
                        TxtSiguiente.Visibility = (currentPage * pageSize) < totalRecords ? Visibility.Visible : Visibility.Collapsed;
                        // Actualiza el texto que muestra "Página X de Y"
                        TxtPagina.Text = "Página " + currentPage + " de " + totalPages;

                        // Muestra u oculta los íconos de flecha según correspondan
                        ImgAnterior.Visibility = (currentPage > 1 ? Visibility.Visible : Visibility.Hidden);
                        ImgSiguiente.Visibility = ((currentPage * pageSize) < totalRecords ? Visibility.Visible : Visibility.Hidden);
                    }
                    else
                    {
                        // Si no hay filas, resetea totales y muestra mensaje de página vacía
                        totalRecords = 0;
                        TxtRegistro.Text = totalRecords.ToString() + " Registros";
                        dt.Clear();
                        DgUsuarios.ItemsSource = dt.Tables[0].DefaultView;
                        TxtPagina.Text = "Página 0 de 0";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async void TxtBuscarUsuario_TextChanged(object sender, TextChangedEventArgs e)
        {
            currentPage = 1;
            if (TxtBuscarUsuario.Text.Trim() != string.Empty)
            {
                // Si hay texto, filtra por ese texto y actualiza strBusquedad
                CargarUsuarios(TxtBuscarUsuario.Text.Trim().Replace("'", "").Replace("\"", ""), 1, pageSize);
            }
            else
            {
                // Si el cuadro de búsqueda está vacío, restaura sin filtro
                CargarUsuarios("", 1, pageSize);
            }
        }
        private void BtnAnterior_Click(object sender, RoutedEventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--; // Disminuye el número de página
                CargarUsuarios(TxtBuscarUsuario.Text.Trim().Replace("'", "").Replace("\"", ""), currentPage, pageSize);
                TxtPagina.Text = "Página " + currentPage + " de " + totalPages;
            }
        }

        private void BtnSiguiente_Click(object sender, RoutedEventArgs e)
        {
            if ((currentPage * pageSize) < totalRecords)
            {
                currentPage++; // Aumenta el número de página
                CargarUsuarios(TxtBuscarUsuario.Text.Trim().Replace("'", "").Replace("\"", ""), currentPage, pageSize);
                TxtPagina.Text = "Página " + currentPage + " de " + totalPages;
            }
        }

        private void EditarUsuario_Click(object sender, RoutedEventArgs e)
        {
            // Botón que disparó el evento
            if (sender is Button btn)
            {
                if (btn != null)
                {
                    // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
                    if (btn.DataContext is DataRowView rowView)
                    {
                        if (rowView != null)
                        {
                            // Construye una lista de KeyValuePair con los datos del usuario para pasar a la ventana
                            var listUsuario = new List<KeyValuePair<string, string>>
                            {
                                new KeyValuePair<string, string>("@IdUsuario", rowView.Row[0].ToString()),
                                new KeyValuePair<string, string>("@Usuario", rowView.Row[1].ToString()),
                                new KeyValuePair<string, string>("@NombreCompleto", rowView.Row[2].ToString()),
                                new KeyValuePair<string, string>("@DiasPermitidos", rowView.Row[3].ToString()),
                                new KeyValuePair<string, string>("@cambioPassword", rowView.Row[4].ToString()),
                                new KeyValuePair<string, string>("@Estado", rowView.Row[5].ToString())
                            };

                            // Crea la ventana de actualización y le pasa esta página como referencia
                            EditarUsuario editarUsuario = new EditarUsuario(this);

                            // Si la ventana implementa la interfaz IFormUsuario, le asigna los datos
                            if (editarUsuario is IFormUsuario formdata)
                            {
                                formdata.SetData(listUsuario);
                            }
                            try
                            {
                                editarUsuario.ShowDialog(); // Muestra la ventana de edición de usuario
                            }
                            catch (Exception ex)
                            {
                                // Si ocurre un error al abrir la ventana, muestra un MessageBox con el detalle
                                MessageBox.Show(ex.Message, "Error al enviar información", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                    }
                }
            }
        }
        private async void EliminarUsuario_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn) // Botón que disparó el evento
            {                         // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
                if (btn.DataContext is DataRowView rowView)
                {
                    //Pregunta antes de proceder a eliminar usuario
                    MessageBoxResult messageBoxResult = MessageBox.Show($"¿Eliminar usuario: '{rowView.Row[1]}' - {rowView.Row[2]}?\nNota: si el Usuario se elimina también se eliminanará su historial.\n¿Desea continuar?", "Elimina Usuario", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (messageBoxResult == MessageBoxResult.Yes)
                    {
                        UsuariosController usuariosController = new UsuariosController();
                        //Procede a eliminar usuario seleccionado
                        if (await usuariosController.DeleteUsuarioAsync(rowView.Row[0].ToString(), rowView.Row[1].ToString(), rowView.Row[2].ToString(), MainWindow.IdUsuario))
                        {
                            MessageBox.Show($"Usuario '{rowView.Row[1]}' - {rowView.Row[2]}' elimino correctamente", "Elimina Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                            CargarUsuarios(TxtBuscarUsuario.Text.Trim().Replace("'", "").Replace("\"", ""), currentPage, pageSize);
                        }
                    }
                }
            }    
        }
        public interface IFormUsuario
        {
            void SetData(List<KeyValuePair<string, string>> dataUsuario);
        }

        private void ContenedorAcciones_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is StackPanel panel)
            {
                Permisos permisos = new Permisos();

                // Buscar los controles internos por tipo/nombre dentro del template
                var btnEditar = panel.Children.OfType<Button>().FirstOrDefault(b => b.Name == "EditarUsuario");
                var btnEliminar = panel.Children.OfType<Button>().FirstOrDefault(b => b.Name == "EliminarUsuario");
                var rtcSeparador = panel.Children.OfType<Rectangle>().FirstOrDefault(r => r.Name == "RtcEditarUsuario");

                // 1. Evaluar permisos globales
                bool puedeEditar = permisos.TienePermiso("Usuarios", "Editar Usuario");
                bool puedeEliminar = permisos.TienePermiso("Usuarios", "Eliminar Usuario");

                // 2. Evaluar regla para usuario protegido (ID 1)
                bool esUsuarioProtegido = false;
                if (panel.DataContext is DataRowView rowView)
                {
                    if (rowView.Row.Table.Columns.Contains("UsuarioID") && Convert.ToInt32(rowView["UsuarioID"]) == 1)
                    {
                        esUsuarioProtegido = true;
                    }
                }

                // Determinar visibilidades finales
                bool mostrarEditar = puedeEditar;
                bool mostrarEliminar = puedeEliminar && !esUsuarioProtegido;

                // Aplicar a los botones
                if (btnEditar != null)
                    btnEditar.Visibility = mostrarEditar ? Visibility.Visible : Visibility.Collapsed;

                if (btnEliminar != null)
                    btnEliminar.Visibility = mostrarEliminar ? Visibility.Visible : Visibility.Collapsed;

                // 3. EL TRUCO: La línea divisoria SOLO se muestra si AMBOS botones están visibles
                if (rtcSeparador != null)
                {
                    rtcSeparador.Visibility = (mostrarEditar && mostrarEliminar) ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }
    }
}