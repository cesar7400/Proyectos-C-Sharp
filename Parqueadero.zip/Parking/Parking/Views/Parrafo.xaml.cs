﻿using Parking.Resources;
using System;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para Parrafo.xaml
    /// </summary>
    public partial class Parrafo : Window
    {
        public Parrafo(ControlParrafo controlParrafo)
        {
            InitializeComponent();
            this.controlParrafo = controlParrafo;
        }
        readonly ControlParrafo controlParrafo = null;
        // Constantes y funciones de WinAPI para permitir arrastrar la ventana desde cualquier zona
        public const int WM_NCLBUTTONDOWN = 0xA1;// Código para clic izquierdo en non-client area
        public const int HTCAPTION = 0x2;        // Código para simular clic en la barra de título
        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture();// Libera la captura del mouse
        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                // Libera la captura para poder arrastrar
                ReleaseCapture();
                var winHandle = new WindowInteropHelper(this).Handle;
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
                // Envía mensaje para iniciar arrastre simulando clic en título
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow is MainTicket mainWin)
            {
                controlParrafo.Parrafo = "";
                mainWin.ActualizarVisualizacionTicket();
            }
            Window.GetWindow(this).Close();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (controlParrafo.Parrafo != "")
            {
                if (Application.Current.Windows.OfType<MainTicket>().FirstOrDefault() is MainTicket mainWin)
                {
                    mainWin.ActualizarVisualizacionTicket();
                }
                txtParrafo.Text = controlParrafo.Parrafo;
            }
            txtParrafo.Focus();
            //Posicionar carácter en el ultimo caracter
            txtParrafo.CaretIndex = txtParrafo.Text.Length;
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }

        // Evento que se ejecuta cada vez que cambia el texto en el TextBox
        private void TxtParrafo_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Se obtiene el valor máximo de caracteres permitido en el TextBox
            int max = txtParrafo.MaxLength;

            // Se cuentan los caracteres que ya fueron digitados
            int usados = txtParrafo.Text.Length;
            // Se calcula la cantidad de caracteres que aún se pueden escribir
            int restantes = max - usados;
            if (Application.Current.Windows.OfType<MainTicket>().FirstOrDefault() is MainTicket mainWin)
            {
                controlParrafo.Parrafo = txtParrafo.Text;
                mainWin.ActualizarVisualizacionTicket();
            }
            tamanoCaracteres.Text = $"Quedan: {restantes}";
        }
        private void BtnAgregarObservacion_Click(object sender, RoutedEventArgs e)
        {
            try
            {   //Se agrega observacion
                controlParrafo.strParrafo = txtParrafo.Text;
                this.Close();
            }
            catch (Exception ex)
            {
                //Si hay error al agregar se muestra el error
                MessageBox.Show("Error al agregar.\n" + ex.Message, "Observación", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}