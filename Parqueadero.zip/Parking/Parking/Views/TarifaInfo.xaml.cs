﻿using System;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para TarifaInfo.xaml
    /// </summary>
    public partial class TarifaInfo : Window
    {
        public TarifaInfo()
        {
            InitializeComponent();
            // Nos suscribimos para escuchar cuándo cambia o llega el DataContext
            this.DataContextChanged += VerInfoPlan_DataContextChanged;
        }
        public string IdPlanTarifa { get; set; }

        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana
        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private async void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            //DiccionarioEmpresa = await Configuracion.dEmpresa();
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        private async void VerInfoPlan_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            InfoPlan();
        }
        private async void InfoPlan()
        {
            // Recuperamos el nuevo DataContext asignado de forma segura
            var miContexto = this.DataContext;

            if (miContexto != null && miContexto is DataRowView view)
            {
                // Accedemos a la tabla completa que le dio origen a ese contexto
                DataTable tablaData = view.Row.Table;

                // Búsqueda con LINQ sobre el DataTable
                DataRow filaEncontrada = tablaData.AsEnumerable()
                    .FirstOrDefault(r => Convert.ToString(r["IdPlanTarifa"]) == IdPlanTarifa);

                if (filaEncontrada != null)
                {
                    // Creamos un FlowDocument con fuente Arial y tamaño 12
                    FlowDocument doc = new FlowDocument
                    {
                        PagePadding = new Thickness(10),
                        FontFamily = new FontFamily("Arial"),
                        FontSize = 12
                    };

                    // Función auxiliar para títulos de sección
                    void AgregarTitulo(string texto)
                    {
                        doc.Blocks.Add(new Paragraph(new Run(texto))
                        {
                            FontWeight = FontWeights.Bold,
                            FontSize = 13,
                            Margin = new Thickness(0, 10, 0, 2)
                        });
                    }

                    // Función auxiliar para cada línea de campo
                    void AgregarCampo(string etiqueta, string valor)
                    {
                        Paragraph p = new Paragraph { Margin = new Thickness(0, 0, 0, 2) };
                        p.Inlines.Add(new Run(etiqueta) { FontWeight = FontWeights.Bold });
                        p.Inlines.Add(new Run($" {valor}"));
                        doc.Blocks.Add(p);
                    }

                    bool estadoPlanTarifa = filaEncontrada.Field<bool>("EstadoPlanTarifa");

                    // ================= 1. INFORMACIÓN DEL PLAN =================
                    AgregarTitulo("Información del plan");
                    AgregarCampo("Tipo de Plan:", filaEncontrada.Field<string>("Nombre"));
                    AgregarCampo("Plan:", filaEncontrada.Field<string>("NombrePlan"));
                    AgregarCampo("Descripción:", filaEncontrada.Field<string>("Descripcion"));
                    AgregarCampo("Estado:", estadoPlanTarifa ? "Activo" : "Inactivo");

                    // ================= 2. VIGENCIA =================
                    AgregarTitulo("Vigencia");
                    AgregarCampo("Tipo vigencia:", filaEncontrada.Field<string>("Vigencia"));
                    AgregarCampo("Valor:", filaEncontrada.Field<string>("ValorTarifa"));
                    AgregarCampo("Estado:", estadoPlanTarifa ? "Activo" : "Inactivo");

                    // ================= 3. TIPO Y CATEGORÍA DE VEHÍCULO =================
                    AgregarTitulo("Tipo y categoría de vehículo");
                    AgregarCampo("Tipo de vehículo:", filaEncontrada.Field<string>("NombreTipoVehiculo"));
                    AgregarCampo("Descripción:", filaEncontrada.Field<string>("DescripcionTipoVehiculo"));
                    AgregarCampo("Categoría vehículo:", filaEncontrada.Field<string>("NombreCategoriaVehiculo"));
                    AgregarCampo("Descripción:", filaEncontrada.Field<string>("CategoriaVehiculoDescripcion"));

                    // Asignamos el documento completo al RichTextBox (ajusta el nombre del control si es diferente)
                    RtbInfoPlan.Document = doc;
                }
            }
        }
    }
}
