﻿using Parking.Controller;
using System;
using System.Data;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para SeleccionarTarifa.xaml
    /// </summary>
    public partial class SeleccionarTarifa : Window
    {
        public SeleccionarTarifa(EntradaSalida entradaSalida)
        {
            InitializeComponent();
            this.entradaSalida = entradaSalida;
        }
        private readonly EntradaSalida entradaSalida;
        DataTable dtOriginal;
        public string IdPlan {  get; set; }
        public string Placa {  get; set; }
        public string IdMovimiento {  get; set; }
        public string IdTipoVehiculo = "";
        public string IdCategoriaVehiculo = "";
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Tarifas(IdPlan);
        }

        public async void Tarifas(string IdPlan)
        {
            try
            {
                Movimientos movimientos = new Movimientos();

                var ds = await movimientos.TipoVehiculolAsync("3");

                if (ds != null) // Si hay resultados
                {
                    // Guardamos la tabla completa (CON TODAS SUS COLUMNAS)
                    dtOriginal = ds.Tables[0];

                    EntradaSalida entradaSalida = new EntradaSalida();
                    entradaSalida.richTextBoxPlan.Document.Blocks.Clear();
                    // Creamos una mini-tabla SOLO para el ComboBox (para quitar los duplicados en la lista desplegable)
                    DataTable dtCombo = dtOriginal.DefaultView.ToTable(true, "IdPlan", "NombrePlan");

                    CmbSeleccionarTarifa.IsEnabled = true;
                    // Asignamos la mini-tabla ÚNICAMENTE al ComboBox
                    CmbSeleccionarTarifa.ItemsSource = dtCombo.DefaultView;
                    CmbSeleccionarTarifa.DisplayMemberPath = "NombrePlan";
                    CmbSeleccionarTarifa.SelectedValuePath = "IdPlan";
                    CmbSeleccionarTarifa.SelectedValue = IdPlan;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CmbSeleccionarTarifa_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Validar que haya un elemento seleccionado y que la placa no esté vacía
            if (CmbSeleccionarTarifa.SelectedItem is DataRowView rowView)
            {
                string nombrePlanSeleccionado = rowView["NombrePlan"].ToString();

                // Filtrar dtOriginal según el NombrePlan seleccionado
                DataRow[] filas = dtOriginal.Select($"NombrePlan = '{nombrePlanSeleccionado}'");

                if (filas.Length > 0)
                {
                    // CORRECCIÓN: Tomamos únicamente la primera fila del plan seleccionado 
                    // para evitar llamadas múltiples y concurrentes a la base de datos.
                    DataRow primeraFila = filas[0];
                    IdTipoVehiculo = primeraFila["IdTipoVehiculo"].ToString();
                    IdCategoriaVehiculo = primeraFila["IdCategoriaVehiculo"].ToString();

                    entradaSalida.TiempoDemandaInfo(Placa, IdTipoVehiculo, IdCategoriaVehiculo, dtOriginal);
                }
            }
        }

        private async void BtnAceptar_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult confirmar = MessageBox.Show($"Confirmar salida vehículo con placa: '{Placa}'", "Confirmar Salida", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (confirmar == MessageBoxResult.Yes)
            {
                Movimientos movimientos = new Movimientos();

                if (await movimientos.RegistrarSalidaVehiculoAsync(Placa, IdTipoVehiculo, IdCategoriaVehiculo, IdMovimiento, "1", MainWindow.IdUsuario))
                {
                    entradaSalida.richTextBoxPlan.Document.Blocks.Clear();
                    entradaSalida.TxtPlaca.Text = string.Empty;
                    entradaSalida.MovimientosVehiculos();
                    entradaSalida.tbValorPagar.Text = "$ 0,0";
                    this.Close();
                }
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}