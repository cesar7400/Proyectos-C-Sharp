﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Data;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para TiempoPorDemanda.xaml
    /// </summary>
    public partial class TiempoPorDemanda : UserControl
    {
        public TiempoPorDemanda(Planes planes)
        {
            InitializeComponent();
            this._planes = planes;
        }
        private readonly Planes _planes;
        // Propiedades para manejar la paginación y búsqueda de usuarios
        public int currentPageTiempoPorDemanda = 1;    // Página actual (inicia en 1)
        public int pageSizeTiempoPorDemanda = 3;      // Cantidad de registros por página
        public int totalRecordsTiempoPorDemanda = 0;   // Total de usuarios que coinciden con la búsqueda
        public int totalPagesTiempoPorDemanda = 0;     // Total de páginas calculadas

        private string IdPlan = "";
        private string IdPlanReglaCobro = "";
        public string IdPlanTarifa = "";

        public string IdPlanHorario = "";
        TimeSpan horaInicio;
        TimeSpan horaFin;

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Obtiene la ventana que contiene esta página
            var window = Window.GetWindow(this);
            if (window is MainWindow mainWindow)
            {
                // Limpia el contenido del contenedor principal (fContainer)
                mainWindow.ContenedorPrincipal.Content = null;
            }
        }

        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            await ListaTipoPlan();
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void PreviewTextInputNumbers(object sender, TextCompositionEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            // Evita el cero si es el primer carácter escrito
            if (e.Text == "0" && (textBox.Text.Length == 0 || textBox.SelectionLength == textBox.Text.Length))
            {
                e.Handled = true;
            }
            Library clsLibrary = new Library(); // Instancia de librería auxiliar
            clsLibrary.Numbers(sender, e); // Permite solo números en el TextBox
        }
        private void Txt_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true; // Evita que la tecla Espacio genere un carácter
            }
        }
        private void TextBox_formatoMiles_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Verifica que el sender sea un TextBox usando coincidencia de patrones
            if (sender is TextBox textBox)
            {
                // 1. FILTRO ESTRICTO: Remueve cualquier cosa que NO sea un número o un punto
                string textoFiltrado = Regex.Replace(textBox.Text, @"[^0-9.]", "");

                // Si el usuario intentó meter un espacio o letra, restauramos el texto limpio
                if (textBox.Text != textoFiltrado)
                {
                    textBox.Text = textoFiltrado;
                    textBox.SelectionStart = textBox.Text.Length; // Mantiene el cursor al final
                    return;
                }

                // Limpiamos los puntos para hacer la validación numérica interna
                string textoLimpio = textBox.Text.Replace(".", "").Trim();

                // Si el texto quedó vacío al borrar, salimos limpiamente sin romper nada
                if (string.IsNullOrEmpty(textoLimpio))
                {
                    return;
                }

                // 2. VALIDACIÓN DE RANGO NUMÉRICO
                if (Int64.TryParse(textoLimpio, out long valorConvertido))
                {
                    // Verifica si excede el valor máximo permitido para un entero estándar
                    if (valorConvertido >= int.MaxValue)
                    {
                        textBox.Text = ""; // Si excede el valor máximo de int, limpia el TextBox
                    }
                    else
                    {
                        Library clsLibrary = new Library(); // Instancia de librería auxiliar
                        clsLibrary.FormatNumberML(sender, e); // Formatea el número con puntos de miles
                    }

                    textBox.SelectionStart = textBox.Text.Length; // Coloca el cursor al final
                    textBox.Focus(); // Vuelve a enfocar el TextBox
                }
            }
        }

        public async Task TarifaPorTiempoDemanda(string IdPlan, int pageNumber, int pageSize)
        {
            TiposPlanes tiposPlanes = new TiposPlanes();

            try
            {
                var dt = await tiposPlanes.ListadoTiempoPorDemandaAsync(IdPlan, pageNumber, pageSize);

                if (dt != null) // Si hay resultados
                {
                    this.IdPlan = IdPlan;
                    this.TbInfoTipoPlan.Text = _planes.NombreTipoPlan;
                    // Verifica si la tabla 0 (registros) tiene filas
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        TbEstado.Text = dt.Tables[0].Rows[0]["EstadoPlan"].ToString() == "True" ? "Activo":"Inactivo";

                        // Obtiene el total de registros de la segunda tabla (índice 1)
                        totalRecordsTiempoPorDemanda = int.Parse(dt.Tables[1].Rows[0][0].ToString());

                        // Calcular el registro inicial de la página
                        int desde = ((currentPageTiempoPorDemanda - 1) * pageSizeTiempoPorDemanda) + 1;

                        // Calcular el registro final (evita pasarse del total real, ej. en la última página)
                        int hasta = Math.Min(currentPageTiempoPorDemanda * pageSizeTiempoPorDemanda, totalRecordsTiempoPorDemanda);

                        // Asignar el texto formateado al TextBlock
                        TbContadorTiempoPorDemanda.Text = $"Mostrando {desde} a {hasta} de {totalRecordsTiempoPorDemanda} registros";

                        // Calcula el total de páginas
                        totalPagesTiempoPorDemanda = (int)Math.Ceiling((double)totalRecordsTiempoPorDemanda / pageSize);

                        //muestra pagina actual
                        TxtPaginaTiempoPorDemanda.Text = "Página " + currentPageTiempoPorDemanda + " de " + totalPagesTiempoPorDemanda;
                        // Asigna la fuente de datos del DataGrid a la vista por defecto del DataTable
                        DgTiempoPorDemanda.ItemsSource = dt.Tables[0].DefaultView;
                        // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                        DgTiempoPorDemanda.CanUserSortColumns = false;

                        // Habilita o deshabilita los botones de navegación según la página actual
                        BtnAnteriorTiempoPorDemanda.IsEnabled = currentPageTiempoPorDemanda > 1;
                        BtnSiguienteTiempoPorDemanda.IsEnabled = (currentPageTiempoPorDemanda * pageSize) < totalRecordsTiempoPorDemanda;

                        // Muestra u oculta los íconos de flecha según correspondan
                        ImgAnteriorTiempoPorDemanda.Visibility = (currentPageTiempoPorDemanda > 1 ? Visibility.Visible : Visibility.Hidden);
                        ImgSiguienteTiempoPorDemanda.Visibility = ((currentPageTiempoPorDemanda * pageSize) < totalRecordsTiempoPorDemanda ? Visibility.Visible : Visibility.Hidden);
                    }
                    else
                    {
                        // Si no hay filas, resetea totales y muestra mensaje de página vacía
                        totalRecordsTiempoPorDemanda = 0;
                        // Asignar el texto formateado al TextBlock
                        TbContadorTiempoPorDemanda.Text = $"Mostrando {0} a {0} de {totalRecordsTiempoPorDemanda} registros";
                        dt.Clear();
                        DgTiempoPorDemanda.ItemsSource = dt.Tables[0].DefaultView;
                        TxtPaginaTiempoPorDemanda.Text = "0";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void CmbUnidadCobro_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbUnidadCobro.SelectedIndex == 0)
            {
                GrdMinutosGratis.Visibility = Visibility.Visible;
                TbFraccionTiempoDemanda.Text = "Fracción de tiempo:";
                TbMinutosGratis.Text = "Minutos gratis:";
            }
            else
            {
                TbFraccionTiempoDemanda.Text = "Fracción de tiempo:";
                GrdMinutosGratis.Visibility = Visibility.Collapsed;
            }
            TxtFraccionTiempoDemanda.Text = string.Empty;
            TxtMinutosGratis.Text = string.Empty;
            TxtFraccionTiempoDemanda.Focus();
        }


        private async void BtnAnteriorTiempoPorDemanda_Click(object sender, RoutedEventArgs e)
        {
            if (currentPageTiempoPorDemanda > 1)
            {
                currentPageTiempoPorDemanda--; // Disminuye el número de página
                await TarifaPorTiempoDemanda(IdPlan, currentPageTiempoPorDemanda, pageSizeTiempoPorDemanda);
                TxtPaginaTiempoPorDemanda.Text = "Página " + currentPageTiempoPorDemanda + " de " + totalPagesTiempoPorDemanda;
            }
        }

        private async void BtnSiguienteTiempoPorDemanda_Click(object sender, RoutedEventArgs e)
        {
            if ((currentPageTiempoPorDemanda * pageSizeTiempoPorDemanda) < totalRecordsTiempoPorDemanda)
            {
                currentPageTiempoPorDemanda++; // Aumenta el número de página
                await TarifaPorTiempoDemanda(IdPlan, currentPageTiempoPorDemanda, pageSizeTiempoPorDemanda);
                TxtPaginaTiempoPorDemanda.Text = "Página " + currentPageTiempoPorDemanda + " de " + totalPagesTiempoPorDemanda;
            }
        }
        
        private string FormatoHora(string Tiempo)
        {
            // El formato debe coincidir exactamente con los espacios: "hh : mm tt"
            DateTime hora24 = DateTime.ParseExact(Tiempo, "hh : mm tt", System.Globalization.CultureInfo.InvariantCulture);

            return hora24.ToString("HH:mm");
        }
        private async void BtnGuardarTiempoDemanda_Click(object sender, RoutedEventArgs e)
        {
            if (TxtHorarioTiempoDemanda.Text == string.Empty)
            {
                MessageBox.Show("Ingresar horario", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtHorarioTiempoDemanda.Focus();
                return;
            }
            // Verificamos si la hora no es válida o está vacía
            if (!dtpHorarioInicio.EsHoraValida())
            {
                MessageBox.Show("Por favor, ingrese una hora válida o verifique que el campo no esté vacío.",
                                "Nuevo Plan Demanada",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);

                // Opcional: Enfocar el control para que el usuario lo corrija
                dtpHorarioInicio.Focus();
                return; // Detiene la ejecución para que no continúe guardando
            }
            if (!dtpHorarioFin.EsHoraValida())
            {
                MessageBox.Show("Por favor, ingrese una hora válida o verifique que el campo no esté vacío.",
                                "Nuevo Plan Demanada",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);

                // Opcional: Enfocar el control para que el usuario lo corrija
                dtpHorarioFin.Focus();
                return; // Detiene la ejecución para que no continúe guardando
            }

            if (CmbUnidadCobro.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccionar unidad de cobro", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbUnidadCobro.Focus();
                return;
            }
            if (TxtFraccionTiempoDemanda.Text == string.Empty)
            {
                MessageBox.Show($"Ingresar {(CmbUnidadCobro.Text == "Hora" ? "fracción minutos" : "cantidad minutos")}", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtFraccionTiempoDemanda.Focus();
                return;
            }
            if (CmbUnidadCobro.Text == "Hora" && TxtMinutosGratis.Text == string.Empty)
            {
                MessageBox.Show("Ingresar minutos gratis", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtMinutosGratis.Focus();
                return;
            }
            if (ChkLunes.IsChecked == false && ChkMartes.IsChecked == false && ChkMiercoles.IsChecked == false && ChkJueves.IsChecked == false && ChkViernes.IsChecked == false && ChkSabado.IsChecked == false && ChkDomingo.IsChecked == false)
            {
                MessageBox.Show("Seleccionar uno o varios días", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Information); // Valida que se haya seleccionado al menos un día
                return;
            }
            if (TxtValorMinuto.Text == string.Empty)
            {
                MessageBox.Show("Ingresar valor minuto", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtValorMinuto.Focus();
                return;
            }
            if (TxtValorHora.Text == string.Empty)
            {
                MessageBox.Show("Ingresar valor hora", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtValorHora.Focus();
                return;
            }
            if (TxtValor12Horas.Text == string.Empty)
            {
                MessageBox.Show("Ingresar valor 12 horas", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtValor12Horas.Focus();
                return;
            }
            if (TxtValor24Horas.Text == string.Empty)
            {
                MessageBox.Show("Ingresar valor 24 horas", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtValor24Horas.Focus();
                return;
            }
            if (CmbEstadoTiempoDemanda.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccionar estado", "Tiempo por Demanda", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbEstadoTiempoDemanda.Focus();
                return;
            }

            else
            {
                if (dtpHorarioInicio.EsHoraValida() && dtpHorarioFin.EsHoraValida())
                {
                    horaInicio = TimeSpan.Parse(FormatoHora(dtpHorarioInicio.TextoHora)); // Convierte a TimeSpan
                    horaFin = TimeSpan.Parse(FormatoHora(dtpHorarioFin.TextoHora)); // Convierte a TimeSpan
                }
                // Cruce media noche
                bool cruzaMedianoche = horaFin < horaInicio;
                //concatenar días
                string strDias = (ChkLunes.IsChecked == true ? "1," : "") + (ChkMartes.IsChecked == true ? "2," : "") + (ChkMiercoles.IsChecked == true ? "3," : "") + (ChkJueves.IsChecked == true ? "4," : "") + (ChkViernes.IsChecked == true ? "5," : "") + (ChkSabado.IsChecked == true ? "6," : "") + (ChkDomingo.IsChecked == true ? "7," : "");

                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar plan
                TiposPlanes tiposPlanes = new TiposPlanes();
                //Igresar
                if (TbGuardarTiempoDemanda.Text == "Guardar" ? await tiposPlanes.NuevoPlanTiempoDemanda(_planes.NombrePlan, IdPlan, CmbEstadoTiempoDemanda.Text, TxtHorarioTiempoDemanda.Text.Trim(), horaInicio, horaFin, cruzaMedianoche, strDias.Remove(strDias.Length - 1), TxtValorMinuto.Text.Trim().Replace(".", ""), TxtValorHora.Text.Trim().Replace(".", ""), TxtValor12Horas.Text.Trim().Replace(".", ""), TxtValor24Horas.Text.Trim().Replace(".", ""), CmbUnidadCobro.Text, TxtFraccionTiempoDemanda.Text.Trim(), TxtMinutosGratis.Text.Trim(), MainWindow.IdUsuario)
                                                              :await tiposPlanes.ActualizarPlanTiempoDemanda(_planes.NombrePlan, IdPlanHorario, IdPlan, IdPlanReglaCobro, IdPlanTarifa, CmbEstadoTiempoDemanda.Text, TxtHorarioTiempoDemanda.Text.Trim(), horaInicio, horaFin, cruzaMedianoche, strDias.Remove(strDias.Length - 1), TxtValorMinuto.Text.Trim().Replace(".", ""), TxtValorHora.Text.Trim().Replace(".", ""), TxtValor12Horas.Text.Trim().Replace(".", ""), TxtValor24Horas.Text.Trim().Replace(".", ""), CmbUnidadCobro.Text, TxtFraccionTiempoDemanda.Text.Trim(), TxtMinutosGratis.Text.Trim(), MainWindow.IdUsuario))
                {
                    // actualiza el datagrid
                    await TarifaPorTiempoDemanda(IdPlan, currentPageTiempoPorDemanda, pageSizeTiempoPorDemanda);
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show($"Plan '{_planes.NombrePlan}' de {_planes.NombreTipoPlan} se {(TbGuardarTiempoDemanda.Text == "Guardar" ? "agrego" : "actualizo")} correctamente", "Tiempo Por Demanda", MessageBoxButton.OK, MessageBoxImage.Information);
                    LimpiarTiempoDemanda();
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }

        private void BtnCancelarTiempoDemanda_Click(object sender, RoutedEventArgs e)
        {
            LimpiarTiempoDemanda();
        }

        private async void LimpiarTiempoDemanda()
        {
            dtpHorarioInicio.SelectedTime = DateTime.Now;
            dtpHorarioFin.SelectedTime = DateTime.Now;
            CmbEstadoTiempoDemanda.SelectedIndex = -1;
            TxtValorMinuto.Text = string.Empty;
            TxtValorHora.Text = string.Empty;
            TxtValor12Horas.Text = string.Empty;
            TxtValor24Horas.Text = string.Empty;
            TxtHorarioTiempoDemanda.Text = string.Empty;
            CmbUnidadCobro.SelectedIndex = 0;
            TxtFraccionTiempoDemanda.Text = string.Empty;
            TxtMinutosGratis.Text = string.Empty;

            ChkLunes.IsChecked = false;
            ChkMartes.IsChecked = false;
            ChkMiercoles.IsChecked = false;
            ChkJueves.IsChecked = false;
            ChkViernes.IsChecked = false;
            ChkSabado.IsChecked = false;
            ChkDomingo.IsChecked = false;

            await EstadoGuardar(true, false);
        }

        private async void BtnEditarPlan_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;

            IdPlanHorario = filaSeleccionada["IdPlanHorario"].ToString();
            IdPlanReglaCobro = filaSeleccionada["IdPlanReglaCobro"].ToString(); 
            IdPlanTarifa = filaSeleccionada["IdPlanTarifa"].ToString();
            // Horario
            TxtHorarioTiempoDemanda.Text = filaSeleccionada["NombrePlanHorario"].ToString();
            dtpHorarioInicio.SelectedTime = DateTime.Today.Add((TimeSpan)filaSeleccionada["HoraInicio"]);
            dtpHorarioFin.SelectedTime = DateTime.Today.Add((TimeSpan)filaSeleccionada["HoraFin"]);
            // Regla cobro
            CmbUnidadCobro.Text = filaSeleccionada["UnidadCobro"].ToString();
            TxtFraccionTiempoDemanda.Text = filaSeleccionada["MinutosFraccion"].ToString();
            TxtMinutosGratis.Text = filaSeleccionada["MinutosGracia"].ToString();

            //Días
            string diasStr = filaSeleccionada["DiasSemana"].ToString(); // O la variable que contiene el resultado de la base de datos

            ChkLunes.IsChecked = diasStr.Contains("Lunes");
            ChkMartes.IsChecked = diasStr.Contains("Martes");
            ChkMiercoles.IsChecked = diasStr.Contains("Miércoles");
            ChkJueves.IsChecked = diasStr.Contains("Jueves");
            ChkViernes.IsChecked = diasStr.Contains("Viernes");
            ChkSabado.IsChecked = diasStr.Contains("Sábado");
            ChkDomingo.IsChecked = diasStr.Contains("Domingo");

            //Tarifas
            TxtValorMinuto.Text = filaSeleccionada["ValorMinuto"].ToString();
            TxtValorHora.Text = filaSeleccionada["ValorHora"].ToString();
            TxtValor12Horas.Text = filaSeleccionada["Valor12Horas"].ToString();
            TxtValor24Horas.Text = filaSeleccionada["Valor24Horas"].ToString();
            CmbEstadoTiempoDemanda.Text = Convert.ToBoolean(filaSeleccionada["EstadoPlanTarifa"]) == true ? "Activo": "Inactivo";

            await EstadoGuardar(false, true);
        }

        private async void BtnSeleccionarPlan_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;

            await EstadoGuardar(true, false);

            string IdPlanTarifa = filaSeleccionada["IdPlanTarifa"].ToString();

            var tiempoDemandaInfo = new TiempoDemandaInfo()
            {
                IdPlanTarifa = IdPlanTarifa,
                DataContext = filaSeleccionada
            };
            tiempoDemandaInfo.ShowDialog();
        }

        private async void BtnEliminarPlan_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;

            string Plan = filaSeleccionada["NombrePlanHorario"].ToString();
            string IdPlan = filaSeleccionada["IdPlan"].ToString();
            string IdPlanTarifa = filaSeleccionada["IdPlanTarifa"].ToString();
            string IdPlanHorario = filaSeleccionada["IdPlanHorario"].ToString();
            string IdPlanReglaCobro = filaSeleccionada["IdPlanReglaCobro"].ToString();

            //Pregunta antes de proceder a eliminar tipo plan
            MessageBoxResult messageBoxResult = MessageBox.Show($"¿Eliminar '{Plan}' ¿Desea continuar?", "Eliminar Plan", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar plan
                TiposPlanes tiposPlanes = new TiposPlanes();
                //Igresar / actualizar Tipo de plan
                if (await tiposPlanes.EliminarPlanTiempoDemandaDetalle(IdPlan, IdPlanTarifa, IdPlanHorario, IdPlanReglaCobro, Plan, MainWindow.IdUsuario))
                {
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show($"Plan '{Plan}' se eliminó correctamente", "Eliminar Plan", MessageBoxButton.OK, MessageBoxImage.Information);
                    // actualiza el datagrid
                    await TarifaPorTiempoDemanda(IdPlan, currentPageTiempoPorDemanda, pageSizeTiempoPorDemanda);
                    LimpiarTiempoDemanda();
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                Mouse.OverrideCursor = null;
            }
        }

        public async Task ListaTipoPlan()
        {
            Permisos permisos = new Permisos();
            try
            {
                // Consultar permisos
                bool PuedeGuardar = permisos.TienePermiso("Planes", "Agregar tiempo demanda");
                bool verPlanes = permisos.TienePermiso("Planes", "Ver tiempo demanda");
                bool puedeEditar = permisos.TienePermiso("Planes", "Editar tiempo demanda");
                bool puedeEliminar = permisos.TienePermiso("Planes", "Eliminar tiempo demanda");


                // Si TODOS los permisos están en false, ocultamos toda la columna Acciones
                if (!puedeEditar && !puedeEliminar && !verPlanes)
                {
                    ColAcciones.Visibility = Visibility.Collapsed;
                }
                else
                {
                    ColAcciones.Visibility = Visibility.Visible;
                }
                await EstadoGuardar(true, false);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async Task EstadoGuardar(bool Guardar, bool Editar)
        {

            BtnGuardarTiempoDemanda.Visibility = Visibility.Collapsed;

            Permisos permisos = new Permisos();

            bool puedeEditar = permisos.TienePermiso("Planes", "Editar tiempo demanda");
            bool puedeAgregar = permisos.TienePermiso("Planes", "Agregar tiempo demanda");


            if (puedeEditar == false && puedeAgregar == false)
            {
                BtnGuardarTiempoDemanda.Visibility = Visibility.Collapsed;
                return;
            }

            if (puedeAgregar == true && Guardar == true)
            {
                BtnGuardarTiempoDemanda.Visibility = Visibility.Visible;
                TbGuardarTiempoDemanda.Text = "Guardar";
                return;
            }

            if (puedeEditar == true && Editar == true)
            {
                BtnGuardarTiempoDemanda.Visibility = Visibility.Visible;
                TbGuardarTiempoDemanda.Text = "Guardar Cambios";
                return;
            }
            else
            {
                TbGuardarTiempoDemanda.Text = "Guardar";
            }
        }

        private void PanelTiempoDemanda_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is StackPanel panel)
            {
                Permisos permisos = new Permisos();

                // Validar permisos para el módulo "Planes"
                bool puedeVerPlanes = permisos.TienePermiso("Planes", "Ver tiempo demanda");
                bool puedeEditar = permisos.TienePermiso("Planes", "Editar tiempo demanda");
                bool puedeEliminar = permisos.TienePermiso("Planes", "Eliminar tiempo demanda");

                // Aplicar visibilidad a los botones principales
                if (panel.FindName("BtnSeleccionarPlan") is Button BtnSeleccionarPlan)
                {
                    BtnSeleccionarPlan.Visibility = puedeVerPlanes ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("BtnEditarPlan") is Button BtnEditarPlan)
                {
                    BtnEditarPlan.Visibility = puedeEditar ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("BtnEliminarPlan") is Button BtnEliminarPlan)
                {
                    BtnEliminarPlan.Visibility = puedeEliminar ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }
    }
}
