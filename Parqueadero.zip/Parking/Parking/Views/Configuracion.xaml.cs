﻿using Microsoft.Win32;
using Parking.Controller;
using Parking.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para Configuracion.xaml
    /// </summary>
    public partial class Configuracion : Page
    {
        public Configuracion()
        {
            InitializeComponent();
            // Asignar el DataContext si usas Code-Behind para los datos del DataGrid
            this.DataContext = this;
        }
        string IdUsuario = "";
        string strIva = "";
        string strTicket = "";
        private string srcImageExtension = ""; // Extensión de archivo de la imagen seleccionada
        private string srcImage = "";          // Ruta original de la imagen seleccionada
        public ObservableCollection<string> ListaImpresoras { get; set; } = new ObservableCollection<string>();
        // Diccionario público accesible desde otros formularios o clases
        public static Dictionary<string, string> DicEmpresa { get; set; } = new Dictionary<string, string>();

        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            DatosEmpresa();
            await CargarTickets();
            CargarUsuarios("", 1, 30);

            Permisos permisos = new Permisos();

            // 1. Validar permisos para el módulo "Configuración"
            bool puedeActualizarInformacion = permisos.TienePermiso("Configuración", "Actualizar Información");
            bool puedeCrearTicket = permisos.TienePermiso("Configuración", "Nuevo Ticket");
            // 2. Aplicar visibilidad a los GroupBox
            if (BtnGuardarInformacion != null)
                BtnGuardarInformacion.IsEnabled = puedeActualizarInformacion;
            
            if (BtnNuevoTicket != null)
                BtnNuevoTicket.IsEnabled = puedeCrearTicket;
            
            Color ColorInfo = (Color)ColorConverter.ConvertFromString(puedeActualizarInformacion == true ? "#007BFF" : "#c2c2c2");
            BtnGuardarInformacion.Background = new SolidColorBrush(ColorInfo);

            Color ColorTicket = (Color)ColorConverter.ConvertFromString(puedeCrearTicket == true ? "#007BFF" : "#c2c2c2");
            BtnNuevoTicket.Background = new SolidColorBrush(ColorTicket);
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Obtiene la ventana que contiene esta página
            var window = Window.GetWindow(this);
            if (window is MainWindow mainWindow)
            {
                // Limpia el contenido del contenedor principal (fContainer)
                mainWindow.ContenedorPrincipal.Content = null;
            }
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void PreviewTextInputTextLetters(object sender, TextCompositionEventArgs e)
        {
            // Crea una instancia de la biblioteca de utilidades
            Library library = new Library();
            // Llama al método que permite solo letras
            library.Letters(sender, e);
        }
        // Formatea el número de celular a medida que el usuario escribe
        private void TxtCelular_TextChanged(object sender, TextChangedEventArgs e)
        {
            Library library = new Library();
            string formattedPhoneNumber = library.FormatCelularNumber(TxtTelefono.Text);
            // Llama al método que formatea el número de celular
            TxtTelefono.Text = formattedPhoneNumber;     // Asigna el texto formateado
            TxtTelefono.CaretIndex = TxtTelefono.Text.Length;
            // Mueve el cursor al final del texto
        }
        private void Txt_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true; // Evita que la tecla Espacio genere un carácter
            }
        }
        private void PreviewTextInputNumbers(object sender, TextCompositionEventArgs e)
        {
            Library clsLibrary = new Library(); // Instancia de librería auxiliar
            clsLibrary.Numbers(sender, e); // Permite solo números en el TextBox
        }
        private void TxtNit_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Crea una instancia de la biblioteca de utilidades
            Library clsLibrary = new Library();
            // Calcula y muestra el dígito de verificación basado en el NIT ingresado
            TxtDV.Text = clsLibrary.CalcularDigitoVerificacion(TxtNit.Text.Trim());
        }
        private void CmbRegimen_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbRegimen.SelectedItem == null)
            {
                return;
            }
            else
            {
                if (CmbRegimen.SelectedIndex == 0)
                {
                    TxtIVA.IsReadOnly = false;
                    TxtIVA.Text = strIva;
                }
                else
                {
                    TxtIVA.IsReadOnly = true;
                    TxtIVA.Text = "0";
                }
            }
        }
        private async void DatosEmpresa()
        {
            ConfiguracionController configuracion = new ConfiguracionController();

            var infoEmpresa = await configuracion.ObtenerInformacionEmpresaAsync();
            if (infoEmpresa != null)
            {
                if (infoEmpresa.Rows.Count > 0)
                {
                    TxtRazonSocial.Text = infoEmpresa.Rows[0]["razon_social"].ToString();
                    TxtDireccion.Text = infoEmpresa.Rows[0]["direccion"].ToString();
                    TxtTelefono.Text = infoEmpresa.Rows[0]["telefono"].ToString();
                    TxtConsecutivoRecibo.Text = infoEmpresa.Rows[0]["consecutivo_recibo"].ToString();
                    TxtHorario.Text = infoEmpresa.Rows[0]["horario"].ToString();
                    TxtResponsable.Text = infoEmpresa.Rows[0]["responsable"].ToString();
                    TxtNit.Text = infoEmpresa.Rows[0]["nit"].ToString().Split('-')[0];
                    TxtDV.Text = infoEmpresa.Rows[0]["nit"].ToString().Split('-')[1];
                    TxtIVA.Text = infoEmpresa.Rows[0]["iva"].ToString();
                    strIva = infoEmpresa.Rows[0]["iva"].ToString();
                    CmbRegimen.Text = infoEmpresa.Rows[0]["regimen"].ToString();
                    TxtNumeroResolucion.Text = infoEmpresa.Rows[0]["numero_resolucion"].ToString();
                    DtpFecha.Text = infoEmpresa.Rows[0]["fecha_resolucion"].ToString();
                    strTicket = infoEmpresa.Rows[0]["ticket"].ToString();

                    //Pasamos la información de la empresa al 'Dictionary'
                    DataRow fila = infoEmpresa.Rows[0];

                    if (fila["regimen"].ToString() == "Común")
                    {
                        fila["regimen"] = "Responsables del IVA";
                    }
                    else
                    {
                        fila["regimen"] = "No Responsables del IVA";
                    }
                    DicEmpresa = new Dictionary<string, string>
                    {
                        { "razon_social", fila["razon_social"].ToString() },
                        { "nit", "NIT: " + fila["nit"].ToString() },
                        { "regimen", fila["regimen"].ToString() },
                        { "direccion", fila["direccion"].ToString() },
                        { "telefono","TELÉFONO: "+ fila["telefono"].ToString() },
                        { "horario", "HORARIO: "+fila["horario"].ToString() }
                    };
                    //lectura para carga de la imagen
                    // IMPORTANTE: Validar si la columna no es DBNull
                    if (infoEmpresa.Rows.Count > 0 && infoEmpresa.Rows[0]["Imagen"] != DBNull.Value)
                    {
                        try
                        {
                            byte[] imgBytes = null;
                            var valorCelda = infoEmpresa.Rows[0]["Imagen"];

                            // Si la base de datos lo devuelve como byte[] directamente
                            if (valorCelda is byte[] bytes)
                            {
                                imgBytes = bytes;
                            }
                            // Si la base de datos lo devuelve como texto Base64
                            else if (valorCelda is string base64String && !string.IsNullOrEmpty(base64String))
                            {
                                if (base64String.Contains(","))
                                {
                                    base64String = base64String.Split(',')[1];
                                }
                                imgBytes = Convert.FromBase64String(base64String);
                            }

                            if (imgBytes != null && imgBytes.Length > 0)
                            {
                                using (MemoryStream ms = new MemoryStream(imgBytes))
                                {
                                    BitmapImage image = new BitmapImage();
                                    image.BeginInit();
                                    image.CacheOption = BitmapCacheOption.OnLoad;
                                    image.StreamSource = ms;
                                    image.EndInit();
                                    ImgLogo.Stretch = Stretch.UniformToFill; // Ajusta la imagen al tamaño del control Image
                                    ImgLogo.Source = image;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error al cargar la imagen: " + ex.Message,"Error",MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
        }
        private void BtnAddImagen_Click(object sender, RoutedEventArgs e)
        {
            if (BtnAddImagen.ToolTip.ToString() == "Seleccionar imagen")
            {
                OpenFileDialog openFileDialog = new OpenFileDialog
                {
                    Title = "Seleccionar imagen",                 // Título de la ventana de diálogo
                    Filter = "Archivos de imagen|*.bmp;*.jpg;*.jpeg;*.gif;*.png;", // Filtros de imagen
                    Multiselect = false,                          // Solo permite seleccionar un archivo
                    FilterIndex = 1                               // Índice del filtro por defecto
                };
                bool? result = openFileDialog.ShowDialog();        // Muestra el diálogo y espera resultado

                if (result == true)
                {
                    string originalPath = openFileDialog.FileName; // Ruta completa del archivo seleccionado
                    string newPath = Path.ChangeExtension(originalPath, ".jpg");
                    srcImageExtension = Path.GetExtension(newPath); // Obtiene la extensión .jpg
                    srcImage = Path.GetDirectoryName(openFileDialog.FileName) + "\\" + Path.GetFileName(openFileDialog.FileName);
                    // Guarda la ruta completa original

                    Library library = new Library();      // Instancia para validar la imagen
                    if (library.ImageValidacion(srcImage))      // Verifica que la imagen cumpla condiciones (tamaño, tipo)
                    {
                        ImgLogo.Source = new BitmapImage(new Uri($@"{srcImage}"));
                        BtnAddImagen.ToolTip = "Eliminar imagen";
                        // Muestra la imagen seleccionada en el control Image
                        // si se quita la imagen seleccionada vuel a la imagen predeterminada
                        var uri = new Uri("pack://application:,,,/Icons/deleteImg.png", UriKind.Absolute);
                        var bitmap = new BitmapImage(uri);
                        ImgButton.Source = bitmap;
                    }
                }
            }
            else
            {
                srcImage = "";
                // si se quita la imagen seleccionada vuel a la imagen predeterminada
                var url = new Uri("pack://application:,,,/Icons/add image.png", UriKind.Absolute);
                var bitmapl = new BitmapImage(url);
                ImgButton.Source = bitmapl;

                BtnAddImagen.ToolTip = "Seleccionar imagen";
                // Carga la imagen por defecto del recurso
                var uri = new Uri("pack://application:,,,/Icons/parking.png", UriKind.Absolute);
                var bitmap = new BitmapImage(uri);
                ImgLogo.Source = bitmap;  // Asigna la imagen por defecto al control Image
            }
        }
        private async void BtnGuardarInformacion_Click(object sender, RoutedEventArgs e)
        {
            //Validar campos

            if (TxtRazonSocial.Text == "")
            {
                MessageBox.Show("Ingresar razón social", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtRazonSocial.Focus();
                return;
            }
            if (TxtDireccion.Text == "")
            {
                MessageBox.Show("Ingresar dirección", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtDireccion.Focus();
                return;
            }
            if (TxtTelefono.Text == "")
            {
                MessageBox.Show("Ingresar teléfono", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtTelefono.Focus();
                return;
            }
            if (TxtConsecutivoRecibo.Text == "")
            {
                MessageBox.Show("Ingresar consecutivo recibo", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtConsecutivoRecibo.Focus();
                return;
            }
            if (TxtConsecutivoRecibo.Text == "")
            {
                MessageBox.Show("Ingresar consecutivo recibo", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtConsecutivoRecibo.Focus();
                return;
            }
            if (!Regex.IsMatch(TxtConsecutivoRecibo.Text.Trim(), @"0{5,}", RegexOptions.None))
            {
                MessageBox.Show("Número consecutivo no valido\nEjemplo: 0000012345", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtConsecutivoRecibo.Focus();
                return;
            }
            if (TxtHorario.Text == "")
            {
                MessageBox.Show("Ingresar horario", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtHorario.Focus();
                return;
            }
            if (TxtResponsable.Text == "")
            {
                MessageBox.Show("Ingresar responsable", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtResponsable.Focus();
                return;
            }
            if (TxtNit.Text == "")
            {
                MessageBox.Show("Ingresar NIT", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtNit.Focus();
                return;
            }
            if (TxtIVA.Text == "")
            {
                MessageBox.Show("Ingresar IVA", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtIVA.Focus();
                return;
            }
            if (CmbRegimen.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccionar regimen", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbRegimen.Focus();
                return;
            }
            if (TxtNumeroResolucion.Text == "")
            {
                MessageBox.Show("Ingresar número resolución", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtNumeroResolucion.Focus();
                return;
            }
            if (DtpFecha.Text == "")
            {
                MessageBox.Show("Seleccionar fecha", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                DtpFecha.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                ConfiguracionController configuracion = new ConfiguracionController();

                if (await configuracion.AgregarInformacionEmpresa(TxtRazonSocial.Text.Trim(), TxtDireccion.Text.Trim(), TxtTelefono.Text.Trim(), TxtConsecutivoRecibo.Text.Trim(), TxtHorario.Text.Trim(), TxtResponsable.Text.Trim(), TxtNit.Text.Trim() + "-" + TxtDV.Text.Trim(), CmbRegimen.Text.Trim(), TxtIVA.Text.Trim(), TxtNumeroResolucion.Text.Trim(), DtpFecha.Text.Replace("-", "/").Trim(), CmbRegimen.Text == "Simplificado" ? "Recibo" : "Factura", Regex.Match(TxtConsecutivoRecibo.Text.Trim(), @"^0*").Length.ToString(), (Regex.Match(TxtConsecutivoRecibo.Text.Trim(), @"^0*(.*)").Groups[1].Value), strTicket, srcImage, MainWindow.IdUsuario))
                {
                    MessageBox.Show("Información empresa agregada correctamente", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                // Cambiar cursor a normal
                Mouse.OverrideCursor = null;
            }
        }
        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            DatosEmpresa();
        }
        /*--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

        public async Task<string> CargarTickets(string strConfiguracionID = "")
        {
            // Cargar las impresoras instaladas primero
            ListaImpresoras.Clear();
            string ConfigID = "";
            foreach (string printer in System.Drawing.Printing.PrinterSettings.InstalledPrinters)
            {
                ListaImpresoras.Add(printer);
            }
            ConfiguracionController configuracion = new ConfiguracionController();
            try
            {
                var dt = await configuracion.TicketsAsync();

                if (dt != null) // Si hay resultados
                {
                    if (dt != null && dt.Tables.Count > 0)
                    {
                        var tabla = dt.Tables[0];

                        // IMPORTANTE: Agregar la columna si no viene desde SQL Server
                        if (!tabla.Columns.Contains("ImpresoraSeleccionada"))
                        {
                            tabla.Columns.Add("ImpresoraSeleccionada", typeof(string));
                        }

                        DgTickets.ItemsSource = tabla.DefaultView;
                        DgTickets.CanUserSortColumns = false;
                    }
                    else
                    {
                        dt.Clear();
                        DgTickets.ItemsSource = dt.Tables[0].DefaultView;
                    }
                    if (strConfiguracionID !="")
                    {
                        // Buscamos la fila usando LINQ
                        var filaEncontrada = dt.Tables[0].AsEnumerable()
                            .FirstOrDefault(row => row.Field<string>("Ticket") == strConfiguracionID);
                        // Obtenemos el ConfiguracionID (ajusta el tipo según tu base de datos, ej: int o string)
                        int configuracionId = filaEncontrada.Field<int>("ConfiguracionID");
                        ConfigID = configuracionId.ToString();
                    }
                    CargarConfiguracionGuardada();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return ConfigID;
        }
        private async void BtnEditarTicket_Click(object sender, RoutedEventArgs e)
        {
            // Botón que disparó el evento
            if (sender is Button btn)
            {
                if (btn != null)
                {
                    // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
                    if (btn.DataContext is DataRowView rowView)
                    {
                        if (rowView != null)
                        {
                            // Construye una lista de KeyValuePair con los datos del usuario para pasar a la ventana
                            var listTicket = new List<KeyValuePair<string, string>>
                            {
                                new KeyValuePair<string, string>("@ConfiguracionID", rowView.Row["ConfiguracionID"].ToString()),
                                new KeyValuePair<string, string>("@Valor", rowView.Row["Valor"].ToString()),
                                new KeyValuePair<string, string>("@Ticket", rowView.Row["Ticket"].ToString()),
                                new KeyValuePair<string, string>("@Tipo", rowView.Row["Tipo"].ToString()),
                            };

                            // Crea la ventana de actualización y le pasa esta página como referencia
                            MainTicket mainTicket = new MainTicket(this);

                            if (mainTicket is IFormVerTicket formdata)
                            {
                                formdata.SetData(listTicket);
                            }
                            try
                            {
                                mainTicket.StrTipoTikect = "Editar"; // Indica que es un ticket existente
                                mainTicket.ShowDialog(); // Muestra la ventana de edición de usuario
                            }
                            catch (Exception ex)
                            {
                                // Si ocurre un error al abrir la ventana, muestra un MessageBox con el detalle
                                MessageBox.Show(ex.Message, "Error al enviar información", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                    }
                }
            }
        }
        private async void BtnEliminarTicket_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!(sender is Button boton)) return;

                // Obtener la fila seleccionada
                if (boton.DataContext is DataRowView filaSeleccionada)
                {
                    if (filaSeleccionada != null)
                    {
                        //Pregunta antes de proceder a eliminar usuario
                        MessageBoxResult messageBoxResult = MessageBox.Show($"¿Eliminar ticket: '{filaSeleccionada.Row["Ticket"]}' Tipo: {filaSeleccionada.Row["Tipo"]}?\nNota: si el ticket se elimina tendrá que volverlo a crear.\n¿Desea continuar?", "Eliminar Ticket", MessageBoxButton.YesNo, MessageBoxImage.Question);
                        if (messageBoxResult == MessageBoxResult.Yes)
                        {
                            ConfiguracionController configuracion = new ConfiguracionController();
                            //Procede a eliminar usuario seleccionado
                            if (await configuracion.DeleteTicketAsync(filaSeleccionada.Row["ConfiguracionID"].ToString(), ("Ticket: " + filaSeleccionada.Row["Ticket"].ToString() + " Tipo:" + filaSeleccionada.Row["Tipo"].ToString()), MainWindow.IdUsuario))
                            {
                                // Leer los datos actuales guardados en las propiedades del proyecto
                                string jsonActual = Properties.Settings.Default.Impresoras;
                                List<string> listaBloques = new List<string>();

                                // Analizar el JSON actual mediante búsqueda de llaves {}
                                if (!string.IsNullOrWhiteSpace(jsonActual))
                                {
                                    int index = 0;
                                    while ((index = jsonActual.IndexOf("{", index)) != -1)
                                    {
                                        int endIndex = jsonActual.IndexOf("}", index);
                                        if (endIndex == -1) break;

                                        string objStr = jsonActual.Substring(index, (endIndex - index) + 1).Trim();

                                        // EXCLUIR el ticket que queremos borrar, conservando todos los demás
                                        if (!objStr.Contains($"\"Ticket\": \"{filaSeleccionada["Ticket"]}\""))
                                        {
                                            listaBloques.Add("  " + objStr);
                                        }

                                        index = endIndex + 1;
                                    }
                                }

                                // Consolidar el string JSON final con los elementos restantes
                                string jsonFinal = listaBloques.Count > 0 ? "[\n" + string.Join(",\n", listaBloques) + "\n]" : "[]";

                                // Guardar en las propiedades de la aplicación
                                Properties.Settings.Default.Impresoras = jsonFinal;
                                Properties.Settings.Default.Save();

                                // Opcional: Limpiar la selección en el DataGrid visualmente
                                filaSeleccionada["ImpresoraSeleccionada"] = DBNull.Value; // o el valor por defecto que uses
                                await CargarTickets();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar Impresora: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private async void BtnSeleccionarImpresora_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Library library = new Library();
                if (!(sender is Button boton)) return;
                if (boton == null) return;
                DependencyObject parent = VisualTreeHelper.GetParent(boton);
                while (parent != null && !(parent is DataGridRow))
                {
                    parent = VisualTreeHelper.GetParent(parent);
                }

                // Obtenemos la fila
                if (!(parent is DataGridRow fila))
                {
                    return;
                }
                // Buscamos el ComboBox dentro de la fila
                ComboBox CbSeleccionarImpresora = library.FindChild<ComboBox>(fila, "CbSeleccionarImpresora");
                if (CbSeleccionarImpresora.SelectedIndex == -1)
                {
                    MessageBox.Show("Seleccionar impresora", "Seleccionar Impresora", MessageBoxButton.OK, MessageBoxImage.Information);
                    CbSeleccionarImpresora.Focus();
                    return;
                }
                else
                {
                    // 1. Obtener la fila seleccionada
                    if (boton.DataContext is DataRowView filaSeleccionada)
                    {
                        if (filaSeleccionada != null)
                        {
                            string ticket = filaSeleccionada["Ticket"].ToString();
                            string tipo = filaSeleccionada["Tipo"].ToString();

                            string impresoraSeleccionada = "";

                            impresoraSeleccionada = CbSeleccionarImpresora.Text;

                            // 3. Validar que se haya seleccionado una impresora válida
                            if (string.IsNullOrWhiteSpace(impresoraSeleccionada) || impresoraSeleccionada == "Seleccionar Impresora")
                            {
                                MessageBox.Show("Por favor, selecciona una impresora válida antes de guardar.", "Advertencia", MessageBoxButton.OK, MessageBoxImage.Warning);
                                return;
                            }

                            // 4. Crear el bloque JSON para este ticket específico
                            string nuevoBloque = $"  {{\"Ticket\": \"{ticket}\", \"Tipo\": \"{tipo}\", \"Impresora\": \"{impresoraSeleccionada}\"}}";

                            // 5. Leer los datos actuales guardados en las propiedades del proyecto
                            string jsonActual = Properties.Settings.Default.Impresoras;
                            List<string> listaBloques = new List<string>();

                            // 6. Análisis robusto de objetos existentes mediante búsqueda de llaves {}
                            if (!string.IsNullOrWhiteSpace(jsonActual))
                            {
                                int index = 0;
                                while ((index = jsonActual.IndexOf("{", index)) != -1)
                                {
                                    int endIndex = jsonActual.IndexOf("}", index);
                                    if (endIndex == -1) break;

                                    string objStr = jsonActual.Substring(index, (endIndex - index) + 1).Trim();

                                    // Conservar todos los tickets anteriores EXCEPTO el que estamos actualizando ahora
                                    if (!objStr.Contains($"\"Ticket\": \"{ticket}\""))
                                    {
                                        listaBloques.Add("  " + objStr);
                                    }

                                    index = endIndex + 1;
                                }
                            }

                            // 7. Añadir el nuevo ticket (o la versión actualizada) a la lista
                            listaBloques.Add(nuevoBloque);

                            // 8. Consolidar el string JSON final con formato de arreglo
                            string jsonFinal = "[\n" + string.Join(",\n", listaBloques) + "\n]";

                            // 9. Guardar en las propiedades de la aplicación de forma persistente
                            Properties.Settings.Default.Impresoras = jsonFinal;
                            Properties.Settings.Default.Save();

                            MessageBox.Show($"¡Impresora {impresoraSeleccionada} para el ticket '{ticket}' fue seleccionada correctamente!", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar en la configuración: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void CargarConfiguracionGuardada()
        {
            try
            {
                // 1. Obtenemos el string JSON almacenado en las propiedades
                string jsonGuardado = Properties.Settings.Default.Impresoras;

                if (string.IsNullOrWhiteSpace(jsonGuardado))
                    return; // Si está vacío, no hay nada que cargar

                int index = 0;
                // 2. Recorremos todas las llaves '{' y '}' para extraer cada objeto individualmente
                while ((index = jsonGuardado.IndexOf("{", index)) != -1)
                {
                    int endIndex = jsonGuardado.IndexOf("}", index);
                    if (endIndex == -1) break;

                    // Extraemos el bloque completo de un ticket (ej: {"Ticket": "tiempo", ...})
                    string objStr = jsonGuardado.Substring(index, (endIndex - index) + 1).Trim();

                    // 3. Extraemos los valores de los campos
                    string ticket = ExtraerValorJson(objStr, "Ticket");
                    string impresora = ExtraerValorJson(objStr, "Impresora");

                    // 4. Si encontramos el ticket, actualizamos su ComboBox correspondiente en el DataGrid
                    if (!string.IsNullOrEmpty(ticket))
                    {
                        ActualizarFilaEnInterfaz(ticket, impresora);
                    }

                    index = endIndex + 1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al leer la configuración guardada: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Método auxiliar para extraer el valor de una clave dentro del string JSON
        private string ExtraerValorJson(string json, string clave)
        {
            try
            {
                string patron = $"\"{clave}\": \"";
                int inicio = json.IndexOf(patron);
                if (inicio == -1) return "";
                inicio += patron.Length;
                int fin = json.IndexOf("\"", inicio);
                if (fin == -1) return "";
                return json.Substring(inicio, fin - inicio);
            }
            catch
            {
                return "";
            }
        }

        // Método para buscar el ticket en el DataGrid y mostrar la impresora seleccionada en su ComboBox
        private void ActualizarFilaEnInterfaz(string nombreTicket, string impresoraGuardada)
        {
            foreach (var item in DgTickets.Items)
            {
                if (item is DataRowView fila)
                {
                    string ticketFila = fila["Ticket"].ToString();

                    if (ticketFila == nombreTicket)
                    {
                        fila["ImpresoraSeleccionada"] = impresoraGuardada;
                        break;
                    }
                }
            }
        }
        public interface IFormVerTicket
        {
            void SetData(List<KeyValuePair<string, string>> dataUsuario);
        }

        private void BtnNuevoTicket_Click(object sender, RoutedEventArgs e)
        {
            // Crea la ventana de actualización y le pasa esta página como referencia
            MainTicket mainTicket = new MainTicket(this);
            {
                mainTicket.StrTipoTikect = "Nuevo"; // Indica que es un nuevo ticket
            }
            mainTicket.ShowDialog(); // Muestra la ventana de edición de usuario
        }

        private void BtnVistaPrevia_Click(object sender, RoutedEventArgs e)
        {
            // Botón que disparó el evento
            if (sender is Button btn)
            {
                if (btn != null)
                {
                    // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
                    if (btn.DataContext is DataRowView rowView)
                    {
                        if (rowView != null)
                        {
                            // Crea la ventana de actualización y le pasa esta página como referencia
                            VistaPreviaTicket vistaPreviaTicket = new VistaPreviaTicket {
                                IdTicket = rowView.Row["ConfiguracionID"].ToString(),
                                Tipo = rowView.Row["Tipo"].ToString()
                            };
                            vistaPreviaTicket.ShowDialog();
                        }
                    }
                }
            }
        }
        private async void TxtBuscarUsuario_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtBuscarUsuario.Text.Trim() != string.Empty)
            {
                // Si hay texto, filtra por ese texto y actualiza strBusquedad
                CargarUsuarios(TxtBuscarUsuario.Text.Trim().Replace("'", "").Replace("\"", ""), 1, 30);
            }
            else
            {
                // Si el cuadro de búsqueda está vacío, restaura sin filtro
                CargarUsuarios("", 1, 30);
            }
        }
        public async void CargarUsuarios(string strUsuario, int pageNumber, int pageSize)
        {
            UsuariosController usuariosController = new UsuariosController();
            try
            {
                var dt = await usuariosController.ObtenerUsuariosAsync(strUsuario, pageNumber, pageSize);

                if (dt != null) // Si hay resultados
                {
                    // Supongamos que 'miDataSet' es tu DataSet y 'miTabla' es el nombre de la tabla
                    DataTable DtUsuarios = dt.Tables[0];

                    // Crear una columna calculada que concatene ambas columnas
                    DataColumn columnaConcatenada = new DataColumn("UsuarioCompleto", typeof(string), "'Usuario: ' + Usuario + ' Nombres: ' + NombreCompleto");
                    DtUsuarios.Columns.Add(columnaConcatenada);

                    int maxRowsToShow = 30; // Número máximo de filas a mostrar en pantalla

                    // Verifica si la tabla 0 (registros) tiene filas
                    if (DtUsuarios.Rows.Count > 0)
                    {
                        var rowsToShow = DtUsuarios
                                           .AsEnumerable()
                                           .Take(maxRowsToShow)
                                           .CopyToDataTable();

                        // Asigna la fuente de datos del DataGrid a la vista por defecto del DataTable
                        DgUsuarios.ItemsSource = rowsToShow.DefaultView;
                        // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                        DgUsuarios.CanUserSortColumns = false;
                    }
                    else
                    {
                        dt.Clear();
                        DgUsuarios.ItemsSource = dt.Tables[0].DefaultView;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public string ConvertirJsonAuditoria(string jsonPermisos)
        {
            StringBuilder sbAuditoria = new StringBuilder();
            sbAuditoria.AppendLine("Actualización de permisos registrada:");

            // Buscar cada bloque de objeto dentro del arreglo JSON { ... }
            MatchCollection matchesModulos = Regex.Matches(jsonPermisos, @"\{([^}]+)\}");

            foreach (Match matchModulo in matchesModulos)
            {
                string contenidoModulo = matchModulo.Groups[1].Value;

                // Extraer las propiedades clave-valor del objeto
                MatchCollection pares = Regex.Matches(contenidoModulo, @"""([^""]+)""\s*:\s*([^,]+)");

                string nombreModulo = "Desconocido";
                StringBuilder sbPermisos = new StringBuilder();

                foreach (Match par in pares)
                {
                    string clave = par.Groups[1].Value;
                    string valor = par.Groups[2].Value.Trim().ToLower();

                    // Si la clave es "modulo", guardamos su nombre; de lo contrario, es un permiso
                    if (clave.Equals("modulo", StringComparison.OrdinalIgnoreCase))
                    {
                        nombreModulo = valor.Trim('"');
                    }
                    else
                    {
                        bool estado = valor == "true";
                        string estadoTexto = estado ? "Permitido" : "Denegado";
                        sbPermisos.AppendLine($"  * {clave}: {estadoTexto}");
                    }
                }

                // Construir la estructura final para la auditoría de este módulo
                sbAuditoria.AppendLine($"- Módulo [{nombreModulo}]:");
                sbAuditoria.Append(sbPermisos.ToString());
            }

            return sbAuditoria.ToString();
        }
        public void CargarPermisosDesdeJson(TabControl tabControl, string jsonPermisos)
        {
            // 0. PASO CLAVE: Blanquear/Resetear TODOS los CheckBox a false antes de cargar
            foreach (var item in tabControl.Items)
            {
                if (item is TabItem tabItem && tabItem.Content is Panel panelContenedor)
                {
                    foreach (var child in panelContenedor.Children)
                    {
                        if (child is CheckBox chk)
                        {
                            chk.IsChecked = false; // Limpia el estado anterior
                        }
                    }
                }
            }

            if (string.IsNullOrEmpty(jsonPermisos)) return;

            // 1. Extraer cada bloque de objeto ({ ... }) dentro del arreglo JSON
            MatchCollection matchesModulos = Regex.Matches(jsonPermisos, @"\{([^}]+)\}");

            foreach (Match matchModulo in matchesModulos)
            {
                string contenidoModulo = matchModulo.Groups[1].Value;

                // Extraer las propiedades clave-valor del JSON
                MatchCollection pares = Regex.Matches(contenidoModulo, @"""([^""]+)""\s*:\s*([^,]+)");

                string nombreModuloJson = "";
                Dictionary<string, bool> permisosJson = new Dictionary<string, bool>();

                foreach (Match par in pares)
                {
                    string clave = par.Groups[1].Value;
                    string valor = par.Groups[2].Value.Trim().ToLower();

                    if (clave.Equals("modulo", StringComparison.OrdinalIgnoreCase))
                    {
                        nombreModuloJson = valor.Trim('"');
                    }
                    else
                    {
                        bool estado = valor == "true";
                        permisosJson[clave] = estado;
                    }
                }

                // 2. Buscar la pestaña (TabItem) que coincida con el nombre del módulo
                foreach (var item in tabControl.Items)
                {
                    if (item is TabItem tabItem)
                    {
                        string nombreModuloTab = ObtenerNombreModulo(tabItem);

                        if (string.Equals(nombreModuloTab, nombreModuloJson, StringComparison.OrdinalIgnoreCase))
                        {
                            // 3. Recorrer los CheckBox y aplicar el estado del JSON actual
                            if (tabItem.Content is Panel panelContenedor)
                            {
                                foreach (var child in panelContenedor.Children)
                                {
                                    if (child is CheckBox chk)
                                    {
                                        string textoChk = chk.Content?.ToString() ?? "";
                                        if (permisosJson.ContainsKey(textoChk))
                                        {
                                            chk.IsChecked = permisosJson[textoChk];
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Método auxiliar para extraer el texto del Header de forma segura
        private string ObtenerNombreModulo(TabItem tabItem)
        {
            if (tabItem.Header is StackPanel spHeader)
            {
                foreach (var child in spHeader.Children)
                {
                    if (child is TextBlock tb) return tb.Text;
                }
            }
            else if (tabItem.Header is TextBlock tbHeader)
            {
                return tbHeader.Text;
            }
            else if (tabItem.Header != null)
            {
                return tabItem.Header.ToString();
            }
            return "";
        }
        private async void BtnGuardarPermisos_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("["); // Iniciamos un arreglo JSON para soportar múltiples módulos

            bool primerModulo = true;

            // Recorrer cada pestaña (TabItem) del TabControl llamado TcPermisos
            foreach (var item in TcPermisos.Items)
            {
                if (item is TabItem tabItem)
                {
                    // Extraer el nombre del módulo de forma segura desde el Header (soporta StackPanel y TextBlock)
                    string nombreModulo = "Desconocido";
                    if (tabItem.Header is StackPanel spHeader)
                    {
                        foreach (var child in spHeader.Children)
                        {
                            if (child is TextBlock tb)
                            {
                                nombreModulo = tb.Text;
                                break;
                            }
                        }
                    }
                    else if (tabItem.Header is TextBlock tbHeader)
                    {
                        nombreModulo = tbHeader.Text;
                    }
                    else if (tabItem.Header != null)
                    {
                        nombreModulo = tabItem.Header.ToString();
                    }

                    // Si no es el primer módulo, agregamos una coma para separar los objetos en el JSON
                    if (!primerModulo)
                    {
                        sb.Append(",");
                    }
                    primerModulo = false;

                    sb.Append("{");
                    sb.AppendFormat("\"modulo\": \"{0}\"", nombreModulo);

                    // Recorrer los CheckBox dentro del StackPanel principal de la pestaña
                    if (tabItem.Content is Panel panelContenedor)
                    {
                        foreach (var child in panelContenedor.Children)
                        {
                            if (child is CheckBox chk)
                            {
                                string nombrePermiso = chk.Content?.ToString() ?? "permiso";
                                bool estaMarcado = chk.IsChecked ?? false;

                                sb.Append(",");
                                // Agrega cada CheckBox como una propiedad booleana (true/false)
                                sb.AppendFormat("\"{0}\": {1}", nombrePermiso, estaMarcado.ToString().ToLower());
                            }
                        }
                    }

                    sb.Append("}");
                }
            }

            sb.Append("]");
            string jsonResultado = sb.ToString();

            // Validaciones de campos obligatorios y formato de email
            if (TxtUsuario.Text == string.Empty)
            {
                MessageBox.Show("Seleccionar usuario", "Permisos Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtUsuario.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de actualuzar usuario
                UsuariosController usuariosController = new UsuariosController();
                //Actualizar usuario
                if (await usuariosController.UpdatePermisosAsync(IdUsuario, TxtUsuario.Text, jsonResultado, ConvertirJsonAuditoria(jsonResultado), MainWindow.IdUsuario)){
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show($"{TxtUsuario.Text.Trim().ToLower()} se le asignaron los persimos:\n{ConvertirJsonAuditoria(jsonResultado)}", "Permisos de Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }
        //Selecciona todos los checkbos dentro del TabControl
        private void MarcarCheckboxesRecursivo(DependencyObject parent, bool checkEstado ,bool estadoEnable)
        {
            foreach (var child in LogicalTreeHelper.GetChildren(parent))
            {
                if (child is CheckBox checkBox)
                {
                    // Opcional: Verifica si está habilitado antes de marcarlo
                    if (checkBox.IsEnabled || !checkBox.IsEnabled)
                    {
                        checkBox.IsChecked = checkEstado;
                        checkBox.IsEnabled = estadoEnable;
                    }
                }
                else if (child is DependencyObject dependencyObject)
                {
                    // Continuar buscando recursivamente en contenedores (StackPanel, TabItem, etc.)
                    MarcarCheckboxesRecursivo(dependencyObject, checkEstado, estadoEnable);
                }
            }
        }
        private void DgUsuarios_CurrentCellChanged(object sender, EventArgs e)
        {
            if (DgUsuarios.CurrentCell.IsValid)
            {
                var cellInfo = DgUsuarios.CurrentCell;

                // Si el origen es un DataTable/DataSet, cada elemento es un DataRowView
                if (cellInfo.Item is DataRowView rowView)
                {
                    // Extraer directamente cualquier columna de la fila seleccionada
                    IdUsuario = rowView["UsuarioID"].ToString();
                    string Permisos = rowView["Permisos"].ToString();
                    object NombreCompleto = rowView["UsuarioCompleto"];
                    TxtUsuario.Text = NombreCompleto.ToString();
                    //usuario por defecto se selecciona todos los "PERMISOS"
                    if (IdUsuario == "19")
                    {
                        MarcarCheckboxesRecursivo(TcPermisos, true, false);
                    }
                    else
                    {
                        MarcarCheckboxesRecursivo(TcPermisos, false, true);
                        // Llamas a la función para que pinte los CheckBox automáticamente
                        CargarPermisosDesdeJson(TcPermisos, Permisos);
                    }
                    // Ejemplo de uso
                    //MessageBox.Show($"UsuarioID: {usuarioId} \nNombreCompleto: {nombreCompleto}", "Fila Seleccionada");
                }
            }
        }

        private void ChkVerCelda_Click(object sender, RoutedEventArgs e)
        {
            if(ChkVerCelda.IsChecked == false)
            {
                ChkAgregarCelda.IsChecked = false;
                ChkAgregarCelda.IsEnabled = false;
                ChkCambiarEstadoCelda.IsChecked = false;
                ChkCambiarEstadoCelda.IsEnabled = false;
                Color Color = (Color)ColorConverter.ConvertFromString("#C2C2C2");
                ChkAgregarCelda.Foreground = new SolidColorBrush(Color);
                ChkCambiarEstadoCelda.Foreground = new SolidColorBrush(Color);
            }
        }

        private void ChkVerCelda_Checked(object sender, RoutedEventArgs e)
        {
            ChkAgregarCelda.IsEnabled = true;
            ChkCambiarEstadoCelda.IsEnabled = true;
            Color Color = (Color)ColorConverter.ConvertFromString("#2A4379");
            ChkAgregarCelda.Foreground = new SolidColorBrush(Color);
            ChkCambiarEstadoCelda.Foreground = new SolidColorBrush(Color);
        }

        private void ChkVerAuditoria_Click(object sender, RoutedEventArgs e)
        {
            if (ChkVerAuditoria.IsChecked == true)
            {
                ChkEliminarAuditoria.IsEnabled = true;
                Color Color = (Color)ColorConverter.ConvertFromString("#2A4379");
                ChkEliminarAuditoria.Foreground = new SolidColorBrush(Color);
            }
            else
            {
                ChkEliminarAuditoria.IsChecked = false;
                ChkEliminarAuditoria.IsEnabled = false;
                Color Color = (Color)ColorConverter.ConvertFromString("#C2C2C2");
                ChkEliminarAuditoria.Foreground = new SolidColorBrush(Color);
            }
        }

        private void ChkVerAuditoria_Checked(object sender, RoutedEventArgs e)
        {
            if (ChkVerAuditoria.IsChecked == true)
            {
                ChkEliminarAuditoria.IsEnabled = true;
                Color Color = (Color)ColorConverter.ConvertFromString("#2A4379");
                ChkEliminarAuditoria.Foreground = new SolidColorBrush(Color);
            }
        }

        private void StackPanelAcciones_Loaded(object sender, RoutedEventArgs e)
        {
            // Coincidencia de patrones para asegurar que el sender es un StackPanel
            if (sender is StackPanel panel)
            {
                Permisos permisos = new Permisos();
                // 1. Consultar permisos específicos del módulo Tickets
                
                bool puedeEditar = permisos.TienePermiso("Configuración", "Editar Ticket");
                bool puedeVistaPrevia = permisos.TienePermiso("Configuración", "Vista Previa");
                bool puedeEliminar = permisos.TienePermiso("Configuración", "Eliminar Ticket");
                bool puedeImpresora = permisos.TienePermiso("Configuración", "Seleccionar Impresora");

                // 2. Controlar visibilidad de botones usando pattern matching (is Button ...)
                if (panel.FindName("BtnEditarTicket") is Button btnEditar)
                    btnEditar.Visibility = puedeEditar ? Visibility.Visible : Visibility.Collapsed;

                if (panel.FindName("BtnVistaPrevia") is Button btnVista)
                    btnVista.Visibility = puedeVistaPrevia ? Visibility.Visible : Visibility.Collapsed;

                if (panel.FindName("BtnEliminarTicket") is Button btnEliminar)
                    btnEliminar.Visibility = puedeEliminar ? Visibility.Visible : Visibility.Collapsed;

                if (panel.FindName("BtnSeleccionarImpresora") is Button btnImpresora)
                    btnImpresora.Visibility = puedeImpresora ? Visibility.Visible : Visibility.Collapsed;

                // 3. Controlar rectángulos divisores para evitar líneas huérfanas mediante patrones (is Rectangle ...)
                if (panel.FindName("Rc1") is System.Windows.Shapes.Rectangle rc1)
                    rc1.Visibility = (puedeEditar && puedeVistaPrevia) ? Visibility.Visible : Visibility.Collapsed;

                if (panel.FindName("Rc2") is System.Windows.Shapes.Rectangle rc2)
                    rc2.Visibility = ((puedeEditar || puedeVistaPrevia) && puedeEliminar) ? Visibility.Visible : Visibility.Collapsed;

                if (panel.FindName("Rc3") is System.Windows.Shapes.Rectangle rc3)
                    rc3.Visibility = ((puedeEditar || puedeVistaPrevia || puedeEliminar) && puedeImpresora) ? Visibility.Visible : Visibility.Collapsed;
            }
        }
        private void CbSeleccionarImpresora_Loaded(object sender, RoutedEventArgs e)
        {
            // Coincidencia de patrones para verificar y castear de forma segura
            if (sender is ComboBox cb)
            {
                Permisos permisos = new Permisos();
                // Consultar el permiso correspondiente
                bool puedeSeleccionar = permisos.TienePermiso("Configuración", "Seleccionar Impresora");

                // Habilitar o deshabilitar según el permiso
                cb.IsEnabled = puedeSeleccionar;
            }
        }
    }
}