﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para AgregarCliente.xaml
    /// </summary>
    public partial class AgregarCliente : Window
    {
        public AgregarCliente(Clientes _clientes)
        {
            InitializeComponent();
            this._clientes = _clientes;
        }
        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            await SeleccionarTipoDocumento(); // Carga los tipos de documento al cargar la ventana
        }
        private readonly Clientes _clientes;
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void PreviewTextInputTextLetters(object sender, TextCompositionEventArgs e)
        {
            // Crea una instancia de la biblioteca de utilidades
            Library library = new Library();
            // Llama al método que permite solo letras
            library.Letters(sender, e);
        }
        private void Txt_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Si la tecla presionada es el espacio, cancelamos el evento
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }
        private void PreviewTextInputNumbers(object sender, TextCompositionEventArgs e)
        {
            Library library = new Library();
            library.Numbers(sender, e); // Restringe la entrada a dígitos
        }
        private void TxtCelular_TextChanged(object sender, TextChangedEventArgs e)
        {
            Library library = new Library();
            string formattedPhoneNumber = library.FormatCelularNumber(TxtCelular.Text);
            // Llama al método que formatea el número de celular
            TxtCelular.Text = formattedPhoneNumber;     // Asigna el texto formateado
            TxtCelular.CaretIndex = TxtCelular.Text.Length;
            // Mueve el cursor al final del texto
        }
        public async Task SeleccionarTipoDocumento()// se cargan tipo de documento
        {
            TipoDocumento tipoDocumento = new TipoDocumento();

            var dt = await tipoDocumento.SelectTipoDocumentoAsync();
            if (dt != null) // Si hay resultados
            {
                CmbTipoDocumento.ItemsSource = dt.DefaultView;
                CmbTipoDocumento.DisplayMemberPath = "Tipo"; // Muestra el nombre de la jornada
                CmbTipoDocumento.SelectedValuePath = "Documentoid"; // El valor seleccionado será el ID
            }
        }
        private void RestablecerCampos()
        {
            TxtNombres.Text = string.Empty;
            CmbTipoDocumento.SelectedIndex = -1;
            CmbTipoDocumento.Text = "Seleccione tipo documento";
            TxtDocumento.Text = string.Empty;
            TxtCelular.Text = string.Empty;
            TxtCorreo.Text = string.Empty;
            BtnGuardar.IsEnabled = true;
            BtnCancelar.IsEnabled = true;
        }
        private async void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            Library library = new Library();
            // Validaciones de campos obligatorios y formato de email
            if (TxtNombres.Text == string.Empty)
            {
                MessageBox.Show("Ingresar nombres", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtNombres.Focus();
                return;
            }
            else if (CmbTipoDocumento.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccionar tipo documento", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbTipoDocumento.Focus();
                return;
            }
            else if (TxtDocumento.Text == string.Empty)
            {
                MessageBox.Show("Ingresar Número Documento", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtDocumento.Focus();
                return;
            }
            else if (!library.ValidNumberCel(TxtCelular.Text.Trim()) && TxtCelular.Text != "")
            {
                MessageBox.Show("Número de celular no válido", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Error);
                TxtCelular.Focus();
                return;
            }
            else if (!library.IsValidEmail(TxtCorreo.Text.Trim()) && TxtCorreo.Text != "")
            {
                MessageBox.Show("Correo no valido", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Error);
                TxtCorreo.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar usuario
                Clientes_ clientes = new Clientes_();
                //Igresar nuevo usuario
                if (await clientes.NuevoCliente(CmbTipoDocumento.SelectedValue.ToString(), TxtNombres.Text.Trim(), CmbTipoDocumento.Text, TxtDocumento.Text.Trim(), TxtCelular.Text.Trim(), TxtCorreo.Text.Trim(), MainWindow.IdUsuario))
                {
                    //Muestra un mensaje de confirmaciín de guardado del cliente nuevo
                    MessageBox.Show($"Cliente '{TxtNombres.Text.Trim().ToLower()}' se guardo correctamente", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Information);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                    // actualiza el datagrid
                    _clientes.CargarClientes(_clientes.TxtBuscarCliente.Text.Trim(), _clientes.currentPage, _clientes.pageSize);
                    this.Close();
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            RestablecerCampos();
        }
    }
}