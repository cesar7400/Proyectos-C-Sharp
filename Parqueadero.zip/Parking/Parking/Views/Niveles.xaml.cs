﻿using Parking.Controller;
using Parking.Models;
using Parking.ViewModels;
using System;
using System.Data;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para Niveles.xaml
    /// </summary>
    public partial class Niveles : Page
    {
        public Niveles()
        {
            InitializeComponent();
            // Enlazar el DataContext de la ventana con esta instancia
            this.DataContext = dashboardViewModel;
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Obtiene la ventana que contiene esta página
            var window = Window.GetWindow(this);
            if (window is MainWindow mainWindow)
            {
                // Limpia el contenido del contenedor principal (fContainer)
                mainWindow.ContenedorPrincipal.Content = null;
            }
        }
        // Declaras o instancias tu ViewModel a nivel de la clase de la Ventana
        public DashboardViewModel dashboardViewModel = new DashboardViewModel();
        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            await ListaNiveles();
            // Configurar el Temporizador para refrescar automáticamente cada 5 segundos
            var timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };

            // Se quita el 'await' de aquí
            timer.Tick += async (s, args) => await ListaNivelesDashBoard();
            timer.Start();
        }
        public async Task ListaNivelesDashBoard()
        {
            Nivel nivel = new Nivel();
            try
            {
                var dt = await nivel.NivelesAsync();
                if (dt != null) // Si hay resultados
                {
                    // Al llamar a este método sobre la misma instancia, los textos se actualizarán automáticamente en el XAML
                    dashboardViewModel.NivelEstado(dt.Tables[0]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public async Task ListaNiveles()
        {
            Permisos permisos = new Permisos();
            Nivel nivel = new Nivel();
            try
            {
                var dt = await nivel.NivelesAsync();

                // Consultar permisos
                bool puedeEditar = permisos.TienePermiso("Niveles", "Editar Nivel");
                bool puedeEliminar = permisos.TienePermiso("Niveles", "Eliminar Nivel");
                bool verCeldas = permisos.TienePermiso("Niveles", "Ver Celdas");
                bool puedeCambiarEstado = permisos.TienePermiso("Niveles", "Activar - Desactivar Nivel");
                bool puedeCrear = permisos.TienePermiso("Niveles", "Agregar Nivel");

                // Si TODOS los permisos están en false, ocultamos toda la columna Acciones
                if (!puedeEditar && !puedeEliminar && !verCeldas && !puedeCambiarEstado && !puedeCrear)
                {
                    ColAcciones.Visibility = Visibility.Collapsed;
                }
                else
                {
                    ColAcciones.Visibility = Visibility.Visible;
                }

                if (dt != null && dt.Tables.Count > 0)
                {
                    DataTable tabla = dt.Tables[0];

                    tabla.Columns.Add("EsNuevaFila", typeof(bool));

                    foreach (DataRow r in tabla.Rows)
                    {
                        r["EsNuevaFila"] = false;
                    }

                    // Solo agregamos la fila de guardado si tiene permiso de crear
                    if (puedeCrear)
                    {
                        DataRow rowEdicion = tabla.NewRow();
                        rowEdicion["EsNuevaFila"] = true;
                        tabla.Rows.Add(rowEdicion);
                    }

                    DgNiveles.ItemsSource = tabla.DefaultView;
                    DgNiveles.CanUserSortColumns = false;
                }
                else
                {
                    DgNiveles.CanUserAddRows = true;
                    DgNiveles.ItemsSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private async void BtnAgregarNivel_Click(object sender, RoutedEventArgs e)
        {
            Library library = new Library();

            // Buscamos la celda que contiene al botón
            if (!(sender is Button btnSender)) return;
            DependencyObject parent = VisualTreeHelper.GetParent(btnSender);
            while (parent != null && !(parent is DataGridRow))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }

            // Obtenemos la fila
            if (!(parent is DataGridRow fila))
            {
                return;
            }

            // Buscamos el TextBox por su nombre dentro de la fila
            // Nota: Necesitas una función auxiliar para buscar en el árbol visual
            TextBox TxtNombre = library.FindChild<TextBox>(fila, "TxtNombre");
            TextBox TxtDescripcion = library.FindChild<TextBox>(fila, "TxtDescripcion");

            if (TxtNombre.Text == string.Empty)
            {
                MessageBox.Show("Ingresar nombre", "Nuevo Nivel", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtNombre.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar nivel
                Nivel nivel = new Nivel();
                //Igresar nuevo usuario
                if (await nivel.NuevoNivel(TxtNombre.Text.Trim(), TxtDescripcion.Text.Trim(), MainWindow.IdUsuario))
                {
                    // actualiza el datagrid
                    await ListaNiveles();
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show($"Nivel '{TxtNombre.Text.Trim()}' se guardo correctamente", "Nuevo Nivel", MessageBoxButton.OK, MessageBoxImage.Information);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    TxtNombre.Focus();
                    TxtNombre.SelectAll();
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }
        private async void BtnEditar_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView rowView)) return;

            string IdNivel = rowView.Row["IdNivel"].ToString();

            string Nombre = rowView.Row["Nivel"].ToString();
            string Descripcion = rowView.Row["Descripcion"].ToString();


            // Buscamos la fila que contiene el botón presionado
            if (!(DgNiveles.ContainerFromElement(btn) is DataGridRow fila))
            {
                return;
            }
            // Ponemos la fila en modo edición oficial de WPF/DataTable
            rowView.BeginEdit();

            await Dispatcher.BeginInvoke(new Action(async () => {

                Library library = new Library();
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;

                if (!(DgNiveles.Columns[0].GetCellContent(fila) is ContentPresenter cpNombre)) return;
                if (!(DgNiveles.Columns[1].GetCellContent(fila) is ContentPresenter cpDescripcion)) return;
                if (!(DgNiveles.Columns[8].GetCellContent(fila) is ContentPresenter cpBotones)) return;

                TextBox TxtNombre = library.FindChild<TextBox>(cpNombre, "TxtNombre");
                TextBlock TbNombre = library.FindChild<TextBlock>(cpNombre, "TbNombre");

                TextBox TxtDescripcion = library.FindChild<TextBox>(cpDescripcion, "TxtDescripcion");
                TextBlock TbDescripcion = library.FindChild<TextBlock>(cpDescripcion, "TbDescripcion");

                if (!(cpBotones.ContentTemplate.FindName("BtnEditar", cpBotones) is Button BtnEditar)) return;
                if (!(cpBotones.ContentTemplate.FindName("BtnEliminar", cpBotones) is Button BtnEliminar)) return;
                if (!(cpBotones.ContentTemplate.FindName("BtnCancelarNivel", cpBotones) is Button BtnCancelarNivel)) return;
                if (!(cpBotones.ContentTemplate.FindName("BtnVerCeldas", cpBotones) is Button BtnVerCeldas)) return;
                if (!(cpBotones.ContentTemplate.FindName("BtnEstadoNivel", cpBotones) is Button BtnEstadoNivel)) return;
                if (!(cpBotones.ContentTemplate.FindName("RcVerceldas", cpBotones) is Rectangle RcVerceldas)) return;
                if (!(cpBotones.ContentTemplate.FindName("RcEstadoNivel", cpBotones) is Rectangle RcEstadoNivel)) return;

                Image ImgEditar = null;

                if (cpBotones.ContentTemplate.FindName("ImgEditar", cpBotones) is Image img) ImgEditar = img;

                if (BtnEditar.ToolTip.ToString() == "Editar")
                {
                    // Cambiamos el Tag a "Editando". 
                    // Esto dispara los Triggers de las dos columnas al mismo tiempo.
                    fila.Tag = "Editando";

                    if (TxtNombre != null)
                    {
                        TxtNombre.IsReadOnly = false;
                        TxtNombre.Focus();
                        TxtNombre.SelectAll();
                    }
                    BtnEditar.ToolTip = "Guardar Cambios";
                    BtnEliminar.Visibility = Visibility.Collapsed;
                    BtnCancelarNivel.Visibility = Visibility.Visible;
                    BtnVerCeldas.Visibility = Visibility.Collapsed;
                    BtnEstadoNivel.Visibility = Visibility.Collapsed;
                    RcVerceldas.Visibility = Visibility.Collapsed;
                    RcEstadoNivel.Visibility = Visibility.Collapsed;
                    // Cambiar cursor a modo normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    // Validaciones de campos obligatorios y formato de email
                    if (TxtNombre.Text == string.Empty)
                    {
                        MessageBox.Show("Ingresar nombre", "Nivel", MessageBoxButton.OK, MessageBoxImage.Information);
                        TxtNombre.Focus();
                        Mouse.OverrideCursor = null;
                        return;
                    }

                    else
                    {
                        // Cambiar cursor a espera
                        Mouse.OverrideCursor = Cursors.Wait;
                        //Inicia el proceso para guardar
                        Nivel nivel = new Nivel();
                        if (await nivel.UpdateNivelAsync(IdNivel, TxtNombre.Text.Trim(), TxtDescripcion.Text.Trim(), MainWindow.IdUsuario))
                        {
                            // actualiza el datagrid
                            await ListaNiveles();
                            //Volvemos al modo lectura (los Triggers ocultan los combos)
                            fila.Tag = "Lectura";
                            // Cambiar cursor a modo normal
                            Mouse.OverrideCursor = null;
                        }
                        else
                        {
                            TxtNombre.Text = TbNombre.Text;
                            TxtDescripcion.Text = TbDescripcion.Text;
                        }
                    }
                    // Cambiar cursor a modo normal
                    Mouse.OverrideCursor = null;
                }

            }), DispatcherPriority.Background);
        }
        private async void BtnCancelarNivel_Click(object sender, RoutedEventArgs e)
        {
            // Buscamos la fila que contiene el botón presionado
            if (!(sender is Button btn)) return;
            if (!(DgNiveles.ContainerFromElement(btn) is DataGridRow fila))
            {
                return;
            }

            if (fila != null)
            {
                Library library = new Library();
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;

                if (!(DgNiveles.Columns[0].GetCellContent(fila) is ContentPresenter cpNombre)) return;
                if (!(DgNiveles.Columns[1].GetCellContent(fila) is ContentPresenter cpDescripcion)) return;
                if (!(DgNiveles.Columns[8].GetCellContent(fila) is ContentPresenter cpBotones)) return;

                TextBox TxtNombre = library.FindChild<TextBox>(cpNombre, "TxtNombre");
                TextBlock TbNombre = library.FindChild<TextBlock>(cpNombre, "TbNombre");

                TextBox TxtDescripcion = library.FindChild<TextBox>(cpDescripcion, "TxtDescripcion");
                TextBlock TbDescripcion = library.FindChild<TextBlock>(cpDescripcion, "TbDescripcion");

                if (!(cpBotones.ContentTemplate.FindName("BtnEditar", cpBotones) is Button BtnEditar)) return;
                if (!(cpBotones.ContentTemplate.FindName("BtnEliminar", cpBotones) is Button BtnEliminar)) return;
                if (!(cpBotones.ContentTemplate.FindName("BtnCancelarNivel", cpBotones) is Button BtnCancelarNivel)) return;
                if (!(cpBotones.ContentTemplate.FindName("BtnVerCeldas", cpBotones) is Button BtnVerCeldas)) return;
                if (!(cpBotones.ContentTemplate.FindName("BtnEstadoNivel", cpBotones) is Button BtnEstadoNivel)) return;
                if (!(cpBotones.ContentTemplate.FindName("RcEstadoNivel", cpBotones) is Rectangle RcEstadoNivel)) return;
                if (!(cpBotones.ContentTemplate.FindName("RcVerceldas", cpBotones) is Rectangle RcVerceldas)) return;
                //Obtener el dato vinculado a la fila (DataRowView)
                if (fila.Item is DataRowView rowView)
                {
                    // Esto revierte los cambios en el DataTable original
                    rowView.CancelEdit();
                }
                TxtNombre.Text = TbNombre.Text;
                TxtDescripcion.Text = TbDescripcion.Text;
                BtnEditar.ToolTip = "Editar";
                BtnEliminar.Visibility = Visibility.Visible;
                BtnCancelarNivel.Visibility = Visibility.Collapsed;
                BtnVerCeldas.Visibility = Visibility.Visible;
                BtnEstadoNivel.Visibility = Visibility.Visible;
                RcEstadoNivel.Visibility = Visibility.Visible;
                RcVerceldas.Visibility = Visibility.Visible;
                await Dispatcher.BeginInvoke(new Action(async () => {

                    // Cambiar cursor a espera
                    Mouse.OverrideCursor = Cursors.Wait;
                    //Volvemos al modo lectura se restablece todo a su estado original
                    fila.Tag = "Lectura";
                    // Cambiar cursor a modo normal
                    Mouse.OverrideCursor = null;
                }), DispatcherPriority.Background);
            }
        }
        private async void BtnEliminar_Click(object sender, RoutedEventArgs e)
        {
            // Cambiar cursor a espera
            Mouse.OverrideCursor = Cursors.Wait;
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView rowView)) return;

            string IdNivel = rowView.Row["IdNivel"].ToString();
            string Nombre = rowView.Row["Nivel"].ToString();

            MessageBoxResult message = MessageBox.Show($"¿Está seguro de eliminar el nivel '{Nombre}'?\nEsta acción no se puede deshacer.", "Confirmar Eliminación", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (message == MessageBoxResult.Yes)
            {
                Nivel nivel = new Nivel();

                if (await nivel.DeleteNivelAsync(IdNivel, Nombre, MainWindow.IdUsuario))
                {
                    // actualiza el datagrid
                    await ListaNiveles();
                }
            }
            // Cambiar cursor a modo normal
            Mouse.OverrideCursor = null;
        }

        private void BtnVerCeldas_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView rowView)) return;

            string IdNivel = rowView.Row["IdNivel"].ToString();
            string Nivel = rowView.Row["Nivel"].ToString();
            string IdEstadoNivel = rowView.Row["IdEstadoNivel"].ToString();

            Celdas celdas = new Celdas(this);
            if (celdas is IFormCeldas formdata)
            {
                formdata.SetData(int.Parse(IdNivel), Nivel, IdEstadoNivel);
            }
            celdas.ShowDialog();
        }

        private async void BtnEstadoNivel_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView rowView)) return;

            string IdNivel = rowView.Row["IdNivel"].ToString();
            string Nivel = rowView.Row["Nivel"].ToString();
            string IdEstadoNivel = rowView.Row["IdEstadoNivel"].ToString();
            
            // Buscamos la fila que contiene el botón presionado
            if (!(DgNiveles.ContainerFromElement(btn) is DataGridRow fila))
            {
                return;
            }
            // Ponemos la fila en modo edición oficial de WPF/DataTable
            rowView.BeginEdit();

            await Dispatcher.BeginInvoke(new Action(async () => {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                Nivel nivel = new Nivel();

                if (await nivel.UpdateEstadoNivelAsync(IdNivel, Nivel, IdEstadoNivel, MainWindow.IdUsuario))
                {
                    await ListaNiveles();
                    MessageBox.Show($"Nivel '{Nivel}' se cambio de estado correctamente", "Cambio Estado Nivel", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show($"Error al cambiar el estado del nivel '{Nivel}'", "Cambio Estado Nivel", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                // Cambiar cursor a modo normal
                Mouse.OverrideCursor = null;

            }), DispatcherPriority.Background);
        }
        public interface IFormCeldas
        {
            void SetData(int IdNivel, string Nivel, string IdEstadoNivel);
        }

        private void PanelExistente_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is StackPanel panel)
            {
                Permisos permisos = new Permisos();

                // Validar permisos para el módulo "Niveles"
                bool puedeEditar = permisos.TienePermiso("Niveles", "Editar Nivel");
                bool puedeEliminar = permisos.TienePermiso("Niveles", "Eliminar Nivel");
                bool puedeVerCeldas = permisos.TienePermiso("Niveles", "Ver Celdas");
                bool puedeCambiarEstado = permisos.TienePermiso("Niveles", "Activar - Desactivar Nivel");

                // Aplicar visibilidad a los botones principales
                if (panel.FindName("BtnEditar") is Button btnEditar)
                {
                    btnEditar.Visibility = puedeEditar ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("BtnEliminar") is Button BtnEliminar)
                {
                    BtnEliminar.Visibility = puedeEliminar ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("BtnVerCeldas") is Button BtnVerCeldas)
                {
                    BtnVerCeldas.Visibility = puedeVerCeldas ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("BtnEstadoNivel") is Button BtnEstadoNivel)
                {
                    BtnEstadoNivel.Visibility = puedeCambiarEstado ? Visibility.Visible : Visibility.Collapsed;
                }

                // Controlar los rectángulos divisores para evitar líneas huérfanas
                if (panel.FindName("RcEditarEliminar") is Rectangle RcEditarEliminar)
                {
                    RcEditarEliminar.Visibility = (puedeEditar && puedeEliminar) ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("RcVerceldas") is Rectangle RcVerceldas)
                {
                    RcVerceldas.Visibility = ((puedeEditar || puedeEliminar) && puedeVerCeldas) ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("rcEstadoNivel") is Rectangle RcEstadoNivel)
                {
                    RcEstadoNivel.Visibility = (puedeVerCeldas && puedeCambiarEstado) ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }
    }
}