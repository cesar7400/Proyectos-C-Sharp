﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Data;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para Tarifas.xaml
    /// </summary>
    public partial class Tarifas : UserControl
    {
        public Tarifas()
        {
            InitializeComponent();
        }
        // Propiedades para manejar la paginación y búsqueda de usuarios
        public int currentPageTarifa = 1;    // Página actual (inicia en 1)
        public int pageSizeTarifa = 7;      // Cantidad de registros por página
        public int totalRecordsTarifa = 0;   // Total de usuarios que coinciden con la búsqueda
        public int totalPagesTarifa = 0;     // Total de páginas calculadas
        private DataTable DtTipoVehiculo;
        private DataTable DtCategoriaVehiculo;
        public string Tarifa { get; set; }
        public string TipoTarifa { get; set; }
        public string IdPlan { get; set; }
        public string IdTipoPlan { get; set; }

        private string IdPlanTarifa = "";
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Obtiene la ventana que contiene esta página
            var window = Window.GetWindow(this);
            if (window is MainWindow mainWindow)
            {
                // Limpia el contenido del contenedor principal (fContainer)
                mainWindow.ContenedorPrincipal.Content = null;
            }
        }
        private async void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            TbTarifa.Text = Tarifa;

            await TipoVehiculos();
            await CategoriaVehiculos();

            if(TbTarifa.Text == "Mensualidad")
            {
                CmbVigencia.SelectedIndex = 1;
                CmbVigencia.IsEnabled = false;
            }

            await ListaTipoPlan();
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void PreviewTextInputNumbers(object sender, TextCompositionEventArgs e)
        {
            Library clsLibrary = new Library(); // Instancia de librería auxiliar
            clsLibrary.Numbers(sender, e); // Permite solo números en el TextBox
        }
        private void Txt_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true; // Evita que la tecla Espacio genere un carácter
            }
        }
        private void TextBox_formatoMiles_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Verifica que el sender sea un TextBox usando coincidencia de patrones
            if (sender is TextBox textBox)
            {
                // 1. FILTRO ESTRICTO: Remueve cualquier cosa que NO sea un número o un punto
                string textoFiltrado = Regex.Replace(textBox.Text, @"[^0-9.]", "");

                // Si el usuario intentó meter un espacio o letra, restauramos el texto limpio
                if (textBox.Text != textoFiltrado)
                {
                    textBox.Text = textoFiltrado;
                    textBox.SelectionStart = textBox.Text.Length; // Mantiene el cursor al final
                    return;
                }

                // Limpiamos los puntos para hacer la validación numérica interna
                string textoLimpio = textBox.Text.Replace(".", "").Trim();

                // Si el texto quedó vacío al borrar, salimos limpiamente sin romper nada
                if (string.IsNullOrEmpty(textoLimpio))
                {
                    return;
                }

                // 2. VALIDACIÓN DE RANGO NUMÉRICO
                if (Int64.TryParse(textoLimpio, out long valorConvertido))
                {
                    // Verifica si excede el valor máximo permitido para un entero estándar
                    if (valorConvertido >= int.MaxValue)
                    {
                        textBox.Text = ""; // Si excede el valor máximo de int, limpia el TextBox
                    }
                    else
                    {
                        Library clsLibrary = new Library(); // Instancia de librería auxiliar
                        clsLibrary.FormatNumberML(sender, e); // Formatea el número con puntos de miles
                    }

                    textBox.SelectionStart = textBox.Text.Length; // Coloca el cursor al final
                    textBox.Focus(); // Vuelve a enfocar el TextBox
                }
            }
        }
        public async Task TipoVehiculos()
        {
            Vehiculo vehiculo = new Vehiculo();
            if (await vehiculo.TiposVehiculosAsync() is DataTable tipoVehiculo)
            {
                DtTipoVehiculo = tipoVehiculo;
            }
        }
        public async Task CategoriaVehiculos()
        {
            Vehiculo vehiculo = new Vehiculo();
            if (await vehiculo.CategoriaVehiculosAsync() is DataTable categoriaVehiculo)
            {
                DtCategoriaVehiculo = categoriaVehiculo;
            }
        }
        public async Task TarifaMembresiaMensualidad(string IdPlan, int pageNumber, int pageSize)
        {
            TiposPlanes tiposPlanes = new TiposPlanes();

            try
            {
                var dt = await tiposPlanes.TarifasMemnbresiaMensualidadAsync(IdPlan, pageNumber, pageSize);

                if (dt != null) // Si hay resultados
                {
                    // Verifica si la tabla 0 (registros) tiene filas
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        // Obtiene el total de registros de la segunda tabla (índice 1)
                        totalRecordsTarifa = int.Parse(dt.Tables[1].Rows[0][0].ToString());

                        // Calcular el registro inicial de la página
                        int desde = ((currentPageTarifa - 1) * pageSizeTarifa) + 1;

                        // Calcular el registro final (evita pasarse del total real, ej. en la última página)
                        int hasta = Math.Min(currentPageTarifa * pageSizeTarifa, totalRecordsTarifa);

                        // Asignar el texto formateado al TextBlock
                        TbContadorTarifa.Text = $"Mostrando {desde} a {hasta} de {totalRecordsTarifa} registros";

                        // Calcula el total de páginas
                        totalPagesTarifa = (int)Math.Ceiling((double)totalRecordsTarifa / pageSize);

                        //muestra pagina actual
                        TxtPaginaTarifa.Text = "Página " + currentPageTarifa + " de " + totalPagesTarifa;
                        // Asigna la fuente de datos del DataGrid a la vista por defecto del DataTable
                        DgTarifas.ItemsSource = dt.Tables[0].DefaultView;
                        // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                        DgTarifas.CanUserSortColumns = false;

                        // Habilita o deshabilita los botones de navegación según la página actual
                        BtnAnteriorTarifa.IsEnabled = currentPageTarifa > 1;
                        BtnSiguienteTarifa.IsEnabled = (currentPageTarifa * pageSize) < totalRecordsTarifa;

                        // Muestra u oculta los íconos de flecha según correspondan
                        ImgAnteriorTarifa.Visibility = (currentPageTarifa > 1 ? Visibility.Visible : Visibility.Hidden);
                        ImgSiguienteTarifa.Visibility = ((currentPageTarifa * pageSize) < totalRecordsTarifa ? Visibility.Visible : Visibility.Hidden);
                    }
                    else
                    {
                        // Si no hay filas, resetea totales y muestra mensaje de página vacía
                        totalRecordsTarifa = 0;
                        // Asignar el texto formateado al TextBlock
                        TbContadorTarifa.Text = $"Mostrando {0} a {0} de {totalRecordsTarifa} registros";
                        dt.Clear();
                        DgTarifas.ItemsSource = dt.Tables[0].DefaultView;
                        TxtPaginaTarifa.Text = "0";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CmbVigencia_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(CmbVigencia.SelectedIndex == 0)
            {
                TbTipoVigencia.Text = "Ingresar día(s)";
            }
            else
            {
                TbTipoVigencia.Text = "Ingresar Mes(es)";
            }
            TxtVigencia.Focus();
        }

        private async void BtnGuardarTarifa_Click(object sender, RoutedEventArgs e)
        {
            if(CmbVigencia.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccionar vigencia", $"{(TbTarifa.Text == "Mensualidad" ? "Mensualidad" : "Membresía")}", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbVigencia.Focus();
                return;
            }

            if(TxtVigencia.Text == string.Empty)
            {
                MessageBox.Show("Ingresar vigencia", $"{(TbTarifa.Text == "Mensualidad" ? "Mensualidad" : "Membresía")}", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtVigencia.Focus();
                return;
            }
            if (TxtValor.Text == string.Empty)
            {
                MessageBox.Show($"Ingresar valor {(TbTarifa.Text == "Mensualidad" ? "Mensualidad" : "Membresía")}", $"{(TbTarifa.Text == "Mensualidad" ? "Mensualidad" : "Membresía")}", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtValor.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar plan
                TiposPlanes tiposPlanes = new TiposPlanes();
                //Igresar - Actualizar
                if (TbGuardarTarifa.Text == "Guardar" ? await tiposPlanes.NuevoTarifa($"Tarifa {TipoTarifa} de '{Tarifa}'", IdPlan, TxtValor.Text.Trim().Replace(".",""), CmbVigencia.Text, TxtVigencia.Text.Trim().Replace(".",""), CmbEstadoTarifa.Text, MainWindow.IdUsuario)
                                                       :await tiposPlanes.ActualizarTarifa(IdPlanTarifa, $"Tarifa {TipoTarifa} de '{Tarifa}'", TxtValor.Text.Trim().Replace(".", ""), CmbVigencia.Text, TxtVigencia.Text.Trim().Replace(".",""), CmbEstadoTarifa.Text, MainWindow.IdUsuario))
                {
                    await TipoVehiculos();
                    await CategoriaVehiculos();
                    // actualiza el datagrid
                    await TarifaMembresiaMensualidad(IdPlan, currentPageTarifa, pageSizeTarifa);
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show($"{(TbTarifa.Text == "Mensualidad" ? "Mensualidad" : "Membresía")} se {(TbGuardarTarifa.Text == "Guardar" ? "agrego" : "actualizo")} correctamente", $"{(TbTarifa.Text == "Mensualidad" ? "Mensualidad" : "Membresía")}", MessageBoxButton.OK, MessageBoxImage.Information);
                    LimpiarTarifa();
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }

        private void BtnCancelarTarifa_Click(object sender, RoutedEventArgs e)
        {
            LimpiarTarifa();
        }

        private async void LimpiarTarifa()
        {
            if (TbTarifa.Text == "Mensualidad")
            {
                CmbVigencia.SelectedIndex = 1;
            }
            else
            {
                CmbVigencia.SelectedIndex = -1;
            }
            CmbEstadoTarifa.SelectedIndex = -1;
            TxtVigencia.Text = string.Empty;
            TxtValor.Text = string.Empty;

            await EstadoGuardar(true, false);
        }

        private async void BtnAnteriorTarifa_Click(object sender, RoutedEventArgs e)
        {
            if (currentPageTarifa > 1)
            {
                currentPageTarifa--; // Disminuye el número de página
                await TarifaMembresiaMensualidad(IdTipoPlan, currentPageTarifa, pageSizeTarifa);
                TxtPaginaTarifa.Text = "Página " + currentPageTarifa + " de " + totalPagesTarifa;
            }
        }

        private async void BtnSiguienteTarifa_Click(object sender, RoutedEventArgs e)
        {
            if ((currentPageTarifa * pageSizeTarifa) < totalRecordsTarifa)
            {
                currentPageTarifa++; // Aumenta el número de página
                await TarifaMembresiaMensualidad(IdTipoPlan, currentPageTarifa, pageSizeTarifa);
                TxtPaginaTarifa.Text = "Página " + currentPageTarifa + " de " + totalPagesTarifa;
            }
        }

        private async void BtnSeleccionarTarifa_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;

            await EstadoGuardar(true, false);

            string IdPlanTarifa = filaSeleccionada["IdPlanTarifa"].ToString();

            var tarifaInfo = new TarifaInfo()
            {
                IdPlanTarifa = IdPlanTarifa,
                DataContext = filaSeleccionada,
            };
            tarifaInfo.ShowDialog();


        }

        private async void BtnEditarTarifa_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;

            IdPlanTarifa = filaSeleccionada["IdPlanTarifa"].ToString();
            string Unidad = filaSeleccionada["Unidad"].ToString();
            string Cantidad = filaSeleccionada["Cantidad"].ToString();
            string ValorTarifa = filaSeleccionada["ValorTarifa"].ToString();
            string EstadoPlanTarifa = filaSeleccionada["EstadoPlanTarifa"].ToString();

            CmbVigencia.Text = Unidad;
            TxtVigencia.Text = Cantidad;
            TxtValor.Text = ValorTarifa;
            CmbEstadoTarifa.Text = EstadoPlanTarifa == "True" ? "Activo" : "Inactivo";

            await EstadoGuardar(false, true);
        }

        private async void BtnEliminarTarifa_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;

            string IdPlanTarifa = filaSeleccionada["IdPlanTarifa"].ToString();

            //Pregunta antes de proceder a eliminar tipo plan
            MessageBoxResult messageBoxResult = MessageBox.Show($"¿Eliminar Tarifa {TipoTarifa} de '{Tarifa}' ¿Desea continuar?", $"{(TbTarifa.Text == "Mensualidad" ? "Eliminar Mensualidad" : "Eliminar Membresía")}", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar plan
                TiposPlanes tiposPlanes = new TiposPlanes();
                //Igresar / actualizar Tipo de plan
                if (await tiposPlanes.EliminarTarifa(IdPlanTarifa, $"Tarifa {TipoTarifa} de '{Tarifa}'", MainWindow.IdUsuario))
                {
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show($"{TipoTarifa} de '{Tarifa}' se eliminó correctamente", $"{(TbTarifa.Text == "Mensualidad" ? "Eliminar Mensualidad" : "Eliminar Membresía")}", MessageBoxButton.OK, MessageBoxImage.Information);
                    // actualiza el datagrid
                    await TarifaMembresiaMensualidad(IdPlan, currentPageTarifa, pageSizeTarifa);
                    LimpiarTarifa();
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                Mouse.OverrideCursor = null;
            }
        }
        public async Task ListaTipoPlan()//IdTipoPlan 1-membresía,  2-mensualidad
        {
            Permisos permisos = new Permisos();
            try
            {
                string StrTipoTarifa = (IdTipoPlan == "1" ? "membresía" : "mensualidad");
                // Consultar permisos
                bool PuedeGuardar = permisos.TienePermiso("Planes", $"Agregar {StrTipoTarifa}");
                bool verPlanes = permisos.TienePermiso("Planes", $"Ver {StrTipoTarifa}");
                bool puedeEditar = permisos.TienePermiso("Planes", $"Editar {StrTipoTarifa}");
                bool puedeEliminar = permisos.TienePermiso("Planes", $"Eliminar {StrTipoTarifa}");


                // Si TODOS los permisos están en false, ocultamos toda la columna Acciones
                if (!puedeEditar && !puedeEliminar && !verPlanes)
                {
                    ColAcciones.Visibility = Visibility.Collapsed;
                }
                else
                {
                    ColAcciones.Visibility = Visibility.Visible;
                }
                await EstadoGuardar(true, false);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async Task EstadoGuardar(bool Guardar, bool Editar)
        {

            BtnGuardarTarifa.Visibility = Visibility.Collapsed;

            Permisos permisos = new Permisos();

            string StrTipoTarifa = (IdTipoPlan == "1" ? "membresía" : "mensualidad");

            bool puedeEditar = permisos.TienePermiso("Planes", $"Editar {StrTipoTarifa}");
            bool puedeAgregar = permisos.TienePermiso("Planes", $"Agregar {StrTipoTarifa}");


            if (puedeEditar == false && puedeAgregar == false)
            {
                BtnGuardarTarifa.Visibility = Visibility.Collapsed;
                return;
            }

            if (puedeAgregar == true && Guardar == true)
            {
                BtnGuardarTarifa.Visibility = Visibility.Visible;
                TbGuardarTarifa.Text = "Guardar";
                return;
            }

            if (puedeEditar == true && Editar == true)
            {
                BtnGuardarTarifa.Visibility = Visibility.Visible;
                TbGuardarTarifa.Text = "Guardar Cambios";
                return;
            }
            else
            {
                TbGuardarTarifa.Text = "Guardar";
            }
        }

        private void PanelTarifas_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is StackPanel panel)
            {
                Permisos permisos = new Permisos();

                string StrTipoTarifa = (IdTipoPlan == "1" ? "membresía" : "mensualidad");

                // Validar permisos para el módulo "Planes"
                bool puedeVerPlanes = permisos.TienePermiso("Planes", $"Ver {StrTipoTarifa}");
                bool puedeEditar = permisos.TienePermiso("Planes", $"Editar {StrTipoTarifa}");
                bool puedeEliminar = permisos.TienePermiso("Planes", $"Eliminar {StrTipoTarifa}");

                // Aplicar visibilidad a los botones principales
                if (panel.FindName("BtnSeleccionarTarifa") is Button BtnSeleccionarTarifa)
                {
                    BtnSeleccionarTarifa.Visibility = puedeVerPlanes ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("BtnEditarTarifa") is Button BtnEditarTarifa)
                {
                    BtnEditarTarifa.Visibility = puedeEditar ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("BtnEliminarTarifa") is Button BtnEliminarTarifa)
                {
                    BtnEliminarTarifa.Visibility = puedeEliminar ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }
    }
}