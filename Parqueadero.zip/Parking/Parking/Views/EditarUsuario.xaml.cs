﻿using Parking.Models;
using Parking.Controller;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using static Parking.Views.Usuarios;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para EditarUsuario.xaml
    /// </summary>
    public partial class EditarUsuario : Window, IFormUsuario
    {
        public EditarUsuario(Usuarios usuarios)
        {
            InitializeComponent();
            this.usuarios = usuarios;
            TxtUsuario.Focus();
        }
        readonly Usuarios usuarios;
        private string StrUsuarioID = "";     // ID del usuario que se está actualizando
        readonly List<string> ListUsuarios = new List<string>(); // Guarda datos originales del usuario para restaurar en "Cancelar"
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void PreviewTextInputTextLetters(object sender, TextCompositionEventArgs e)
        {
            // Crea una instancia de la biblioteca de utilidades
            Library library = new Library();
            // Llama al método que permite solo letras
            library.Letters(sender, e);
        }
        private void TxtPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            PasswordBox pb = (PasswordBox)sender;
            // Buscamos el TextBlock del placeholder dentro del Template
            var template = pb.Template;
            var placeholder = (TextBlock)template.FindName("placeHolderTextBlock", pb);

            if (placeholder != null)
            {
                // Si hay texto, ocultamos el Tag. Si está vacío, lo mostramos.
                placeholder.Visibility = string.IsNullOrEmpty(pb.Password)
                                         ? Visibility.Visible
                                         : Visibility.Collapsed;
            }
        }
        private void TxtUsuario_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Si la tecla presionada es el espacio, cancelamos el evento
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }
        private void ValidarComillas(object sender, TextCompositionEventArgs e)
        {
            // Si el texto que intenta ingresar es una comilla simple o doble
            if (e.Text == "'" || e.Text == "\"")
            {
                e.Handled = true; // Aquí le decimos a WPF: "No proceses esta tecla"
            }
        }
        public void SetData(List<KeyValuePair<string, string>> data)
        {
            //Informacion actual del cliente
            StrUsuarioID = data[0].Value.ToString();
            TxtUsuario.Text = data[1].Value.ToString();
            TxtNombres.Text = data[2].Value.ToString();
            byte dias = Convert.ToByte(data[3].Value);
            bool cambioPassw = Convert.ToBoolean(data[4].Value);
            bool esActivo = Convert.ToBoolean(data[5].Value);

            ChkCambioPassword.IsChecked = cambioPassw;
            RdActivo.IsChecked = esActivo;
            RdInactivo.IsChecked = !esActivo;

            CargarDiasSeleccionados(dias);
            
            ListUsuarios.Add(data[1].Value); // Usuario
            ListUsuarios.Add(data[2].Value); // nombres
            ListUsuarios.Add(data[3].Value); // dias
            ListUsuarios.Add(data[4].Value); // cambio contraseña
            ListUsuarios.Add(data[5].Value); // estado
            //Administrador principal solo se le permite cambio de contraseña
            if (StrUsuarioID == "1")
            {
                ChkLunes.IsChecked = true;
                ChkMartes.IsChecked = true;
                ChkMiercoles.IsChecked = true;
                ChkJueves.IsChecked = true;
                ChkViernes.IsChecked = true;
                ChkSabado.IsChecked = true;
                ChkDomingo.IsChecked = true;
                RdActivo.IsChecked = true;
                RdInactivo.IsChecked = false;

                ChkLunes.IsEnabled = false;
                ChkMartes.IsEnabled = false;
                ChkMiercoles.IsEnabled = false;
                ChkJueves.IsEnabled = false;
                ChkViernes.IsEnabled = false;
                ChkSabado.IsEnabled = false;
                ChkDomingo.IsEnabled = false;
                RdActivo.IsEnabled = false;
                RdInactivo.IsEnabled = false;
            }
        }
        private byte ObtenerDiasSeleccionados()
        {
            byte dias = 0;

            if (ChkLunes.IsChecked == true) dias |= 1;
            if (ChkMartes.IsChecked == true) dias |= 2;
            if (ChkMiercoles.IsChecked == true) dias |= 4;
            if (ChkJueves.IsChecked == true) dias |= 8;
            if (ChkViernes.IsChecked == true) dias |= 16;
            if (ChkSabado.IsChecked == true) dias |= 32;
            if (ChkDomingo.IsChecked == true) dias |= 64;

            return dias;
        }
        private void CargarDiasSeleccionados(byte dias)
        {
            ChkLunes.IsChecked = (dias & 1) != 0;
            ChkMartes.IsChecked = (dias & 2) != 0;
            ChkMiercoles.IsChecked = (dias & 4) != 0;
            ChkJueves.IsChecked = (dias & 8) != 0;
            ChkViernes.IsChecked = (dias & 16) != 0;
            ChkSabado.IsChecked = (dias & 32) != 0;
            ChkDomingo.IsChecked = (dias & 64) != 0;
        }
        private async void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            // Validaciones de campos obligatorios
            if (TxtNombres.Text == string.Empty)
            {
                MessageBox.Show("Ingresar nombres", "Editar Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtNombres.Focus();
                return;
            }
            if (TxtPassword.Password != "" || TxtPasswordR.Password != "")
            {
                if (TxtPassword.Password == string.Empty)
                {
                    MessageBox.Show("Ingresar contraseña", "Editar Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                    TxtPassword.Focus();
                    return;
                }
                else if (TxtPassword.Password.Length < 8)
                {
                    MessageBox.Show("Contraseña debe tener mínimo ocho caracteres", "Editar Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                    TxtPassword.Focus();
                    return;
                }
                else if (TxtPasswordR.Password == string.Empty)
                {
                    MessageBox.Show("Ingresar contraseña", "Editar Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                    TxtPasswordR.Focus();
                    return;
                }
                else if (TxtPasswordR.Password.Length < 8)
                {
                    MessageBox.Show("Contraseña debe tener mínimo ocho caracteres", "Editar Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                    TxtPasswordR.Focus();
                    return;
                }

                else if (TxtPassword.Password.Trim().ToLower() != TxtPasswordR.Password.Trim().ToLower())
                {
                    MessageBox.Show("Contraseña no coincide", "Editar Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                    TxtPasswordR.Focus();
                    return;
                }
            }

            if (ChkLunes.IsChecked == false && ChkMartes.IsChecked == false && ChkMiercoles.IsChecked == false && ChkJueves.IsChecked == false && ChkViernes.IsChecked == false && ChkSabado.IsChecked == false && ChkDomingo.IsChecked == false)
            {
                MessageBox.Show("Seleccionar uno o varios días", "Editar Usuario", MessageBoxButton.OK, MessageBoxImage.Information); // Valida que se haya seleccionado al menos un día
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de actualuzar usuario
                UsuariosController usuariosController = new UsuariosController();
                //Actualizar usuario
                if (await usuariosController.UpdateUsuarioAsync(StrUsuarioID, TxtNombres.Text.Trim().ToLower(), TxtPasswordR.Password.Trim().ToLower(), ObtenerDiasSeleccionados(), (ChkCambioPassword.IsChecked == true ? "1" : "0"), (RdActivo.IsChecked == true ? "1" : "0"), MainWindow.IdUsuario, TxtUsuario.Text.Trim()))
                {
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show($"Usuario '{TxtUsuario.Text.Trim().ToLower()}' con nombre '{TxtNombres.Text.Trim().ToLower()}' se actualizo correctamente", "Editar Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                    // actualiza el datagrid
                    usuarios.CargarUsuarios(usuarios.TxtBuscarUsuario.Text.Trim(), usuarios.currentPage, usuarios.pageSize);
                    this.Close();
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }
        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            // reestablacer valores
            TxtUsuario.Text = ListUsuarios[0];
            TxtNombres.Text = ListUsuarios[1]; // nombres
            byte dias = Convert.ToByte(ListUsuarios[2]);// dias seleccionados
            bool cambioPassw = Convert.ToBoolean(ListUsuarios[3]);//cambio contraseña
            bool esActivo = Convert.ToBoolean(ListUsuarios[4]); // estado

            ChkCambioPassword.IsChecked = cambioPassw;
            RdActivo.IsChecked = esActivo;
            RdInactivo.IsChecked = !esActivo;

            CargarDiasSeleccionados(dias);// dias seleccionados
            TxtPassword.Clear();
            TxtPasswordR.Clear();
        }
    }
}