﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using static Parking.Views.Clientes;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para EditarCliente.xaml
    /// </summary>
    public partial class EditarCliente : Window, IFormCliente
    {
        public EditarCliente(Clientes _clientes)
        {
            InitializeComponent();
            this._clientes = _clientes;
        }
        readonly List<string> ListCliente = new List<string>(); // Guarda datos originales del usuario para restaurar en "Cancelar"
        private readonly Clientes _clientes;
        private string StrClienteID = "";
        private string StrClienteAntes = "";
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void PreviewTextInputTextLetters(object sender, TextCompositionEventArgs e)
        {
            // Crea una instancia de la biblioteca de utilidades
            Library library = new Library();
            // Llama al método que permite solo letras
            library.Letters(sender, e);
        }
        private void Txt_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Si la tecla presionada es el espacio, cancelamos el evento
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }
        private void PreviewTextInputNumbers(object sender, TextCompositionEventArgs e)
        {
            Library library = new Library();
            library.Numbers(sender, e); // Restringe la entrada a dígitos
        }
        private void TxtCelular_TextChanged(object sender, TextChangedEventArgs e)
        {
            Library library = new Library();
            string formattedPhoneNumber = library.FormatCelularNumber(TxtCelular.Text);
            // Llama al método que formatea el número de celular
            TxtCelular.Text = formattedPhoneNumber;     // Asigna el texto formateado
            TxtCelular.CaretIndex = TxtCelular.Text.Length;
            // Mueve el cursor al final del texto
        }
        public async Task SeleccionarTipoDocumento(string Documentoid)// se cargan tipo de documento
        {
            TipoDocumento tipoDocumento = new TipoDocumento();

            var dt = await tipoDocumento.SelectTipoDocumentoAsync();
            if (dt != null) // Si hay resultados
            {
                CmbTipoDocumento.ItemsSource = dt.DefaultView;
                CmbTipoDocumento.DisplayMemberPath = "Tipo"; // Muestra el nombre de la jornada
                CmbTipoDocumento.SelectedValuePath = "Documentoid"; // El valor seleccionado será el ID
                CmbTipoDocumento.SelectedValue = Documentoid; // Selecciona el tipo de vehículo actual
            }
        }
        public async void SetData(List<KeyValuePair<string, string>> data)
        {
            //Informacion actual del cliente
            StrClienteID = data[0].Value.ToString();
            TxtNombres.Text = data[1].Value.ToString();
            await SeleccionarTipoDocumento(data[2].Value.ToString());
            TxtDocumento.Text = data[3].Value.ToString();
            TxtCelular.Text= data[4].Value.ToString();
            TxtCorreo.Text = data[5].Value.ToString();
            StrClienteAntes = data[6].Value.ToString();
            ListCliente.Add(data[1].Value); // nombre
            ListCliente.Add(data[2].Value); // Tipo documento
            ListCliente.Add(data[3].Value); // documento
            ListCliente.Add(data[4].Value); // celular
            ListCliente.Add(data[5].Value); // email


        }
        private async void RestablecerCampos()
        {
            TxtNombres.Text = ListCliente[0];
            await SeleccionarTipoDocumento(ListCliente[1]);
            TxtDocumento.Text= ListCliente[2];
            TxtCelular.Text = ListCliente[3];
            TxtCorreo.Text= ListCliente[4];
        }
        private async void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            Library library = new Library();
            // Validaciones de campos obligatorios y formato de email
            if (TxtNombres.Text == string.Empty)
            {
                MessageBox.Show("Ingresar nombres", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtNombres.Focus();
                return;
            }
            else if (CmbTipoDocumento.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccionar tipo documento", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbTipoDocumento.Focus();
                return;
            }
            else if (TxtDocumento.Text == string.Empty)
            {
                MessageBox.Show("Ingresar Número Documento", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtDocumento.Focus();
                return;
            }
            else if (!library.ValidNumberCel(TxtCelular.Text.Trim()) && TxtCelular.Text != "")
            {
                MessageBox.Show("Número de celular no válido", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Error);
                TxtCelular.Focus();
                return;
            }
            else if (!library.IsValidEmail(TxtCorreo.Text.Trim()) && TxtCorreo.Text != "")
            {
                MessageBox.Show("Correo no valido", "Nuevo Cliente", MessageBoxButton.OK, MessageBoxImage.Error);
                TxtCorreo.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar usuario
                Clientes_ clientes = new Clientes_();
                //Igresar nuevo usuario
                string strClienteDespues = $"Nombre: {TxtNombres.Text.Trim()}, Tipo Documento: {CmbTipoDocumento.Text}, Número Documento: {TxtDocumento.Text.Trim()}, Celular. {TxtCelular.Text.Trim()}, Correo: {TxtCorreo.Text.Trim()}";
                if (await clientes.ActualizarCliente(StrClienteID, CmbTipoDocumento.SelectedValue.ToString(), TxtNombres.Text.Trim(), TxtDocumento.Text.Trim(), TxtCelular.Text.Trim(), TxtCorreo.Text.Trim(), StrClienteAntes, strClienteDespues,  MainWindow.IdUsuario))
                {
                    //Muestra un mensaje de confirmaciín de guardado del cliente nuevo
                    MessageBox.Show($"Cliente '{TxtNombres.Text.Trim().ToLower()}' se actualizo correctamente", "Actualizar Cliente", MessageBoxButton.OK, MessageBoxImage.Information);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                    // actualiza el datagrid
                    _clientes.CargarClientes(_clientes.TxtBuscarCliente.Text.Trim(), _clientes.currentPage, _clientes.pageSize);
                    this.Close();
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            RestablecerCampos();
        }
    }
}
