﻿using Parking.Models;
using Parking.Resources;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using static Parking.Views.Configuracion;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para MainTicket.xaml
    /// </summary>
    public partial class MainTicket : Window, IFormVerTicket
    {
        readonly ConfigTicket configTicket = new ConfigTicket();
        public MainTicket(Configuracion configuracion)
        {
            InitializeComponent();
            this.configuracion = configuracion;
        }
        
        readonly Configuracion configuracion;
        public string StrTipoTikect {  get; set; }
        private string strConfiguracionID = "";
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana
        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        FlowDocument nuevoDoc;

        // Ahora la lista dentro del diccionario soporta 5 valores por fila
        readonly private Dictionary<string, List<(string C1, string C2, string C3, string C4, string C5)>> datosPorColumna
            = new Dictionary<string, List<(string, string, string, string, string)>>();
        public void SetData(List<KeyValuePair<string, string>> data)
        {
            strConfiguracionID = data[0].Value.ToString();
            configTicket.CargarTicket(strConfiguracionID);
            txtNombreTicket.Text = data[2].Value.ToString();
            CmbSeleccionarForm.Text = data[3].Value.ToString();
            CmbSeleccionarForm.IsEnabled = false;
        }

        public async void ActualizarVisualizacionTicket()
        {
            Ticket ticket = new Ticket();
            nuevoDoc = ticket.Doc_();

            foreach (var item in  pnlContenedorGrupos.Children)
            {
                // Es un control de Texto
                if (item is ControlTexto grupoTxt)
                {
                    if (grupoTxt.ChkIncluirInformacionEmpresa.IsChecked == false)
                    {
                        ticket.AgregarTexto(
                            nuevoDoc,
                            grupoTxt.ChkPlacaVehiculo.IsChecked == true ? "{{PLACA VEHICULO}}" : (grupoTxt.ChkNumeroTicket.IsChecked == true ? "{{NUMERO TICKET}}" : grupoTxt.Texto),
                            grupoTxt.PesoFuente,
                            (double)grupoTxt.TamanioFuente,
                            grupoTxt.Alineacion,
                            grupoTxt.FuenteSeleccionada,
                            grupoTxt.InterlineadoTexto,
                            grupoTxt.EspacioVertical,
                            grupoTxt.EspacioHorizontal
                            // Aquí podrías pasar también el interlineado si lo añadiste a AgregarTexto
                        );
                    }
                    else
                    {
                        foreach (KeyValuePair<string, string> par in Configuracion.DicEmpresa)
                        {
                            ticket.AgregarTexto(
                                nuevoDoc,
                                par.Value.ToString(),
                                par.Key == "razon_social" ? FontWeights.Bold : grupoTxt.PesoFuente,
                                (double)grupoTxt.TamanioFuente,
                                grupoTxt.Alineacion,
                                grupoTxt.FuenteSeleccionada,
                                grupoTxt.InterlineadoTexto,
                                grupoTxt.EspacioVertical,
                                grupoTxt.EspacioHorizontal
                            );
                        }
                    }
                }
                // Es un control de Texto
                if (item is ControlParrafo parrafoTxt)
                {
                    ticket.AgregarTexto(
                        nuevoDoc,
                        parrafoTxt.Parrafo,
                        parrafoTxt.PesoFuente,
                        (double)parrafoTxt.TamanioFuente,
                        parrafoTxt.Alineacion,
                        parrafoTxt.FuenteSeleccionada,
                        parrafoTxt.InterlineadoTexto, 
                        parrafoTxt.EspacioVertical
                    // Aquí podrías pasar también el interlineado si lo añadiste a AgregarTexto
                    );
                }
                else if (item is ControlDatos controlDatos)
                {
                    ticket.AgregarMatrizDatos(
                        nuevoDoc,
                        controlDatos.DatosMatriz,
                        controlDatos.FuenteSeleccionada,
                        controlDatos.PesoFuente,
                        controlDatos.Alineacion,
                        controlDatos.TamanioFuente,
                        controlDatos.EspacioVertical,
                        controlDatos.EspacioHorizontal,
                        controlDatos.InterlineadoTexto,
                        controlDatos.FilaPintadaIndex,
                        controlDatos.ColumnaPintadaIndex
                    );
                }

                // Es un control de Imagen
                if (item is ControlImagen grupoImg)
                {
                    ticket.AgregarImagen(
                        nuevoDoc,
                        grupoImg.Bitmap,
                        grupoImg.Ancho,
                        grupoImg.Alto,
                        grupoImg.InterlineadoTexto, // Usa el interlineado decimal
                        grupoImg.AlineacionSeleccionada, // ComboBox
                        grupoImg.DesplazamientoX       // NumericUpDown
                    );
                }
            }

            rtbTicket.Document = nuevoDoc;
        }
        private void EjecutarMovimiento(object sender, int direccion)
        {
            // Recuperamos el control usando coincidencia de patrones
            if (!(sender is UserControl controlQuePulso)) return;

            // Buscamos su índice REAL en el panel de la derecha
            int indiceActual = pnlContenedorGrupos.Children.IndexOf(controlQuePulso);
            int nuevoIndice = indiceActual + direccion;

            // Validamos límites para no salirnos de la lista
            if (nuevoIndice >= 0 && nuevoIndice < pnlContenedorGrupos.Children.Count)
            {
                // Movimiento físico en el panel
                pnlContenedorGrupos.Children.RemoveAt(indiceActual);
                pnlContenedorGrupos.Children.Insert(nuevoIndice, controlQuePulso);

                // Actualizar el ticket (izquierda) recorriendo el panel en su nuevo orden
                ActualizarVisualizacionTicket();

                // Mantener el foco para que no se pierda la selección
                controlQuePulso.Focus();
            }
        }
        public void SuscribirEventosYAgregar(UserControl control)
        {
            if (control is ControlTexto t)
            {
                // Al usar (s, e), 's' es el control que disparó el evento (identidad única)
                t.MoverArriba += (s, e) => EjecutarMovimiento(s, -1);
                t.MoverAbajo += (s, e) => EjecutarMovimiento(s, 1);
                t.AjusteCambiado += (s, e) => ActualizarVisualizacionTicket();
                t.ControlQuitado += (s, e) => {
                    pnlContenedorGrupos.Children.Remove(t);
                    ActualizarVisualizacionTicket();
                };
            }
            if (control is ControlParrafo cp)
            {
                // Al usar (s, e), 's' es el control que disparó el evento (identidad única)
                cp.MoverArriba += (s, e) => EjecutarMovimiento(s, -1);
                cp.MoverAbajo += (s, e) => EjecutarMovimiento(s, 1);
                cp.AjusteCambiado += (s, e) => ActualizarVisualizacionTicket();
                cp.ControlQuitado += (s, e) => {
                    pnlContenedorGrupos.Children.Remove(cp);
                    ActualizarVisualizacionTicket();
                };
            }

            else if (control is ControlDatos colDinamicas)
            {
                colDinamicas.MoverArriba += (s, e) => EjecutarMovimiento(s, -1);
                colDinamicas.MoverAbajo += (s, e) => EjecutarMovimiento(s, 1);
                colDinamicas.AjusteCambiado += (s, e) => ActualizarVisualizacionTicket();
                colDinamicas.ControlQuitado += (s, e) => {
                    pnlContenedorGrupos.Children.Remove(colDinamicas);
                    ActualizarVisualizacionTicket();
                };
            }
            
            else if (control is ControlImagen i)
            {
                i.MoverArriba += (s, e) => EjecutarMovimiento(s, -1);
                i.MoverAbajo += (s, e) => EjecutarMovimiento(s, 1);
                i.AjusteCambiadoImagen += (s, e) => ActualizarVisualizacionTicket();
                i.ControlQuitadoImagen += (s, e) => {
                    pnlContenedorGrupos.Children.Remove(i);
                    ActualizarVisualizacionTicket();
                };
            }
            // Solo lo agregamos al panel una vez que tiene todos los cables (eventos) conectados
            if (!pnlContenedorGrupos.Children.Contains(control))
            {
                pnlContenedorGrupos.Children.Add(control);
            }
        }
        private async void BtnAgregar_Click(object sender, RoutedEventArgs e)
        {
            if (cmbSeleccionar.SelectedIndex == -1 && StrTipoTikect == "Nuevo")
            {
                MessageBox.Show("Seleccionar tipo de dato", "Ticket", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                string nombre = txtNombre.Text;
                if (cmbSeleccionar.SelectedIndex == 0)
                {
                    if (!string.IsNullOrWhiteSpace(nombre))
                    {
                        var nuevoGrupoImagen = new ControlImagen(nombre);

                        // Usamos el mismo método centralizado
                        SuscribirEventosYAgregar(nuevoGrupoImagen);
                        cmbSeleccionar.Text = "";
                        txtNombre.Clear();
                        ActualizarVisualizacionTicket();
                    }
                    else
                    {
                        MessageBox.Show("Ingresar nombre imagen", "Ingresar", MessageBoxButton.OK, MessageBoxImage.Information);
                        txtNombre.Focus();
                    }
                }
                if (cmbSeleccionar.SelectedIndex == 1)
                {
                    if (!string.IsNullOrWhiteSpace(nombre))
                    {
                        var nuevoControlDatos = new ControlDatos(nombre);
                        SuscribirEventosYAgregar(nuevoControlDatos);
                        cmbSeleccionar.Text = "";
                        txtNombre.Clear();
                        ActualizarVisualizacionTicket();
                    }
                    else
                    {
                        MessageBox.Show("Ingresar nombre grupo", "Ingresar", MessageBoxButton.OK, MessageBoxImage.Information);
                        txtNombre.Focus();
                    }
                }
                if (cmbSeleccionar.SelectedIndex == 2)
                {
                    if (!string.IsNullOrWhiteSpace(nombre))
                    {
                        var nuevoParrafo = new ControlParrafo(nombre);

                        // ¡ESTA ES LA CLAVE! No suscribas eventos aquí, usa el método que ya creaste
                        SuscribirEventosYAgregar(nuevoParrafo);
                        cmbSeleccionar.Text = "";
                        txtNombre.Clear();
                        ActualizarVisualizacionTicket();
                    }
                    else
                    {
                        MessageBox.Show("Ingresar nombre grupo", "Ingresar", MessageBoxButton.OK, MessageBoxImage.Information);
                        txtNombre.Focus();
                    }
                }
                if (cmbSeleccionar.SelectedIndex == 3)
                {
                    if (!string.IsNullOrWhiteSpace(nombre))
                    {
                        var nuevoGrupoTexto = new ControlTexto(nombre);

                        // ¡ESTA ES LA CLAVE! No suscribas eventos aquí, usa el método que ya creaste
                        SuscribirEventosYAgregar(nuevoGrupoTexto);
                        cmbSeleccionar.Text = "";
                        txtNombre.Clear();
                        ActualizarVisualizacionTicket();
                    }
                    else
                    {
                        MessageBox.Show("Ingresar nombre grupo", "Ingresar", MessageBoxButton.OK, MessageBoxImage.Information);
                        txtNombre.Focus();
                    }
                }
            }
        }
        public bool TieneInformacion(RichTextBox richTextBox)
        {
            if (richTextBox?.Document == null) return false;

            // 1. Extraer el texto plano y limpiar espacios/saltos de línea
            TextRange textRange = new TextRange(
                richTextBox.Document.ContentStart,
                richTextBox.Document.ContentEnd
            );

            string texto = textRange.Text?.Trim() ?? string.Empty;

            // Si tiene texto real (más allá de los saltos de línea automáticos)
            if (!string.IsNullOrEmpty(texto))
            {
                return true;
            }

            // 2. Por si contiene elementos visuales no textuales (como imágenes o UI Elements)
            // Verificamos si hay bloques dentro del FlowDocument que contengan contenido real
            foreach (var block in richTextBox.Document.Blocks)
            {
                if (block is Paragraph paragraph)
                {
                    // Si el párrafo tiene inlines (texto, imágenes, etc.) que no estén vacíos
                    if (paragraph.Inlines.Count > 0)
                    {
                        // Opcional: puedes recorrer los inlines si necesitas filtrar elementos vacíos
                        return true;
                    }
                }
                else
                {
                    // Si hay listas, tablas u otros bloques
                    return true;
                }
            }

            return false;
        }
        private async void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            // Validaciones de campos obligatorios
            if (CmbSeleccionarForm.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccionar tipo ticket", "Ticket", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbSeleccionarForm.Focus();
                return;
            }
            // Validaciones de campos obligatorios y formato de email
            if (txtNombreTicket.Text == string.Empty)
            {
                MessageBox.Show("Ingresar nombre ticket", "Ticket", MessageBoxButton.OK, MessageBoxImage.Information);
                txtNombreTicket.Focus();
                return;
            }
            if(!TieneInformacion(rtbTicket))
            {
                MessageBox.Show("No hay contenido en el ticket para guardar", "Ticket", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Guarda ticket NUEVO
                if (await configTicket.GuardarConfiguracion(pnlContenedorGrupos, "TICKET:" + txtNombreTicket.Text.Trim() + "-" + CmbSeleccionarForm.Text, strConfiguracionID))
                {
                    if (StrTipoTikect == "Nuevo")
                    {
                        strConfiguracionID = await configuracion.CargarTickets(txtNombreTicket.Text.Trim());
                        StrTipoTikect = "Editar";
                    }
                    else
                    {
                        await configuracion.CargarTickets();
                    }
                    
                }
                // Cambiar cursor a normal
                Mouse.OverrideCursor = null;
            }
        }
    }
}