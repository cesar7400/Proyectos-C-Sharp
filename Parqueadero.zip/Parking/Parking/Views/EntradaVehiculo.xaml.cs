﻿using Parking.Controller;
using System;
using System.Data;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para EntradaVehiculo.xaml
    /// </summary>
    public partial class EntradaVehiculo : Window
    {
        public EntradaVehiculo(EntradaSalida entradaSalida)
        {
            InitializeComponent();
            this.entradaSalida = entradaSalida;
        }
        readonly EntradaSalida entradaSalida;
        // Propiedad para asignar o leer el texto del TextBlock
        public string TxtPlaca
        {
            get => TbPlaca.Text;
            set => TbPlaca.Text = value;
        }

        bool PlanActivo = false;
        public int IdTipoVehiculo;
        public int IdCategoriaVehiculo;

        //Definimos los colores (según la leyenda de la interfaz)
        private readonly Brush colorDisponible = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#57aa3c")); // Verde
        private readonly Brush colorSeleccionado = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#007bff")); // azul

        private string IdCelda = "";
        // Variable global para recordar cuál botón fue el último en pulsarse
        private Button botonSeleccionadoAnterior = null;

        DataTable dtOriginal;
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana
        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            await EstadoTipoPlan();
            await NivelCeldas();
        }

        
        private async Task TarifaPorTiempoDemanda(string IdPlan, int pageNumber, int pageSize)
        {
            TiposPlanes tiposPlanes = new TiposPlanes();

            try
            {
                var ds = await tiposPlanes.ListadoTiempoPorDemandaAsync(IdPlan, pageNumber, pageSize);

                if (ds != null) // Si hay resultados
                {
                    // 1. Guardamos la tabla completa (CON TODAS SUS COLUMNAS)
                    dtOriginal = ds.Tables[0];

                    // 2. Creamos una mini-tabla SOLO para el ComboBox (para quitar los duplicados en la lista desplegable)
                    DataTable dtCombo = dtOriginal.DefaultView.ToTable(true, "IdPlan", "NombrePlan");

                    // 3. Asignamos la mini-tabla ÚNICAMENTE al ComboBox
                    CmbPlanVehiculo.ItemsSource = dtCombo.DefaultView;
                    CmbPlanVehiculo.DisplayMemberPath = "NombrePlan";
                    CmbPlanVehiculo.SelectedValuePath = "IdPlan";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async Task EstadoTipoPlan()
        {
            Movimientos movimientos = new Movimientos();
            //verificar si algun vehiculo tiene membresía o mensualidad vigente(activa)
            var dt = await movimientos.EstadoTipoPlanAsync(TxtPlaca);
            if (dt != null)
            {
                if(dt.Tables[0].Rows.Count > 0)
                {
                    DataRow fila = dt.Tables[0].Rows[0];
                    
                    bool TieneMembresiaActiva = Convert.ToBoolean(fila["TieneMembresiaActiva"]);

                    bool TieneMensualidadActiva = Convert.ToBoolean(fila["TieneMensualidadActiva"]);

                    bool Vip = Convert.ToBoolean(fila["Vip"]);

                    IdTipoVehiculo = Convert.ToInt32(fila["idtipovehiculo"]);

                    IdCategoriaVehiculo = Convert.ToInt32(fila["IdCategoriaVehiculo"]);

                    // Basta con que tenga uno de los dos beneficios.
                    PlanActivo = TieneMembresiaActiva || TieneMensualidadActiva || Vip;

                    if(PlanActivo)
                    {
                        // Oculta el Grid completo
                        GrdPlan.Visibility = Visibility.Collapsed;

                        // Hace que la columna izquierda mida 0 para que GrdNivel se expanda por completo
                        ColPlan.Width = new GridLength(0);
                        //cambia tamaño formulario
                        this.Width = 450;
                    }
                    else
                    {
                        await TarifaPorTiempoDemanda("", 1, 30);
                    }
                }
                else
                {
                    await TarifaPorTiempoDemanda("", 1, 30);
                }
            }
        }
        private async Task NivelCeldas()
        {
            Nivel nivel = new Nivel();

            try
            {
                var ds = await nivel.SeleccionarNivelAsync();

                if (ds != null) // Si hay resultados
                {
                    CmbSeleccionarNivel.ItemsSource = ds.Tables[0].DefaultView;
                    CmbSeleccionarNivel.DisplayMemberPath = "Nombre";
                    CmbSeleccionarNivel.SelectedValuePath = "IdNivel";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CmbPlanVehiculo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbPlanVehiculo.SelectedValue != null && dtOriginal != null)
            {
                IdCelda = "";

                // Obtiene el número entero (ejemplo: 10)
                int idPlan = Convert.ToInt32(CmbPlanVehiculo.SelectedValue);

                // Filtra directamente en la tabla original: "IdPlan = 10"
                DataRow[] filasDelPlan = dtOriginal.Select($"IdPlan = {idPlan}");

                if (filasDelPlan.Length > 0)
                {
                    // Obtener las columnas de la primera fila encontrada
                    IdTipoVehiculo = Convert.ToInt32(filasDelPlan[0]["IdTipoVehiculo"]);
                    IdCategoriaVehiculo = Convert.ToInt32(filasDelPlan[0]["IdCategoriaVehiculo"]);
                    rtbInformacion.Document = GenerarTextoPlan(filasDelPlan);
                }
            }
        }


        private FlowDocument GenerarTextoPlan(DataRow[] filas)
        {
            FlowDocument doc = new FlowDocument
            {
                PagePadding = new Thickness(10),
                FontFamily = new FontFamily("Arial"),
                FontSize = 12
            };

            Paragraph p = new Paragraph
            {
                Margin = new Thickness(0),
                LineHeight = 16
            };

            // Fila base para los datos generales del plan y vehículo
            DataRow rowGeneral = filas[0];

            // --- 1. INFORMACIÓN DEL PLAN ---
            AgregarTitulo(p, "--- INFORMACIÓN DEL PLAN ---");
            AgregarLinea(p, "Nombre del Plan: ", rowGeneral["NombrePlan"]?.ToString());
            AgregarLinea(p, "Descripción Plan: ", rowGeneral["DescripcionPlan"]?.ToString());
            AgregarLinea(p, "Tipo de Plan: ", rowGeneral["NombreTipoPlan"]?.ToString());
            AgregarLinea(p, "Descripción Tipo Plan: ", rowGeneral["DescripcionTipoPlan"]?.ToString());

            p.Inlines.Add(new LineBreak());

            // --- 2. VEHÍCULO Y CATEGORÍA ---
            AgregarTitulo(p, "--- VEHÍCULO Y CATEGORÍA ---");
            AgregarLinea(p, "Categoría Vehículo: ", rowGeneral["NombreCategoriaVehiculo"]?.ToString());
            AgregarLinea(p, "Descripción Categoría: ", rowGeneral["DescripcionCategoriaVehiculo"]?.ToString());
            AgregarLinea(p, "Tipo de Vehículo: ", rowGeneral["NombreTipoVehiculo"]?.ToString());
            AgregarLinea(p, "Descripción Tipo Vehículo: ", rowGeneral["DescripcionTipoVehiculo"]?.ToString());

            p.Inlines.Add(new LineBreak());

            // --- 3. HORARIOS Y TARIFAS (Un solo título para todos los bloques) ---
            AgregarTitulo(p, "--- HORARIOS Y TARIFAS ---");

            for (int i = 0; i < filas.Length; i++)
            {
                DataRow row = filas[i];

                // Bloque Horario
                AgregarLinea(p, "Plan Horario: ", row["NombrePlanHorario"]?.ToString());
                AgregarLinea(p, "Hora Inicio: ", FormatearHoraAMPM(row["HoraInicio"]?.ToString()));
                AgregarLinea(p, "Hora Fin: ", FormatearHoraAMPM(row["HoraFin"]?.ToString()));

                p.Inlines.Add(new LineBreak());

                // --- Regla de cobro---
                if (row["UnidadCobro"]?.ToString() == "Hora")
                {
                    AgregarLinea(p, "Fracción Hora: ", row["MinutosFraccion"]?.ToString() + " Minuto(s)");
                    AgregarLinea(p, "Minutos Gratis: ", row["MinutosGracia"]?.ToString());
                }
                else
                {
                    AgregarLinea(p, "Fracción Hora: ", row["MinutosFraccion"]?.ToString() + " Minuto(s)");
                }

                p.Inlines.Add(new LineBreak()); // Espacio entre horario y sus tarifas

                // Bloque Tarifas
                AgregarLinea(p, "Valor Minuto: ", FormatearMoneda(row["ValorMinuto"]));
                AgregarLinea(p, "Valor Hora: ", FormatearMoneda(row["ValorHora"]));
                AgregarLinea(p, "Valor 12 Horas: ", FormatearMoneda(row["Valor12Horas"]));
                AgregarLinea(p, "Valor 24 Horas: ", FormatearMoneda(row["Valor24Horas"]));
                AgregarLinea(p, "Inicio Vigencia: ", FormatearFecha(row["FechaInicioVigencia"]?.ToString()));

                // Espacio entre diferentes bloques (ej: entre Diurno y Nocturno)
                if (i < filas.Length - 1)
                {
                    p.Inlines.Add(new LineBreak());
                }
            }

            doc.Blocks.Add(p);
            return doc;
        }

        // Métodos auxiliares
        private void AgregarTitulo(Paragraph p, string titulo)
        {
            Run runTitulo = new Run(titulo + "\n")
            {
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Navy,
                FontSize = 13.5
            };
            p.Inlines.Add(runTitulo);
        }

        private void AgregarLinea(Paragraph p, string etiqueta, string valor)
        {
            Run runEtiqueta = new Run(etiqueta) { FontWeight = FontWeights.Bold };
            Run runValor = new Run((valor ?? "") + "\n");

            p.Inlines.Add(runEtiqueta);
            p.Inlines.Add(runValor);
        }

        private string FormatearMoneda(object valor)
        {
            if (valor == null || valor == DBNull.Value || string.IsNullOrWhiteSpace(valor.ToString()))
                return "$ 0";

            if (decimal.TryParse(valor.ToString(), out decimal decVal))
            {
                return string.Format("$ {0:N0}", decVal).Replace(',', '.');
            }

            string str = valor.ToString();
            return str.StartsWith("$") ? str : $"$ {str}";
        }

        private string FormatearFecha(object valor)
        {
            if (valor == null || valor == DBNull.Value || string.IsNullOrWhiteSpace(valor.ToString()))
                return string.Empty;

            if (DateTime.TryParse(valor.ToString(), out DateTime fecha))
            {
                // Clonar la cultura en español para personalizar el AM / PM
                var culturaEs = (System.Globalization.CultureInfo)System.Globalization.CultureInfo.GetCultureInfo("es-ES").Clone();

                // Forzar explícitamente los designadores
                culturaEs.DateTimeFormat.AMDesignator = "AM";
                culturaEs.DateTimeFormat.PMDesignator = "PM";

                // Formato de 12 horas: hh:mm tt
                string fechaTexto = fecha.ToString("dddd, dd 'de' MMMM 'de' yyyy, hh:mm tt", culturaEs);

                // Capitalizar la primera letra del día ("martes" -> "Martes")
                return char.ToUpper(fechaTexto[0]) + fechaTexto.Substring(1);
            }

            return valor.ToString();
        }
        // Método auxiliar para convertir cualquier tipo de dato de hora a formato AM/PM
        private string FormatearHoraAMPM(object valorHora)
        {
            if (valorHora == null || valorHora == DBNull.Value)
                return string.Empty;

            if (valorHora is TimeSpan ts)
            {
                return DateTime.Today.Add(ts).ToString("hh:mm:ss tt", new System.Globalization.CultureInfo("en-US"));
            }
            else if (DateTime.TryParse(valorHora.ToString(), out DateTime dt))
            {
                return dt.ToString("hh:mm:ss tt", new System.Globalization.CultureInfo("en-US"));
            }

            return valorHora.ToString();
        }
        private async void CmbSeleccionarNivel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbSeleccionarNivel.SelectedValue != null)
            {
                IdCelda = "";

                // Obtener el ID del nivel
                int idNivel = Convert.ToInt32(CmbSeleccionarNivel.SelectedValue);

                // Obtener el texto visible del ítem seleccionado
                string nombreNivel = string.Empty;

                if (CmbSeleccionarNivel.SelectedItem is DataRowView drv)
                {
                    // Lee la columna configurada en DisplayMemberPath (ej. "NombreNivel")
                    string campoTexto = CmbSeleccionarNivel.DisplayMemberPath;
                    nombreNivel = drv[campoTexto]?.ToString();
                }
                else if (CmbSeleccionarNivel.SelectedItem != null)
                {
                    nombreNivel = CmbSeleccionarNivel.SelectedItem.ToString();
                }

                // Asignar al TextBlock
                TbNivel.Text = "Nivel: " + nombreNivel;

                // Cargar celdas
                await CargarCeldasAsync(idNivel);
            }
        }
        // Obtiene las celdas por nivel y su estado actual de estas
        public async Task CargarCeldasAsync(int idNivel)
        {
            try
            {
                Celda celda = new Celda();
                var dt = await celda.ObtenerCeldasPorNivelAsync(idNivel);

                wpCeldas.Children.Clear();
                botonSeleccionadoAnterior = null; // Reiniciar selección

                TbCantidadCeldas.Text = "Cantidad de Celdas: " + dt.Tables[0].Rows.Count;

                foreach (DataRow row in dt.Tables[0].Rows)
                {
                    int IdCelda = Convert.ToInt32(row["IdCelda"]);
                    string Codigo = row["Codigo"].ToString();
                    string Estado = row["Estado"].ToString();
                    string IdEstadoCelda = row["IdEstadoCelda"].ToString();
                    Color Color = (Color)ColorConverter.ConvertFromString(IdEstadoCelda == "1" ? "#57aa3c" : (IdEstadoCelda == "2" ? "#fda603" : "#c2c2c2"));
                    Button btn = new Button()
                    {
                        Width = 88,
                        Height = 40,
                        Content = Codigo,
                        Tag = IdCelda,
                        ToolTip = Estado,
                        Style = (Style)FindResource("CellButton"),
                        Background = new SolidColorBrush(Color)
                    };

                    if(IdEstadoCelda == "2" || IdEstadoCelda == "3")
                    {
                        btn.IsEnabled = false;
                    }
                    btn.Click += BtnCelda_Click;
                    
                    wpCeldas.Children.Add(btn);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al obtener celdas.\n{ex.Message}", "Celdas", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private async void BtnCelda_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sender is Button btn)
                {
                    if (btn == null) return;
                    // Si pulsamos el mismo botón que ya estaba seleccionado, no hace falta procesar de nuevo
                    if (btn == botonSeleccionadoAnterior) return;

                    // Regresar el botón anterior a su color habitua/disponible
                    if (botonSeleccionadoAnterior != null)
                    {
                        botonSeleccionadoAnterior.Background = colorDisponible;
                    }

                    // Pintar el botón actual con el color de seleccionado
                    btn.Background = colorSeleccionado;

                    // Actualizar la variable para la próxima interacción
                    botonSeleccionadoAnterior = btn;

                    // --- Aquí puedes agregar tu código adicional (ej. obtener el identificador de la celda) ---
                    IdCelda = btn.Tag.ToString();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener información en la celda: " + ex.Message);
            }
        }

        private async void BtnAceptar_Click(object sender, RoutedEventArgs e)
        {
            if(CmbPlanVehiculo.SelectedIndex == -1 && PlanActivo == false)
            {
                MessageBox.Show("Seleccionar tarifa para ingreso de vehículo","Ingreso Vehículo", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbPlanVehiculo.Focus();
                return;
            }
            if (IdCelda == "")
            {
                MessageBox.Show("Seleccionar celda para ingreso de vehículo", "Ingreso Vehículo", MessageBoxButton.OK, MessageBoxImage.Information);
                wpCeldas.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar usuario
                Movimientos movimientos = new Movimientos();
                //Igresar nuevo usuario
                if (await movimientos.RegistrarEntradaVehiculoAsync(TbPlaca.Text.Trim(), IdTipoVehiculo.ToString(), IdCategoriaVehiculo.ToString(), IdCelda, MainWindow.IdUsuario))
                {
                    entradaSalida.TxtPlaca.Text = "";
                    entradaSalida.TxtPlaca.Focus();
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                    // actualiza el datagrid
                    entradaSalida.MovimientosVehiculos();
                    this.Close();
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }
    }
}