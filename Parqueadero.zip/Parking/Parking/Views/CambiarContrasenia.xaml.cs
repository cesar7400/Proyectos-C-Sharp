﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using static Parking.Views.Login;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para CambiarContraseniaxaml.xaml
    /// </summary>
    public partial class CambiarContrasenia : Window, IFormLogin
    {
        public CambiarContrasenia(Login login)
        {
            InitializeComponent();
            this.login = login;
        }
        readonly Login login;
        private string strUsuarioID = "";
        private string Usuario = "";
        private string NombreCompleto = "";
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            TxtPassword.Focus();
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void PreviewTextInputTextLetters(object sender, TextCompositionEventArgs e)
        {
            // Crea una instancia de la biblioteca de utilidades
            Library library = new Library();
            // Llama al método que permite solo letras
            library.Letters(sender, e);
        }
        private void TxtEspacio_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Si la tecla presionada es el espacio, cancelamos el evento
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }
        private void ValidarComillas(object sender, TextCompositionEventArgs e)
        {
            // Si el texto que intenta ingresar es una comilla simple o doble
            if (e.Text == "'" || e.Text == "\"")
            {
                e.Handled = true; // Aquí le decimos a WPF: "No proceses esta tecla"
            }
        }
        private void TxtPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            PasswordBox pb = (PasswordBox)sender;
            // Buscamos el TextBlock del placeholder dentro del Template
            var template = pb.Template;
            var placeholder = (TextBlock)template.FindName("placeHolderTextBlock", pb);

            if (placeholder != null)
            {
                // Si hay texto, ocultamos el Tag. Si está vacío, lo mostramos.
                placeholder.Visibility = string.IsNullOrEmpty(pb.Password)
                                         ? Visibility.Visible
                                         : Visibility.Collapsed;
            }
        }
        public void SetData(List<KeyValuePair<string, string>> data)
        {
            //ID del usuario
            strUsuarioID = data[0].Value.ToString();
            Usuario = data[1].Value.ToString();
            NombreCompleto = data[2].Value.ToString();
        }
        private async void BtnCambiar_Click(object sender, RoutedEventArgs e)
        {
            // Cambiar cursor a espera
            Mouse.OverrideCursor = Cursors.Wait;

            string password = TxtPassword.Password.Trim().ToLower().Replace("'", "").Replace("\"", "");
            string passwordR = TxtPasswordR.Password.Trim().ToLower().Replace("'", "").Replace("\"", "");

            // Validar contraseña
            if (string.IsNullOrWhiteSpace(password))
            {
                // Cambiar cursor a estado normal
                Mouse.OverrideCursor = null;
                MessageBox.Show("Ingrese contraseña.", "Cambio contraseña", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPassword.Focus();
                return;
            }

            // Validar contraseña
            else if (string.IsNullOrWhiteSpace(passwordR))
            {
                // Cambiar cursor a estado normal
                Mouse.OverrideCursor = null;
                MessageBox.Show("Ingrese contraseña.", "Cambio contraseña", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPasswordR.Focus();
                return;
            }
            else if (TxtPassword.Password.Length < 8)
            {
                // Cambiar cursor a estado normal
                Mouse.OverrideCursor = null;
                MessageBox.Show("Contraseña debe tener mínimo ocho caracteres", "Cambio contraseña", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPassword.Focus();
                return;
            }
            else if (TxtPasswordR.Password.Length < 8)
            {
                // Cambiar cursor a estado normal
                Mouse.OverrideCursor = null;
                MessageBox.Show("Contraseña debe tener mínimo ocho caracteres", "Cambio contraseña", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPasswordR.Focus();
                return;
            }
            else if (TxtPassword.Password.Trim().ToLower() != TxtPasswordR.Password.Trim().ToLower())
            {
                // Cambiar cursor a estado normal
                Mouse.OverrideCursor = null;
                MessageBox.Show("Contraseña no coincide", "Cambio contraseña", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPasswordR.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de actualuzar usuario
                UsuariosController usuariosController = new UsuariosController();
                //Actualizar usuario
                if (await usuariosController.UpdatePasswdAsync(strUsuarioID, TxtPassword.Password.Trim().ToLower(), Usuario, NombreCompleto))
                {
                    login.TxtPassword.Clear();
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show("Contraseña cambiada correctamente", "Cambio contraseña", MessageBoxButton.OK, MessageBoxImage.Information);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                    this.Close();
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }
    }
}