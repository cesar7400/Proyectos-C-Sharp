﻿using System;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para TiempoDemandaInfo.xaml
    /// </summary>
    public partial class TiempoDemandaInfo : Window
    {
        public TiempoDemandaInfo()
        {
            InitializeComponent();
            // Nos suscribimos para escuchar cuándo cambia o llega el DataContext
            this.DataContextChanged += VerInfoPlan_DataContextChanged;
        }
        public string IdPlanTarifa { get; set; }
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana
        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private async void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        private async void VerInfoPlan_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            InfoPlan();
        }
        private async void InfoPlan()
        {
            var miContexto = this.DataContext;

            if (miContexto != null && miContexto is DataRowView view)
            {
                DataTable tablaData = view.Row.Table;

                // Obtenemos el IdPlan para recuperar todas sus tarifas y horarios asociados
                string idPlan = Convert.ToString(view.Row["IdPlan"]);

                var filasPlan = tablaData.AsEnumerable()
                    .Where(r => Convert.ToString(r["IdPlan"]) == idPlan)
                    .ToList();

                if (filasPlan.Count > 0)
                {
                    DataRow filaPrincipal = filasPlan[0];

                    FlowDocument doc = new FlowDocument
                    {
                        PagePadding = new Thickness(10),
                        FontFamily = new FontFamily("Arial"),
                        FontSize = 12
                    };

                    // Función auxiliar para títulos de sección en un párrafo independiente
                    void AgregarTitulo(string texto)
                    {
                        doc.Blocks.Add(new Paragraph(new Run(texto))
                        {
                            FontWeight = FontWeights.Bold,
                            FontSize = 13,
                            Margin = new Thickness(0, 10, 0, 2)
                        });
                    }

                    // Función auxiliar para cada línea de texto en un párrafo independiente
                    void AgregarCampo(string etiqueta, string valor)
                    {
                        Paragraph p = new Paragraph { Margin = new Thickness(0, 0, 0, 2) };
                        p.Inlines.Add(new Run(etiqueta) { FontWeight = FontWeights.Bold });
                        p.Inlines.Add(new Run($" {valor}"));
                        doc.Blocks.Add(p);
                    }

                    // ================= 1. INFORMACIÓN DEL PLAN =================
                    AgregarTitulo("Información del plan");
                    AgregarCampo("Tipo de Plan:", filaPrincipal.Field<string>("NombreTipoPlan"));
                    AgregarCampo("Plan:", filaPrincipal.Field<string>("NombrePlan"));
                    AgregarCampo("Descripción:", filaPrincipal.Field<string>("DescripcionPlan"));
                    bool estadoPlan = filaPrincipal.Field<bool>("EstadoPlan");
                    AgregarCampo("Estado:", estadoPlan ? "Activo" : "Inactivo");

                    // ================= 2. HORARIOS =================
                    var horariosUnicos = filasPlan
                        .GroupBy(r => r["NombrePlanHorario"])
                        .Select(g => g.First());

                    foreach (var fila in horariosUnicos)
                    {
                        AgregarTitulo("Horario");
                        AgregarCampo("Nombre:", fila.Field<string>("NombrePlanHorario"));

                        var horaInicio = DateTime.Today.Add(TimeSpan.Parse(fila["HoraInicio"].ToString())).ToString("hh:mm tt", System.Globalization.CultureInfo.InvariantCulture);
                        var horaFin = DateTime.Today.Add(TimeSpan.Parse(fila["HoraFin"].ToString())).ToString("hh:mm tt", System.Globalization.CultureInfo.InvariantCulture);

                        AgregarCampo("Hora inicio:", horaInicio);
                        AgregarCampo("Hora fin:", horaFin);

                        string unidadCobro = fila.Field<string>("UnidadCobro");
                        AgregarCampo("Unidad de cobro:", unidadCobro);

                        if (unidadCobro == "Minuto")
                        {
                            AgregarCampo("Cantidad:", fila.Field<int>("MinutosFraccion").ToString());
                        }
                        else
                        {
                            AgregarCampo("Fracción de tiempo:", fila.Field<int>("MinutosFraccion").ToString());
                            AgregarCampo("Minutos gratis:", fila.Field<int>("MinutosGracia").ToString());
                        }

                        AgregarCampo("Días:", fila.Field<string>("DiasSemana").ToString());
                    }

                    // ================= 3. TARIFAS =================
                    foreach (var fila in filasPlan)
                    {
                        AgregarTitulo("Tarifas "+ fila.Field<string>("NombrePlanHorario"));
                        AgregarCampo("Valor por minuto:", fila.Field<string>("ValorMinuto"));
                        AgregarCampo("Valor por hora:", fila.Field<string>("ValorHora"));
                        AgregarCampo("Valor 12 horas:", fila.Field<string>("Valor12Horas"));
                        AgregarCampo("Valor 24 horas:", fila.Field<string>("Valor24Horas"));
                        bool estadoTarifa = fila.Field<bool>("EstadoPlanTarifa");
                        AgregarCampo("Estado:", estadoTarifa ? "Activo" : "Inactivo");
                    }

                    // ================= 4. TIPO Y CATEGORÍA DE VEHÍCULO =================
                    AgregarTitulo("Tipo y categoría de vehículo");
                    AgregarCampo("Tipo de vehículo:", filaPrincipal.Field<string>("NombreTipoVehiculo"));
                    AgregarCampo("Descripción:", filaPrincipal.Field<string>("DescripcionTipoVehiculo"));
                    AgregarCampo("Categoría vehículo:", filaPrincipal.Field<string>("NombreCategoriaVehiculo"));
                    AgregarCampo("Descripción:", filaPrincipal.Field<string>("DescripcionCategoriaVehiculo"));

                    // Asignar el documento al RichTextBox
                    RtbInfoPlan.Document = doc;
                }
            }
        }
    }
}