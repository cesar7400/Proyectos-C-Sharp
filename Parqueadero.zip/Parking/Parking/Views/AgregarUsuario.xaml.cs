﻿using Parking.Models;
using Parking.Controller;
using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para AgregarUsuario.xaml
    /// </summary>
    public partial class AgregarUsuario : Window
    {
        public AgregarUsuario(Usuarios usuarios)
        {
            InitializeComponent();
            this.usuarios = usuarios;
            TxtUsuario.Focus();
        }
        readonly Usuarios usuarios;
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void PreviewTextInputTextLetters(object sender, TextCompositionEventArgs e)
        {
            // Crea una instancia de la biblioteca de utilidades
            Library library = new Library();
            // Llama al método que permite solo letras
            library.Letters(sender, e);
        }
        private void TxtPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            PasswordBox pb = (PasswordBox)sender;
            // Buscamos el TextBlock del placeholder dentro del Template
            var template = pb.Template;
            var placeholder = (TextBlock)template.FindName("placeHolderTextBlock", pb);

            if (placeholder != null)
            {
                // Si hay texto, ocultamos el Tag. Si está vacío, lo mostramos.
                placeholder.Visibility = string.IsNullOrEmpty(pb.Password)
                                         ? Visibility.Visible
                                         : Visibility.Collapsed;
            }
        }
        private void TxtUsuario_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Si la tecla presionada es el espacio, cancelamos el evento
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }
        private void ValidarComillas(object sender, TextCompositionEventArgs e)
        {
            // Si el texto que intenta ingresar es una comilla simple o doble
            if (e.Text == "'" || e.Text == "\"")
            {
                e.Handled = true; // Aquí le decimos a WPF: "No proceses esta tecla"
            }
        }
        private byte ObtenerDiasSeleccionados()
        {
            byte dias = 0;

            if (ChkLunes.IsChecked == true) dias |= 1;
            if (ChkMartes.IsChecked == true) dias |= 2;
            if (ChkMiercoles.IsChecked == true) dias |= 4;
            if (ChkJueves.IsChecked == true) dias |= 8;
            if (ChkViernes.IsChecked == true) dias |= 16;
            if (ChkSabado.IsChecked == true) dias |= 32;
            if (ChkDomingo.IsChecked == true) dias |= 64;

            return dias;
        }
        private async void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {

            // Validaciones de campos obligatorios y formato de email
            if (TxtUsuario.Text == string.Empty)
            {
                MessageBox.Show("Ingresar usuario", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtUsuario.Focus();
                return;
            }
            else if (TxtNombres.Text == string.Empty)
            {
                MessageBox.Show("Ingresar nombres", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtNombres.Focus();
                return;
            }
            else if (TxtPassword.Password == string.Empty)
            {
                MessageBox.Show("Ingresar contraseña", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPassword.Focus();
                return;
            }
            else if (TxtPassword.Password.Length < 8)
            {
                MessageBox.Show("Contraseña debe tener mínimo ocho caracteres", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPassword.Focus();
                return;
            }
            else if (TxtPasswordR.Password == string.Empty)
            {
                MessageBox.Show("Ingresar contraseña", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPasswordR.Focus();
                return;
            }
            else if (TxtPasswordR.Password.Length < 8)
            {
                MessageBox.Show("Contraseña debe tener mínimo ocho caracteres", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPasswordR.Focus();
                return;
            }
            else if (TxtPassword.Password.Trim().ToLower() != TxtPasswordR.Password.Trim().ToLower())
            {
                MessageBox.Show("Contraseña no coincide", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPasswordR.Focus();
                return;
            }
            else if (ChkLunes.IsChecked == false && ChkMartes.IsChecked == false && ChkMiercoles.IsChecked == false && ChkJueves.IsChecked == false && ChkViernes.IsChecked == false && ChkSabado.IsChecked == false && ChkDomingo.IsChecked == false)
            {
                MessageBox.Show("Seleccionar uno o varios días", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Information); // Valida que se haya seleccionado al menos un día
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar usuario
                UsuariosController usuariosController = new UsuariosController();
                byte dias = ObtenerDiasSeleccionados();
                //Igresar nuevo usuario
                if (await usuariosController.NuevoUsuario(TxtUsuario.Text.Trim().ToLower(), TxtNombres.Text.Trim().ToLower(), TxtPasswordR.Password.Trim().ToLower(), dias, RdActivo.IsChecked == true ? "1" : "0", MainWindow.IdUsuario))
                {
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show($"Usuario '{TxtUsuario.Text.Trim().ToLower()}' con nombre '{TxtNombres.Text.Trim().ToLower()}' se guardo correctamente", "Nuevo Usuario", MessageBoxButton.OK, MessageBoxImage.Information);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                    // actualiza el datagrid
                    usuarios.CargarUsuarios(usuarios.TxtBuscarUsuario.Text.Trim(), usuarios.currentPage, usuarios.pageSize);
                    this.Close();
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            // Limpia Controles
            TxtUsuario.Text = string.Empty;
            TxtNombres.Text = string.Empty;
            TxtPassword.Clear();
            TxtPasswordR.Clear();
            ChkLunes.IsChecked = false;
            ChkMartes.IsChecked = false;
            ChkMiercoles.IsChecked = false;
            ChkJueves.IsChecked = false;
            ChkViernes.IsChecked = false;
            ChkSabado.IsChecked = false;
            ChkDomingo.IsChecked = false;
            RdActivo.IsChecked = true;
            RdInactivo.IsChecked = false;
        }
    }
}