﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para Auditoria.xaml
    /// </summary>
    public partial class Auditoria : Page
    {
        public Auditoria()
        {
            InitializeComponent();
        }
        // Propiedades para manejar la paginación y búsqueda de usuarios
        public int currentPage = 1;    // Página actual (inicia en 1)
        public int pageSize = 30;      // Cantidad de registros por página
        public int totalRecords = 0;   // Total de usuarios que coinciden con la búsqueda
        public int totalPages = 0;     // Total de páginas calculadas
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Usuarios();
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Obtiene la ventana que contiene esta página
            var window = Window.GetWindow(this);
            if (window is MainWindow mainWindow)
            {
                // Limpia el contenido del contenedor principal (fContainer)
                mainWindow.ContenedorPrincipal.Content = null;
            }
        }

        private async void Usuarios()
        {
            UsuariosController usuariosController = new UsuariosController();

            var dt = await usuariosController.UsuariosAsync();
            if (dt != null) // Si hay resultados
            {
                DataTable _dt = dt.Tables[0].Copy();
                DataRow fila = _dt.NewRow();
                fila["UsuarioID"] = DBNull.Value;
                fila["Usuario"] = "-- Todos los Usuarios --";

                _dt.Rows.InsertAt(fila, 0);
                CmbUsuario.ItemsSource = _dt.DefaultView;
                CmbUsuario.DisplayMemberPath = "Usuario"; // Muestra el nombre del usuario
                CmbUsuario.SelectedValuePath = "UsuarioID"; // El valor seleccionado será el ID
                CmbUsuario.SelectedIndex = 0;
            }

            Permisos permisos = new Permisos();

            // 1. Validar permisos para el módulo "auditoría"
            bool puedeEliminar = permisos.TienePermiso("Auditoría", "Eliminar Auditoría");
            // 2. Aplicar visibilidad a los GroupBox
            if (BtnVaciarAuditoria != null)
                BtnVaciarAuditoria.Visibility = puedeEliminar ? Visibility.Visible : Visibility.Collapsed;
        }
        private async void AuditoriaLog(int pageNumber, int pageSize)
        {
            try
            {
                int? idUsuario = null;

                if (CmbUsuario.SelectedValue != null && CmbUsuario.SelectedValue != DBNull.Value)
                {
                    idUsuario = Convert.ToInt32(CmbUsuario.SelectedValue);
                }

                DateTime? fechaInicio = DtpFechaDesde.SelectedDate;
                DateTime? fechaFin = DtpFechaHasta.SelectedDate;

                AuditoriaController auditoriaController = new AuditoriaController();
                var dt = await auditoriaController.ObtenerAuditoriaFiltradaAsync(pageNumber, pageSize, idUsuario, fechaInicio, fechaFin);

                if (dt != null) // Si hay resultados
                {
                    int maxRowsToShow = 30; // Número máximo de filas a mostrar en pantalla

                    // Verifica si la tabla 0 (registros) tiene filas
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        // Obtiene el total de registros de la segunda tabla (índice 1)
                        totalRecords = int.Parse(dt.Tables[1].Rows[0][0].ToString());
                        //muestra cantidad de registros encontrados
                        TxtRegistro.Text = totalRecords + (totalRecords == 1 ? " Registro" : " Registros");

                        // Calcula el total de páginas
                        totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                        TxtCantidadRegistros.Text = "Cantidad total de registro(s): " + (dt.Tables[2].Rows[0][0].ToString());
                        // Toma hasta maxRowsToShow filas para mostrar (evita cargar más de 30 aunque pageSize sea mayor)
                        var rowsToShow = dt.Tables[0]
                                           .AsEnumerable()
                                           .Take(maxRowsToShow)
                                           .CopyToDataTable();

                        // Asigna la fuente de datos del DataGrid a la vista por defecto del DataTable
                        dgAuditoria.ItemsSource = rowsToShow.DefaultView;
                        // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                        dgAuditoria.CanUserSortColumns = false;

                        // Habilita o deshabilita los botones de navegación según la página actual
                        BtnAnterior.IsEnabled = currentPage > 1;
                        TxtAnterior.Visibility = (currentPage > 1) ? Visibility.Visible : Visibility.Collapsed;
                        BtnSiguiente.IsEnabled = (currentPage * pageSize) < totalRecords;
                        TxtSiguiente.Visibility = (currentPage * pageSize) < totalRecords ? Visibility.Visible : Visibility.Collapsed;
                        // Actualiza el texto que muestra "Página X de Y"
                        TxtPagina.Text = "Página " + currentPage + " de " + totalPages;

                        // Muestra u oculta los íconos de flecha según correspondan
                        ImgAnterior.Visibility = (currentPage > 1 ? Visibility.Visible : Visibility.Hidden);
                        ImgSiguiente.Visibility = ((currentPage * pageSize) < totalRecords ? Visibility.Visible : Visibility.Hidden);
                    }
                    else
                    {
                        // Si no hay filas, resetea totales y muestra mensaje de página vacía
                        totalRecords = 0;
                        TxtRegistro.Text = totalRecords.ToString() + " Registros";
                        dt.Clear();
                        dgAuditoria.ItemsSource = dt.Tables[0].DefaultView;
                        TxtPagina.Text = "Página 0 de 0";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar auditoría: " + ex.Message);
            }
        }
        private async void BtnBuscar_Click(object sender, RoutedEventArgs e)
        {
            currentPage = 1;
            AuditoriaLog(currentPage, pageSize);
        }

        private void BtnAnterior_Click(object sender, RoutedEventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--; // Disminuye el número de página
                AuditoriaLog(currentPage, pageSize);
                TxtPagina.Text = "Página " + currentPage + " de " + totalPages;
            }
        }

        private void BtnSiguiente_Click(object sender, RoutedEventArgs e)
        {
            if ((currentPage * pageSize) < totalRecords)
            {
                currentPage++; // Aumenta el número de página
                AuditoriaLog(currentPage, pageSize);
                TxtPagina.Text = "Página " + currentPage + " de " + totalPages;
            }
        }

        private async void BtnVaciarAuditoria_Click(object sender, RoutedEventArgs e)
        {
            AuditoriaController auditoriaController = new AuditoriaController();

            //Pregunta antes de proceder a eliminar usuario
            MessageBoxResult messageBoxResult = MessageBox.Show($"¿Eliminar auditoría?\nNota: Una vez eliminada ya no es posible recuperar.\n¿Desea continuar?", "Elimina Auditoría", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                if (await auditoriaController.DeleteAuditoriaAsync(MainWindow.IdUsuario))
                {
                    currentPage = 1;
                    AuditoriaLog(currentPage, pageSize);
                }
            }
        }
    }
}