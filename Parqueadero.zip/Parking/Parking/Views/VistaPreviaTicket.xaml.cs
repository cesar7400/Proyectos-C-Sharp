﻿using Parking.Models;
using System;
using System.Data;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para VistaPreviaTicket.xaml
    /// </summary>
    public partial class VistaPreviaTicket : Window
    {
        public VistaPreviaTicket()
        {
            InitializeComponent();
        }
        public string IdTicket { get; set; }
        public string Tipo { get; set; }
        readonly TicketVistaPrevia ticketVistaPrevia = new TicketVistaPrevia();

        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana
        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private async void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            //DiccionarioEmpresa = await Configuracion.dEmpresa();
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
            
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RtbTicketPreview.Document = await ticketVistaPrevia.PreviewTicket(IdTicket, DatosTicket());
        }

        private DataSet DatosTicket()
        {
            // Obtener la fecha y hora actual del sistema
            DateTime fechaActual = DateTime.Now;

            // Crear la cultura en español
            CultureInfo culturaEsFechaActual = new CultureInfo("es-ES");

            // Aplicar el formato personalizado
            string resultadoFechaActual = fechaActual.ToString("dddd, d 'de' MMMM 'de' yyyy, hh:mm tt", culturaEsFechaActual);

            // Obtener la fecha de ayer (hoy menos 1 día)
            DateTime ayer = DateTime.Now.AddDays(-1);

            // Crear la cultura en español
            CultureInfo culturaEsAyer = new CultureInfo("es-ES");

            // Aplicar el formato personalizado
            string resultadoAyer = ayer.ToString("dddd, d 'de' MMMM 'de' yyyy, hh:mm tt", culturaEsAyer);

            // 1. Definir exactamente el mismo formato que usaste para crearlas
            string formato = "dddd, d 'de' MMMM 'de' yyyy, hh:mm tt";
            CultureInfo culturaEs = new CultureInfo("es-ES");

            // 2. Convertir los strings de vuelta a DateTime
            DateTime fecha1Parsed = DateTime.ParseExact(resultadoFechaActual, formato, culturaEs);
            DateTime fecha2Parsed = DateTime.ParseExact(resultadoAyer, formato, culturaEs);

            // 3. Restar los objetos DateTime recuperados
            TimeSpan diferencia = fecha1Parsed - fecha2Parsed;

            // 4. Obtener horas totales y minutos
            int horasTotales = (int)diferencia.TotalHours;
            int minutos = diferencia.Minutes;
            string Placa = "ABC 012";

            DataTable dtInfo = new DataTable();//{{NUMERO TICKET}} {{PLACA VEHICULO}}
            dtInfo.Columns.Add("NUMERO TICKET", typeof(string));
            dtInfo.Columns.Add("PLACA VEHICULO", typeof(string));
            dtInfo.Rows.Add("Ticket Número: 000000000", $"Placa: {Placa}");

            DataTable dtDatos = new DataTable();//{{ITEM}}
            dtDatos.Columns.Add("Tarifa", typeof(string));
            dtDatos.Columns.Add("Entrada", typeof(string));
            dtDatos.Columns.Add("Salida", typeof(string));
            dtDatos.Columns.Add("Tiempo", typeof(string));
            dtDatos.Columns.Add("Usuario", typeof(string));
            dtDatos.Columns.Add("Medio Pago", typeof(string));
            dtDatos.Columns.Add("IVA", typeof(string));
            dtDatos.Columns.Add("SubTotal", typeof(string));
            dtDatos.Columns.Add("Total", typeof(string));
            dtDatos.Rows.Add("Automovil", resultadoAyer, resultadoFechaActual, $"{horasTotales} hora(s) y {minutos} minuto(s)", "Usuario", "Efectivo", "19%", "1234567890", "1234567890");
            
            DataSet ds = new DataSet();
            ds.Tables.Add(dtInfo);
            ds.Tables.Add(dtDatos);
            return ds;
        }
    }
}