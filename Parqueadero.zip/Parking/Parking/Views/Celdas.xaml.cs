﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using static Parking.Views.Niveles;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para Celdas.xaml
    /// </summary>
    public partial class Celdas : Window, IFormCeldas
    {
        public class InfoVehiculo
        {
            public int IdCelda { get; set; }
            public string FechaEntrada { get; set; }
            public bool Estado { get; set; }
            public string Placa { get; set; }
            public string Nombre { get; set; }
        }
        private readonly DispatcherTimer timer = new DispatcherTimer();
        private string IdCelda = "";
        private string StrCodigo = "";
        private int IdNivel;
        private string IdEstadoNivel;
        public Celdas(Niveles niveles)
        {
            InitializeComponent();
            this.niveles = niveles;
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Permisos permisos = new Permisos();

            // 1. Validar permisos para el módulo "Celdas"
            bool puedeAgregarCelda = permisos.TienePermiso("Celdas", "Agregar Celdas");
            // 2. Aplicar visibilidad a los GroupBox
            if (GrpCelda != null)
                GrpCelda.Visibility = puedeAgregarCelda ? Visibility.Visible : Visibility.Collapsed;
        }
        readonly Niveles niveles;
        List<InfoVehiculo> LstInfoVehiculo = new List<InfoVehiculo>();
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void PreviewTextInputNumbers(object sender, TextCompositionEventArgs e)
        {
            Library clsLibrary = new Library(); // Instancia de librería auxiliar
            clsLibrary.Numbers(sender, e); // Permite solo números en el TextBox
        }
        private void Txt_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true; // Evita que la tecla Espacio genere un carácter
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }
        public async void SetData(int idNivel, string Nivel, string IdEstadoNivel)
        {
            if(IdEstadoNivel == "2")
            {
                this.IdEstadoNivel = IdEstadoNivel;
                CmbEstado.IsEnabled = false;
                BtnCambiarEstado.IsEnabled = false;
                BtnCambiarEstado.Background = (Brush)new BrushConverter().ConvertFromString("#C2C2C2");
            }
            IdNivel = idNivel;
            // Configurar el Temporizador para refrescar automáticamente cada 5 segundos
            var timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            TbNivel.Text = "Nivel: " + Nivel;
            // Se quita el 'await' de aquí
            timer.Tick += async (s, args) => await CargarCeldasAsync(idNivel);

            timer.Start();
        }
        // Obtiene las celdas por nivel y su estado actual de estas
        public async Task CargarCeldasAsync(int idNivel)
        {
            try
            {
                Celda celda = new Celda();
                var dt = await celda.ObtenerCeldasPorNivelAsync(idNivel);
                //se guardan los datos de los vehiculos en la lista de vehiculos en celda(s)
                LstInfoVehiculo = dt.Tables[1].AsEnumerable().Select(fila => new InfoVehiculo
                {
                    IdCelda = fila.Field<int>("IdCelda"),
                    FechaEntrada = fila.Field<string>("FechaEntrada"),
                    Estado = fila.Field<bool>("Estado"),
                    Placa = fila.Field<string>("Placa"),
                    Nombre = fila.Field<string>("Nombre")
                }).ToList();

                wpCeldas.Children.Clear();

                TbCantidadCeldas.Text = "Cantidad de Celdas: " + dt.Tables[0].Rows.Count;
                
                foreach (DataRow row in dt.Tables[0].Rows)
                {
                    int IdCelda = Convert.ToInt32(row["IdCelda"]);
                    string Codigo = row["Codigo"].ToString();
                    string Estado = row["Estado"].ToString();
                    string IdEstadoCelda = row["IdEstadoCelda"].ToString();
                    Color Color = (Color)ColorConverter.ConvertFromString(IdEstadoCelda == "1" ? "#57aa3c" : (IdEstadoCelda == "2" ? "#fda603" : "#c2c2c2"));
                    Button btn = new Button()
                    {
                        Width = 88,
                        Height = 40,
                        Content = Codigo,
                        Tag = IdCelda,
                        ToolTip = Estado,
                        Style = (Style)FindResource("CellButton"),
                        Background = new SolidColorBrush(Color)
                    };
                    btn.Click += BtnCelda_Click;
                    wpCeldas.Children.Add(btn);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al obtener celdas.\n{ex.Message}", "Celdas", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        public async Task EstadoCeldas()
        {
            Celda celda = new Celda();
            try
            {
                var dt = await celda.EstadoCeldasAsync();

                if (dt != null) // Si hay resultados
                {
                    CmbEstado.ItemsSource = dt.Tables[0].DefaultView;
                    CmbEstado.DisplayMemberPath = "Nombre";
                    CmbEstado.SelectedValuePath = "IdEstadoCelda";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async void BtnCelda_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sender is Button btn)
                {
                    if (btn == null) return;
                    await EstadoCeldas();
                    if (btn.ToolTip.ToString() == "Ocupada")
                    {
                        CmbEstado.IsEnabled = false;
                        BtnCambiarEstado.Visibility = Visibility.Collapsed;
                    }
                    else
                    {
                        CmbEstado.IsEnabled = IdEstadoNivel != "2";
                        BtnCambiarEstado.Visibility = Visibility.Visible;
                        CmbEstado.Text = btn.ToolTip?.ToString() ?? "";
                    }

                    TxtCodigo.Text = btn.Content.ToString();
                    TxtEstado.Text = btn.ToolTip?.ToString() ?? "";
                    StrCodigo = btn.Content.ToString();
                    // Busca el primer elemento que coincida con el IdCelda del botón clickeado y lo asigna a InfoVehiculo
                    InfoVehiculo InfoVehiculo = LstInfoVehiculo.FirstOrDefault(p => p.IdCelda == int.Parse(btn.Tag?.ToString() ?? "0"));
                    IdCelda = btn.Tag?.ToString() ?? "";
                    if (InfoVehiculo != null)
                    {
                        TxtVehiculo.Text = InfoVehiculo.Placa;
                        TxtTipo.Text = InfoVehiculo.Nombre;
                        TxtFechaEntrada.Text = InfoVehiculo.FechaEntrada;
                    }
                    else
                    {
                        TxtVehiculo.Text = "";
                        TxtTipo.Text = "";
                        TxtFechaEntrada.Text = "";
                    }
                    if (BtnCambiarEstado.IsEnabled == true)
                    {
                        CmbEstado.IsEnabled = true;
                    }
                    else
                    {
                        CmbEstado.IsEnabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener información en la celda: " + ex.Message);
            }
        }
        private async void BtnAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (TxtPrefijo.Text == "")
            {
                MessageBox.Show("Digite un prefijo válido.", "Agregar Celdas", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPrefijo.Focus();
                return;
            }
            if (!int.TryParse(txtInicio.Text.Trim(), out int inicio))
            {
                MessageBox.Show("Digite un número inicial válido.", "Agregar Celdas", MessageBoxButton.OK, MessageBoxImage.Information);
                txtInicio.Focus();
                return;
            }

            if (!int.TryParse(txtFin.Text.Trim(), out int fin))
            {
                MessageBox.Show("Digite un número final válido.", "Agregar Celdas", MessageBoxButton.OK, MessageBoxImage.Information);
                txtFin.Focus();
                return;
            }

            if (inicio > fin)
            {
                MessageBox.Show("El número inicial no puede ser mayor que el número final.", "Agregar Celdas", MessageBoxButton.OK, MessageBoxImage.Information);
                txtInicio.Focus();
                txtInicio.SelectAll();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;

                Celda celda = new Celda();

                if (await celda.CrearCeldas(IdNivel, TxtPrefijo.Text.Trim().ToUpper(), txtInicio.Text.Trim(), txtFin.Text.Trim(), MainWindow.IdUsuario))
                {
                    await CargarCeldasAsync(IdNivel);
                    await niveles.ListaNiveles();
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
            // Cambiar cursor a normal
            Mouse.OverrideCursor = null;
        }
        private async void BtnCambiarEstado_Click(object sender, RoutedEventArgs e)
        {
            if (CmbEstado.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccionar Celda", "Seleccionar Celda", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbEstado.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                Celda celda = new Celda();

                if (await celda.UpdateEstadoCeldaAsync(IdCelda, StrCodigo, CmbEstado.SelectedValue.ToString(), CmbEstado.Text, MainWindow.IdUsuario))
                {
                    TxtCodigo.Text = "";
                    TxtVehiculo.Text = "";
                    TxtEstado.Text = "";
                    TxtTipo.Text = "";
                    TxtFechaEntrada.Text = "";
                    CmbEstado.ItemsSource = null;
                    CmbEstado.Items.Clear();
                    await niveles.ListaNiveles();
                }
                else
                {
                    MessageBox.Show($"Error al cambiar el estado de la celda '{StrCodigo}'", "Cambio Estado Celda", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                // Cambiar cursor a modo normal
                Mouse.OverrideCursor = null;
            }
        }
        private void BtnHistorialCelda_Click(object sender, RoutedEventArgs e)
        {
            HistorialOcupaciones historialOcupaciones = new HistorialOcupaciones();
            historialOcupaciones.ShowDialog();
        }

        private void GrpCeldas_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is GroupBox groupBox)
            {
                Permisos permisos = new Permisos();
                // 1. Obtener referencias a los botones
                var BtnCambiarEstado = groupBox.FindName("BtnCambiarEstado") as Button;

                // 2. Validar permisos para el módulo "Celdas"
                bool puedeCambiar = permisos.TienePermiso("Celdas", "Cambiar Estado");

                // 3. Aplicar visibilidad a los boton
                if (BtnCambiarEstado != null)
                    BtnCambiarEstado.IsEnabled = puedeCambiar;

                if (groupBox.FindName("CmbEstado") is ComboBox cmbEstado)
                {
                    cmbEstado.SelectedIndex = 0;
                    cmbEstado.IsEnabled = puedeCambiar;
                }

                Color Color = (Color)ColorConverter.ConvertFromString(puedeCambiar == true ? "#007BFF" : "#c2c2c2");
                BtnCambiarEstado.Background = new SolidColorBrush(Color);
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            txtInicio.Text = "";
            txtFin.Text = "";
        }
    }
}