﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Data;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para Planes.xaml
    /// </summary>
    public partial class Planes : Page
    {
        public Planes()
        {
            InitializeComponent();
            // Enlazar el DataContext de la ventana con esta instancia
            this.DataContext = resumenPlanes;
        }
        private DataTable DtTipoVehiculo;
        private DataTable DtCategoriaVehiculo;
        private bool isSelectingTipo = false; // Bandera para evitar bucles en el TextChanged
        private bool isSelectingCategoria = false; // Bandera para evitar bucles en el TextChanged
        // Propiedades para manejar la paginación y búsqueda de usuarios
        public int currentPageTiposPlan = 1;    // Página actual (inicia en 1)
        public int pageSizeTiposPlan = 5;      // Cantidad de registros por página
        public int totalRecordsTiposPlan = 0;   // Total de usuarios que coinciden con la búsqueda
        public int totalPagesTiposPlan = 0;     // Total de páginas calculadas
        public string NombrePlan { get; set; }
        public string NombreTipoPlan { get; set; }
        public string IdPlan { get; set; }

        private string IdTipoPlan = "";
        private DataTable DtTipoPlan;

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Obtiene la ventana que contiene esta página
            var window = Window.GetWindow(this);
            if (window is MainWindow mainWindow)
            {
                // Limpia el contenido del contenedor principal (fContainer)
                mainWindow.ContenedorPrincipal.Content = null;
            }
        }
        // Declaras o instancias tu ViewModel a nivel de la clase de la Ventana
        public ResumenPlanes resumenPlanes = new ResumenPlanes();
        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            await TiposPlanes();
            // Configurar el Temporizador para refrescar automáticamente cada 5 segundos
            var timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };

            // Se quita el 'await' de aquí
            timer.Tick += async (s, args) => await ResumenPlanesDashBoard();
            timer.Start();
            await TipoVehiculos();
            await CategoriaVehiculos();
            await ListaTipoPlan();
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        public async Task TiposPlanes()
        {
            TiposPlanes planes = new TiposPlanes();
            if (await planes.TiposPlanesAsync() is DataTable tipoPlan)
            {
                DtTipoPlan = tipoPlan;

                // Agregamos la opción fija directamente a la tabla cargada
                DtTipoPlan.Rows.Add("0", "Todos");

                // Simplificación: Usamos la vista por defecto y ordenamos de inmediato
                DataView dv = DtTipoPlan.DefaultView;
                dv.Sort = "IdTipoPlan DESC"; // El "0" quedará ordenado según tu lógica

                // Asignamos la vista ordenada directamente al ComboBox
                CmbSeleccionarTipoPlan.ItemsSource = dv;
                CmbSeleccionarTipoPlan.DisplayMemberPath = "Nombre";
                CmbSeleccionarTipoPlan.SelectedValuePath = "IdTipoPlan";
            }
            else
            {
                // Si el servidor no devuelve datos, creamos la estructura mínima para mostrar la opción
                DtTipoPlan = new DataTable();
                DtTipoPlan.Columns.Add("IdTipoPlan", typeof(string));
                DtTipoPlan.Columns.Add("Nombre", typeof(string));

                DtTipoPlan.Rows.Add("0", "Todos");

                CmbSeleccionarTipoPlan.ItemsSource = DtTipoPlan.DefaultView;
                CmbSeleccionarTipoPlan.DisplayMemberPath = "Nombre";
                CmbSeleccionarTipoPlan.SelectedValuePath = "IdTipoPlan";
            }
        }
        
        private async void CmbSeleccionarTipoPlan_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Limpiamos por seguridad el contenedor antes de meter uno nuevo
            ContenedorTipoPlan.Content = null;
            await TiposPlan(CmbSeleccionarTipoPlan.SelectedValue.ToString(), currentPageTiposPlan, pageSizeTiposPlan);
        }
        public async Task TiposPlan(string IdPlan, int pageNumber, int pageSize)
        {
            TiposPlanes tiposPlanes = new TiposPlanes();

            try
            {
                var dt = await tiposPlanes.PlanesTiposTarifaAsync(IdPlan, pageNumber, pageSize);

                if (dt != null) // Si hay resultados
                {

                    // Verifica si la tabla 0 (registros) tiene filas
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        // Obtiene el total de registros de la segunda tabla (índice 1)
                        totalRecordsTiposPlan = int.Parse(dt.Tables[1].Rows[0][0].ToString());

                        // Calcular el registro inicial de la página
                        int desde = ((currentPageTiposPlan - 1) * pageSizeTiposPlan) + 1;

                        // Calcular el registro final (evita pasarse del total real, ej. en la última página)
                        int hasta = Math.Min(currentPageTiposPlan * pageSizeTiposPlan, totalRecordsTiposPlan);

                        // Asignar el texto formateado al TextBlock
                        TbContadorTipoPlan.Text = $"Mostrando {desde} a {hasta} de {totalRecordsTiposPlan} registros";

                        // Calcula el total de páginas
                        totalPagesTiposPlan = (int)Math.Ceiling((double)totalRecordsTiposPlan / pageSize);

                        //muestra pagina actual
                        TxtPaginaTipoPlan.Text = "Página " + currentPageTiposPlan + " de " + totalPagesTiposPlan;
                        // Asigna la fuente de datos del DataGrid a la vista por defecto del DataTable
                        DgTiposPlanes.ItemsSource = dt.Tables[0].DefaultView;
                        // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                        DgTiposPlanes.CanUserSortColumns = false;

                        // Habilita o deshabilita los botones de navegación según la página actual
                        BtnAnteriorTipoPlan.IsEnabled = currentPageTiposPlan > 1;
                        BtnSiguienteTipoPlan.IsEnabled = (currentPageTiposPlan * pageSize) < totalRecordsTiposPlan;

                        // Muestra u oculta los íconos de flecha según correspondan
                        ImgAnteriorTipoPlan.Visibility = (currentPageTiposPlan > 1 ? Visibility.Visible : Visibility.Hidden);
                        ImgSiguienteTipoPlan.Visibility = ((currentPageTiposPlan * pageSize) < totalRecordsTiposPlan ? Visibility.Visible : Visibility.Hidden);
                    }
                    else
                    {
                        // Si no hay filas, resetea totales y muestra mensaje de página vacía
                        totalRecordsTiposPlan = 0;
                        // Asignar el texto formateado al TextBlock
                        TbContadorTipoPlan.Text = $"Mostrando {0} a {0} de {totalRecordsTiposPlan} registros";
                        dt.Clear();
                        DgTiposPlanes.ItemsSource = dt.Tables[0].DefaultView;
                        TxtPaginaTipoPlan.Text = "0";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public async Task ResumenPlanesDashBoard()
        {
            TiposPlanes tiposPlanes = new TiposPlanes();
            try
            {
                var dt = await tiposPlanes.ResumenTrifasAsync();
                if (dt != null) // Si hay resultados
                {
                    // Al llamar a este método sobre la misma instancia, los textos se actualizarán automáticamente en el XAML
                    //resumenPlanes.NivelEstado(dt.Tables[0]);
                    resumenPlanes.TiposPlanes = Convert.ToInt32(dt.Tables[0].Rows[0]["TotalTipoPlanes"].ToString());
                    resumenPlanes.CantidadPlanes = Convert.ToInt32(dt.Tables[0].Rows[0]["TotalPlanes"].ToString());
                    resumenPlanes.PlanesDemanda = Convert.ToInt32(dt.Tables[0].Rows[0]["TotalTarifaTiempoPorDemanda"].ToString());
                    resumenPlanes.TarifaMembresia = Convert.ToInt32(dt.Tables[0].Rows[0]["TotalTarifaMembresia"].ToString());
                    resumenPlanes.TarifaMensualidad = Convert.ToInt32(dt.Tables[0].Rows[0]["TotalTarifaMensualidad"].ToString());
                    resumenPlanes.TarifasConfiguradas = Convert.ToInt32(dt.Tables[0].Rows[0]["TotalPlanTarifa"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async void BtnEditarTipoPlan_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;

            // Extraemos los valores usando el nombre exacto de la columna de la base de datos
            IdPlan = filaSeleccionada["IdPlan"].ToString();
            IdTipoPlan = filaSeleccionada["IdTipoPlan"].ToString();
            NombrePlan = filaSeleccionada["Nombre"].ToString();
            string Descripcion = filaSeleccionada["Descripcion"].ToString();
            string Estado = filaSeleccionada["Estado"].ToString() == "True" ? "Activo" : "Inactivo";

            TxtNombrePlan.Text = NombrePlan;
            TxtDescripcionPlan.Text = Descripcion;
            CmbEstadoPlan.Text = Estado;

            //Tipo y categoría de vehiculo
            txtAutocompleteTipoVehiculo.Text = filaSeleccionada["TipoVehiculo"].ToString();
            TxtDescripcionTipoVehiculo.Text = filaSeleccionada["TipoVehiculoDescripcion"].ToString();

            txtAutocompleteCategoria.Text = filaSeleccionada["CategoriaVehiculo"].ToString();
            TxtDescripcionCategoriaVehiculo.Text = filaSeleccionada["CategoriaVehiculoDescripcion"].ToString();

            popupSuggestionsTipoVehiculo.IsOpen = false;
            popupSuggestionsCategoria.IsOpen = false;

            await EstadoGuardar(false, true);
        }
        private async void BtnSeleccionarPlan_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;

            // Extraemos los valores usando el nombre exacto de la columna de la base de datos
            IdPlan = filaSeleccionada["IdPlan"].ToString();
            IdTipoPlan = filaSeleccionada["IdTipoPlan"].ToString();
            NombrePlan = filaSeleccionada["Nombre"].ToString();
            NombreTipoPlan = filaSeleccionada["NombreTipoPlan"].ToString();

            TxtNombrePlan.Text = "";
            TxtDescripcionPlan.Text = "";
            CmbEstadoPlan.Text = "";

            await EstadoGuardar(true, false);

            ContenedorTipoPlan.Content = null;// Liberar userControl actual

            if (NombreTipoPlan == "Tiempo por demanda")
            {
                // Instanciamos el UserControl de forma limpia
                TiempoPorDemanda tiempoPorDemanda = new TiempoPorDemanda(this);

                tiempoPorDemanda.TbNombre.Text = filaSeleccionada["Nombre"].ToString();
                tiempoPorDemanda.TbDescripcion.Text = filaSeleccionada["Descripcion"].ToString();
                tiempoPorDemanda.TbTipoPlan.Text = filaSeleccionada["NombreTipoPlan"].ToString();
                tiempoPorDemanda.TbEstado.Text = filaSeleccionada["estado"].ToString() == "True" ? "Activo" : "Inactivo";
                tiempoPorDemanda.TbTipoVehiculo.Text = filaSeleccionada["TipoVehiculo"].ToString();
                tiempoPorDemanda.TbDescripcionTipoVehiculo.Text = filaSeleccionada["TipoVehiculoDescripcion"].ToString();
                tiempoPorDemanda.TbCategoriaVehiculo.Text = filaSeleccionada["CategoriaVehiculo"].ToString();
                tiempoPorDemanda.TbDescripcionCategoriaVehiculo.Text = filaSeleccionada["CategoriaVehiculoDescripcion"].ToString();

                await tiempoPorDemanda.TarifaPorTiempoDemanda(IdPlan, tiempoPorDemanda.currentPageTiempoPorDemanda, tiempoPorDemanda.pageSizeTiempoPorDemanda);
                
                // Limpiamos por seguridad el contenedor antes de meter uno nuevo
                ContenedorTipoPlan.Content = null;

                // Lo incrustamos en la interfaz
                ContenedorTipoPlan.Content = tiempoPorDemanda;

                // Forzamos a WPF a recalcular los tamaños del contenedor inmediatamente
                ContenedorTipoPlan.UpdateLayout();
            }
            else
            {
                var tarifas = new Tarifas()
                {
                    Tarifa = NombrePlan,

                    TipoTarifa = NombreTipoPlan,

                    IdPlan = IdPlan,

                    IdTipoPlan = IdTipoPlan
                };

                tarifas.TbNombre.Text = filaSeleccionada["Nombre"].ToString();
                tarifas.TbDescripcion.Text = filaSeleccionada["Descripcion"].ToString();
                tarifas.TbTipoPlan.Text = filaSeleccionada["NombreTipoPlan"].ToString();
                tarifas.TbEstado.Text = filaSeleccionada["estado"].ToString() == "True" ? "Activo" : "Inactivo";
                tarifas.TbTipoVehiculo.Text = filaSeleccionada["TipoVehiculo"].ToString();
                tarifas.TbDescripcionTipoVehiculo.Text = filaSeleccionada["TipoVehiculoDescripcion"].ToString();
                tarifas.TbCategoriaVehiculo.Text = filaSeleccionada["CategoriaVehiculo"].ToString();
                tarifas.TbDescripcionCategoriaVehiculo.Text = filaSeleccionada["CategoriaVehiculoDescripcion"].ToString();
                tarifas.CmbVigencia.SelectedIndex = 1;

                if (NombreTipoPlan == "Mensualidad")
                {
                    tarifas.CmbVigencia.IsEnabled = false;
                }

                await tarifas.TarifaMembresiaMensualidad(IdPlan, tarifas.currentPageTarifa, tarifas.pageSizeTarifa);

                // Limpiamos por seguridad el contenedor antes de meter uno nuevo
                ContenedorTipoPlan.Content = null;

                // Lo incrustamos en la interfaz
                ContenedorTipoPlan.Content = tarifas;

                // Forzamos a WPF a recalcular los tamaños del contenedor inmediatamente
                ContenedorTipoPlan.UpdateLayout();
            }
        }

        private async void BtnAnteriorTipoPlan_Click(object sender, RoutedEventArgs e)
        {
            if (currentPageTiposPlan > 1)
            {
                currentPageTiposPlan--; // Disminuye el número de página
                await TiposPlan(CmbSeleccionarTipoPlan.SelectedValue.ToString(), currentPageTiposPlan, pageSizeTiposPlan);
                TxtPaginaTipoPlan.Text = "Página " + currentPageTiposPlan + " de " + totalPagesTiposPlan;
            }
        }

        private async void BtnSiguienteTipoPlan_Click(object sender, RoutedEventArgs e)
        {
            if ((currentPageTiposPlan * pageSizeTiposPlan) < totalRecordsTiposPlan)
            {
                currentPageTiposPlan++; // Aumenta el número de página
                await TiposPlan(CmbSeleccionarTipoPlan.SelectedValue.ToString(), currentPageTiposPlan, pageSizeTiposPlan);
                TxtPaginaTipoPlan.Text = "Página " + currentPageTiposPlan + " de " + totalPagesTiposPlan;
            }
        }

        

        private async void LimpiarTipoPlan()
        {
            TxtNombrePlan.Text = string.Empty;
            TxtDescripcionPlan.Text = string.Empty;
            CmbEstadoPlan.SelectedIndex = -1;

            txtAutocompleteTipoVehiculo.Text = string.Empty;
            txtAutocompleteCategoria.Text = string.Empty;
            TxtDescripcionTipoVehiculo.Text = string.Empty;
            TxtDescripcionTipoVehiculo.IsEnabled = true;
            TxtDescripcionTipoVehiculo.Background = (Brush)new BrushConverter().ConvertFrom("#FFFFFF");
            TxtDescripcionCategoriaVehiculo.Text = string.Empty;
            TxtDescripcionCategoriaVehiculo.IsEnabled = true;
            TxtDescripcionCategoriaVehiculo.Background = (Brush)new BrushConverter().ConvertFrom("#FFFFFF");

            await EstadoGuardar(true, false);
        }
        private async void BtnGuardarTipoPlan_Click(object sender, RoutedEventArgs e)
        {
            // Validar que realmente haya una fila seleccionada
            if (TbGuardarTipoPlan.Text == "Guardar" && (CmbSeleccionarTipoPlan.SelectedIndex == -1 || CmbSeleccionarTipoPlan.SelectedValue.ToString() == "0"))
            {
                MessageBox.Show("Seleccione un tipo de plan", "Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Warning);
                CmbSeleccionarTipoPlan.Focus();
                return;
            }
            if (TxtNombrePlan.Text == string.Empty)
            {
                MessageBox.Show("Ingresar nombre de plan", "Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtNombrePlan.Focus();
                return;
            }
            if (CmbEstadoPlan.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccione estado de plan", "Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Warning);
                CmbEstadoPlan.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar plan
                TiposPlanes tiposPlanes = new TiposPlanes();
                //Igresar / actualizar Tipo de plan
                if (TbGuardarTipoPlan.Text == "Guardar" ? await tiposPlanes.NuevoTipoPlan(CmbSeleccionarTipoPlan.SelectedValue.ToString(), TxtNombrePlan.Text.Trim(), CmbSeleccionarTipoPlan.Text, TxtDescripcionPlan.Text.Trim(), CmbEstadoPlan.Text, TxtDescripcionTipoVehiculo.Text.Trim(), TxtDescripcionCategoriaVehiculo.Text.Trim(), txtAutocompleteTipoVehiculo.Text.Trim().ToLower(), txtAutocompleteCategoria.Text.Trim().ToLower(), MainWindow.IdUsuario)
                                                        : await tiposPlanes.ActualizarTipoPlan(IdPlan, TxtNombrePlan.Text.Trim(), CmbSeleccionarTipoPlan.Text, TxtDescripcionPlan.Text.Trim(), CmbEstadoPlan.Text, TxtDescripcionTipoVehiculo.Text.Trim(), TxtDescripcionCategoriaVehiculo.Text.Trim(), txtAutocompleteTipoVehiculo.Text.Trim().ToLower(), txtAutocompleteCategoria.Text.Trim().ToLower(), MainWindow.IdUsuario))
                {
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show($"Tipo de Plan '{TxtNombrePlan.Text}' se {(TbGuardarTipoPlan.Text == "Guardar" ? "agrego" : "actualizo")} correctamente", "Tipo de Plan", MessageBoxButton.OK, MessageBoxImage.Information);
                    // actualiza el datagrid
                    await TiposPlan(CmbSeleccionarTipoPlan.SelectedValue.ToString(), currentPageTiposPlan, pageSizeTiposPlan);
                    LimpiarTipoPlan();
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                Mouse.OverrideCursor = null;
            }
        }
        private void BtnCancelarTipoPlan_Click(object sender, RoutedEventArgs e)
        {
            LimpiarTipoPlan();
        }

        private async void BtnEliminarTipoPlan_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;

            // Extraemos los valores usando el nombre exacto de la columna de la base de datos
            string IdPlan = filaSeleccionada["IdPlan"].ToString();
            string NombrePlan = filaSeleccionada["Nombre"].ToString();
            string NombreTipoPlan = filaSeleccionada["NombreTipoPlan"].ToString();

            //Pregunta antes de proceder a eliminar tipo plan
            MessageBoxResult messageBoxResult = MessageBox.Show($"¿Eliminar {NombrePlan} de tipo plan '{NombreTipoPlan}'¿Desea continuar?", "Eliminar Tipo Plan", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar plan
                TiposPlanes tiposPlanes = new TiposPlanes();
                //Igresar / actualizar Tipo de plan
                if (await tiposPlanes.EliminarTipoPlan(IdPlan, NombrePlan, NombreTipoPlan, MainWindow.IdUsuario))
                {
                    //Muestra un mensaje de confirmaciín de guardado del usuario nuevo
                    MessageBox.Show($"Tipo de Plan '{NombrePlan}' de {NombreTipoPlan} se eliminó correctamente", "Eliminar Tipo Plan", MessageBoxButton.OK, MessageBoxImage.Information);
                    // actualiza el datagrid
                    await TiposPlan(CmbSeleccionarTipoPlan.SelectedValue.ToString(), currentPageTiposPlan, pageSizeTiposPlan);
                    LimpiarTipoPlan();
                    // Limpiamos por seguridad el contenedor antes de meter uno nuevo
                    ContenedorTipoPlan.Content = null;
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                Mouse.OverrideCursor = null;
            }
        }
        
        public async Task ListaTipoPlan()
        {
            Permisos permisos = new Permisos();
            try
            {
                // Consultar permisos
                bool PuedeGuardar = permisos.TienePermiso("Planes", "Agregar plan");
                bool verPlanes = permisos.TienePermiso("Planes", "Ver");
                bool puedeEditar = permisos.TienePermiso("Planes", "Editar plan");
                bool puedeEliminar = permisos.TienePermiso("Planes", "Eliminar plan");


                // Si TODOS los permisos están en false, ocultamos toda la columna Acciones
                if (!puedeEditar && !puedeEliminar && !verPlanes)
                {
                    ColAcciones.Visibility = Visibility.Collapsed;
                }
                else
                {
                    ColAcciones.Visibility = Visibility.Visible;
                }
                await EstadoGuardar(true, false);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async Task EstadoGuardar(bool Guardar, bool Editar)
        {

            BtnGuardarTipoPlan.Visibility = Visibility.Collapsed;

            Permisos permisos = new Permisos();

            bool puedeEditar = permisos.TienePermiso("Planes", "Editar plan");
            bool puedeAgregar = permisos.TienePermiso("Planes", "Agregar plan");


            if (puedeEditar == false && puedeAgregar == false)
            {
                BtnGuardarTipoPlan.Visibility = Visibility.Collapsed;
                return;
            }

            if (puedeAgregar == true && Guardar == true)
            {
                BtnGuardarTipoPlan.Visibility = Visibility.Visible;
                TbGuardarTipoPlan.Text = "Guardar";
                return;
            }

            if (puedeEditar == true && Editar == true)
            {
                BtnGuardarTipoPlan.Visibility = Visibility.Visible;
                TbGuardarTipoPlan.Text = "Guardar Cambios";
                return;
            }
            else
            {
                TbGuardarTipoPlan.Text = "Guardar";
            }
        }


        public async Task TipoVehiculos()
        {
            Vehiculo vehiculo = new Vehiculo();
            if (await vehiculo.TiposVehiculosAsync() is DataTable tipoVehiculo)
            {
                DtTipoVehiculo = tipoVehiculo;
            }
        }
        public async Task CategoriaVehiculos()
        {
            Vehiculo vehiculo = new Vehiculo();
            if (await vehiculo.CategoriaVehiculosAsync() is DataTable categoriaVehiculo)
            {
                DtCategoriaVehiculo = categoriaVehiculo;
            }
        }
        private void TxtAutocompleteTipoVehiculo_TextChanged(object sender, TextChangedEventArgs e)
        {

            if (isSelectingTipo || DtTipoVehiculo == null) return;

            string filtro = txtAutocompleteTipoVehiculo.Text.Trim();

            if (string.IsNullOrEmpty(filtro))
            {
                popupSuggestionsTipoVehiculo.IsOpen = false;
                return;
            }

            DataView dv = DtTipoVehiculo.DefaultView;
            dv.RowFilter = $"Nombre LIKE '%{filtro.Replace("'", "''")}%'";

            if (dv.Count > 0)
            {
                lbSuggestionsTipoVehiculo.ItemsSource = dv;
                lbSuggestionsTipoVehiculo.DisplayMemberPath = "Nombre";
                popupSuggestionsTipoVehiculo.IsOpen = true;
            }
            else
            {
                popupSuggestionsTipoVehiculo.IsOpen = false;
                // Se ejecuta cuando el texto ingresado no existe en la tabla
                TxtDescripcionTipoVehiculo.IsEnabled = true;
                TxtDescripcionTipoVehiculo.Text = "";
                TxtDescripcionTipoVehiculo.Background = (Brush)new BrushConverter().ConvertFrom("#FFFFFF");
            }
        }

        private void LbSuggestionsTipoVehiculo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lbSuggestionsTipoVehiculo.SelectedItem != null)
            {
                isSelectingTipo = true;
                if (lbSuggestionsTipoVehiculo.SelectedItem is DataRowView rowView)
                {
                    MostrarDescripcionTipoVehiculo(rowView.Row);
                }
                popupSuggestionsTipoVehiculo.IsOpen = false;
                lbSuggestionsTipoVehiculo.SelectedItem = null;
                isSelectingTipo = false;
            }
        }

        private void TxtAutocompleteTipoVehiculo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (popupSuggestionsTipoVehiculo.IsOpen && lbSuggestionsTipoVehiculo.Items.Count > 0 &&
                    (lbSuggestionsTipoVehiculo.SelectedItem ?? lbSuggestionsTipoVehiculo.Items[0]) is DataRowView rowView)
                {
                    MostrarDescripcionTipoVehiculo(rowView.Row);
                }
                else
                {
                    BuscarYMostrarPorTextoTipoVehiculo(txtAutocompleteTipoVehiculo.Text.Trim());
                }

                popupSuggestionsTipoVehiculo.IsOpen = false;
                e.Handled = true;
            }
        }

        private void TxtAutocompleteTipoVehiculo_LostFocus(object sender, RoutedEventArgs e)
        {
            this.Dispatcher.BeginInvoke(new System.Action(() =>
            {
                if (txtAutocompleteTipoVehiculo.IsKeyboardFocusWithin || popupSuggestionsTipoVehiculo.IsKeyboardFocusWithin)
                    return;

                popupSuggestionsTipoVehiculo.IsOpen = false;
                string texto = txtAutocompleteTipoVehiculo.Text.Trim();
                if (!string.IsNullOrEmpty(texto))
                {
                    BuscarYMostrarPorTextoTipoVehiculo(texto);
                }
            }), System.Windows.Threading.DispatcherPriority.Background);
        }

        private void BuscarYMostrarPorTextoTipoVehiculo(string texto)
        {
            if (string.IsNullOrEmpty(texto) || DtTipoVehiculo == null) return;

            DataRow[] rows = DtTipoVehiculo.Select($"Nombre = '{texto.Replace("'", "''")}'");

            if (rows.Length == 0)
            {
                rows = DtTipoVehiculo.Select($"Nombre LIKE '{texto.Replace("'", "''")}%'");
            }

            if (rows.Length > 0)
            {
                MostrarDescripcionTipoVehiculo(rows[0]);
            }
            else
            {
                // Se ejecuta cuando el texto ingresado no existe en la tabla
                TxtDescripcionTipoVehiculo.IsEnabled = true;
                TxtDescripcionTipoVehiculo.Text = "";
                TxtDescripcionTipoVehiculo.Background = (Brush)new BrushConverter().ConvertFrom("#FFFFFF");
                TxtDescripcionTipoVehiculo.Focus();
            }
        }
        private void MostrarDescripcionTipoVehiculo(DataRow row)
        {
            if (row != null)
            {
                txtAutocompleteTipoVehiculo.Text = row["Nombre"].ToString();
                txtAutocompleteTipoVehiculo.CaretIndex = txtAutocompleteTipoVehiculo.Text.Length;

                string descripcion = row["Descripcion"] != DBNull.Value
                    ? row["Descripcion"].ToString()
                    : "Sin descripción";
                TxtDescripcionTipoVehiculo.Text = descripcion;
                TxtDescripcionTipoVehiculo.IsEnabled = false;
                TxtDescripcionTipoVehiculo.Background = (Brush)new BrushConverter().ConvertFrom("#E9ECEF");
            }
        }
        //******************************************
        private void TxtAutocompleteCategoria_TextChanged(object sender, TextChangedEventArgs e)
        {

            if (isSelectingCategoria || DtCategoriaVehiculo == null) return;

            string filtro = txtAutocompleteCategoria.Text.Trim();

            if (string.IsNullOrEmpty(filtro))
            {
                popupSuggestionsCategoria.IsOpen = false;
                return;
            }

            DataView dv = DtCategoriaVehiculo.DefaultView;
            dv.RowFilter = $"Nombre LIKE '%{filtro.Replace("'", "''")}%'";

            if (dv.Count > 0)
            {
                lbSuggestionsCategoria.ItemsSource = dv;
                lbSuggestionsCategoria.DisplayMemberPath = "Nombre";
                popupSuggestionsCategoria.IsOpen = true;
            }
            else
            {
                popupSuggestionsCategoria.IsOpen = false;
                // Se ejecuta cuando el texto ingresado no existe en la tabla
                TxtDescripcionCategoriaVehiculo.IsEnabled = true;
                TxtDescripcionCategoriaVehiculo.Text = "";
                TxtDescripcionCategoriaVehiculo.Background = (Brush)new BrushConverter().ConvertFrom("#FFFFFF");
            }
        }

        private void MostrarDescripcionCategoria(DataRow row)
        {
            if (row != null)
            {
                txtAutocompleteCategoria.Text = row["Nombre"].ToString();
                txtAutocompleteCategoria.CaretIndex = txtAutocompleteCategoria.Text.Length;

                string descripcion = row["Descripcion"] != DBNull.Value
                    ? row["Descripcion"].ToString()
                    : "Sin descripción";

                TxtDescripcionCategoriaVehiculo.Text = descripcion;
                TxtDescripcionCategoriaVehiculo.IsEnabled = false;
                TxtDescripcionCategoriaVehiculo.Background = (Brush)new BrushConverter().ConvertFrom("#E9ECEF");
            }
        }

        private void LbSuggestionsCategoria_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lbSuggestionsCategoria.SelectedItem != null)
            {
                isSelectingCategoria = true;
                if (lbSuggestionsCategoria.SelectedItem is DataRowView rowView)
                {
                    MostrarDescripcionCategoria(rowView.Row);
                }
                popupSuggestionsCategoria.IsOpen = false;
                lbSuggestionsCategoria.SelectedItem = null;
                isSelectingCategoria = false;
            }
        }

        private void TxtAutocompleteCategoria_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (popupSuggestionsCategoria.IsOpen && lbSuggestionsCategoria.Items.Count > 0 &&
                    (lbSuggestionsCategoria.SelectedItem ?? lbSuggestionsCategoria.Items[0]) is DataRowView rowView)
                {
                    MostrarDescripcionCategoria(rowView.Row);
                }
                else
                {
                    BuscarYMostrarPorTextoCategoria(txtAutocompleteCategoria.Text.Trim());
                }

                popupSuggestionsCategoria.IsOpen = false;
                e.Handled = true;
            }
        }

        private void TxtAutocompleteCategoria_LostFocus(object sender, RoutedEventArgs e)
        {
            this.Dispatcher.BeginInvoke(new System.Action(() =>
            {
                if (txtAutocompleteCategoria.IsKeyboardFocusWithin || popupSuggestionsCategoria.IsKeyboardFocusWithin)
                    return;

                popupSuggestionsCategoria.IsOpen = false;
                string texto = txtAutocompleteCategoria.Text.Trim();
                if (!string.IsNullOrEmpty(texto))
                {
                    BuscarYMostrarPorTextoCategoria(texto);
                }
            }), System.Windows.Threading.DispatcherPriority.Background);
        }

        private void BuscarYMostrarPorTextoCategoria(string texto)
        {
            if (string.IsNullOrEmpty(texto) || DtCategoriaVehiculo == null) return;

            DataRow[] rows = DtCategoriaVehiculo.Select($"Nombre = '{texto.Replace("'", "''")}'");

            if (rows.Length == 0)
            {
                rows = DtCategoriaVehiculo.Select($"Nombre LIKE '{texto.Replace("'", "''")}%'");
            }

            if (rows.Length > 0)
            {
                MostrarDescripcionCategoria(rows[0]);
            }
            else
            {
                // Se ejecuta cuando el texto ingresado no existe en la tabla
                TxtDescripcionCategoriaVehiculo.IsEnabled = true;
                TxtDescripcionCategoriaVehiculo.Text = "";
                TxtDescripcionCategoriaVehiculo.Background = (Brush)new BrushConverter().ConvertFrom("#FFFFFF");
                TxtDescripcionCategoriaVehiculo.Focus();
            }
        }

        private void PanelTipoPlan_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is StackPanel panel)
            {
                Permisos permisos = new Permisos();

                // Validar permisos para el módulo "Planes"
                bool puedeVerPlanes = permisos.TienePermiso("Planes", "Ver plan");
                bool puedeEditar = permisos.TienePermiso("Planes", "Editar plan");
                bool puedeEliminar = permisos.TienePermiso("Planes", "Eliminar plan");

                // Aplicar visibilidad a los botones principales
                if (panel.FindName("BtnSeleccionarPlan") is Button BtnSeleccionarPlan)
                {
                    BtnSeleccionarPlan.Visibility = puedeVerPlanes ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("BtnEditarTipoPlan") is Button BtnEditarTipoPlan)
                {
                    BtnEditarTipoPlan.Visibility = puedeEditar ? Visibility.Visible : Visibility.Collapsed;
                }
                if (panel.FindName("BtnEliminarPlan") is Button BtnEliminarPlan)
                {
                    BtnEliminarPlan.Visibility = puedeEliminar ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }
    }
}