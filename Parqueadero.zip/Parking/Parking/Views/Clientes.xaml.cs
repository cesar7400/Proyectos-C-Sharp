﻿using Parking.Controller;
using Parking.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para Clientes.xaml
    /// </summary>
    public partial class Clientes : Page
    {
        public Clientes()
        {
            InitializeComponent();
            this.DataContext = resumenPlanesCliente;
        }
        string IdPlanMembresia = "";
        string IdPlanTarifaMembresia = "";

        string IdPlanMensualidad = "";
        string IdPlanTarifaMensualidad = "";
        public ResumenPlanesCliente resumenPlanesCliente = new ResumenPlanesCliente();

        // Propiedades para manejar la paginación y búsqueda de usuarios
        public int currentPage = 1;    // Página actual (inicia en 1)
        public int pageSize = 30;      // Cantidad de registros por página
        public int totalRecords = 0;   // Total de usuarios que coinciden con la búsqueda
        public int totalPages = 0;     // Total de páginas calculadas
        public string strBusquedad = "";// Texto de búsqueda actual
        private DataTable DtTipoVehiculo;
        private DataTable DtCategoriaVehiculo;
        public static DataView TipoVehiculoView { get; set; }// Propiedades que exponemos al combobox
        public static DataView CategoriaVehiculoView { get; set; }// Propiedades que exponemos al combobox

        private string nombreCliente = "";
        private string Idcliente = "";

        private string IdVehiculo  = "";
        private DispatcherTimer timer;
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Obtiene la ventana que contiene esta página
            var window = Window.GetWindow(this);
            if (window is MainWindow mainWindow)
            {
                // Limpia el contenido del contenedor principal (fContainer)
                mainWindow.ContenedorPrincipal.Content = null;
            }
        }

        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Permisos permisos = new Permisos();
            // Consultar permisos
            bool puedeCrear = permisos.TienePermiso("Clientes", "Agregar Cliente");
            // Aplicar a los boton
            BtnAddCliente.Visibility = puedeCrear ? Visibility.Visible : Visibility.Collapsed;

            CargarClientes("", currentPage, pageSize);
            await TipoVehiculos();
            await CategoriaVehiculos();
            // Configurar el Temporizador para refrescar automáticamente cada 5 segundos
            #pragma warning disable IDE0017 // Simplificar la inicialización del objeto
            timer = new DispatcherTimer();
            #pragma warning restore IDE0017
            timer.Interval = TimeSpan.FromSeconds(1);

            // Se quita el 'await' de aquí
            timer.Tick += async (s, args) => await ResumenPlanesClienteDashBoard();
            timer.Start();
        }
        private void BtnAddCliente_Click(object sender, RoutedEventArgs e)
        {
            AgregarCliente agregarCliente = new AgregarCliente(this);
            agregarCliente.ShowDialog();
        }
        public async void CargarClientes(string strUsuario, int pageNumber, int pageSize)
        {
            Clientes_ clientes = new Clientes_();
            try
            {
                var dt = await clientes.ObtenerClientesAsync(strUsuario, pageNumber, pageSize);

                Permisos permisos = new Permisos();
                // Consultar permisos
                bool puedeEditar = permisos.TienePermiso("Clientes", "Editar Cliente");
                bool puedeEliminar = permisos.TienePermiso("Clientes", "Eliminar Cliente");

                // Si TODOS los permisos están en false, ocultamos toda la columna Acciones
                if (!puedeEditar && !puedeEliminar)
                {
                    ColAcciones.Visibility = Visibility.Collapsed;
                }
                else
                {
                    ColAcciones.Visibility = Visibility.Visible;
                }

                if (dt != null) // Si hay resultados
                {
                    // Verifica si la tabla 0 (registros) tiene filas
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        // Obtiene el total de registros de la segunda tabla (índice 1)
                        totalRecords = int.Parse(dt.Tables[1].Rows[0][0].ToString());

                        // Calcular el registro inicial de la página
                        int desde = ((currentPage - 1) * pageSize) + 1;

                        // Calcular el registro final (evita pasarse del total real, ej. en la última página)
                        int hasta = Math.Min(currentPage * pageSize, totalRecords);

                        // Asignar el texto formateado al TextBlock
                        TbContador.Text = $"Mostrando {desde} a {hasta} de {totalRecords} registros";

                        // Calcula el total de páginas
                        totalPages = (int)Math.Ceiling((double)totalRecords / pageSize);

                        //muestra pagina actual
                        TxtPagina.Text = "Página " + currentPage + " de " + totalPages;
                        // Asigna la fuente de datos del DataGrid a la vista por defecto del DataTable
                        DgClientes.ItemsSource = dt.Tables[0].DefaultView;
                        // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                        DgClientes.CanUserSortColumns = false;

                        // Habilita o deshabilita los botones de navegación según la página actual
                        BtnAnterior.IsEnabled = currentPage > 1;
                        BtnSiguiente.IsEnabled = (currentPage* pageSize) < totalRecords;

                        // Muestra u oculta los íconos de flecha según correspondan
                        ImgAnteriorTarifa.Visibility = (currentPage > 1 ? Visibility.Visible : Visibility.Hidden);
                        ImgSiguienteTarifa.Visibility = ((currentPage * pageSize) < totalRecords ? Visibility.Visible : Visibility.Hidden);
                    }
                    else
                    {
                        // Si no hay filas, resetea totales y muestra mensaje de página vacía
                        totalRecords = 0;
                        // Asignar el texto formateado al TextBlock
                        TbContador.Text = $"Mostrando {0} a {0} de {totalRecords} registros";
                        dt.Clear();
                        DgClientes.ItemsSource = dt.Tables[0].DefaultView;
                        TxtPagina.Text = "0";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public async Task SeleccionarPlanVehiculo(string IdVehiculo)
        {
            TiposPlanes tiposPlanes = new TiposPlanes();
            try
            {
                var dt = await tiposPlanes.SeleccionarPlanVehiculo(IdVehiculo);

                Permisos permisos = new Permisos();
                // Consultar permisos
                bool puedeRealizarPago = permisos.TienePermiso("Clientes", "Realizar Pago");

                // Si TODOS los permisos están en false, ocultamos toda la columna Acciones
                if (!puedeRealizarPago)
                {
                    ColAccionesPagoPlan.Visibility = Visibility.Collapsed;
                }
                else
                {
                    ColAccionesPagoPlan.Visibility = Visibility.Visible;
                }

                if (dt != null) // Si hay resultados
                {
                    // Verifica si la tabla 0 (registros) tiene filas
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        // Asigna la fuente de datos del DataGrid a la vista por defecto del DataTable
                        DgPlanesCliente.ItemsSource = dt.Tables[0].DefaultView;
                        // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                        DgPlanesCliente.CanUserSortColumns = false;
                    }
                    else
                    {
                        dt.Clear();
                        DgPlanesCliente.ItemsSource = dt.Tables[0].DefaultView;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public async Task ResumenPlanesClienteDashBoard()
        {
            TiposPlanes tiposPlanes = new TiposPlanes();
            try
            {
                var dt = await tiposPlanes.ResumenPlanesClienteAsync();
                if (dt != null) // Si hay resultados
                {
                    // Al llamar a este método sobre la misma instancia, los textos se actualizarán automáticamente en el XAML
                    resumenPlanesCliente.TotalClientes = Convert.ToInt32(dt.Tables[0].Rows[0]["TotalClientes"].ToString());
                    resumenPlanesCliente.TotalVehiculos = Convert.ToInt32(dt.Tables[0].Rows[0]["TotalVehiculos"].ToString());
                    resumenPlanesCliente.TotalVehiculosVIP = Convert.ToInt32(dt.Tables[0].Rows[0]["VehiculosVIP"].ToString());
                    resumenPlanesCliente.TotalMembresia = Convert.ToInt32(dt.Tables[0].Rows[0]["VehiculosMembresia"].ToString());
                    resumenPlanesCliente.TotalMensualidad = Convert.ToInt32(dt.Tables[0].Rows[0]["VehiculosMensualidad"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void TxtBuscarCliente_TextChanged(object sender, TextChangedEventArgs e)
        {
            currentPage = 1;
            if (TxtBuscarCliente.Text.Trim() != string.Empty)
            {
                // Si hay texto, filtra por ese texto y actualiza strBusquedad
                CargarClientes(TxtBuscarCliente.Text.Trim().Replace("'", "").Replace("\"", ""), 1, pageSize);
            }
            else
            {
                // Si el cuadro de búsqueda está vacío, restaura sin filtro
                CargarClientes("", 1, pageSize);
            }
        }

        private async void BtnAnterior_Click(object sender, RoutedEventArgs e)
        {
            if (currentPage > 1)
            {
                currentPage--; // Disminuye el número de página
                CargarClientes(TxtBuscarCliente.Text.Trim().Replace("'", "").Replace("\"", ""), 1, pageSize);
                TxtPagina.Text = "Página " + currentPage + " de " + totalPages;
            }
        }

        private void BtnSiguiente_Click(object sender, RoutedEventArgs e)
        {
            if ((currentPage * pageSize) < totalRecords)
            {
                currentPage++; // Aumenta el número de página
                CargarClientes(TxtBuscarCliente.Text.Trim().Replace("'", "").Replace("\"", ""), 1, pageSize);
                TxtPagina.Text = "Página " + currentPage + " de " + totalPages;
            }
        }
        public interface IFormCliente
        {
            void SetData(List<KeyValuePair<string, string>> dataCliente);
        }
        private void BtnEditar_Click(object sender, RoutedEventArgs e)
        {
            // Botón que disparó el evento
            if (sender is Button btn)
            {
                if (btn != null)
                {
                    // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
                    if (btn.DataContext is DataRowView rowView)
                    {
                        if (rowView != null)
                        {
                            // Construye una lista de KeyValuePair con los datos del usuario para pasar a la ventana
                            var listCliente = new List<KeyValuePair<string, string>>
                            {
                                new KeyValuePair<string, string>("@Idcliente", rowView.Row[0].ToString()),
                                new KeyValuePair<string, string>("@Nombre", rowView.Row[1].ToString()),
                                new KeyValuePair<string, string>("@Documentoid", rowView.Row[2].ToString()),
                                new KeyValuePair<string, string>("@Documento", rowView.Row[4].ToString()),
                                new KeyValuePair<string, string>("@Celular", rowView.Row[5].ToString()),
                                new KeyValuePair<string, string>("@email", rowView.Row[6].ToString()),
                                new KeyValuePair<string, string>("@Antes", $"Nombre: {rowView.Row[1]}, Tipo Documento: {rowView.Row[3]}, Número Documento: {rowView.Row[4]}, Celular. {rowView.Row[5]}, Correo: {rowView.Row[6]}")
                            };

                            // Crea la ventana de actualización y le pasa esta página como referencia
                            EditarCliente editarCliente = new EditarCliente(this);

                            // Si la ventana implementa la interfaz IFormUsuario, le asigna los datos
                            if (editarCliente is IFormCliente formdata)
                            {
                                formdata.SetData(listCliente);
                            }
                            try
                            {
                                editarCliente.ShowDialog(); // Muestra la ventana de edición de usuario
                            }
                            catch (Exception ex)
                            {
                                // Si ocurre un error al abrir la ventana, muestra un MessageBox con el detalle
                                MessageBox.Show(ex.Message, "Error al enviar información", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                    }
                }
            }
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        public async Task TipoVehiculos()
        {
            Vehiculo vehiculo = new Vehiculo();
            var TipoVehiculo_ = await vehiculo.TiposVehiculosAsync();

            if (TipoVehiculo_ != null)
            {
                if (DtTipoVehiculo == null)
                {
                    DtTipoVehiculo = new DataTable();
                    TipoVehiculoView = DtTipoVehiculo.DefaultView;
                }

                DtTipoVehiculo.Rows.Clear();

                if (TipoVehiculo_.Rows.Count > 0)
                {
                    // Ordenamos para que quede donde prefieras (con DESC queda arriba si los IDs son numéricos mayores a 0)
                    DataView dv = new DataView(TipoVehiculo_) { Sort = "IdTipoVehiculo DESC" };

                    DtTipoVehiculo.Merge(dv.ToTable());
                }
            }
        }
        public async Task CategoriaVehiculos()
        {
            Vehiculo vehiculo = new Vehiculo();
            var CategoriaVehiculo_ = await vehiculo.CategoriaVehiculosAsync();

            if (CategoriaVehiculo_ != null)
            {
                if (DtCategoriaVehiculo == null)
                {
                    DtCategoriaVehiculo = new DataTable();
                    CategoriaVehiculoView = DtCategoriaVehiculo.DefaultView;
                }

                DtCategoriaVehiculo.Rows.Clear();

                if (CategoriaVehiculo_.Rows.Count > 0)
                {
                    // Ordenamos para que quede donde prefieras (con DESC queda arriba si los IDs son numéricos mayores a 0)
                    DataView dv = new DataView(CategoriaVehiculo_) { Sort = "IdCategoriaVehiculo DESC" };

                    DtCategoriaVehiculo.Merge(dv.ToTable());
                }
            }
        }
        //Se toma el valor de la membresia y/o mensualidad segun el tipo y categoría del vehículo
        public async Task SeleccionarTipoPlan(string idtipovehiculo, string IdCategoriaVehiculo)
        {
            TiposPlanes tiposPlanes = new TiposPlanes();
            var tiposPlanes_ = await tiposPlanes.SeleccionarTipoPlan(idtipovehiculo, IdCategoriaVehiculo);

            if (tiposPlanes_?.Tables[0]?.Rows.Count > 0)
            {
                DataTable dt = tiposPlanes_.Tables[0];

                // 1. Columna calculada por expresión (reemplaza el foreach y mantiene las filas como DataRowView)
                if (!dt.Columns.Contains("TextoMostrar"))
                {
                    dt.Columns.Add("TextoMostrar", typeof(string),
                        "NombrePlan + ' ' + Cantidad + ' ' + IIF(Unidad = 'Mes', IIF(Cantidad = 1, 'mes', 'meses'), IIF(Cantidad = 1, 'día', 'días'))");
                }

                // 2. DataViews independientes inicializados directamente con su filtro en el constructor
                DataView dvMembresia = new DataView(dt, "IdTipoPlan = 1", "", DataViewRowState.CurrentRows);
                DataView dvMensualidad = new DataView(dt, "IdTipoPlan = 2", "", DataViewRowState.CurrentRows);

                // ==========================================
                // COMBOBOX 1: MEMBRESÍA
                // ==========================================
                CmbPlanMembresia.ItemsSource = dvMembresia;
                CmbPlanMembresia.DisplayMemberPath = "TextoMostrar";
                CmbPlanMembresia.SelectedValuePath = "IdPlanTarifa";
                CmbPlanMembresia.SelectedIndex = dvMembresia.Count > 0 ? 0 : -1;

                // ==========================================
                // COMBOBOX 2: MENSUALIDAD
                // ==========================================
                CmbcantidadMeses.ItemsSource = dvMensualidad;
                CmbcantidadMeses.DisplayMemberPath = "TextoMostrar";
                CmbcantidadMeses.SelectedValuePath = "IdPlanTarifa";
                CmbcantidadMeses.SelectedIndex = dvMensualidad.Count > 0 ? 0 : -1;
            }
            else
            {
                LimpiarCampos();
            }
        }
        private async void CmbTipoVehiculo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox cmb && cmb.DataContext is DataRowView rowView)
            {
                var IdTipoVehiculo = rowView.Row["IdTipoVehiculo"].ToString(); // Obtiene valor seleccionado

                if (IdTipoVehiculo == null)
                {
                    return; // Sale si no hay selección
                }
                else
                {
                    // Usa ?. y ?? para evitar que colapse si SelectedValue es null
                    var sval = cmb.SelectedValue?.ToString() ?? "";

                    if (sval == "0") // Si se eligió la opción "-Agregar o editar-"
                    {
                        // Apagamos el evento para evitar bucles infinitos o saltos raros
                        cmb.SelectionChanged -= CmbTipoVehiculo_SelectionChanged;

                        // BUSCAR EL DATAGRID CONTENEDOR
                        DependencyObject parent = VisualTreeHelper.GetParent(cmb);
                        while (parent != null && !(parent is DataGrid))
                        {
                            parent = VisualTreeHelper.GetParent(parent);
                        }
                        DataGrid dataGrid = parent as DataGrid;

                        if (dataGrid != null)
                        {
                            // Forzamos al DataGrid a salir del modo edición inmediatamente
                            dataGrid.CommitEdit(DataGridEditingUnit.Row, true);
                            dataGrid.CancelEdit();
                        }

                        // Actualizar el DataTable de SQL Server (usando el método corregido sin RowFilter)
                        await TipoVehiculos();

                        if (dataGrid != null)
                        {
                            // EL TRUCO DEFINITIVO PARA EL DATAGRID:
                            // Buscamos la columna del "Tipo Vehículo" por su Header
                            var columna = dataGrid.Columns.FirstOrDefault(c => c.Header?.ToString() == "Tipo Vehículo");
                            if (columna != null)
                            {
                                // Guardamos la plantilla actual (DataTemplate)
                                var plantillaOriginal = (columna as DataGridTemplateColumn).CellTemplate;

                                // La removemos temporalmente (esto destruye los ComboBoxes viejos en caché)
                                (columna as DataGridTemplateColumn).CellTemplate = null;

                                // La volvemos a asignar (obliga al DataGrid a redibujar el ComboBox con los datos nuevos de SQL)
                                (columna as DataGridTemplateColumn).CellTemplate = plantillaOriginal;
                            }
                        }

                        // Limpiar la selección del ComboBox actual
                        cmb.SelectedIndex = -1;

                        await Dispatcher.BeginInvoke(new Action(() =>
                        {
                            cmb.Text = "";
                        }),
                        DispatcherPriority.Background);

                        // 8. Volvemos a encender el evento
                        cmb.SelectionChanged += CmbTipoVehiculo_SelectionChanged;
                    }
                }
            }
        }
        private async void CmbCategoriaVehiculo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox cmb && cmb.DataContext is DataRowView rowView)
            {
                var IdCategoriaVehiculo = rowView.Row["IdCategoriaVehiculo"].ToString(); // Obtiene valor seleccionado

                if (IdCategoriaVehiculo == null)
                {
                    return; // Sale si no hay selección
                }
                else
                {
                    // Usa ?. y ?? para evitar que colapse si SelectedValue es null
                    var sval = cmb.SelectedValue?.ToString() ?? "";

                    if (sval == "0") // Si se eligió la opción "-Agregar o editar-"
                    {
                        // Apagamos el evento para evitar bucles infinitos o saltos raros
                        cmb.SelectionChanged -= CmbCategoriaVehiculo_SelectionChanged;

                        // BUSCAR EL DATAGRID CONTENEDOR
                        DependencyObject parent = VisualTreeHelper.GetParent(cmb);
                        while (parent != null && !(parent is DataGrid))
                        {
                            parent = VisualTreeHelper.GetParent(parent);
                        }
                        DataGrid dataGrid = parent as DataGrid;

                        if (dataGrid != null)
                        {
                            // Forzamos al DataGrid a salir del modo edición inmediatamente
                            dataGrid.CommitEdit(DataGridEditingUnit.Row, true);
                            dataGrid.CancelEdit();
                        }

                        // Actualizar el DataTable de SQL Server (usando el método corregido sin RowFilter)
                        await CategoriaVehiculos();

                        if (dataGrid != null)
                        {
                            // EL TRUCO DEFINITIVO PARA EL DATAGRID:
                            // Buscamos la columna del "Tipo Vehículo" por su Header
                            var columna = dataGrid.Columns.FirstOrDefault(c => c.Header?.ToString() == "Categoría Vehículo");
                            if (columna != null)
                            {
                                // Guardamos la plantilla actual (DataTemplate)
                                var plantillaOriginal = (columna as DataGridTemplateColumn).CellTemplate;

                                // La removemos temporalmente (esto destruye los ComboBoxes viejos en caché)
                                (columna as DataGridTemplateColumn).CellTemplate = null;

                                // La volvemos a asignar (obliga al DataGrid a redibujar el ComboBox con los datos nuevos de SQL)
                                (columna as DataGridTemplateColumn).CellTemplate = plantillaOriginal;
                            }
                        }

                        // Limpiar la selección del ComboBox actual
                        cmb.SelectedIndex = -1;

                        await Dispatcher.BeginInvoke(new Action(() =>
                        {
                            cmb.Text = "";
                        }),
                        DispatcherPriority.Background);

                        // 8. Volvemos a encender el evento
                        cmb.SelectionChanged += CmbCategoriaVehiculo_SelectionChanged;
                    }
                }
            }
        }
        public async Task VehiculosCliente(string Idcliente)
        {
            Vehiculo vehiculo = new Vehiculo();
            try
            {
                var dt = await vehiculo.ListaVehiculosAsync(Idcliente);

                Permisos permisos = new Permisos();
                // Consultar permisos
                bool puedeAgregar = permisos.TienePermiso("Clientes", "Agregar Vehículo");
                bool puedeEditar = permisos.TienePermiso("Clientes", "Editar Vehículo");

                // Si TODOS los permisos están en false, ocultamos toda la columna Acciones
                if (!puedeEditar && !puedeAgregar)
                {
                    ColAccionesVehiculo.Visibility = Visibility.Collapsed;
                }
                else
                {
                    ColAccionesVehiculo.Visibility = Visibility.Visible;
                }

                if (dt != null) // Si hay resultados
                {
                    // Añadimos una columna temporal que no viene de la BD
                    dt.Columns.Add("EsNuevaFila", typeof(bool));

                    // A las filas normales les ponemos false
                    foreach (DataRow r in dt.Rows) r["EsNuevaFila"] = false;

                    // Solo agregamos la fila de guardado si tiene permiso de crear
                    if (puedeAgregar)
                    {
                        // A la fila de edición le ponemos true
                        DataRow rowEdicion = dt.NewRow();
                        rowEdicion["EsNuevaFila"] = true;
                        dt.Rows.Add(rowEdicion);
                    }
                    // Asigna la fuente de datos del DataGrid a la vista por defecto del DataTable
                    DgVehiculosCliente.ItemsSource = dt.DefaultView;
                    // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                    DgVehiculosCliente.CanUserSortColumns = false;
                }
                else
                {
                    DgVehiculosCliente.CanUserAddRows = true;
                    dt.Clear();
                    DgVehiculosCliente.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void DgClientes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (DgClientes.SelectedItem is DataRowView rowView)
                {
                    // Si la fila es nueva (basado en el estado del DataTable) 
                    // o si un campo obligatorio está vacío (tu fila de edición manual)
                    if (rowView.IsNew || rowView.Row.RowState == DataRowState.Detached || string.IsNullOrEmpty(rowView["Idcliente"].ToString()))
                    {
                        DgClientes.UnselectAll();
                    }
                }
                DgPlanesCliente.ItemsSource = null;
                LimpiarCampos();
                if (!(DgClientes.SelectedItem is DataRowView row))
                    return;
                nombreCliente = row["Nombre"].ToString();
                Idcliente = row["Idcliente"].ToString();

                TbNombre.Text = $"Nombre: {nombreCliente}";
                TbDocumento.Text = $"Documento: {row["Tipo"]} {row["Documento"]}";
                TbCelular.Text = $"Celular: {row["Celular"]}";
                TbCorreo.Text = $"Correo: {row["email"]}";

                await VehiculosCliente(Idcliente);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al seleccionar información: " + ex.Message);
            }
        }
        private void TxtPlaca_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!(sender is TextBox textBox))
                return;
            int pos = textBox.SelectionStart;
            // si va en las posiciones 0,1 o 2 → sólo letras
            if (pos == 3)
            {
                textBox.Text += " ";
            }
            if (pos < 3)
            {
                e.Handled = !Regex.IsMatch(e.Text, "^[A-Za-z]$");
            }
            // si va después del guion (pos>=4) → letras o dígitos
            else if (pos >= 3)
            {
                e.Handled = !Regex.IsMatch(e.Text, "^[A-Za-z0-9]$");
            }
            // si está justo en pos==3 (donde debe ir el guion), cancelamos cualquier entrada
            else
            {
                e.Handled = true;
            }
        }
        private void TextBoxPlaca_TextChanged(object sender, EventArgs e)
        {
            if (!(sender is TextBox textBox))
                return;

            // Convertir a mayúsculas y aplicar formato de placa
            string upperText = textBox.Text.ToUpper();

            Library clsLibrary = new Library();
            // Aplica formato placa vehícular sobre el texto en mayúsculas
            string strFormatoPlaca = clsLibrary.FormatPlacaVehiculo(upperText);
            textBox.Text = strFormatoPlaca;
            textBox.CaretIndex = textBox.Text.Length;
        }
        private async void BtnNuevoVehiculo_Click(object sender, RoutedEventArgs e)
        {
            Library library = new Library();

            // Buscamos la celda que contiene al botón
            if (!(sender is Button btnSender)) return;
            DependencyObject parent = VisualTreeHelper.GetParent(btnSender);
            while (parent != null && !(parent is DataGridRow))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }

            // Obtenemos la fila
            if (!(parent is DataGridRow fila))
            {
                return;
            }

            // Buscamos el TextBox por su nombre dentro de la fila
            // Nota: Necesitas una función auxiliar para buscar en el árbol visual
            TextBox TxtPlaca = library.FindChild<TextBox>(fila, "TxtPlaca");
            ComboBox CbTipoVehiculo = library.FindChild<ComboBox>(fila, "cbTipoVehiculo");
            ComboBox CbCategoriaVehiculo = library.FindChild<ComboBox>(fila, "cbCategoriaVehiculo");

            // Validaciones de campos obligatorios y formato de email
            if (TxtPlaca.Text == string.Empty)
            {
                MessageBox.Show("Ingresar placa de vehículo", "Nuevo Vehículo", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPlaca.Focus();
                return;
            }
            //Validar que la placa este escrita correctamente
            else if (!Regex.IsMatch(TxtPlaca.Text.Trim(), @"^[A-Z0-9]{3}\s[A-Z0-9]{3}$"))
            {
                MessageBox.Show("La placa " + TxtPlaca.Text + " no es válida.", "Nuevo Vehículo", MessageBoxButton.OK, MessageBoxImage.Information);
                TxtPlaca.Focus();
                return;
            }
            else if (CbTipoVehiculo.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccionar tipo vehículo", "Nuevo Vehículo", MessageBoxButton.OK, MessageBoxImage.Information);
                CbTipoVehiculo.Focus();
                return;
            }
            else if (CbCategoriaVehiculo.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccionar categoría vehículo", "Nuevo Vehículo", MessageBoxButton.OK, MessageBoxImage.Information);
                CbCategoriaVehiculo.Focus();
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar VEHICULO
                Vehiculo vehiculo = new Vehiculo();
                //Igresar nuevo usuario
                if (await vehiculo.UpsertVehiculoAsync(CbTipoVehiculo.SelectedValue.ToString(), CbCategoriaVehiculo.SelectedValue.ToString(), Idcliente, nombreCliente, TxtPlaca.Text.Trim(), MainWindow.IdUsuario))
                {
                    // actualiza el datagrid
                    await VehiculosCliente(Idcliente);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    TxtPlaca.Focus();
                    TxtPlaca.SelectAll();
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }
        private async void BtnEditarVehiculo_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView rowView)) return;

            string Idvehiculo = rowView.Row["Idvehiculo"].ToString();
            string idtipovehiculo = rowView.Row["idtipovehiculo"].ToString();
            string IdCategoriaVehiculo = rowView.Row["IdCategoriaVehiculo"].ToString();

            // Buscamos la fila que contiene el botón presionado
            if (!(DgVehiculosCliente.ContainerFromElement(btn) is DataGridRow fila))
            {
                return;
            }
            // Ponemos la fila en modo edición oficial de WPF/DataTable
            rowView.BeginEdit();

            await Dispatcher.BeginInvoke(new Action(async () => {

                Library library = new Library();
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;

                if (!(DgVehiculosCliente.Columns[0].GetCellContent(fila) is ContentPresenter cpPlaca)) return;
                if (!(DgVehiculosCliente.Columns[1].GetCellContent(fila) is ContentPresenter cpcbTipoVehiculo)) return;
                if (!(DgVehiculosCliente.Columns[2].GetCellContent(fila) is ContentPresenter cpcbCategoriaVehiculo)) return;
                if (!(DgVehiculosCliente.Columns[3].GetCellContent(fila) is ContentPresenter cpBotones)) return;

                TextBox TxtPlaca = library.FindChild<TextBox>(cpPlaca, "TxtPlaca");
                TextBlock TbPlaca = library.FindChild<TextBlock>(cpPlaca, "TbPlaca");
                ComboBox cbTipoVehiculo = library.FindChild<ComboBox>(cpcbTipoVehiculo, "cbTipoVehiculo");
                ComboBox cbCategoriaVehiculo = library.FindChild<ComboBox>(cpcbCategoriaVehiculo, "cbCategoriaVehiculo");

                if (!(cpBotones.ContentTemplate.FindName("BtnEditarVehiculo", cpBotones) is Button BtnEditar)) return;
                if (!(cpBotones.ContentTemplate.FindName("BtnCancelarVehiculo", cpBotones) is Button BtnCancelarVehiculo)) return;
                Image ImgEditar = null;
                if (cpBotones.ContentTemplate.FindName("ImgEditar", cpBotones) is Image img) ImgEditar = img;

                if (BtnEditar.ToolTip.ToString() == "Editar")
                {
                    // Cambiamos el Tag a "Editando". 
                    // Esto dispara los Triggers de las dos columnas al mismo tiempo.
                    fila.Tag = "Editando";

                    if (TxtPlaca != null)
                    {
                        TxtPlaca.IsReadOnly = false;
                        TxtPlaca.Focus();
                        TxtPlaca.SelectAll();
                    }
                    BtnEditar.ToolTip = "Guardar Cambios";
                    BtnCancelarVehiculo.Visibility = Visibility.Visible;

                    BtnAgregarMembresia.IsEnabled = false;
                    BtnAgregarMembresia.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#C2C2C2");

                    BtnAgregarMensualidad.IsEnabled = false;
                    BtnAgregarMensualidad.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#C2C2C2");

                    // Cambiar cursor a modo normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    // Validaciones de campos obligatorios y formato de email
                    if (TxtPlaca.Text == string.Empty)
                    {
                        MessageBox.Show("Ingresar placa vehículo", "Vehículo", MessageBoxButton.OK, MessageBoxImage.Information);
                        TxtPlaca.Focus();
                        Mouse.OverrideCursor = null;
                        return;
                    }
                    if (cbTipoVehiculo.SelectedIndex == -1)
                    {
                        MessageBox.Show("Seleccionar tipo vehículo", "Vehículo", MessageBoxButton.OK, MessageBoxImage.Information);
                        cbTipoVehiculo.Focus();
                        Mouse.OverrideCursor = null;
                        return;
                    }
                    if (cbCategoriaVehiculo.SelectedIndex == -1)
                    {
                        MessageBox.Show("Seleccionar categoria vehículo", "Vehículo", MessageBoxButton.OK, MessageBoxImage.Information);
                        cbCategoriaVehiculo.Focus();
                        Mouse.OverrideCursor = null;
                        return;
                    }
                    else
                    {
                        // Cambiar cursor a espera
                        Mouse.OverrideCursor = Cursors.Wait;
                        //Inicia el proceso para guardar
                        Vehiculo vehiculo = new Vehiculo();
                        if (await vehiculo.ActualizarVehiculoAsync(Idvehiculo, cbTipoVehiculo.SelectedValue.ToString(), cbCategoriaVehiculo.SelectedValue.ToString(), nombreCliente, TxtPlaca.Text.Trim(), MainWindow.IdUsuario))
                        {
                            // actualiza el datagrid
                            await VehiculosCliente(Idcliente);
                            await SeleccionarTipoPlan(idtipovehiculo, IdCategoriaVehiculo);

                            if (TIMembresia.IsEnabled == true)
                            {
                                BtnAgregarMembresia.IsEnabled = true;
                                BtnAgregarMembresia.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#1565C0");
                            }

                            if (TIMensualidad.IsEnabled == true)
                            {
                                BtnAgregarMensualidad.IsEnabled = true;
                                BtnAgregarMensualidad.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#1565C0");
                            }
                            //Volvemos al modo lectura (los Triggers ocultan los combos)
                            fila.Tag = "Lectura";
                            // Cambiar cursor a modo normal
                            Mouse.OverrideCursor = null;
                        }
                        else
                        {
                            TxtPlaca.Text = TbPlaca.Text;
                        }
                    }
                    // Cambiar cursor a modo normal
                    Mouse.OverrideCursor = null;
                }

            }), DispatcherPriority.Background);
        }

        private async void BtnCancelarVehiculo_Click(object sender, RoutedEventArgs e)
        {
            // Buscamos la fila que contiene el botón presionado
            if (!(sender is Button btn)) return;
            if (!(DgVehiculosCliente.ContainerFromElement(btn) is DataGridRow fila))
            {
                return;
            }

            if (fila != null)
            {
                Library library = new Library();

                if (!(DgVehiculosCliente.Columns[0].GetCellContent(fila) is ContentPresenter cpPlaca)) return;
                if (!(DgVehiculosCliente.Columns[1].GetCellContent(fila) is ContentPresenter cpcbTipoVehiculo)) return;
                if (!(DgVehiculosCliente.Columns[2].GetCellContent(fila) is ContentPresenter cpcbCategoriaVehiculo)) return;
                if (!(DgVehiculosCliente.Columns[3].GetCellContent(fila) is ContentPresenter cpBotones)) return;

                TextBlock TbPlaca = library.FindChild<TextBlock>(cpPlaca, "TbPlaca");
                TextBlock TbTipoVehiculo = library.FindChild<TextBlock>(cpcbTipoVehiculo, "TbTipoVehiculo");
                TextBlock TbCategoriaVehiculo = library.FindChild<TextBlock>(cpcbCategoriaVehiculo, "TbCategoriaVehiculo");


                TextBox TxtPlaca = library.FindChild<TextBox>(cpPlaca, "TxtPlaca");
                ComboBox cbTipoVehiculo = library.FindChild<ComboBox>(cpcbTipoVehiculo, "cbTipoVehiculo");
                ComboBox cbCategoriaVehiculo = library.FindChild<ComboBox>(cpcbCategoriaVehiculo, "cbCategoriaVehiculo");

                if (!(cpBotones.ContentTemplate.FindName("BtnEditarVehiculo", cpBotones) is Button BtnEditar)) return;
                if (!(cpBotones.ContentTemplate.FindName("BtnCancelarVehiculo", cpBotones) is Button BtnCancelarVehiculo)) return;
                //Obtener el dato vinculado a la fila (DataRowView)
                if (fila.Item is DataRowView rowView)
                {
                    // Esto revierte los cambios en el DataTable original
                    rowView.CancelEdit();
                }
                TxtPlaca.Text = TbPlaca.Text;
                cbTipoVehiculo.Text = TbTipoVehiculo.Text;
                cbCategoriaVehiculo.Text = TbCategoriaVehiculo.Text;
                BtnEditar.ToolTip = "Editar";
                BtnCancelarVehiculo.Visibility = Visibility.Collapsed;

                if (TIMembresia.IsEnabled == true)
                {
                    BtnAgregarMembresia.IsEnabled = true;
                    BtnAgregarMembresia.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#1565C0");
                }
                if (TIMensualidad.IsEnabled == true)
                {
                    BtnAgregarMensualidad.IsEnabled = true;
                    BtnAgregarMensualidad.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#1565C0");
                }
                await Dispatcher.BeginInvoke(new Action(async () => {

                    // Cambiar cursor a espera
                    Mouse.OverrideCursor = Cursors.Wait;
                    //Volvemos al modo lectura se restablece todo a su estado original
                    fila.Tag = "Lectura";
                    // Cambiar cursor a modo normal
                    Mouse.OverrideCursor = null;
                }), DispatcherPriority.Background);
            }
        }

        private async void DgVehiculosCliente_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (DgVehiculosCliente.SelectedItem is DataRowView rowView)
                {
                    // Si la fila es nueva (basado en el estado del DataTable) 
                    // o si un campo obligatorio está vacío (tu fila de edición manual)
                    if (rowView.IsNew || rowView.Row.RowState == DataRowState.Detached || string.IsNullOrEmpty(rowView["Idvehiculo"].ToString()))
                    {
                        DgVehiculosCliente.UnselectAll();
                    }
                }
                if (!(DgVehiculosCliente.SelectedItem is DataRowView row))
                    return;

                // --- CÓDIGO PARA ACCEDER AL BOTÓN DE LA FILA SELECCIONADA ---
                var rowContainer = (DataGridRow)DgVehiculosCliente.ItemContainerGenerator.ContainerFromItem(row);
                if (rowContainer != null)
                {
                    Library library = new Library();
                    Button BtnCancelarVehiculo = library.FindChild<Button>(rowContainer, "BtnCancelarVehiculo");

                    // -------------------------------------------------------------

                    IdVehiculo = row["IdVehiculo"].ToString();
                    //nombreCliente = row["idtipovehiculo"].ToString(); IdCategoriaVehiculo
                    if (BtnCancelarVehiculo.Visibility != Visibility.Visible)
                    {
                        await SeleccionarTipoPlan(row["idtipovehiculo"].ToString(), row["IdCategoriaVehiculo"].ToString());
                    }
                    await SeleccionarPlanVehiculo(IdVehiculo);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al seleccionar información: " + ex.Message);
            }
        }

        private void CmbPlanMembresia_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Evaluamos directamente si el elemento seleccionado es un DataRowView
            if (CmbPlanMembresia.SelectedItem is DataRowView rowView)
            {
                // 1. Descripción
                string descripcion = rowView["DescripcionPlan"]?.ToString() ?? string.Empty;
                TbDescripcionMembresia.Text = descripcion;
                TbDescripcionMembresia.ToolTip = descripcion;

                // 2. Fechas de Vigencia
                DateTime? fechaInicio = rowView["FechaInicioVigencia"] != DBNull.Value ? (DateTime?)rowView["FechaInicioVigencia"] : null;
                DateTime? fechaFin = rowView["FechaFinVigencia"] != DBNull.Value ? (DateTime?)rowView["FechaFinVigencia"] : null;

                string strFechaInicioVigencia = fechaInicio.HasValue ? fechaInicio.Value.ToString("dd/MM/yyyy") + " - " : string.Empty;
                string strFechaFinVigencia = fechaFin.HasValue ? fechaFin.Value.ToString("dd/MM/yyyy") : string.Empty;

                TbVigenciaMembresia.Text = strFechaInicioVigencia + strFechaFinVigencia;

                // 3. Precio, Cantidad y Unidad de Membresía
                string Precio = rowView["ValorTarifa"]?.ToString() ?? string.Empty;
                string unidad = rowView["Unidad"]?.ToString() ?? string.Empty;
                int cantidad = rowView["Cantidad"] != DBNull.Value ? Convert.ToInt32(rowView["Cantidad"]) : 0;

                TbPrecioMembresia.Text = Precio;

                TbMembresia.Text = unidad == "Mes"
                    ? (cantidad > 1 ? $"{cantidad} Meses" : $"{cantidad} Mes")
                    : (cantidad > 1 ? $"{cantidad} Días" : $"{cantidad} Día");

                // Capturas el IdPlanTarifa (que ya tenías)
                IdPlanTarifaMembresia = rowView["IdPlanTarifa"].ToString();

                // Capturas también el IdPlan directamente de la misma fila seleccionada
                IdPlanMembresia = rowView["IdPlan"].ToString();
            }
        }

        private void DtpFechaInicioMembresia_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbPlanMembresia.SelectedItem is DataRowView rowView && DtpFechaInicioMembresia.SelectedDate.HasValue)
            {
                string unidad = rowView["Unidad"]?.ToString() ?? string.Empty;
                int cantidad = rowView["Cantidad"] != DBNull.Value ? Convert.ToInt32(rowView["Cantidad"]) : 0;
                DateTime fechaInicio = DtpFechaInicioMembresia.SelectedDate.Value;

                DateTime fechaFin = unidad.Contains("Mes") ? fechaInicio.AddMonths(cantidad) : fechaInicio.AddDays(cantidad);

                // Actualizamos el TextBlock de la fecha fin
                TbFechafinMembresia.Text = fechaFin.ToString("dd/MM/yyyy");
            }
        }

        private void DtpFechaInicioMes_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbcantidadMeses.SelectedItem is DataRowView rowView && DtpFechaInicioMes.SelectedDate.HasValue)
            {
                string unidad = rowView["Unidad"]?.ToString() ?? string.Empty;
                int cantidad = rowView["Cantidad"] != DBNull.Value ? Convert.ToInt32(rowView["Cantidad"]) : 0;
                DateTime fechaInicio = DtpFechaInicioMes.SelectedDate.Value;

                DateTime fechaFin = unidad.Contains("Mes") ? fechaInicio.AddMonths(cantidad) : fechaInicio.AddDays(cantidad);

                // Actualizamos el TextBlock de la fecha fin
                TbFechafinMes.Text = fechaFin.ToString("dd/MM/yyyy");
            }
        }

        private void CmbcantidadMeses_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Evaluamos directamente si el elemento seleccionado es un DataRowView
            if (CmbcantidadMeses.SelectedItem is DataRowView rowView)
            {
                // 1. Descripción
                string descripcion = rowView["DescripcionPlan"]?.ToString() ?? string.Empty;
                TbDescripcionMes.Text = descripcion;
                TbDescripcionMes.ToolTip = descripcion;

                // 2. Fechas de Vigencia
                DateTime? fechaInicio = rowView["FechaInicioVigencia"] != DBNull.Value ? (DateTime?)rowView["FechaInicioVigencia"] : null;
                DateTime? fechaFin = rowView["FechaFinVigencia"] != DBNull.Value ? (DateTime?)rowView["FechaFinVigencia"] : null;

                string strFechaInicioVigencia = fechaInicio.HasValue ? fechaInicio.Value.ToString("dd/MM/yyyy") + " - " : string.Empty;
                string strFechaFinVigencia = fechaFin.HasValue ? fechaFin.Value.ToString("dd/MM/yyyy") : string.Empty;

                TbVigenciaMes.Text = strFechaInicioVigencia + strFechaFinVigencia;

                // 3. Precio, Cantidad y Unidad de Membresía
                string Precio = rowView["ValorTarifa"]?.ToString() ?? string.Empty;
                string unidad = rowView["Unidad"]?.ToString() ?? string.Empty;
                int cantidad = rowView["Cantidad"] != DBNull.Value ? Convert.ToInt32(rowView["Cantidad"]) : 0;

                TbPrecioMes.Text = Precio;

                TbMes.Text = unidad == "Mes"
                    ? (cantidad > 1 ? $"{cantidad} Meses" : $"{cantidad} Mes")
                    : (cantidad > 1 ? $"{cantidad} Días" : $"{cantidad} Día");
                // Capturas el IdPlanTarifa (que ya tenías)
                IdPlanTarifaMensualidad = rowView["IdPlanTarifa"].ToString();

                // Capturas también el IdPlan directamente de la misma fila seleccionada
                IdPlanMensualidad = rowView["IdPlan"].ToString();
            }
        }

        private async void BtnAgregarMembresia_Click(object sender, RoutedEventArgs e)
        {
            if (CmbPlanMembresia.SelectedIndex == -1)
            {
                MessageBox.Show("Ingresar tipo de membresía", "Membresía", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbPlanMembresia.Focus();
                Mouse.OverrideCursor = null;
                return;
            }
            if (DtpFechaInicioMembresia.Text == string.Empty)
            {
                MessageBox.Show("Seleccionar fecha", "Membresía", MessageBoxButton.OK, MessageBoxImage.Information);
                DtpFechaInicioMembresia.Focus();
                Mouse.OverrideCursor = null;
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar membresía seleccionada
                TiposPlanes tiposPlanes = new TiposPlanes();
                //Igresar nuevo usuario
                if (await tiposPlanes.NuevaMembresia(IdVehiculo, IdPlanMembresia, IdPlanTarifaMembresia, DtpFechaInicioMembresia.Text, MainWindow.IdUsuario))
                {
                    // actualiza el datagrid
                    await SeleccionarPlanVehiculo(IdVehiculo);
                    // actualiza el datagrid
                    await VehiculosCliente(Idcliente);
                    MessageBox.Show("Membresía agregada correctamente","Nueva Membresía",MessageBoxButton.OK, MessageBoxImage.Information);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }

        private async void BtnAgregarMensualidad_Click(object sender, RoutedEventArgs e)
        {
            if (CmbcantidadMeses.SelectedIndex == -1)
            {
                MessageBox.Show("Ingresar cantidad meses", "Mensualidad", MessageBoxButton.OK, MessageBoxImage.Information);
                CmbcantidadMeses.Focus();
                Mouse.OverrideCursor = null;
                return;
            }
            if (DtpFechaInicioMes.Text == string.Empty)
            {
                MessageBox.Show("Seleccionar fecha", "Mensualidad", MessageBoxButton.OK, MessageBoxImage.Information);
                DtpFechaInicioMes.Focus();
                Mouse.OverrideCursor = null;
                return;
            }
            else
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar membresía seleccionada
                TiposPlanes tiposPlanes = new TiposPlanes();
                //Igresar mensualidad seleccionada
                if (await tiposPlanes.NuevaMensualidad(IdVehiculo, IdPlanMensualidad, IdPlanTarifaMensualidad, DtpFechaInicioMes.Text, MainWindow.IdUsuario))
                {
                    // actualiza el datagrid
                    await SeleccionarPlanVehiculo(IdVehiculo);
                    // actualiza el datagrid
                    await VehiculosCliente(Idcliente);
                    MessageBox.Show("Mensualidad agregada correctamente", "Nueva Membresía", MessageBoxButton.OK, MessageBoxImage.Information);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
        }

        private async void BtnPagarPlan_Click(object sender, RoutedEventArgs e)
        {
            // Buscamos la fila que contiene el botón presionado
            if (!(sender is Button btn)) return;
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;
            if (!(DgPlanesCliente.ContainerFromElement(btn) is DataGridRow fila))
            {
                return;
            }

            if (fila != null)
            {
                Library library = new Library();

                if (!(DgPlanesCliente.Columns[10].GetCellContent(fila) is ContentPresenter cpCmbMedioPago)) return;

                ComboBox CmbMedioPago = library.FindChild<ComboBox>(cpCmbMedioPago, "CmbMedioPago");

                //Obtener el dato vinculado a la fila (DataRowView)
                if (fila.Item is DataRowView rowView)
                {
                    // Esto revierte los cambios en el DataTable original
                    rowView.CancelEdit();
                }

                if (CmbMedioPago.SelectedIndex == -1)
                {
                    MessageBox.Show("Seleccionar medio de pago", "Seleccionar Medio Pago", MessageBoxButton.OK, MessageBoxImage.Information);
                    CmbMedioPago.Focus();
                    Mouse.OverrideCursor = null;
                    return;
                }
                else
                {
                    //Pregunta antes de proceder con el pago
                    MessageBoxResult messageBoxResult = MessageBox.Show($"¿Confirmar pago {filaSeleccionada["TipoPlan"]} de categoría {filaSeleccionada["CategoriaVehiculo"]} y tipo {filaSeleccionada["TipoVehiculo"]} con vigencia de {filaSeleccionada["Vigencia"]} por valor de de {filaSeleccionada["PrecioContratado"]}?", "Confirmar Pago", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (messageBoxResult == MessageBoxResult.Yes)
                    {
                        // Cambiar cursor a espera
                        Mouse.OverrideCursor = Cursors.Wait;
                        //Clase de guardar membresía seleccionada
                        TiposPlanes tiposPlanes = new TiposPlanes();
                        //Igresar mensualidad seleccionada
                        if (await tiposPlanes.RecibirPagoMembresiaMensualidad(filaSeleccionada["IdVehiculoPlan"].ToString(), CmbMedioPago.SelectedValue.ToString(), MainWindow.IdUsuario))
                        {
                            // actualiza el datagrid
                            await SeleccionarPlanVehiculo(IdVehiculo);
                            // actualiza el datagrid
                            await VehiculosCliente(Idcliente);
                            MessageBox.Show($"Pago {filaSeleccionada["TipoPlan"]} recibido correctamente", "pago Exitoso", MessageBoxButton.OK, MessageBoxImage.Information);
                            // Cambiar cursor a normal
                            Mouse.OverrideCursor = null;
                        }
                        else
                        {
                            // Cambiar cursor a normal
                            Mouse.OverrideCursor = null;
                        }
                    }
                    else
                    {
                        // Cambiar cursor a normal
                        Mouse.OverrideCursor = null;
                    }
                }
            }
        }

        private async void BtnEliminarPlan_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;


            //Pregunta antes de proceder con el pago
            MessageBoxResult messageBoxResult = MessageBox.Show($"¿Eliminar  {filaSeleccionada["TipoPlan"]} de categoría {filaSeleccionada["CategoriaVehiculo"]} y tipo {filaSeleccionada["TipoVehiculo"]} con vigencia de {filaSeleccionada["Vigencia"]} por valor de de {filaSeleccionada["PrecioContratado"]}?", "Confirmar Eliminación", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar membresía seleccionada
                TiposPlanes tiposPlanes = new TiposPlanes();
                //Igresar mensualidad seleccionada
                if (await tiposPlanes.EliminarMembresiaMensualidad(filaSeleccionada["IdVehiculoPlan"].ToString(), MainWindow.IdUsuario))
                {
                    // actualiza el datagrid
                    await SeleccionarPlanVehiculo(IdVehiculo);
                    // actualiza el datagrid
                    await VehiculosCliente(Idcliente);
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
            else
            {
                // Cambiar cursor a normal
                Mouse.OverrideCursor = null;
            }
        }

        private async void BtnEliminarCliente_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button btn)) return; // Botón que disparó el evento
            // Obtiene el DataContext de la fila correspondiente, que debe ser un DataRowView
            if (!(btn.DataContext is DataRowView filaSeleccionada)) return;


            //Pregunta antes de proceder con la inactivacion del cliente
            MessageBoxResult messageBoxResult = MessageBox.Show($"¿Eliminar cliente {filaSeleccionada["Nombre"]} con documento {filaSeleccionada["Tipo"]} número: {filaSeleccionada["Documento"]}?", "Confirmar Eliminación", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (messageBoxResult == MessageBoxResult.Yes)
            {
                // Cambiar cursor a espera
                Mouse.OverrideCursor = Cursors.Wait;
                //Clase de guardar membresía seleccionada
                Clientes_ cliente = new Clientes_();
                //Igresar mensualidad seleccionada
                if (await cliente.InactivarCliente(filaSeleccionada["Idcliente"].ToString(), MainWindow.IdUsuario))
                {
                    // actualiza el datagrid
                    CargarClientes(TxtBuscarCliente.Text.Trim().Replace("'", "").Replace("\"", ""), 1, pageSize);
                    DgVehiculosCliente.ItemsSource = null;
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
                else
                {
                    // Cambiar cursor a normal
                    Mouse.OverrideCursor = null;
                }
            }
            else
            {
                // Cambiar cursor a normal
                Mouse.OverrideCursor = null;
            }
        }

        private void LimpiarCampos()
        {
            CmbPlanMembresia.ItemsSource = null;
            CmbcantidadMeses.ItemsSource = null;

            DtpFechaInicioMembresia.Text = "";
            DtpFechaInicioMes.Text = "";

            TbDescripcionMembresia.Text = "";
            TbPrecioMembresia.Text = "";
            TbVigenciaMembresia.Text = "";
            TbMembresia.Text = "";

            TbDescripcionMes.Text = "";
            TbPrecioMes.Text = "";
            TbVigenciaMes.Text = "";
            TbMes.Text = "";
        }

        private void BtnHistorialVehiculos_Click(object sender, RoutedEventArgs e)
        {
            HistorialVehiculosCliente historialVehiculosCliente = new HistorialVehiculosCliente(Idcliente);
            historialVehiculosCliente.ShowDialog();
        }

        /*Permisos - roles*/

        private void ContenedorAccionesCliente_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is StackPanel panel)
            {
                Permisos permisos = new Permisos();

                // Buscar los controles internos por tipo/nombre dentro del template
                var btnEditar = panel.Children.OfType<Button>().FirstOrDefault(b => b.Name == "BtnEditar");
                var btnEliminar = panel.Children.OfType<Button>().FirstOrDefault(b => b.Name == "BtnEliminarCliente");

                // 1. Evaluar permisos globales
                bool puedeEditar = permisos.TienePermiso("Clientes", "Editar Cliente");
                bool puedeEliminar = permisos.TienePermiso("Clientes", "Eliminar Cliente");

                // Aplicar a los botones
                if (btnEditar != null)
                    btnEditar.Visibility = puedeEditar ? Visibility.Visible : Visibility.Collapsed;

                if (btnEliminar != null)
                    btnEliminar.Visibility = puedeEliminar ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        private void ContenedorAccionesVehiculo_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is StackPanel panel)
            {
                Permisos permisos = new Permisos();

                // Buscar los controles internos por tipo/nombre dentro del template
                var btnEditar = panel.Children.OfType<Button>().FirstOrDefault(b => b.Name == "BtnEditarVehiculo");
                var btnNuevo = panel.Children.OfType<Button>().FirstOrDefault(b => b.Name == "BtnNuevoVehiculo");

                // 1. Evaluar permisos globales
                bool puedeEditar = permisos.TienePermiso("Clientes", "Editar Vehículo");
                bool puedeAgregar = permisos.TienePermiso("Clientes", "Agregar Vehículo");

                // Aplicar a los botones
                if (btnEditar != null)
                    btnEditar.Visibility = puedeEditar ? Visibility.Visible : Visibility.Collapsed;

                if (btnNuevo != null)
                    btnNuevo.Visibility = puedeAgregar ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        private void TcPlan_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is TabControl panel)
            {
                Permisos permisos = new Permisos();

                // Buscar los controles internos por tipo/nombre dentro del template
                var agregarMembresia = panel.Items.OfType<TabItem>().FirstOrDefault(b => b.Name == "TIMembresia");
                var agregarMensualidad = panel.Items.OfType<TabItem>().FirstOrDefault(b => b.Name == "TIMensualidad");

                // 1. Evaluar permisos globales
                bool puedeAgregarMembresia = permisos.TienePermiso("Clientes", "Agregar Membresía");
                bool puedeAgregarMensualidad = permisos.TienePermiso("Clientes", "Agregar Mensualidad");

                // Aplicar a los botones
                if (agregarMembresia != null)
                    // Deshabilita el contenido interno sea cual sea su tipo de control
                    if (agregarMembresia?.Content is UIElement contenido)
                    {
                        agregarMembresia.IsEnabled = puedeAgregarMembresia ? true : false;
                        contenido.IsEnabled = puedeAgregarMembresia ? true : false;
                        BtnAgregarMembresia.Background = puedeAgregarMembresia ? (SolidColorBrush)new BrushConverter().ConvertFrom("#1565C0") : (SolidColorBrush)new BrushConverter().ConvertFrom("#C2C2C2");
                    }
                    

                if (agregarMensualidad != null)
                    // Deshabilita el contenido interno sea cual sea su tipo de control
                    if (agregarMensualidad?.Content is UIElement contenido)
                    {
                        agregarMensualidad.IsEnabled = puedeAgregarMensualidad ? true : false;
                        contenido.IsEnabled = puedeAgregarMensualidad ? true : false;
                        BtnAgregarMensualidad.Background = puedeAgregarMensualidad ? (SolidColorBrush)new BrushConverter().ConvertFrom("#1565C0") : (SolidColorBrush)new BrushConverter().ConvertFrom("#C2C2C2");
                    }
            }
        }

        private void ContenedorPlanesCliente_Loaded(object sender, RoutedEventArgs e)
        {
            if (sender is StackPanel panel)
            {
                Permisos permisos = new Permisos();

                // Buscar los controles internos por tipo/nombre dentro del template
                var BtnPagarPlan = panel.Children.OfType<Button>().FirstOrDefault(b => b.Name == "BtnPagarPlan");
                var BtnEliminarPlan = panel.Children.OfType<Button>().FirstOrDefault(b => b.Name == "BtnEliminarPlan");

                // 1. Evaluar permisos globales
                bool puedePagarPlan = permisos.TienePermiso("Clientes", "Realizar Pago");

                // Aplicar a los botones
                if (BtnPagarPlan != null)
                    BtnPagarPlan.Visibility = puedePagarPlan ? Visibility.Visible : Visibility.Collapsed;
                    BtnEliminarPlan.Visibility = puedePagarPlan ? Visibility.Visible : Visibility.Collapsed;
            }
        }
    }
}