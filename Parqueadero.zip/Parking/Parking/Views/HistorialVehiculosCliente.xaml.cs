﻿using Microsoft.Win32;
using Parking.Controller;
using System;
using System.Data;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.IO;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para HistorialVehiculosCliente.xaml
    /// </summary>
    public partial class HistorialVehiculosCliente : Window
    {
        public HistorialVehiculosCliente(string Idcliente)
        {
            InitializeComponent();
            CargarHistorial(Idcliente);
        }
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                ReleaseCapture(); // Libera la captura del mouse
                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0); // Simula el arrastre de la ventana
            }
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }

        public async void CargarHistorial(string Idcliente)
        {
            Vehiculo vehiculo = new Vehiculo();

            var dt = await vehiculo.HistorialVeHiculos(Idcliente);
            if (dt != null)
            {
                StringBuilder sb = new StringBuilder();

                // Verifica si la tabla 0 (registros) tiene filas
                if (dt.Tables[0].Rows.Count > 0)
                {
                    // Verificamos si hay datos en el DataSet
                    if (dt != null && dt.Tables.Count > 0 && dt.Tables[0].Rows.Count > 0)
                    {
                        string placaAnterior = "";

                        foreach (DataRow row in dt.Tables[0].Rows)
                        {
                            string placaActual = row["Placa"].ToString();

                            // Si la placa cambia (o es la primera vez), mostramos el encabezado del vehículo una sola vez
                            if (placaActual != placaAnterior)
                            {
                                if (placaAnterior != "")
                                {
                                    sb.AppendLine(); // Espacio en blanco si hubiera otro vehículo diferente
                                }

                                sb.AppendLine("========================================");
                                sb.AppendLine($"🚗 PLACA: {placaActual} (VIP: {row["EsVIP"]})");
                                sb.AppendLine("========================================");
                                sb.AppendLine($"• Tipo: {row["TipoVehiculo"]}");
                                sb.AppendLine($"• Categoría: {row["CategoriaVehiculo"]}");
                                sb.AppendLine($"• Vehículo Activo: {(row["VehiculoActivo"].ToString() == "True" ? "Sí" : "No")}");

                                placaAnterior = placaActual; // Actualizamos la placa controlada
                            }

                            // Mostramos los detalles del plan correspondiente a este vehículo
                            sb.AppendLine("----------------------------------------------------------------------");
                            sb.AppendLine($"📋 PLAN CONTRATADO: {row["Plan"]}");
                            sb.AppendLine($"• Tipo de Plan: {row["TipoPlan"]}");
                            sb.AppendLine($"• Vigencia: {row["FechaInicio"]} al {row["FechaFin"]}");
                            sb.AppendLine($"• Precio: {row["PrecioContratado"]}");
                            sb.AppendLine($"• Estado Contrato: {row["EstadoContrato"]}");
                            sb.AppendLine($"• Estado Pago: {row["EstadoPago"]} (Fecha: {row["FechaPago"]})");
                            sb.AppendLine($"• Fecha de Registro: {row["FechaRegistro"]}");
                        }
                    }
                    else
                    {
                        sb.AppendLine("No se encontraron registros para este cliente.");
                    }

                    // Insertar el texto formateado en el RichTextBox de WPF
                    TextRange textRange = new TextRange(
                        richTextBoxHistorial.Document.ContentStart,
                        richTextBoxHistorial.Document.ContentEnd
                    );

                    textRange.Text = sb.ToString();
                }
            }
        }
        private void BtnExportar_Click(object sender, RoutedEventArgs e)
        {
            // 1. Configurar el SaveFileDialog con filtros para TXT y PDF
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Title = "Exportar contenido del RichTextBox",
                Filter = "Archivo de Texto (*.txt)|*.txt",
                DefaultExt = "txt",
                AddExtension = true
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                string extension = Path.GetExtension(filePath).ToLower();

                // Extraer todo el contenido de texto del RichTextBox
                TextRange textRange = new TextRange(
                    richTextBoxHistorial.Document.ContentStart,
                    richTextBoxHistorial.Document.ContentEnd
                );

                if (extension == ".txt")
                {
                    // --- EXPORTAR A TXT (Nativo de .NET) ---
                    try
                    {
                        File.WriteAllText(filePath, textRange.Text);
                        MessageBox.Show($"Archvo {saveFileDialog.SafeFileName} se guardo correctamente", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show($"Error al guardar el archivo de texto: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}