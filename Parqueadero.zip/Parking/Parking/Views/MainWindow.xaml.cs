﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow(Login login)
        {
            InitializeComponent();
            this.login = login;
        }
        readonly Login login;
        public const int WM_NCLBUTTONDOWN = 0xA1; // Constante usada para arrastrar la ventana personalizada
        public const int HTCAPTION = 0x2; // Constante usada para arrastrar la ventana
        static bool isMax = false; // Indica si la ventana está maximizada
        static Point old_loc, default_loc; // Ubicaciones de la ventana
        static Size old_size, default_size; // Tamaños de la ventana
        public static string IdUsuario = "1";//Id usuario logueado
        public static string Permisos { get; set; } //Permisos de usuario

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture(); // Método externo para liberar captura de mouse

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam); // Método externo para enviar mensaje a ventana

        // Evento que permite arrastrar la ventana manteniendo presionado el mouse sobre el frame
        private void Frame_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed && isMax == false)
            {
                ReleaseCapture(); // Libera la captura del mouse para permitir arrastre

                var winHandle = new WindowInteropHelper(this).Handle; // Obtiene el handle (HWND) de la ventana
                SendMessage(winHandle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
                // Envía mensaje para simular que se hizo clic en la barra de título (inicia arrastre)
            }
        }
        private void BtnMinimize_Click(object sender, RoutedEventArgs e)
        {
            // Cambia el estado de la ventana a minimizado
            this.WindowState = WindowState.Minimized;
        }

        private void BtnRestore_Click(object sender, RoutedEventArgs e)
        {
            // Convierte sender a Button para modificar su contenido iconográfico
            Button btn = (Button)sender;
            // Llama al método estático que alterna maximizar/restaurar
            Maximize(this, btn);
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Cierra la ventana que contiene este elemento
            Window.GetWindow(this).Close();
        }

        private void MainW_Loaded(object sender, RoutedEventArgs e)
        {
            IdUsuario = login.IdUsuario;//Id usuario logueado
        }
        static void Maximize(Window win)
        {
            double x = SystemParameters.WorkArea.Width;  // Ancho del área de trabajo (sin barra de tareas)
            double y = SystemParameters.WorkArea.Height; // Alto del área de trabajo
            win.Top = 0;     // Posiciona la ventana en el top (0)
            win.Left = 0;    // Posiciona la ventana en el left (0)
            win.Width = x;   // Establece ancho igual al área de trabajo
            win.Height = y;  // Establece alto igual al área de trabajo
        }

        public static void Maximize(Window win, Button btn)
        {
            if (isMax == false)
            {
                // Si no está maximizada, guarda el tamaño y posición actual
                old_size = new Size(win.Width, win.Height);
                old_loc = new Point(win.Top, win.Left);
                Maximize(win);   // Maximiza la ventana
                isMax = true;    // Actualiza el flag a verdadero (ahora está maximizada)
                btn.Content = "2"; // Cambia contenido del botón para indicar "restaurar" (puede ser un ícono o texto)
            }
            else
            {
                // Si ya estaba maximizada, restaura al tamaño y posición anteriores o por defecto
                if (old_size.Width >= SystemParameters.WorkArea.Width ||
                    old_size.Height >= SystemParameters.WorkArea.Height)
                {
                    // Si el tamaño anterior excede el área de trabajo, usa tamaño por defecto
                    win.Top = default_loc.Y;
                    win.Left = default_loc.X;
                    win.Width = default_size.Width;
                    win.Height = default_size.Height;
                }
                else
                {
                    // Si el tamaño cabía en el área de trabajo, restaura posición y tamaño guardados
                    win.Top = old_loc.Y;
                    win.Left = old_loc.X;
                    win.Width = old_size.Width;
                    win.Height = old_size.Height;
                }
                isMax = false;   // Actualiza el flag a falso (ahora está restaurada)
                btn.Content = "1"; // Cambia contenido del botón para indicar "maximizar"
            }
        }
    }
}