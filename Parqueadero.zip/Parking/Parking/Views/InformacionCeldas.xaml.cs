﻿using Parking.Controller;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using static Parking.Views.Celdas;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para InformacionCeldas.xaml
    /// </summary>
    public partial class InformacionCeldas : Page
    {
        public InformacionCeldas()
        {
            InitializeComponent();
        }
        List<InfoVehiculo> LstInfoVehiculo = new List<InfoVehiculo>();
        private DataSet _dsCeldasCache; // Variable para almacenar los datos en memoria
        private DataTable DtNivel;
        public static DataView NivelView { get; set; }// Propiedades que exponemos al combobox
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Obtiene la ventana que contiene esta página
            var window = Window.GetWindow(this);
            if (window is MainWindow mainWindow)
            {
                // Limpia el contenido del contenedor principal (fContainer)
                mainWindow.ContenedorPrincipal.Content = null;
            }
        }

        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            await SeleccionarNivel();
        }

        public async Task SeleccionarNivel()
        {
            Nivel nivel = new Nivel();
            try
            {
                DtNivel = new DataTable();
                var dt = await nivel.SeleccionarNivelAsync();
                if (dt != null)
                {
                    DtNivel = dt.Tables[0];
                    if (DtNivel.Rows.Count > 0)
                    {
                        // Asigno la vista de la tabla estados niveles para binding a los ComboBox
                        NivelView = DtNivel.DefaultView;
                        //Evita que aparezca "-Todos los Niveles-"
                        NivelView.RowFilter = "IdNivel <> 0";
                        DtNivel.Rows.Add("0", "Todos los Niveles");
                        DataView dv = new DataView(DtNivel) { // Crea DataView para ordenar
                            Sort = "IdNivel DESC", // Ordena por ID descendente
                        };
                        DtNivel = dv.ToTable(); // Convierte de nuevo a DataTable
                        CmbSeleccionarNivel.ItemsSource = DtNivel.DefaultView; // Asocia items al ComboBox
                        CmbSeleccionarNivel.DisplayMemberPath = "Nombre"; // Muestra el nombre de la categoría
                        CmbSeleccionarNivel.SelectedValuePath = "IdNivel"; // El valor seleccionado será el ID
                    }
                    else
                    {
                        DtNivel.Rows.Add("0", "Todos los Niveles"); // Agrega opción editar/agregar
                        CmbSeleccionarNivel.ItemsSource = DtNivel.DefaultView;
                        CmbSeleccionarNivel.DisplayMemberPath = "Nombre"; // Muestra el nombre de la categoría
                        CmbSeleccionarNivel.SelectedValuePath = "IdNivel"; // El valor seleccionado será el ID
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Obtiene las celdas por nivel y su estado actual de estas
        public async Task CargarCeldasAsync(int idNivel)
        {
            try
            {
                Celda celda = new Celda();
                _dsCeldasCache = await celda.ObtenerCeldasPorNivelAsync(idNivel);

                // Cargar inicialmente todas las celdas
                RenderizarCeldas(_dsCeldasCache, string.Empty);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al obtener celdas.\n{ex.Message}", "Celdas", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void TxtBuscar_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_dsCeldasCache != null)
            {
                // Filtra según lo que el usuario escriba en el TextBox
                RenderizarCeldas(_dsCeldasCache, TxtBuscar.Text.Trim());
            }
        }
        private void RenderizarCeldas(DataSet ds, string filtro)
        {
            wpCeldas.Children.Clear();

            LstInfoVehiculo = ds.Tables[1].AsEnumerable().Select(fila => new InfoVehiculo
            {
                IdCelda = fila.Field<int>("IdCelda"),
                FechaEntrada = fila.Field<string>("FechaEntrada"),
                Estado = fila.Field<bool>("Estado"),
                Placa = fila.Field<string>("Placa"),
                Nombre = fila.Field<string>("Nombre")
            }).ToList();
            TbNivel.Text = CmbSeleccionarNivel.Text;
            // Total fijo de celdas obtenidas del nivel
            int totalCeldasFijo = ds.Tables[0].Rows.Count;
            int contadorVisibles = 0;

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                string codigo = row["Codigo"].ToString();
                string idEstadoCelda = row["IdEstadoCelda"].ToString();
                int idCelda = Convert.ToInt32(row["IdCelda"]);

                InfoVehiculo infoVehiculo = LstInfoVehiculo.FirstOrDefault(p => p.IdCelda == idCelda);
                string placa = infoVehiculo != null ? infoVehiculo.Placa : string.Empty;
                string tipo = infoVehiculo != null ? infoVehiculo.Nombre : string.Empty;
                string fechaIngreso = infoVehiculo != null ? infoVehiculo.FechaEntrada : string.Empty;

                // Aplicar el filtro de búsqueda
                if (!string.IsNullOrEmpty(filtro))
                {
                    bool coincideCodigo = codigo.IndexOf(filtro, StringComparison.OrdinalIgnoreCase) >= 0;
                    bool coincidePlaca = placa.IndexOf(filtro, StringComparison.OrdinalIgnoreCase) >= 0;

                    if (!coincideCodigo && !coincidePlaca)
                    {
                        continue;
                    }
                }

                contadorVisibles++;

                string info = $"Código: {codigo}\nEstado: {row["Estado"]}\n";
                if (infoVehiculo != null)
                {
                    info += $"Placa: {placa}\nTipo: {tipo}\nFecha Ingreso: {fechaIngreso}";
                }

                Color color = (Color)ColorConverter.ConvertFromString(idEstadoCelda == "1" ? "#57aa3c" : (idEstadoCelda == "2" ? "#fda603" : "#c2c2c2"));

                DropShadowEffect shadowEffect = new DropShadowEffect
                {
                    Color = (Color)ColorConverter.ConvertFromString("#10000000"),
                    BlurRadius = 8,
                    ShadowDepth = 2,
                    Direction = 270
                };

                Grid grid = new Grid();

                TextBlock textBlock = new TextBlock
                {
                    TextWrapping = TextWrapping.Wrap,
                    FontSize = 12,
                    FontWeight = FontWeights.SemiBold,
                    FontFamily = new FontFamily("Arial"),
                    Foreground = (Brush)new BrushConverter().ConvertFromString("#172B4D"),
                    Margin = new Thickness(0, 0, 0, 16),
                    VerticalAlignment = VerticalAlignment.Center,
                    Text = info
                };
                Grid.SetRow(textBlock, 1);
                grid.Children.Add(textBlock);

                Border border = new Border
                {
                    Background = new SolidColorBrush(color),
                    BorderBrush = (Brush)new BrushConverter().ConvertFromString("#E1E4E8"),
                    BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(4),
                    Margin = new Thickness(8),
                    Padding = new Thickness(16),
                    Effect = shadowEffect,
                    Child = grid
                };

                wpCeldas.Children.Add(border);
            }

            // Mantiene el valor fijo del total de celdas del nivel (puedes agregar cuántas se muestran si filtras)
            TbCantidadCeldas.Text = $"Cantidad de Celdas: {totalCeldasFijo}" + (!string.IsNullOrEmpty(filtro) ? $" (Mostrando {contadorVisibles})" : "");
        }
        private async void CmbSeleccionarNivel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TxtBuscar.Text = string.Empty;
            await CargarCeldasAsync(int.Parse(CmbSeleccionarNivel.SelectedValue.ToString()));
        }
    }
}