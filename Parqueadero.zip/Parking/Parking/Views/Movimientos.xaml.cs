﻿using Parking.Controller;
using Parking.Models;
using Parking.ViewModels;
using System;
using System.Data;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace Parking.Views
{
    /// <summary>
    /// Lógica de interacción para EntradaSalida.xaml
    /// </summary>
    public partial class EntradaSalida : Page
    {
        public EntradaSalida()
        {
            InitializeComponent();
            // Enlazar el DataContext de la ventana con esta instancia
            this.DataContext = dashboardViewModel;
        }
        DataTable dtOriginal;
        string StrPlaca = "";
        string IdTipoVehiculo = "";
        string IdCategoriaVehiculo = "";
        //datos del vehiculo
        private DataSet dtDatosVehiculo;
        // Declaras o instancias tu ViewModel a nivel de la clase de la Ventana
        public DashboardViewModel dashboardViewModel = new DashboardViewModel();
        private async void Page_Loaded(object sender, RoutedEventArgs e)
        {
            MovimientosVehiculos();
            // Configurar el Temporizador para refrescar automáticamente cada 5 segundos
            var timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };

            // Se quita el 'await' de aquí
            timer.Tick += async (s, args) => await ListaNivelesDashBoard();
            timer.Start();
            TxtPlaca.Focus();
        }
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            // Obtiene la ventana que contiene esta página
            var window = Window.GetWindow(this);
            if (window is MainWindow mainWindow)
            {
                // Limpia el contenido del contenedor principal (fContainer)
                mainWindow.ContenedorPrincipal.Content = null;
            }
        }
        private void TxtPlaca_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!(sender is TextBox textBox))
                return;
            int pos = textBox.SelectionStart;
            // si va en las posiciones 0,1 o 2 → sólo letras
            if (pos == 3)
            {
                textBox.Text += " ";
            }
            if (pos < 3)
            {
                e.Handled = !Regex.IsMatch(e.Text, "^[A-Za-z]$");
            }
            // si va después del guion (pos>=4) → letras o dígitos
            else if (pos >= 3)
            {
                e.Handled = !Regex.IsMatch(e.Text, "^[A-Za-z0-9]$");
            }
            // si está justo en pos==3 (donde debe ir el guion), cancelamos cualquier entrada
            else
            {
                e.Handled = true;
            }
        }
        private void TextBoxPlaca_TextChanged(object sender, EventArgs e)
        {
            if (!(sender is TextBox textBox))
                return;

            // Convertir a mayúsculas y aplicar formato de placa
            string upperText = textBox.Text.ToUpper();

            Library clsLibrary = new Library();
            // Aplica formato placa vehícular sobre el texto en mayúsculas
            string strFormatoPlaca = clsLibrary.FormatPlacaVehiculo(upperText);
            textBox.Text = strFormatoPlaca;
            textBox.CaretIndex = textBox.Text.Length;
        }

        private async void TxtPlaca_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TxtPlaca.Text.Length != 7)
                {
                    MessageBox.Show("Ingresar placa vehículo","Placa no Valida", MessageBoxButton.OK, MessageBoxImage.Information);
                    TxtPlaca.Focus();
                    return;
                }
                else
                {
                    StrPlaca = "";
                    Movimientos movimientos = new Movimientos();
                    //verificar si el vehiculo esta dentro del estacionamiento
                    if (await movimientos.VehiculoEstaDentroAsync(TxtPlaca.Text.Trim()))
                    {
                        // Busqueda tipo plan actual del vehiculo
                        DataRow[] filas = dtDatosVehiculo.Tables[0].Select($"Placa = '{TxtPlaca.Text.ToUpper().Trim()}'");
                        DataRow primeraFila = filas[0];
                        string IdTipoPlan = primeraFila["IdTipoPlan"].ToString();
                        string IdMovimiento = primeraFila["IdMovimiento"].ToString();
                        string IdPlan = primeraFila["IdPlan"].ToString();

                        if(IdTipoPlan == "3")
                        {
                            var seleccionarTarifa = new SeleccionarTarifa(this)
                            {
                                IdPlan = IdPlan,
                                IdMovimiento = IdMovimiento,
                                Placa = TxtPlaca.Text.Trim().ToUpper()
                            };
                            seleccionarTarifa.ShowDialog();
                        }
                        else
                        {
                            EstadoVehiculo(TxtPlaca.Text.Trim());
                            if(TxtPlaca.Text.Length == 7)
                            {
                                await RegistrarSalida(TxtPlaca.Text.Trim().ToUpper(), IdTipoVehiculo, IdCategoriaVehiculo, IdMovimiento, "1", MainWindow.IdUsuario);
                            }
                        }
                    }
                    else
                    {
                        var entradaVehiculo = new EntradaVehiculo(this)
                        {
                            TxtPlaca = TxtPlaca.Text.Trim().ToUpper(),
                        };
                        entradaVehiculo.ShowDialog();
                    }
                }
            }
        }

        public async void MovimientosVehiculos()
        {
            Movimientos movimientos = new Movimientos();
            try
            {
                var dt = await movimientos.MovimientosVehiculoslAsync();

                if (dt != null) // Si hay resultados
                {
                    // Verifica si la tabla 0 (registros) tiene filas
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        dtDatosVehiculo = dt;
                        DgVehiculos.ItemsSource = dt.Tables[0].DefaultView;
                        // Deshabilita el ordenamiento de columnas en tiempo de ejecución
                        DgVehiculos.CanUserSortColumns = false;
                    }
                    else
                    {
                        dt.Clear();
                        DgVehiculos.ItemsSource = dt.Tables[0].DefaultView;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private async void EstadoVehiculo(string Placa)
        {
            // Busqueda tipo plan actual del vehiculo
            DataRow[] filas = dtDatosVehiculo.Tables[0].Select($"Placa = '{Placa.ToUpper().Trim()}'");
            DataRow primeraFila = filas[0];

            //Id del tipo de plan del vehiculo
            string IdTipoPlan = primeraFila["IdTipoPlan"].ToString();
            bool EsVIP = Convert.ToBoolean(primeraFila["EsVIP"]);
            IdTipoVehiculo = primeraFila["IdTipoVehiculo"].ToString();
            IdCategoriaVehiculo = primeraFila["IdCategoriaVehiculo"].ToString();
            

            try
            {
                Movimientos movimientos = new Movimientos();

                var ds = await movimientos.TipoVehiculolAsync(IdTipoPlan);

                if (ds != null) // Si hay resultados
                {
                    // Guardamos la tabla completa (CON TODAS SUS COLUMNAS)
                    dtOriginal = ds.Tables[0];

                    if (IdTipoPlan == "3")
                    {
                        richTextBoxPlan.Document.Blocks.Clear();
                        int IdPlan = Convert.ToInt32(primeraFila["IdPlan"]);
                        // Creamos una mini-tabla SOLO para el ComboBox (para quitar los duplicados en la lista desplegable)
                        DataTable dtCombo = dtOriginal.DefaultView.ToTable(true, "IdPlan", "NombrePlan");

                        CmbSeleccionarTarifa.IsEnabled = true;
                        // Asignamos la mini-tabla ÚNICAMENTE al ComboBox
                        CmbSeleccionarTarifa.ItemsSource = dtCombo.DefaultView;
                        CmbSeleccionarTarifa.DisplayMemberPath = "NombrePlan";
                        CmbSeleccionarTarifa.SelectedValuePath = "IdPlan";
                        CmbSeleccionarTarifa.SelectedValue = IdPlan;
                    }
                    else
                    {
                        CmbSeleccionarTarifa.ItemsSource = null;
                        CmbSeleccionarTarifa.IsEnabled = false;
                        richTextBoxPlan.Document.Blocks.Clear();
                        if (!EsVIP)
                        {
                            MembresiaMensualidadInfo(Placa, IdTipoVehiculo, IdCategoriaVehiculo);
                        }
                        else
                        {
                            VIPInfo(Placa);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        // registra la salida del vehículo 
        public async Task RegistrarSalida(string Placa, string idTipoVehiculo, string idCategoriaVehiculo, string idMovimiento, string idMetodoPago, string idUsuarioSalida)
        {
            MessageBoxResult confirmar = MessageBox.Show($"Confirmar salida vehículo con placa: '{Placa}'", "Confirmar Salida", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if(confirmar == MessageBoxResult.Yes)
            {
                Movimientos movimientos = new Movimientos();

                if(await movimientos.RegistrarSalidaVehiculoAsync(Placa, idTipoVehiculo, idCategoriaVehiculo, idMovimiento, idMetodoPago, idUsuarioSalida))
                {
                    CmbSeleccionarTarifa.ItemsSource = null;
                    CmbSeleccionarTarifa.IsEnabled = false;
                    richTextBoxPlan.Document.Blocks.Clear();
                    TxtPlaca.Text = string.Empty;
                    tbValorPagar.Text = "$ 0,0";
                    MovimientosVehiculos();
                }
            }
        }
        private void CmbSeleccionarTarifa_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Validar que haya un elemento seleccionado y que la placa no esté vacía
            if (CmbSeleccionarTarifa.SelectedItem is DataRowView rowView)
            {
                string nombrePlanSeleccionado = rowView["NombrePlan"].ToString();

                // Filtrar dtOriginal según el NombrePlan seleccionado
                DataRow[] filas = dtOriginal.Select($"NombrePlan = '{nombrePlanSeleccionado}'");

                if (filas.Length > 0)
                {
                    // CORRECCIÓN: Tomamos únicamente la primera fila del plan seleccionado 
                    // para evitar llamadas múltiples y concurrentes a la base de datos.
                    DataRow primeraFila = filas[0];

                    IdTipoVehiculo = primeraFila["IdTipoVehiculo"].ToString();
                    IdCategoriaVehiculo = primeraFila["IdCategoriaVehiculo"].ToString();

                    TiempoDemandaInfo(StrPlaca == "" ? TxtPlaca.Text.Trim():StrPlaca, IdTipoVehiculo, IdCategoriaVehiculo, dtOriginal);
                }
            }
        }

        private string FormatearHoraAMPM(object valorHora)
        {
            if (valorHora == null || valorHora == DBNull.Value)
                return string.Empty;

            if (valorHora is TimeSpan ts)
            {
                return DateTime.Today.Add(ts).ToString("hh:mm:ss tt", new System.Globalization.CultureInfo("en-US"));
            }
            else if (DateTime.TryParse(valorHora.ToString(), out DateTime dt))
            {
                return dt.ToString("hh:mm:ss tt", new System.Globalization.CultureInfo("en-US"));
            }

            return valorHora.ToString();
        }
        private async void MembresiaMensualidadInfo(string Placa, string IdTipoVehiculo, string IdCategoriaVehiculo)
        {
            Movimientos movimientos = new Movimientos();

            var dt = await movimientos.TipoVehiculoMembresiaMensualidadlAsync(Placa, IdTipoVehiculo, IdCategoriaVehiculo);

            if (dt != null) // Si hay resultados
            {
                if (dt.Tables[0].Rows.Count > 0)
                {
                    FlowDocument documento = new FlowDocument()
                    {
                        FontFamily = new FontFamily("Arial"),
                        FontSize = 11
                    };

                    DataRow primeraFila = dt.Tables[1].Rows[0];

                    // Encabezado General (Tarifa, Tipo, Categoría)
                    Paragraph parrafoGeneral = new Paragraph
                    {
                        Margin = new Thickness(0, 0, 0, 0)
                    };

                    // Texto normal para la etiqueta
                    parrafoGeneral.Inlines.Add(new Run("Placa: ") { FontWeight = FontWeights.Bold });

                    // Texto en negrita para el valor del plan
                    parrafoGeneral.Inlines.Add(new Run($"{Placa}\n"));

                    // Texto normal para la etiqueta
                    parrafoGeneral.Inlines.Add(new Run("Tipo plan: ") { FontWeight = FontWeights.Bold });

                    // Texto en negrita para el valor del plan
                    parrafoGeneral.Inlines.Add(new Run($"{primeraFila["NombrePlan"]}\n"));

                    // Texto normal para la etiqueta
                    parrafoGeneral.Inlines.Add(new Run("Tipo: ") { FontWeight = FontWeights.Bold });

                    // Texto en negrita para el valor del plan
                    parrafoGeneral.Inlines.Add(new Run($"{primeraFila["NombreTipoVehiculo"]}\n"));

                    // Texto normal para la etiqueta
                    parrafoGeneral.Inlines.Add(new Run("Categoría: ") { FontWeight = FontWeights.Bold });

                    // Texto en negrita para el valor del plan
                    parrafoGeneral.Inlines.Add(new Run($"{primeraFila["NombreCategoriaVehiculo"]}\n"));

                    // Texto normal para la etiqueta
                    parrafoGeneral.Inlines.Add(new Run("Descripción plan: ") { FontWeight = FontWeights.Bold });

                    // Texto en negrita para el valor del plan
                    parrafoGeneral.Inlines.Add(new Run($"{primeraFila["DescripcionPlan"]}"));

                    documento.Blocks.Add(parrafoGeneral);

                    // 4. Sección inferior (Días de la semana)
                    // Crear el separador nativo de WPF
                    Separator separador = new Separator
                    {
                        Height = 1,
                        Background = Brushes.Gray,
                        Margin = new Thickness(0, 5, 0, 5) // Espaciado superior e inferior
                    };
                    // Agregar el separador al documento mediante BlockUIContainer
                    documento.Blocks.Add(new BlockUIContainer(separador));

                    // Verificar que el DataSet contenga la información necesaria
                    if (dt.Tables[0] != null && dt.Tables[0].Rows.Count > 0 && dt.Tables[0].Rows.Count > 0)
                    {
                        DataRow rowResumen = dt.Tables[0].Rows[0];
                        // Cliente, precio plan, estado contrado, vigencia plan
                        Paragraph parrafoDatosPlan = new Paragraph
                        {
                            Margin = new Thickness(0, 0, 0, 0)
                        };
                        // Texto normal para la etiqueta
                        parrafoDatosPlan.Inlines.Add(new Run("Nombre: ") { FontWeight = FontWeights.Bold });

                        // Texto en negrita para el valor del plan
                        parrafoDatosPlan.Inlines.Add(new Run($"{rowResumen["Nombre"]}\n"));

                        // Texto normal para la etiqueta
                        parrafoDatosPlan.Inlines.Add(new Run("Fecha inicio: ") { FontWeight = FontWeights.Bold });

                        // Texto en negrita para el valor del plan
                        parrafoDatosPlan.Inlines.Add(new Run($"{rowResumen["FechaInicio"]}\n"));

                        // Texto normal para la etiqueta
                        parrafoDatosPlan.Inlines.Add(new Run("Fecha fin: ") { FontWeight = FontWeights.Bold });

                        // Texto en negrita para el valor del plan
                        parrafoDatosPlan.Inlines.Add(new Run($"{rowResumen["FechaInicio"]}\n"));

                        // Texto normal para la etiqueta
                        parrafoDatosPlan.Inlines.Add(new Run("Días restantes: ") { FontWeight = FontWeights.Bold });

                        // Texto en negrita para el valor del plan
                        parrafoDatosPlan.Inlines.Add(new Run($"{rowResumen["DiasRestantes"]}\n"));

                        // Texto normal para la etiqueta
                        parrafoDatosPlan.Inlines.Add(new Run("Precio: ") { FontWeight = FontWeights.Bold });

                        // Texto en negrita para el valor del plan
                        parrafoDatosPlan.Inlines.Add(new Run($"{rowResumen["PrecioContratado"]}\n"));

                        // Texto normal para la etiqueta
                        parrafoDatosPlan.Inlines.Add(new Run("Estado: ") { FontWeight = FontWeights.Bold });

                        // Texto en negrita para el valor del plan
                        parrafoDatosPlan.Inlines.Add(new Run($"{rowResumen["EstadoContrato"]}"));
                        documento.Blocks.Add(parrafoDatosPlan);

                        if(rowResumen["EstadoContrato"].ToString() == "Vencida")
                        {
                            // Crear el separador nativo de WPF
                            Separator separadorTD = new Separator
                            {
                                Height = 1,
                                Background = Brushes.Gray,
                                Margin = new Thickness(0, 5, 0, 5) // Espaciado superior e inferior
                            };
                            // Agregar el separador al documento mediante BlockUIContainer
                            documento.Blocks.Add(new BlockUIContainer(separadorTD));

                            // Verificar que el DataSet contenga la información necesaria
                            if (dt.Tables[2] != null && dt.Tables.Count > 0 && dt.Tables[2].Rows.Count > 0)
                            {
                                DataRow row = dt.Tables[2].Rows[0];

                                // ==========================================
                                // 2. SECCIÓN DE CABECERA (DATOS GENERALES)
                                // ==========================================
                                Paragraph pHeader = new Paragraph { Margin = new Thickness(0, 0, 0, 15) };

                                void AgregarLineaHeader(string etiqueta, string valor)
                                {
                                    Run runEtiqueta = new Run(etiqueta); // Texto normal
                                    Run runValor = new Run(valor) { FontWeight = FontWeights.Bold }; // Valor en negrita
                                    pHeader.Inlines.Add(runEtiqueta);
                                    pHeader.Inlines.Add(runValor);
                                    pHeader.Inlines.Add(new LineBreak());
                                }

                                AgregarLineaHeader("Hora llegada: ", row["HoraLlegada"].ToString());
                                AgregarLineaHeader("Hora salida: ", row["HoraSalidaConsultada"].ToString());
                                AgregarLineaHeader("Tiempo de permanencia: ", row["TiempoPermanencia"].ToString());
                                AgregarLineaHeader("Tipo vehículo: ", row["TipoVehiculo"].ToString());
                                AgregarLineaHeader("Categoría vehículo: ", row["CategoriaVehiculo"].ToString());
                                AgregarLineaHeader("Nivel: ", row["Nivel"].ToString());
                                AgregarLineaHeader("Celda: ", row["Celda"].ToString());
                                AgregarLineaHeader("Modalidad de cobro: ", row["ModalidadCobro"].ToString());

                                // Tomamos el plan tarifario del primer registro del detalle
                                string nombrePlan = (dt.Tables.Count > 1 && dt.Tables[2].Rows.Count > 0)
                                                    ? dt.Tables[3].Rows[0]["PlanTarifario"].ToString()
                                                    : "";
                                AgregarLineaHeader("Plan: ", nombrePlan);

                                documento.Blocks.Add(pHeader);

                                // ==========================================
                                // 3. SECCIÓN DE TABLA DE DETALLE
                                // ==========================================
                                if (dt.Tables.Count > 1)
                                {
                                    DataTable dtDetalle = dt.Tables[3];

                                    Table tablaDetalle = new Table
                                    {
                                        CellSpacing = 0,
                                        BorderBrush = Brushes.Black,
                                        BorderThickness = new Thickness(1),
                                        Margin = new Thickness(0, 0, 0, 15)
                                    };

                                    // Definir las 7 columnas exactas de tu estructura
                                    int colCount = 7;
                                    for (int i = 0; i < colCount; i++)
                                    {
                                        tablaDetalle.Columns.Add(new TableColumn());
                                    }

                                    TableRowGroup rowGroup = new TableRowGroup();

                                    // --- ENCABEZADOS DE LA TABLA ---
                                    TableRow headerRow = new TableRow { Background = Brushes.LightGray };
                                    string[] headers = { "Tipo cálculo", "Fecha inicio", "Fecha fin", "Jornada", "Tiempo tramo formateado", "Minutos gratis aplicados", "Tiempo cobrado formateado" };

                                    foreach (string h in headers)
                                    {
                                        headerRow.Cells.Add(new TableCell(new Paragraph(new Run(h) { FontWeight = FontWeights.Bold })
                                        {
                                            FontSize = 10,
                                            Margin = new Thickness(4)
                                        })
                                        {
                                            BorderBrush = Brushes.Black,
                                            BorderThickness = new Thickness(0.5)
                                        });
                                    }
                                    rowGroup.Rows.Add(headerRow);

                                    // --- FILAS DE DATOS ---
                                    foreach (DataRow filaDetalle in dtDetalle.Rows)
                                    {
                                        TableRow dataRow = new TableRow();

                                        string[] valoresCelda = {
                                        filaDetalle["TipoCalculo"].ToString(),
                                        filaDetalle["FechaHoraInicio"].ToString(),
                                        filaDetalle["FechaHoraFin"].ToString(),
                                        filaDetalle["Jornada"].ToString(),
                                        filaDetalle["TiempoTramoFormateado"].ToString(),
                                        filaDetalle["MinutosGratisAplicados"].ToString(),
                                        filaDetalle["ImporteFormateado"].ToString() // O la columna de tiempo cobrado formateado según prefieras mostrar en esa celda
                                     };

                                        foreach (string val in valoresCelda)
                                        {
                                            dataRow.Cells.Add(new TableCell(new Paragraph(new Run(val))
                                            {
                                                FontSize = 10,
                                                Margin = new Thickness(4)
                                            })
                                            {
                                                BorderBrush = Brushes.Black,
                                                BorderThickness = new Thickness(0.5)
                                            });
                                        }
                                        rowGroup.Rows.Add(dataRow);
                                    }

                                    tablaDetalle.RowGroups.Add(rowGroup);
                                    documento.Blocks.Add(tablaDetalle);
                                }

                                // ==========================================
                                // 4. SECCIÓN DE PIE (TOTAL A PAGAR)
                                // ==========================================
                                Paragraph pTotal = new Paragraph { Margin = new Thickness(0, 5, 0, 0) };
                                pTotal.Inlines.Add(new Run("Total a pagar formateado: "));
                                pTotal.Inlines.Add(new Run($"{row["TotalPorPagarFormateado"]}") { FontWeight = FontWeights.Bold, FontSize = 12 });
                                tbValorPagar.Text = row["TotalPorPagarFormateado"].ToString();
                                documento.Blocks.Add(pTotal);
                            }
                        }
                    }
                    // Asignar el documento al RichTextBox
                    richTextBoxPlan.Document = documento;
                }
            }
        }
        public async void TiempoDemandaInfo(string Placa, string IdTipoVehiculo, string IdCategoriaVehiculo, DataTable tiempoDemanda)
        {
            // Filtrar dtOriginal según el NombrePlan seleccionado
            DataRow[] filas = tiempoDemanda.Select($"IdTipoVehiculo = '{IdTipoVehiculo}' AND IdCategoriaVehiculo = '{IdCategoriaVehiculo}'");

            if (filas.Length > 0)
            {
                Movimientos movimientos = new Movimientos();

                FlowDocument documento = new FlowDocument()
                {
                    FontFamily = new FontFamily("Arial"),
                    FontSize = 11
                };

                DataRow primeraFila = filas[0];

                // 1. Encabezado General (Tarifa, Tipo, Categoría)
                Paragraph parrafoGeneral = new Paragraph();
                parrafoGeneral.Inlines.Add(new Run($"Tarifa: {primeraFila["NombrePlan"]}\n") { FontWeight = FontWeights.Bold });
                parrafoGeneral.Inlines.Add(new Run($"Tipo: {primeraFila["NombreTipoVehiculo"]}\n"));
                parrafoGeneral.Inlines.Add(new Run($"Categoría: {primeraFila["NombreCategoriaVehiculo"]}"));
                documento.Blocks.Add(parrafoGeneral);

                // 2. Crear Tabla para los horarios en columnas (lado a lado)
                Table tablaHorarios = new Table();
                int numHorarios = filas.Length;

                for (int i = 0; i < numHorarios; i++)
                {
                    tablaHorarios.Columns.Add(new TableColumn());
                }

                TableRowGroup grupoFilas = new TableRowGroup();

                // Fila: Nombre del Horario
                TableRow filaNombre = new TableRow();
                foreach (DataRow fila in filas)
                {
                    filaNombre.Cells.Add(new TableCell(new Paragraph(new Run($"Horario: {fila["NombrePlanHorario"]}") { FontWeight = FontWeights.Bold })));
                }
                grupoFilas.Rows.Add(filaNombre);

                // Fila: Hora inicio
                TableRow filaHoraInicio = new TableRow();
                foreach (DataRow fila in filas)
                {
                    filaHoraInicio.Cells.Add(new TableCell(new Paragraph(new Run($"Hora inicio: {FormatearHoraAMPM(fila["HoraInicio"])}"))));
                }
                grupoFilas.Rows.Add(filaHoraInicio);
                
                // Fila: Hora fin
                TableRow filaHoraFin = new TableRow();
                foreach (DataRow fila in filas)
                {
                    filaHoraFin.Cells.Add(new TableCell(new Paragraph(new Run($"Hora fin: {FormatearHoraAMPM(fila["HoraFin"])}"))));
                }
                grupoFilas.Rows.Add(filaHoraFin);

                // Fila: Valor minuto
                TableRow filaValMin = new TableRow();
                foreach (DataRow fila in filas)
                {
                    filaValMin.Cells.Add(new TableCell(new Paragraph(new Run($"Valor minuto: {fila["ValorMinuto"]}"))));
                }
                grupoFilas.Rows.Add(filaValMin);

                // Fila: Valor hora
                TableRow filaValHora = new TableRow();
                foreach (DataRow fila in filas)
                {
                    filaValHora.Cells.Add(new TableCell(new Paragraph(new Run($"Valor hora: {fila["ValorHora"]}"))));
                }
                grupoFilas.Rows.Add(filaValHora);
                
                // Fila: Valor 12 horas
                TableRow filaVal12 = new TableRow();
                foreach (DataRow fila in filas)
                {
                    filaVal12.Cells.Add(new TableCell(new Paragraph(new Run($"Valor 12 horas: {fila["Valor12Horas"]}"))));
                }
                grupoFilas.Rows.Add(filaVal12);

                // Fila: Valor 24 horas
                TableRow filaVal24 = new TableRow();
                foreach (DataRow fila in filas)
                {
                    filaVal24.Cells.Add(new TableCell(new Paragraph(new Run($"Valor 24 horas: {fila["Valor24Horas"]}"))));
                }
                grupoFilas.Rows.Add(filaVal24);
                // Fila: fraccion hora(minutos)
                TableRow filaHoraFraccion = new TableRow();
                foreach (DataRow fila in filas)
                {
                    filaHoraFraccion.Cells.Add(new TableCell(new Paragraph(new Run($"Hora fracción: {fila["MinutosFraccion"]} minuto(s)"))));
                }
                // Fila: minutos gratis
                TableRow minutosGratis = new TableRow();
                foreach (DataRow fila in filas)
                {
                    minutosGratis.Cells.Add(new TableCell(new Paragraph(new Run($"minutos gratis: {fila["MinutosGracia"]} minuto(s)"))));
                }
                grupoFilas.Rows.Add(minutosGratis);
                // Fila: minutos fracción hora
                TableRow minutosFraccionHora = new TableRow();
                foreach (DataRow fila in filas)
                {
                    minutosFraccionHora.Cells.Add(new TableCell(new Paragraph(new Run($"Fracción hora: {fila["MinutosFraccion"]} {(Convert.ToInt32(fila["MinutosFraccion"]) > 1 ? "minutos" : "minuto")}"))));
                }
                grupoFilas.Rows.Add(minutosFraccionHora);
                
                tablaHorarios.RowGroups.Add(grupoFilas);
                documento.Blocks.Add(tablaHorarios);

                // 3. Sección inferior (Días de la semana)
                Paragraph parrafoDias = new Paragraph
                {
                    Margin = new Thickness(0)
                };
                parrafoDias.Inlines.Add(new Run($"Días: {primeraFila["DiasSemana"]}") { FontWeight = FontWeights.Bold });
                documento.Blocks.Add(parrafoDias);

                // 4. Sección inferior (Días de la semana)
                // Crear el separador nativo de WPF
                Separator separador = new Separator
                {
                    Height = 1,
                    Background = Brushes.Gray,
                    Margin = new Thickness(0, 5, 0, 5) // Espaciado superior e inferior
                };

                // Agregar el separador al documento mediante BlockUIContainer
                documento.Blocks.Add(new BlockUIContainer(separador));

                // Llamar al método pasando solo la placa
                DataSet dsResultado = await movimientos.CalcularCobroEstadiaAsync(Placa, primeraFila["IdTipoVehiculo"].ToString(), primeraFila["IdCategoriaVehiculo"].ToString());
                
                // Verificar que el DataSet contenga la información necesaria
                if (dsResultado != null && dsResultado.Tables.Count > 0 && dsResultado.Tables[0].Rows.Count > 0)
                {
                    DataRow rowResumen = dsResultado.Tables[0].Rows[0];

                    // ==========================================
                    // 2. SECCIÓN DE CABECERA (DATOS GENERALES)
                    // ==========================================
                    Paragraph pHeader = new Paragraph { Margin = new Thickness(0, 0, 0, 15) };

                    void AgregarLineaHeader(string etiqueta, string valor)
                    {
                        Run runEtiqueta = new Run(etiqueta); // Texto normal
                        Run runValor = new Run(valor) { FontWeight = FontWeights.Bold }; // Valor en negrita
                        pHeader.Inlines.Add(runEtiqueta);
                        pHeader.Inlines.Add(runValor);
                        pHeader.Inlines.Add(new LineBreak());
                    }

                    AgregarLineaHeader("Placa: ", rowResumen["Placa"].ToString());
                    AgregarLineaHeader("Hora llegada: ", rowResumen["HoraLlegada"].ToString());
                    AgregarLineaHeader("Hora salida: ", rowResumen["HoraSalidaConsultada"].ToString());
                    AgregarLineaHeader("Tiempo de permanencia: ", rowResumen["TiempoPermanencia"].ToString());
                    AgregarLineaHeader("Tipo vehículo: ", rowResumen["TipoVehiculo"].ToString());
                    AgregarLineaHeader("Categoría vehículo: ", rowResumen["CategoriaVehiculo"].ToString());
                    AgregarLineaHeader("Nivel: ", rowResumen["Nivel"].ToString());
                    AgregarLineaHeader("Celda: ", rowResumen["Celda"].ToString());
                    AgregarLineaHeader("Modalidad de cobro: ", rowResumen["ModalidadCobro"].ToString());

                    // Tomamos el plan tarifario del primer registro del detalle
                    string nombrePlan = (dsResultado.Tables.Count > 1 && dsResultado.Tables[1].Rows.Count > 0)
                                        ? dsResultado.Tables[1].Rows[0]["PlanTarifario"].ToString()
                                        : "";
                    AgregarLineaHeader("Plan: ", nombrePlan);

                    documento.Blocks.Add(pHeader);

                    // ==========================================
                    // 3. SECCIÓN DE TABLA DE DETALLE
                    // ==========================================
                    if (dsResultado.Tables.Count > 1)
                    {
                        DataTable dtDetalle = dsResultado.Tables[1];

                        Table tablaDetalle = new Table
                        {
                            CellSpacing = 0,
                            BorderBrush = Brushes.Black,
                            BorderThickness = new Thickness(1),
                            Margin = new Thickness(0, 0, 0, 15)
                        };

                        // Definir las 7 columnas exactas de tu estructura
                        int colCount = 7;
                        for (int i = 0; i < colCount; i++)
                        {
                            tablaDetalle.Columns.Add(new TableColumn());
                        }

                        TableRowGroup rowGroup = new TableRowGroup();

                        // --- ENCABEZADOS DE LA TABLA ---
                        TableRow headerRow = new TableRow { Background = Brushes.LightGray };
                        string[] headers = { "Tipo cálculo", "Fecha inicio", "Fecha fin", "Jornada", "Tiempo tramo formateado", "Minutos gratis aplicados", "Tiempo cobrado formateado" };

                        foreach (string h in headers)
                        {
                            headerRow.Cells.Add(new TableCell(new Paragraph(new Run(h) { FontWeight = FontWeights.Bold })
                            {
                                FontSize = 10,
                                Margin = new Thickness(4)
                            })
                            {
                                BorderBrush = Brushes.Black,
                                BorderThickness = new Thickness(0.5)
                            });
                        }
                        rowGroup.Rows.Add(headerRow);

                        // --- FILAS DE DATOS ---
                        foreach (DataRow filaDetalle in dtDetalle.Rows)
                        {
                            TableRow dataRow = new TableRow();

                            string[] valoresCelda = {
                                filaDetalle["TipoCalculo"].ToString(),
                                filaDetalle["FechaHoraInicio"].ToString(),
                                filaDetalle["FechaHoraFin"].ToString(),
                                filaDetalle["Jornada"].ToString(),
                                filaDetalle["TiempoTramoFormateado"].ToString(),
                                filaDetalle["MinutosGratisAplicados"].ToString(),
                                filaDetalle["ImporteFormateado"].ToString() // O la columna de tiempo cobrado formateado según prefieras mostrar en esa celda
                             };

                            foreach (string val in valoresCelda)
                            {
                                dataRow.Cells.Add(new TableCell(new Paragraph(new Run(val))
                                {
                                    FontSize = 10,
                                    Margin = new Thickness(4)
                                })
                                {
                                    BorderBrush = Brushes.Black,
                                    BorderThickness = new Thickness(0.5)
                                });
                            }
                            rowGroup.Rows.Add(dataRow);
                        }

                        tablaDetalle.RowGroups.Add(rowGroup);
                        documento.Blocks.Add(tablaDetalle);
                    }

                    // ==========================================
                    // 4. SECCIÓN DE PIE (TOTAL A PAGAR)
                    // ==========================================
                    Paragraph pTotal = new Paragraph { Margin = new Thickness(0, 5, 0, 0) };
                    pTotal.Inlines.Add(new Run("Total a pagar formateado: "));
                    pTotal.Inlines.Add(new Run($"{rowResumen["TotalPorPagarFormateado"]}") { FontWeight = FontWeights.Bold, FontSize = 12 });
                    tbValorPagar.Text = rowResumen["TotalPorPagarFormateado"].ToString();
                    documento.Blocks.Add(pTotal);
                }

                // Asignar el documento al RichTextBox
                richTextBoxPlan.Document = documento;
            }
        }
        private async void VIPInfo(string Placa)
        {
            Movimientos movimientos = new Movimientos();
            var dt = await movimientos.VIPInfoAsync(Placa);

            if (dt != null)
            {
                FlowDocument documento = new FlowDocument()
                {
                    FontFamily = new FontFamily("Arial"),
                    FontSize = 11
                };

                DataRow primeraFila = dt.Tables[0].Rows[0];

                // Encabezado General (Tarifa, Tipo, Categoría)
                Paragraph parrafoGeneral = new Paragraph
                {
                    Margin = new Thickness(0, 0, 0, 0)
                };

                // Texto normal para la etiqueta
                parrafoGeneral.Inlines.Add(new Run("Nombre: ") { FontWeight = FontWeights.Bold });

                // Texto en negrita para el valor del plan
                parrafoGeneral.Inlines.Add(new Run($"{primeraFila["Nombre"]}\n"));

                // Texto normal para la etiqueta
                parrafoGeneral.Inlines.Add(new Run("Placa: ") { FontWeight = FontWeights.Bold });

                // Texto en negrita para el valor del plan
                parrafoGeneral.Inlines.Add(new Run($"{primeraFila["Placa"]}\n"));

                // Texto normal para la etiqueta
                parrafoGeneral.Inlines.Add(new Run("Tipo: ") { FontWeight = FontWeights.Bold });

                // Texto en negrita para el valor del plan
                parrafoGeneral.Inlines.Add(new Run($"{primeraFila["TipoVehiculo"]}\n"));

                // Texto normal para la etiqueta
                parrafoGeneral.Inlines.Add(new Run("Categoría: ") { FontWeight = FontWeights.Bold });

                // Texto en negrita para el valor del plan
                parrafoGeneral.Inlines.Add(new Run($"{primeraFila["CategoriaVehiculo"]}\n"));

                // Texto normal para la etiqueta
                parrafoGeneral.Inlines.Add(new Run("Descripción plan: ") { FontWeight = FontWeights.Bold });

                // Texto en negrita para el valor del plan
                parrafoGeneral.Inlines.Add(new Run($"VIP"));

                documento.Blocks.Add(parrafoGeneral);

                // Asignar el documento al RichTextBox
                richTextBoxPlan.Document = documento;
            }
        }
        private void DataGridRow_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            // Obtener la fila sobre la que se hizo clic
            if (sender is DataGridRow gridRow && gridRow.Item is DataRowView rowView)
            {
                // Forzar la selección de la fila al hacer clic
                gridRow.IsSelected = true;

                DataRow row = rowView.Row;
                // Leer el tipo de plan de forma segura
                StrPlaca = row.Field<string>("Placa").ToString();
                // La condición 'if / else' va AFUERA de la creación del objeto
                EstadoVehiculo(StrPlaca);
            }
        }

        public async Task ListaNivelesDashBoard()
        {
            Nivel nivel = new Nivel();
            try
            {
                var dt = await nivel.NivelesAsync();
                if (dt != null) // Si hay resultados
                {
                    // Al llamar a este método sobre la misma instancia, los textos se actualizarán automáticamente en el XAML
                    dashboardViewModel.NivelEstado(dt.Tables[0]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void DgVehiculos_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // Verifica que el emisor sea efectivamente una fila
            if (sender is DataGridRow gridRow && gridRow.Item is DataRowView rowView)
            {
                DataRow row = rowView.Row;
                // Extraer el tipo de plan para decidir qué vista cargar
                string IdTipoPlan = row.Field<int?>("IdTipoPlan").ToString() ?? string.Empty;
                string IdPlan = row.Field<int?>("IdPlan").ToString() ?? string.Empty;
                string Placa = row.Field<string>("Placa") ?? string.Empty;
                string IdMovimiento = row.Field<int>("IdMovimiento").ToString() ?? string.Empty;
                string IdTipoVehiculo = row.Field<int>("IdTipoVehiculo").ToString() ?? string.Empty;
                string IdCategoriaVehiculo = row.Field<int>("IdCategoriaVehiculo").ToString() ?? string.Empty;

                if (IdTipoPlan == "3")
                {
                    SeleccionarTarifa seleccionarTarifa = new SeleccionarTarifa(this)
                    {
                        IdPlan = IdPlan,
                        Placa = Placa,
                        IdMovimiento = IdMovimiento,
                    };
                    seleccionarTarifa.ShowDialog();
                }
                else
                {
                    await RegistrarSalida(Placa, IdTipoVehiculo, IdCategoriaVehiculo, IdMovimiento, "1", MainWindow.IdUsuario);
                }
            }
        }
    }
}