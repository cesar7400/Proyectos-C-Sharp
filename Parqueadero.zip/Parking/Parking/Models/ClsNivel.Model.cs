﻿using System;
using System.ComponentModel;
using System.Data;
using System.Runtime.CompilerServices;

namespace Parking.ViewModels
{
    public class DashboardViewModel : INotifyPropertyChanged
    {
        private int _totalNiveles;
        private int _nivelesDisponibles;
        private int _nivelesFueraDeServicio;
        private int _totalCeldas;
        private int _celdasLibres;
        private int _celdasOcupadas;
        private int _celdasNoDisponibles;
        private int _ocupacionesActivas;
        private int _vehiculosActivos;

        public int TotalNiveles
        {
            get => _totalNiveles;
            set { _totalNiveles = value; OnPropertyChanged(); }
        }

        public int NivelesDisponibles
        {
            get => _nivelesDisponibles;
            set { _nivelesDisponibles = value; OnPropertyChanged(); }
        }

        public int NivelesFueraDeServicio
        {
            get => _nivelesFueraDeServicio;
            set { _nivelesFueraDeServicio = value; OnPropertyChanged(); }
        }

        public int TotalCeldas
        {
            get => _totalCeldas;
            set { _totalCeldas = value; OnPropertyChanged(); OnPropertyChanged(nameof(PorcentajeDisponibilidad)); }
        }

        public int CeldasLibres
        {
            get => _celdasLibres;
            set { _celdasLibres = value; OnPropertyChanged(); OnPropertyChanged(nameof(PorcentajeDisponibilidad)); }
        }

        public int CeldasOcupadas
        {
            get => _celdasOcupadas;
            set { _celdasOcupadas = value; OnPropertyChanged(); }
        }

        public int CeldasNoDisponibles
        {
            get => _celdasNoDisponibles;
            set { _celdasNoDisponibles = value; OnPropertyChanged(); }
        }

        public int OcupacionesActivas
        {
            get => _ocupacionesActivas;
            set { _ocupacionesActivas = value; OnPropertyChanged(); }
        }

        public int VehiculosActivos
        {
            get => _vehiculosActivos;
            set { _vehiculosActivos = value; OnPropertyChanged(); }
        }

        public double PorcentajeDisponibilidad
        {
            get
            {
                if (_totalCeldas == 0) return 0.0;
                return (double)_celdasLibres / _totalCeldas;
            }
        }

        public void NivelEstado(DataTable dt)
        {
            int totalNiveles = dt.Rows.Count;
            int nivelesDisponibles = 0;
            int nivelesFueraServicio = 0;
            int totalCeldas = 0;
            int celdasLibres = 0;
            int celdasOcupadas = 0;
            int celdasNoDisponibles = 0;

            foreach (DataRow row in dt.Rows)
            {
                if (row["EstadoNivel"].ToString() == "Disponible")
                    nivelesDisponibles++;
                else
                    nivelesFueraServicio++;

                totalCeldas += Convert.ToInt32(row["TotalCeldas"]);
                celdasLibres += Convert.ToInt32(row["Libres"]);
                celdasOcupadas += Convert.ToInt32(row["Ocupadas"]);
                celdasNoDisponibles += Convert.ToInt32(row["NoDisponibles"]);
            }

            TotalNiveles = totalNiveles;
            NivelesDisponibles = nivelesDisponibles;
            NivelesFueraDeServicio = nivelesFueraServicio;
            TotalCeldas = totalCeldas;
            CeldasLibres = celdasLibres;
            CeldasOcupadas = celdasOcupadas;
            CeldasNoDisponibles = celdasNoDisponibles;
            OcupacionesActivas = celdasOcupadas;
            VehiculosActivos = celdasOcupadas;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}