﻿using System.Security.Cryptography;

namespace Parking.Models
{
    public static class PasswordHasher
    {
        private const int SaltSize = 16;   // 128 bits
        private const int HashSize = 32;   // 256 bits
        private const int Iterations = 100000;

        // 🔹 Crear Hash + Salt
        public static void Create(string password, out byte[] hash, out byte[] salt)
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                salt = new byte[SaltSize];
                rng.GetBytes(salt);
            }

            using (var deriveBytes = new Rfc2898DeriveBytes(password, salt, Iterations))
            {
                hash = deriveBytes.GetBytes(HashSize);
            }
        }

        // Verificar Password
        public static bool VerifyPassword(string password, byte[] storedHash, byte[] storedSalt)
        {
            byte[] testHash;

            using (var deriveBytes = new Rfc2898DeriveBytes(password, storedSalt, Iterations))
            {
                testHash = deriveBytes.GetBytes(HashSize);
            }

            return CompareBytes(testHash, storedHash);
        }

        // Comparación segura (evita ataques de timing)
        private static bool CompareBytes(byte[] a, byte[] b)
        {
            if (a.Length != b.Length)
                return false;

            int result = 0;

            for (int i = 0; i < a.Length; i++)
            {
                result |= a[i] ^ b[i];
            }

            return result == 0;
        }
    }
}