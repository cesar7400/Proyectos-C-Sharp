﻿namespace Parking.Models
{
    public class UsuariosModel
    {
        public class LoginUsuarios
        {
            public int IdUsuario { get; set; }
            public string UsuarioLogin { get; set; }
            public string NombreCompleto { get; set; }
            public byte[] PasswordHash { get; set; }
            public byte[] PasswordSalt { get; set; }
            public byte DiasPermitidos { get; set; }
            public bool CambioPassword { get; set; }
            public string Permisos { get; set; }
            public bool Estado { get; set; }
            public string Mensaje { get; set; }
            public string LoginUsuario { get; set; }
        }
    }
}