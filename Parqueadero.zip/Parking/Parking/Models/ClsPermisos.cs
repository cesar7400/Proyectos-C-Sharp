﻿using Parking.Views;
using System;
using System.Text.RegularExpressions;

namespace Parking.Models
{
    public class Permisos
    {
        public bool TienePermiso(string nombreModulo, string nombrePermiso)
        {
            if (string.IsNullOrEmpty(MainWindow.Permisos)) return false;

            try
            {
                // 1. Buscar el bloque del módulo específico dentro del JSON
                string patronModulo = $@"""modulo""\s*:\s*""{nombreModulo}""([^}}]+)";
                var matchModulo = Regex.Match(MainWindow.Permisos, patronModulo, RegexOptions.IgnoreCase);

                if (matchModulo.Success)
                {
                    string contenidoModulo = matchModulo.Groups[1].Value;

                    // 2. Buscar el estado del permiso (ej: "Agregar Usuario": true)
                    string patronPermiso = $@"""{nombrePermiso}""\s*:\s*(true|false)";
                    var matchPermiso = Regex.Match(contenidoModulo, patronPermiso, RegexOptions.IgnoreCase);

                    if (matchPermiso.Success)
                    {
                        return matchPermiso.Groups[1].Value.Equals("true", StringComparison.OrdinalIgnoreCase);
                    }
                }
            }
            catch
            {
                return false;
            }

            return false; // Si no lo encuentra, por seguridad se deniega
        }
    }
}