﻿using System.Xml;

namespace Parking.Models
{
    public class Desencriptar
    {
        private readonly AES AES = new AES();
        private string connection;
        private string connectionDB;
        public string appPwdUnique = "Parking";

        public string CheckServer()
        {
            // Crear una nueva instancia de XmlDocument para manejar el archivo XML
            XmlDocument xmlDocument = new XmlDocument();

            // Cargar el archivo XML que contiene la cadena de conexión
            xmlDocument.Load("ConnectionString.xml");

            // Obtener el elemento raíz del documento XML
            XmlElement xmlElement = xmlDocument.DocumentElement;

            // Obtener el valor del primer atributo del elemento raíz (que contiene la cadena de conexión encriptada)
            connectionDB = xmlElement.Attributes.Item(0).Value;

            // Desencriptar la cadena de conexión usando el método AES.Decrypt
            connection = (AES.Decrypt(connectionDB, appPwdUnique, int.Parse("256")));

            // Devolver la cadena de conexión desencriptada
            return connection;
        }
    }
}