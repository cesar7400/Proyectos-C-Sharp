﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace Parking.Models
{
    public class ImprimirTicket
    {
        // Llama a este método desde el hilo UI (por ejemplo, desde un botón).

        public void PrintRichTextBox(RichTextBox rtb, string strImpresora)
        {
            try
            {
                var printDialog = new PrintDialog();
                if (!string.IsNullOrEmpty(strImpresora))
                {
                    var server = new LocalPrintServer();
                    printDialog.PrintQueue = server.GetPrintQueue(strImpresora);
                }

                // 1. OBTENER EL LARGO DINÁMICO (Usa el RTB original para medir)
                double largoMm = ObtenerLargoContenidoEnMm(rtb);
                double anchoMm = 80;
                double anchoWPF = (anchoMm / 25.4) * 96;
                double largoWPF = (largoMm / 25.4) * 96;

                // 2. CLONAR Y ELIMINAR CONTROLES (Recibe el documento aquí)
                // Esta función convierte los UserControls en Paragraph e Image
                FlowDocument docToPrint = CloneFlowDocument(rtb.Document);

                // 3. CONFIGURAR EL DOCUMENTO YA "APLANADO"
                docToPrint.PageWidth = anchoWPF;
                docToPrint.ColumnWidth = anchoWPF;
                docToPrint.ColumnGap = 0;
                docToPrint.PagePadding = new Thickness(5, 0, 5, 0);
                docToPrint.PageHeight = largoWPF;
                docToPrint.MaxPageHeight = largoWPF;

                // 4. CONFIGURAR TICKET FÍSICO
                if (printDialog.PrintQueue != null)
                {
                    PrintTicket ticket = printDialog.PrintQueue.DefaultPrintTicket;
                    ticket.PageMediaSize = new PageMediaSize(anchoWPF, largoWPF);
                    printDialog.PrintTicket = ticket;
                }

                // 5. ENVIAR A IMPRESIÓN
                var basePaginator = ((IDocumentPaginatorSource)docToPrint).DocumentPaginator;
                var single = new SinglePagePaginator(basePaginator, new Size(anchoWPF, largoWPF));

                printDialog.PrintDocument(single, "Ticket_Aplanado");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en impresión: " + ex.Message);
            }
        }

        // ESTA FUNCIÓN ES LA QUE EVITA QUE EL PDF SALGA EN BLANCO
        public FlowDocument CloneFlowDocument(FlowDocument original)
        {
            string xaml = System.Windows.Markup.XamlWriter.Save(original);
            FlowDocument copia = (FlowDocument)System.Windows.Markup.XamlReader.Parse(xaml);

            var bloques = copia.Blocks.ToList();
            foreach (var bloque in bloques)
            {
                if (bloque is BlockUIContainer container)
                {
                    var control = container.Child;
                    Block contenidoPuro = null;

                    // Extraer Texto de los TextBox internos
                    var listaTxt = BuscarControlesTipo<TextBox>(control);
                    if (listaTxt.Count > 0)
                    {
                        string texto = string.Join("  ", listaTxt.Select(t => t.Text));
                        Paragraph p = new Paragraph(new Run(texto)) { FontSize = 14, TextAlignment = TextAlignment.Center };
                        contenidoPuro = p;
                    }
                    // Extraer Imágenes
                    else
                    {
                        var img = BuscarControlesTipo<Image>(control).FirstOrDefault();
                        if (img != null)
                        {
                            Image imgNueva = new Image { Source = img.Source, Width = 150 };
                            contenidoPuro = new BlockUIContainer(imgNueva);
                        }
                    }

                    if (contenidoPuro != null)
                    {
                        copia.Blocks.InsertAfter(bloque, contenidoPuro);
                        copia.Blocks.Remove(bloque); // ELIMINA BOTONES Y BORDES
                    }
                }
            }
            return copia;
        }

        private List<T> BuscarControlesTipo<T>(DependencyObject padre) where T : DependencyObject
        {
            List<T> encontrados = new List<T>();
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(padre); i++)
            {
                var hijo = VisualTreeHelper.GetChild(padre, i);
                if (hijo is T t) encontrados.Add(t);
                encontrados.AddRange(BuscarControlesTipo<T>(hijo));
            }
            return encontrados;
        }
        public double ObtenerLargoContenidoEnMm(RichTextBox rtb)
        {
            // Obtenemos el largo total del contenido en unidades de WPF
            // ExtentHeight mide todo el contenido (texto + imágenes) de arriba a abajo
            double unidadesWpf = rtb.ExtentHeight;

            // Si el RichTextBox está vacío o no se ha renderizado, ExtentHeight podría ser 0
            if (unidadesWpf == 0) return 0;

            // Conversión a milímetros: (unidades / 96 DPI) * 25.4 mm por pulgada
            double milimetros = (unidadesWpf * 25.4) / 96.0;

            return milimetros;
        }
    }


    // DocumentPaginator que fuerza una única página usando el paginator interno.
    public class SinglePagePaginator : DocumentPaginator
    {
        private readonly DocumentPaginator _paginator;
        private readonly Size _pageSize;

        public SinglePagePaginator(DocumentPaginator paginator, Size pageSize)
        {
            _paginator = paginator ?? throw new ArgumentNullException(nameof(paginator));
            _pageSize = pageSize;
            _paginator.PageSize = pageSize;
        }

        public override DocumentPage GetPage(int pageNumber)
        {
            // Devolvemos siempre la primera página del paginator interno
            return _paginator.GetPage(0);
        }

        public override bool IsPageCountValid => true;

        public override int PageCount => 1;

        public override Size PageSize
        {
            get => _pageSize;
            set { /* ignore set */ }
        }

        public override IDocumentPaginatorSource Source => _paginator.Source;
    }
}