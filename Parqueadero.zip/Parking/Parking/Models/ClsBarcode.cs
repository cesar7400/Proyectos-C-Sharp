﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Parking.Models
{
    public class Barcode
    {
        private double _Width;
        private double _Height;
        public double Width
        {
            get { return _Width; }
            set { _Width = value; }
        }
        public double Height
        {
            get { return _Height; }
            set { _Height = value; }
        }

        // =======================
        // MAPA CODE 39
        // =======================
        private static readonly Dictionary<char, string> Code39Map =
            new Dictionary<char, string>
        {
            { '0', "nnnwwnwnn" }, { '1', "wnnwnnnnw" }, { '2', "nnwwnnnnw" },
            { '3', "wnwwnnnnn" }, { '4', "nnnwwnnnw" }, { '5', "wnnwwnnnn" },
            { '6', "nnwwwnnnn" }, { '7', "nnnwnnwnw" }, { '8', "wnnwnnwnn" },
            { '9', "nnwwnnwnn" },

            { 'A', "wnnnnwnnw" }, { 'B', "nnwnnwnnw" }, { 'C', "wnwnnwnnn" },
            { 'D', "nnnnwwnnw" }, { 'E', "wnnnwwnnn" }, { 'F', "nnwnwwnnn" },
            { 'G', "nnnnnwwnw" }, { 'H', "wnnnnwwnn" }, { 'I', "nnwnnwwnn" },
            { 'J', "nnnnwwwnn" },

            { 'K', "wnnnnnnww" }, { 'L', "nnwnnnnww" }, { 'M', "wnwnnnnwn" },
            { 'N', "nnnnwnnww" }, { 'O', "wnnnwnnwn" }, { 'P', "nnwnwnnwn" },
            { 'Q', "nnnnnnwww" }, { 'R', "wnnnnnwwn" }, { 'S', "nnwnnnwwn" },
            { 'T', "nnnnwnwwn" },

            { 'U', "wwnnnnnnw" }, { 'V', "nwwnnnnnw" }, { 'W', "wwwnnnnnn" },
            { 'X', "nwnnwnnnw" }, { 'Y', "wwnnwnnnn" }, { 'Z', "nwwnwnnnn" },

            { '-', "nwnnnnwnw" },
            { '*', "nwnnwnwnn" } // START / STOP
        };

        // =======================
        // GENERAR IMAGEN CODE 39
        // =======================
        private BitmapSource GenerarCode39(string value)
        {
            value = "*" + value + "*";

            int narrow = 2;
            int wide = 5;
            int height = 70;
            int gap = narrow;

            // Solución: Usar bucles foreach en lugar de lambdas anidadas de LINQ
            int totalWidth = 0;
            foreach (char ch in value)
            {
                string pattern = Code39Map[ch];
                foreach (char p in pattern)
                {
                    totalWidth += (p == 'w' ? wide : narrow);
                }
                totalWidth += gap;
            }

            DrawingVisual visual = new DrawingVisual();
            using (DrawingContext dc = visual.RenderOpen())
            {
                double posX = 0;

                foreach (char ch in value)
                {
                    string pattern = Code39Map[ch];
                    bool isBar = true;

                    foreach (char p in pattern)
                    {
                        double barWidth = (p == 'w') ? wide : narrow;
                        if (isBar)
                            dc.DrawRectangle(Brushes.Black, null,
                                new Rect(posX, 0, barWidth, height));

                        posX += barWidth;
                        isBar = !isBar;
                    }
                    posX += gap;
                }
            }

            RenderTargetBitmap bmp = new RenderTargetBitmap(
                totalWidth, height, 96, 96, PixelFormats.Pbgra32);

            bmp.Render(visual);
            bmp.Freeze();

            return bmp;
        }

        private string NormalizarPlaca(string placa)
        {
            if (string.IsNullOrWhiteSpace(placa))
                throw new ArgumentException("Placa vacía");

            placa = placa.ToUpper().Trim();

            if (!System.Text.RegularExpressions.Regex.IsMatch(placa, @"^[A-Z]{3}\s[0-9]{3}$"))
                throw new ArgumentException("Formato inválido. Use: ABC 123");

            return placa.Replace(" ", "");
        }

        private BitmapImage ConvertirABitmapImage(BitmapSource source)
        {
            using (var ms = new System.IO.MemoryStream())
            {
                BitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(source));
                encoder.Save(ms);

                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.StreamSource = new System.IO.MemoryStream(ms.ToArray());
                bitmapImage.EndInit();
                bitmapImage.Freeze();
                _Width = bitmapImage.PixelWidth;
                _Height = bitmapImage.PixelHeight;
                return bitmapImage;
            }
        }

        public BitmapImage ObtenerBarcodeCode39BitmapImage(string placaConEspacio)
        {
            string placa = NormalizarPlaca(placaConEspacio);
            BitmapSource source = GenerarCode39(placa);
            return ConvertirABitmapImage(source);
        }
    }
}