﻿using System.ComponentModel;
using System.Data;
using System.Runtime.CompilerServices;

namespace Parking.Models
{
    public class ResumenPlanes : INotifyPropertyChanged
    {
        private int _tiposPlanes;
        private int _cantidadPlanes;
        private int _planesDemanda;
        private int _tarifaMembresia;
        private int _tarifaMensualidad;
        private int _tarifasConfiguradas;
        private int _horariosActivos;
        private int _diasConfigurados;

        public int TiposPlanes
        {
            get => _tiposPlanes;
            set { _tiposPlanes = value; OnPropertyChanged(); }
        }
        public int CantidadPlanes
        {
            get => _cantidadPlanes;
            set { _cantidadPlanes = value; OnPropertyChanged(); }
        }
        public int PlanesDemanda
        {
            get => _planesDemanda;
            set { _planesDemanda = value; OnPropertyChanged(); }
        }
        public int TarifaMembresia
        {
            get => _tarifaMembresia;
            set { _tarifaMembresia = value; OnPropertyChanged(); }
        }
        public int TarifaMensualidad
        {
            get => _tarifaMensualidad;
            set { _tarifaMensualidad = value; OnPropertyChanged(); }
        }
        public int TarifasConfiguradas
        {
            get => _tarifasConfiguradas;
            set { _tarifasConfiguradas = value; OnPropertyChanged(); }
        }

        public int HorariosActivos
        {
            get => _horariosActivos;
            set { _horariosActivos = value; OnPropertyChanged(); }
        }

        public int DiasConfigurados
        {
            get => _diasConfigurados;
            set { _diasConfigurados = value; OnPropertyChanged(); }
        }

        public void CargarDatosResumen(DataTable dtTiposPlanes, DataTable dtCantidadPlanes,  DataTable dtPlanesDemanda, DataTable dtTarifaMembresia, DataTable dtTarifaMensualidad, DataTable dtTarifas, DataTable dtHorarios, DataTable dtDias)
        {
            TiposPlanes = dtTiposPlanes?.Rows.Count ?? 0;
            CantidadPlanes = dtCantidadPlanes?.Rows.Count ?? 0;
            PlanesDemanda = dtPlanesDemanda?.Rows.Count ?? 0;
            TarifaMembresia = dtTarifaMembresia?.Rows.Count ?? 0;
            TarifaMensualidad = dtTarifaMensualidad?.Rows.Count ?? 0;
            TarifasConfiguradas = dtTarifas?.Rows.Count ?? 0;
            HorariosActivos = dtHorarios?.Rows.Count ?? 0;
            DiasConfigurados = dtDias?.Rows.Count ?? 0;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}