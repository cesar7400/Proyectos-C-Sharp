﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Parking.Models
{
    public class Ticket
    {
        private readonly FlowDocument doc = new FlowDocument();
        // Ancho constante para simular ticket de 80mm
        //private const double ANCHO_TICKET = 300;
        private const double PADDING = 5;

        public FlowDocument Doc_()
        {
            //doc.PageWidth = ANCHO_TICKET + (PADDING * 2);
            doc.PagePadding = new Thickness(PADDING);
            doc.ColumnWidth = double.PositiveInfinity;

            return doc;
        }
        public void AgregarTexto(FlowDocument doc, string texto, FontWeight peso, double tamano, TextAlignment alineacion, FontFamily fuente, double interlineado, double desplazamientoY = 0, double desplazamientoX = 0)
        {
            var p = new Paragraph(new Run(texto))
            {
                FontWeight = peso,
                FontSize = tamano,
                TextAlignment = alineacion,
                FontFamily = fuente,

                // 1. ELIMINAMOS MÁRGENES TOTALMENTE
                // Esto hace que los párrafos se peguen uno tras otro sin espacios extra.
                Margin = new Thickness(0, 0, 0, 0),

                // 2. CONTROL DE INTERLINEADO (PEGADO)
                // Usamos LineStackingStrategy para que el texto no tenga "aire" arriba ni abajo.
                LineStackingStrategy = LineStackingStrategy.BlockLineHeight,
                LineHeight = tamano * interlineado
            };
            // 3. DESPLAZAMIENTO REAL (USANDO PADDING)
            // El Padding NO se colapsa, por lo que moverá el texto sí o sí.
            // X: Mueve a la derecha
            // Y: Mueve hacia abajo (Si es positivo)
            double moveX = (desplazamientoX < 0) ? 0 : desplazamientoX;
            double moveY = (desplazamientoY < 0) ? 0 : desplazamientoY;

            p.Padding = new Thickness(moveX, moveY, 0, 0);

            // 4. PARA SUBIR MÁS ALLÁ DEL CERO (Si desplazamientoY es negativo)
            // Solo usamos margen negativo aquí si realmente necesitamos "encimar" o subir al tope.
            if (desplazamientoY < 0)
            {
                p.Margin = new Thickness(0, 0, 0, 0);
            }

            doc.Blocks.Add(p);
        }
        
        public void AgregarImagen(FlowDocument doc, BitmapImage bitmap, double Width, double Height,
                 double interlineado, TextAlignment alineacion, double desplazamientoX)
        {
            var imageControl = new Image()
            {
                Source = bitmap,
                Width = Width,
                Height = Height,
                Stretch = Stretch.Uniform
            };

            // Creamos un Grid para gestionar el espacio y la posición con total libertad
            var grid = new Grid()
            {
                Height = Height * interlineado, // Respeta perfectamente tu interlineado vertical
                HorizontalAlignment = HorizontalAlignment.Stretch
            };

            // Configuramos la alineación y el desplazamiento horizontal de forma robusta
            switch (alineacion)
            {
                case TextAlignment.Left:
                    imageControl.HorizontalAlignment = HorizontalAlignment.Left;
                    imageControl.Margin = new Thickness(desplazamientoX, 0, 0, 0);
                    break;

                case TextAlignment.Center:
                    imageControl.HorizontalAlignment = HorizontalAlignment.Center;
                    // Si está centrada, la transformación mueve la imagen con precisión desde el centro
                    imageControl.RenderTransform = new TranslateTransform(desplazamientoX, 0);
                    break;

                case TextAlignment.Right:
                    imageControl.HorizontalAlignment = HorizontalAlignment.Right;
                    imageControl.Margin = new Thickness(0, 0, desplazamientoX, 0);
                    break;
            }

            grid.Children.Add(imageControl);

            // BlockUIContainer actúa como un bloque completo (tipo párrafo) 
            // liberando las restricciones del formato de texto plano.
            var blockContainer = new BlockUIContainer(grid)
            {
                Margin = new Thickness(0) // Evita espacios gigantes por defecto
            };

            doc.Blocks.Add(blockContainer);
        }

        public void AgregarMatrizDatos(FlowDocument doc, List<List<string>> datosMatriz, FontFamily fuente, FontWeight peso, TextAlignment alinear, double size, double espacioVertical, double espacioHorizontal, double interlineadoColumna, int filaPintadaIndex = -1, int columnaPintadaIndex = -1)
        {
            var grid = new Grid()
            {
                Margin = new Thickness(0),
                HorizontalAlignment = HorizontalAlignment.Stretch // El Grid sí soporta el estiramiento
            };

            if (datosMatriz == null || datosMatriz.Count == 0) return;

            int maxColumnasDatos = datosMatriz.Max(f => f?.Count ?? 0);
            int totalFilas = datosMatriz.Count;

            // 1. Definición de columnas con espaciadores escalables
            for (int j = 0; j < maxColumnasDatos; j++)
            {
                if (j > 0 && espacioHorizontal > 0)
                {
                    grid.ColumnDefinitions.Add(new ColumnDefinition
                    {
                        Width = new GridLength(espacioHorizontal, GridUnitType.Pixel)
                    });
                }

                grid.ColumnDefinitions.Add(new ColumnDefinition
                {
                    Width = (j == 0) ? GridLength.Auto : new GridLength(1, GridUnitType.Star)
                });
            }

            int totalGridColumns = grid.ColumnDefinitions.Count;

            for (int i = 0; i < totalFilas; i++)
            {
                grid.RowDefinitions.Add(new RowDefinition
                {
                    Height = GridLength.Auto
                });
            }

            // 2. Fondo unificado para toda la COLUMNA seleccionada
            if (columnaPintadaIndex >= 0 && columnaPintadaIndex < maxColumnasDatos)
            {
                int gridColumnIndex = (espacioHorizontal > 0) ? columnaPintadaIndex * 2 : columnaPintadaIndex;

                var fondoColumna = new Border
                {
                    Background = Brushes.Black,
                    Margin = new Thickness(0, 0, 0, 0)
                };
                Grid.SetRow(fondoColumna, 0);
                Grid.SetColumn(fondoColumna, gridColumnIndex);
                Grid.SetRowSpan(fondoColumna, totalFilas);
                grid.Children.Add(fondoColumna);
            }

            // 3. Fondo unificado para toda la FILA seleccionada
            if (filaPintadaIndex >= 0 && filaPintadaIndex < totalFilas)
            {
                var fondoFila = new Border
                {
                    Background = Brushes.Black,
                    Margin = new Thickness(0, espacioVertical, 0, 0)
                };
                Grid.SetRow(fondoFila, filaPintadaIndex);
                Grid.SetColumn(fondoFila, 0);
                Grid.SetColumnSpan(fondoFila, totalGridColumns);
                grid.Children.Add(fondoFila);
            }

            // 4. Creación de las celdas y textos
            for (int i = 0; i < totalFilas; i++)
            {
                for (int j = 0; j < datosMatriz[i].Count; j++)
                {
                    string texto = datosMatriz[i][j];
                    bool esFilaPintada = (i == filaPintadaIndex);
                    bool esColumnaPintada = (j == columnaPintadaIndex);
                    bool estaPintada = (esFilaPintada || esColumnaPintada);

                    TextAlignment alineacionCelda = (j == 0) ? TextAlignment.Left : alinear;

                    var tb = new TextBlock
                    {
                        Text = texto,
                        FontSize = size,
                        FontWeight = (peso is FontWeight fw) ? fw : FontWeights.Normal,
                        FontFamily = (fuente is FontFamily ff) ? ff : new FontFamily("Arial"),
                        TextWrapping = TextWrapping.Wrap,
                        VerticalAlignment = VerticalAlignment.Center,
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        TextAlignment = alineacionCelda,
                        LineStackingStrategy = LineStackingStrategy.BlockLineHeight,
                        LineHeight = (size) * (interlineadoColumna),
                        Foreground = estaPintada ? Brushes.White : Brushes.Black,
                    };

                    var border = new Border
                    {
                        Child = tb,
                        Margin = new Thickness(0, espacioVertical, 0, 0),
                        Background = Brushes.Transparent,
                        HorizontalAlignment = HorizontalAlignment.Stretch
                    };

                    int gridColumnIndex = (espacioHorizontal > 0) ? j * 2 : j;

                    Grid.SetRow(border, i);
                    Grid.SetColumn(border, gridColumnIndex);
                    grid.Children.Add(border);
                }
            }

            var container = new BlockUIContainer(grid)
            {
                Margin = new Thickness(0)
            };
            doc.Blocks.Add(container);
        }
    }
}