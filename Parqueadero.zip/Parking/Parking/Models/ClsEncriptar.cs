﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows;

namespace Parking.Models
{
    public class AES
    {
        // Método privado para encriptar datos
        private byte[] Encrypt(byte[] clearData, byte[] Key, byte[] IV)
        {
            // Crear un flujo de memoria para almacenar los datos encriptados
            MemoryStream ms = new MemoryStream();

            // Crear una instancia del algoritmo AES
            Aes alg = Aes.Create();
            alg.Key = Key; // Establecer la clave de encriptación
            alg.IV = IV;   // Establecer el vector de inicialización

            // Crear un CryptoStream para realizar la encriptación
            CryptoStream cs = new CryptoStream(ms, alg.CreateEncryptor(), CryptoStreamMode.Write);
            cs.Write(clearData, 0, clearData.Length); // Escribir los datos claros en el CryptoStream
            cs.Close(); // Cerrar el CryptoStream para completar la encriptación

            // Convertir el flujo de memoria en un array de bytes y devolverlo
            byte[] encryptedData = ms.ToArray();
            return encryptedData;
        }

        // Método público para encriptar una cadena de texto
        public string Encrypt(string Data, string Password, int Bits)
        {
            // Convertir la cadena a un array de bytes
            byte[] clearBytes = System.Text.Encoding.Unicode.GetBytes(Data);

            // Derivar la clave y el IV a partir de la contraseña
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(Password, new byte[] { 0x0, 0x1, 0x2, 0x1, 0x1D, 0x1E, 0x3, 0x4, 0x5, 0xF, 0x20, 0x21, 0xAD, 0xAF, 0xA4 });

            // Comprobar el tamaño de la clave deseada (Bits)
            if (Bits == 128)
            {
                // Encriptar con una clave de 128 bits
                byte[] encryptedData = Encrypt(clearBytes, pdb.GetBytes(16), pdb.GetBytes(16));
                return Convert.ToBase64String(encryptedData); // Devolver los datos encriptados en Base64
            }
            else if (Bits == 192)
            {
                // Encriptar con una clave de 192 bits
                byte[] encryptedData = Encrypt(clearBytes, pdb.GetBytes(24), pdb.GetBytes(16));
                return Convert.ToBase64String(encryptedData);
            }
            else if (Bits == 256)
            {
                // Encriptar con una clave de 256 bits
                byte[] encryptedData = Encrypt(clearBytes, pdb.GetBytes(32), pdb.GetBytes(16));
                return Convert.ToBase64String(encryptedData);
            }
            else
                return string.Concat(Bits); // Devolver los bits como cadena si no es válido
        }

        // Método privado para desencriptar datos
        private byte[] Decrypt(byte[] cipherData, byte[] Key, byte[] IV)
        {
            // Crear un flujo de memoria para almacenar los datos desencriptados
            MemoryStream ms = new MemoryStream();

            // Crear una instancia del algoritmo AES
            Aes alg = Aes.Create();
            alg.Key = Key; // Establecer la clave de desencriptación
            alg.IV = IV;   // Establecer el vector de inicialización

            // Crear un CryptoStream para realizar la desencriptación
            CryptoStream cs = new CryptoStream(ms, alg.CreateDecryptor(), CryptoStreamMode.Write);
            cs.Write(cipherData, 0, cipherData.Length); // Escribir los datos cifrados en el CryptoStream
            cs.Close(); // Cerrar el CryptoStream para completar la desencriptación

            // Convertir el flujo de memoria en un array de bytes y devolverlo
            byte[] decryptedData = ms.ToArray();
            return decryptedData;
        }

        // Método público para desencriptar una cadena encriptada
        public string Decrypt(string data, string password, int bits)
        {
            try
            {
                // Convertir la cadena Base64 a un array de bytes
                byte[] cipherBytes = Convert.FromBase64String(data);

                // Derivar la clave y el IV a partir de la contraseña
                PasswordDeriveBytes pdb = new PasswordDeriveBytes(password, new byte[] { 0x0, 0x1, 0x2, 0x1C, 0x1D, 0x1E, 0x3, 0x4, 0x5, 0xF, 0x20, 0x21, 0xAD, 0xAF, 0xA4 });

                // Comprobar el tamaño de la clave deseada (Bits)
                if (bits == 128)
                {
                    // Desencriptar con una clave de 128 bits
                    byte[] decryptedData = Decrypt(cipherBytes, pdb.GetBytes(16), pdb.GetBytes(16));
                    return Encoding.Unicode.GetString(decryptedData); // Devolver la cadena desencriptada
                }
                else if (bits == 192)
                {
                    // Desencriptar con una clave de 192 bits
                    byte[] decryptedData = Decrypt(cipherBytes, pdb.GetBytes(24), pdb.GetBytes(16));
                    return Encoding.Unicode.GetString(decryptedData);
                }
                else if (bits == 256)
                {
                    // Desencriptar con una clave de 256 bits
                    byte[] decryptedData = Decrypt(cipherBytes, pdb.GetBytes(32), pdb.GetBytes(16));
                    return Encoding.Unicode.GetString(decryptedData);
                }
                else
                {
                    return bits.ToString(); // Devolver los bits como cadena si no es válido
                }
            }
            catch (Exception ex)
            {
                // Manejar excepciones y mostrar un mensaje de error
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return null; // Devolver null en caso de error
            }
        }
    }
}