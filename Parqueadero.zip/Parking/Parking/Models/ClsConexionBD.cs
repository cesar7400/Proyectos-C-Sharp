﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Parking.Models
{
    public class ConexionBD
    {
        private string strConnection;
        private string strError;
        private SqlConnection sqlConnection;
        private SqlCommand sqlCommand;
        private SqlDataReader sqlDataReader;
        private DataSet dataSet;
        private int filasAfectadas;

        public string StrError
        {
            get { return strError; }
            set { strError = value; }
        }

        public SqlCommand SqlCommand
        {
            get { return sqlCommand; }
            set { sqlCommand = value; }
        }
        public SqlDataReader SqlDataReader
        {
            get { return sqlDataReader; }
            set { sqlDataReader = value; }
        }
        public DataSet DataSet
        {
            get { return dataSet; }
            set { dataSet = value; }
        }
        public int FilasAfectadas
        {
            get { return filasAfectadas; }
            set { filasAfectadas = value; }
        }
        public async Task<bool> Connection()
        {
            try
            {
                // Crear una instancia de la clase de desencriptación
                Desencriptar clsDesencriptar = new Desencriptar();

                // Obtener la cadena de conexión desencriptada
                strConnection = clsDesencriptar.CheckServer();

                // Inicializar la conexión a la base de datos
                sqlConnection = new SqlConnection(strConnection);

                // USAR OpenAsync para no bloquear el hilo de la interfaz de usuario
                await sqlConnection.OpenAsync();

                // Retornar true si la conexión fue exitosa
                return true;
            }
            catch (Exception error)
            {
                // Capturar el error y almacenar el mensaje de error
                strError = $"Error de conexión\n{error.Message}";

                // Retornar false si hubo un error
                return false;
            }
        }
        public async Task<bool> CloseConnection()
        {
            try
            {
                if (sqlConnection != null && sqlConnection.State != ConnectionState.Closed)
                {
                    // Close() es suficiente aquí, incluso en métodos async
                    sqlConnection.Close();
                }
                return await Task.FromResult(true); // Retornamos true indicando éxito
            }
            catch (Exception error)
            {
                strError = $"Error al cerrar conexión\n{error.Message}";
                return false;
            }
        }
        public async Task<bool> InsertAsync(string strSql, CommandType type, List<KeyValuePair<string, object>> strCmd = null)
        {
            try
            {
                // Usamos 'using' para que el comando se destruya al terminar
                using (SqlCommand cmd = new SqlCommand(strSql, sqlConnection))
                {
                    cmd.CommandType = type;

                    if (strCmd != null)
                    {
                        foreach (var param in strCmd)
                        {
                            cmd.Parameters.AddWithValue(param.Key, param.Value);
                        }
                    }

                    // ExecuteNonQueryAsync devuelve el número de filas afectadas
                    filasAfectadas = await cmd.ExecuteNonQueryAsync();

                    return filasAfectadas > 0;
                }
            }
            catch (SqlException error)
            {
                strError = $"{error.Number}-{error.Message}";
                throw;
            }
        }
        public async Task<bool> ReadAsync(string strSql, CommandType type, List<KeyValuePair<string, object>> strCmd = null)
        {
            try
            {
                // Se inicializa el comando y su propiedad CommandType en una sola expresión
                sqlCommand = new SqlCommand(strSql, sqlConnection)
                {
                    CommandType = type
                };

                // Se simplifica la adición de parámetros usando el método ForEach y el operador ?.
                strCmd?.ForEach(param => sqlCommand.Parameters.AddWithValue(param.Key, param.Value));

                // CommandBehavior.CloseConnection asegura que al cerrar el Reader se cierre la conexión.
                sqlDataReader = await sqlCommand.ExecuteReaderAsync(CommandBehavior.CloseConnection);
                return sqlDataReader != null; // Retorna true si el reader se creó correctamente
            }
            catch (SqlException error)
            {
                strError = $"{error.Number}-{error.Message}";
                throw;
            }
        }
        public async Task<bool> DataSetAsync(string strSQL, CommandType type, List<KeyValuePair<string, object>> strCmd = null)
        {
            try
            {
                // Usamos 'using' para asegurar que el adaptador se libere de la memoria
                using (SqlDataAdapter dap = new SqlDataAdapter(strSQL, sqlConnection))
                {
                    dap.SelectCommand.CommandType = type;

                    if (strCmd != null)
                    {
                        foreach (var lst in strCmd)
                        {
                            dap.SelectCommand.Parameters.AddWithValue(lst.Key, lst.Value ?? DBNull.Value);
                        }
                    }

                    dataSet = new DataSet();

                    // IMPORTANTE: Aseguramos que la conexión esté asignada al comando
                    // antes de ejecutar el hilo secundario
                    await Task.Run(() =>
                    {
                        dap.Fill(dataSet);
                    });
                }

                return true;
            }
            catch (SqlException error)
            {
                strError = $"{error.Number}-{error.Message}";
                throw;
            }
        }
        public async Task<bool> UpdateAsync(string strSql, CommandType type, List<KeyValuePair<string, object>> strCmd = null)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand(strSql, sqlConnection))
                {
                    cmd.CommandType = type;

                    if (strCmd != null)
                    {
                        foreach (var param in strCmd)
                        {
                            // Si el valor es null en C#, lo convertimos a DBNull para SQL.
                            // Esto permite que tu lógica de "ISNULL(@Param, Columna)" funcione.
                            object value = param.Value ?? DBNull.Value;
                            cmd.Parameters.AddWithValue(param.Key, value);
                        }
                    }

                    // Ejecutamos la actualización
                    int filasAfectadas = await cmd.ExecuteNonQueryAsync();

                    // Si se actualizó al menos 1 fila, devolvemos true
                    return filasAfectadas > 0;
                }
            }
            catch (SqlException error)
            {
                strError = $"{error.Number}-{error.Message}";
                // Es buena práctica relanzar la excepción o manejarla según tu lógica
                throw;
            }
        }
        public async Task<bool> DeleteAsync(string strSql, CommandType type, List<KeyValuePair<string, object>> strCmd = null)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand(strSql, sqlConnection))
                {
                    cmd.CommandType = type;

                    if (strCmd != null)
                    {
                        foreach (var param in strCmd)
                        {
                            // En un DELETE normalmente solo pasas el ID, pero mantenemos 
                            // la validación de nulos por si envías parámetros opcionales.
                            object value = param.Value ?? DBNull.Value;
                            cmd.Parameters.AddWithValue(param.Key, value);
                        }
                    }

                    // Ejecutamos la eliminación
                    int filasAfectadas = await cmd.ExecuteNonQueryAsync();

                    // Si se eliminó al menos 1 fila, devolvemos true
                    return filasAfectadas > 0;
                }
            }
            catch (SqlException error)
            {
                strError = $"{error.Number}-{error.Message}";
                throw; // Relanza la excepción para capturarla en el controlador
            }
        }
    }
}