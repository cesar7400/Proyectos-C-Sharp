﻿using Parking.Controller;
using Parking.Resources;
using Parking.Views;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Parking.Models
{
    // Modelo de datos que incluye todas las propiedades visuales
    [DataContract]
    public class ColumnaConfig
    {
        [DataMember] public string Texto { get; set; }
        [DataMember] public string Fuente { get; set; }
        [DataMember] public string Peso { get; set; }
        [DataMember] public double Size { get; set; }
        [DataMember] public double EspacioVertical { get; set; }
        [DataMember] public double EspacioHorizontal { get; set; }
        [DataMember] public double Interlineado { get; set; }
        [DataMember] public string Alinear { get; set; }
        [DataMember] public string Background { get; set; }
        [DataMember] public string Foreground { get; set; }
    }
    public class TicketItemData
    {
        // Guardamos como strings para evitar errores de serialización de objetos WPF
        [DataMember] public List<ColumnaConfig> Columnas { get; set; }
        [DataMember] public string Tipo { get; set; }
        [DataMember] public string Encabezado { get; set; }
        [DataMember] public double EspacioVertical { get; set; }
        [DataMember] public double EspacioHorizontal { get; set; }
        [DataMember] public string Parrafo { get; set; }
        [DataMember] public string TextoUno { get; set; }
        [DataMember] public string TextoDos { get; set; }
        [DataMember] public string TextoTres { get; set; }
        [DataMember] public string TextoCuatro { get; set; }
        [DataMember] public string TextoCinco { get; set; }
        [DataMember] public double Interlineado { get; set; }
        [DataMember] public double TamanioFuente { get; set; }
        [DataMember] public string Fuente { get; set; }
        [DataMember] public string Peso { get; set; } // Se guarda como String para evitar el error de Cast
        [DataMember] public string AlineacionTexto { get; set; }
        [DataMember] public double Ancho { get; set; }
        [DataMember] public double Alto { get; set; }
        [DataMember] public double DesplazamientoX { get; set; }
        [DataMember] public string AlineacionImagen { get; set; }
        [DataMember] public string RutaImagen { get; set; }
        [DataMember] public byte[] ImagenBytes { get; set; }
        [DataMember] public string PlacaVehiculoImagen { get; set; }
        [DataMember] public int InfoIncluida { get; set; }
        [DataMember] public string SelectModulo { get; set; }
        [DataMember] public int SelectTipoDatos { get; set; }
        [DataMember] public int InformacionEmpresa { get; set; }
        [DataMember] public int PlacaVehiculo { get; set; }
        [DataMember] public int Ticket { get; set; }
        [DataMember] public List<List<string>> MatrizDatos { get; set; }
        [DataMember] public bool CheckFila { get; set; }
        [DataMember] public bool CheckColumna { get; set; }
        [DataMember] public string ColumnaSeleccionada { get; set; }
        [DataMember] public int FilaPintadaIndex { get; set; }
        [DataMember] public int ColumnaPintadaIndex { get; set; }
    }
    public class ConfigTicket
    {
        // MÉTODO PARA GUARDAR ESTADO ACTUAL
        public async Task<bool> GuardarConfiguracion(Panel contenedor, string strValor, string strConfiguracionID)
        {
            bool b = false;
            var lista = new List<TicketItemData>();
            foreach (var item in contenedor.Children)
            {
                if (item is ControlTexto t)
                {
                    lista.Add(new TicketItemData
                    {
                        Tipo = "Texto",
                        Encabezado = t.gbGrupoTexto.Header.ToString(),
                        TextoUno = t.ChkPlaca == 1 ? "{{PLACA VEHICULO}}" : (t.ChkTicket == 1 ? "{{NUMERO TICKET}}" : t.txtTexto.Text),
                        TamanioFuente = t.nbTamanioFuente.Value,
                        Interlineado = t.nbInterlineado.Value,
                        Fuente = t.cmbTipoFuente.SelectedItem?.ToString(),
                        Peso = t.cmbPesoFuente.SelectedItem?.ToString(), // Guardamos el nombre del peso (ej: "Bold")
                        AlineacionTexto = (t.cmbAlinearTexto.SelectedItem as ComboBoxItem)?.Tag.ToString(),
                        EspacioVertical = t.EspacioVertical,
                        EspacioHorizontal = t.EspacioHorizontal,
                        InformacionEmpresa = t.ChkInfo,
                        PlacaVehiculo = t.ChkPlaca,
                        Ticket = t.ChkTicket,
                    });
                }
                else if (item is ControlParrafo cp)
                {
                    lista.Add(new TicketItemData
                    {
                        Tipo = "Parrafo",
                        Encabezado = cp.gbParrafo.Header.ToString(),
                        Parrafo = cp.Parrafo,
                        TamanioFuente = cp.nbTamanioFuente.Value,
                        Interlineado = cp.nbInterlineado.Value,
                        Fuente = cp.cmbTipoFuente.SelectedItem?.ToString(),
                        Peso = cp.cmbPesoFuente.SelectedItem?.ToString(), // Guardamos el nombre del peso (ej: "Bold")
                        AlineacionTexto = (cp.cmbAlinearTexto.SelectedItem as ComboBoxItem)?.Tag.ToString()
                    });
                }
                else if (item is ControlDatos cds)
                {
                    var matrizSerializada = new List<List<string>>();

                    foreach (var fila in cds.DatosMatriz)
                    {
                        // Guardamos cada fila completa con sus columnas respetando el orden
                        matrizSerializada.Add(new List<string>(fila));
                    }

                    lista.Add(new TicketItemData
                    {
                        Tipo = "Control datos",
                        Encabezado = cds.gbControlDatos.Header.ToString(),
                        TamanioFuente = cds.nbTamanioFuente.Value,
                        Interlineado = cds.nbInterlineado.Value,
                        EspacioHorizontal = cds.nbEspacioHorizontal.Value,
                        EspacioVertical = cds.nbEspacioVertical.Value,
                        Fuente = cds.cmbTipoFuente.SelectedItem?.ToString(),
                        Peso = cds.cmbPesoFuente.SelectedItem?.ToString(),
                        AlineacionTexto = (cds.cmbAlinearTexto.SelectedItem as ComboBoxItem)?.Tag.ToString(),
                        MatrizDatos = matrizSerializada, // Propiedad tipo List<List<string>> en tu JSON/Data
                        CheckFila = cds.CheckFilaSeleccionada,       // Usando la propiedad pública
                        CheckColumna = cds.CheckColumnaSeleccionada, // Usando la propiedad pública
                        ColumnaSeleccionada = cds.StrColorSeleccionado,
                        FilaPintadaIndex = cds.FilaPintadaIndex,
                        ColumnaPintadaIndex = cds.ColumnaPintadaIndex
                    });
                }

                else if (item is ControlImagen i)
                {
                    lista.Add(new TicketItemData
                    {
                        Tipo = "Imagen",
                        Encabezado = i.gbGrupoImagen.Header.ToString(),
                        Ancho = i.nbAncho.Value,
                        Alto = i.nbAlto.Value,
                        Interlineado = i.nbInterlineado.Value,
                        DesplazamientoX = i.nbdesplazar.Value,
                        AlineacionImagen = (i.cmbAlineacion.SelectedItem as ComboBoxItem)?.Tag.ToString(),
                        RutaImagen = i.StrImagen,
                        ImagenBytes = i.StrImagen == "placa_vehiculo_barcode" ? null : i.ImagenBytes,
                        PlacaVehiculoImagen = i.StrPlacaVehiculo,
                    });
                }
            }
            using (MemoryStream ms = new MemoryStream())
            {
                var ser = new DataContractJsonSerializer(typeof(List<TicketItemData>));
                ser.WriteObject(ms, lista);
                string strTicket = Encoding.UTF8.GetString(ms.ToArray());

                ConfiguracionController configuracion = new ConfiguracionController();

                if(await configuracion.GuardarConfiguracionTicket(strTicket, MainWindow.IdUsuario, strValor, strConfiguracionID))
                {
                    if (strConfiguracionID == "")
                    {
                        MessageBox.Show("Ticket guardado correctamente.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("Ticket actualizado correctamente.", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    b = true;
                }
                else
                {
                    b = false;
                }
            }
            return b;
        }
        // MÉTODO PARA CARGAR TODO
        public async Task<List<TicketItemData>> CargarConfiguracion(string ConfiguracionID)
        {
            ConfiguracionController configuracion = new ConfiguracionController();
            
            var resultado = await configuracion.CargarConfiguracionTicket(ConfiguracionID);

            try
            {
                string json = resultado.Tables[0].Rows[0]["DatosJson"].ToString();
                using (MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(json)))
                {
                    var ser = new DataContractJsonSerializer(typeof(List<TicketItemData>));
                    return (List<TicketItemData>)ser.ReadObject(ms);
                }
            }
            catch { return new List<TicketItemData>(); }
        }

        public async void CargarTicket(string ConfiguracionID)
        {
            var datos = await CargarConfiguracion(ConfiguracionID);
            if (Application.Current.Windows.OfType<MainTicket>().FirstOrDefault() is MainTicket mainWin)
            {
                mainWin.pnlContenedorGrupos.Children.Clear();


                foreach (var data in datos)
                {
                    if (data.Tipo == "Texto")
                    {
                        var txt = new ControlTexto(data.Encabezado);
                        txt.txtTexto.Text = data.TextoUno == "{{PLACA VEHICULO}}" ?  "" : (data.TextoUno == "{{NUMERO TICKET}}" ? "": data.TextoUno);
                        txt.nbTamanioFuente.Value = data.TamanioFuente;
                        txt.nbInterlineado.Value = data.Interlineado;
                        txt.nbEspacioVertical.Value = data.EspacioVertical;
                        txt.nbEspacioHorizontal.Value = data.EspacioHorizontal;
                        txt.ChkIncluirInformacionEmpresa.IsChecked = (data.InformacionEmpresa == 1);
                        txt.ChkNumeroTicket.IsChecked = (data.Ticket == 1);
                        txt.txtTexto.IsEnabled = !(data.InformacionEmpresa == 1 || data.PlacaVehiculo == 1 || data.PlacaVehiculo == 1);
                        txt.txtTexto.Background = !(data.InformacionEmpresa == 1 || data.PlacaVehiculo == 1 || data.PlacaVehiculo == 1) ? (SolidColorBrush)new BrushConverter().ConvertFrom("#FFFFFF"): (SolidColorBrush)new BrushConverter().ConvertFrom("#E9ECEF"); ;
                        txt.ChkPlacaVehiculo.IsChecked = (data.PlacaVehiculo == 1);
                        // Restaurar Tipo Fuente
                        foreach (var f in txt.cmbTipoFuente.Items)
                            if (f.ToString() == data.Fuente) { txt.cmbTipoFuente.SelectedItem = f; break; }

                        // Restaurar Peso Fuente (SOLUCIÓN AL INVALIDCAST)
                        foreach (var p in txt.cmbPesoFuente.Items)
                            if (p.ToString() == data.Peso) { txt.cmbPesoFuente.SelectedItem = p; break; }

                        // Restaurar Alineación
                        foreach (ComboBoxItem a in txt.cmbAlinearTexto.Items)
                            if (a.Tag.ToString() == data.AlineacionTexto) { txt.cmbAlinearTexto.SelectedItem = a; break; }

                        mainWin.SuscribirEventosYAgregar(txt);
                    }
                    else if (data.Tipo == "Parrafo")
                    {
                        var parrafo = new ControlParrafo(data.Encabezado)
                        {
                            Parrafo = data.Parrafo
                        };
                        parrafo.nbTamanioFuente.Value = data.TamanioFuente;
                        parrafo.nbInterlineado.Value = data.Interlineado;

                        // Restaurar Tipo Fuente
                        foreach (var f in parrafo.cmbTipoFuente.Items)
                            if (f.ToString() == data.Fuente) { parrafo.cmbTipoFuente.SelectedItem = f; break; }

                        // Restaurar Peso Fuente (SOLUCIÓN AL INVALIDCAST)
                        foreach (var p in parrafo.cmbPesoFuente.Items)
                            if (p.ToString() == data.Peso) { parrafo.cmbPesoFuente.SelectedItem = p; break; }

                        // Restaurar Alineación
                        foreach (ComboBoxItem a in parrafo.cmbAlinearTexto.Items)
                            if (a.Tag.ToString() == data.AlineacionTexto) { parrafo.cmbAlinearTexto.SelectedItem = a; break; }

                        mainWin.SuscribirEventosYAgregar(parrafo);
                    }

                    else if (data.Tipo == "Control datos")
                    {
                        var cd = new ControlDatos(data.Encabezado)
                        {
                            DatosMatriz = data.MatrizDatos,
                            CheckFilaSeleccionada = data.CheckFila,
                            CheckColumnaSeleccionada = data.CheckColumna,
                            StrColorSeleccionado = data.ColumnaSeleccionada
                        };

                        // Asignamos propiedades adicionales de estilo si es necesario
                        cd.nbTamanioFuente.Value = data.TamanioFuente;
                        cd.nbInterlineado.Value = data.Interlineado;
                        cd.nbEspacioVertical.Value = data.EspacioVertical;
                        cd.nbEspacioHorizontal.Value = data.EspacioHorizontal;
                        
                        // Restaurar Tipo Fuente
                        foreach (var f in cd.cmbTipoFuente.Items)
                            if (f.ToString() == data.Fuente) { cd.cmbTipoFuente.SelectedItem = f; break; }

                        // Restaurar Peso Fuente (SOLUCIÓN AL INVALIDCAST)
                        foreach (var p in cd.cmbPesoFuente.Items)
                            if (p.ToString() == data.Peso) { cd.cmbPesoFuente.SelectedItem = p; break; }

                        // Restaurar Alineación
                        foreach (ComboBoxItem a in cd.cmbAlinearTexto.Items)
                            if (a.Tag.ToString() == data.AlineacionTexto) { cd.cmbAlinearTexto.SelectedItem = a; break; }

                        mainWin.SuscribirEventosYAgregar(cd);
                    }

                    else if (data.Tipo == "Imagen")  
                    {
                        var img = new ControlImagen(data.Encabezado);
                        img.nbAlto.Value = data.Alto;
                        img.nbAncho.Value = data.Ancho;
                        img.nbInterlineado.Value = data.Interlineado;
                        img.nbdesplazar.Value = data.DesplazamientoX;
                        img.StrImagen = data.RutaImagen;
                        img.ImagenBytes = data.RutaImagen == "placa_vehiculo_barcode" ? null : data.ImagenBytes;
                        img.StrPlacaVehiculo = data.PlacaVehiculoImagen;

                        foreach (ComboBoxItem item in img.cmbAlineacion.Items)
                            if (item.Tag.ToString() == data.AlineacionImagen) { img.cmbAlineacion.SelectedItem = item; break; }

                        mainWin.SuscribirEventosYAgregar(img);
                    }
                }
                mainWin.ActualizarVisualizacionTicket();
            }
        }

        public string DatosEntrada(string buscar, string reemplazar)
        {
            string[] datosDisponibles = { "PLACA:", "Banana", "Naranja", "Manzana Roja", "Pera", "Uva" };

            if (string.IsNullOrWhiteSpace(buscar))
            {
                return string.Empty;
            }

            var resultados = datosDisponibles
                .Where(dato => dato.IndexOf(buscar, StringComparison.OrdinalIgnoreCase) >= 0)
                .Select(dato => dato.Replace(buscar, reemplazar))
                .ToArray();

            // Devuelve el primer resultado encontrado, o una cadena vacía si no hay coincidencias
            return resultados.FirstOrDefault() ?? string.Empty;
        }
    }
}