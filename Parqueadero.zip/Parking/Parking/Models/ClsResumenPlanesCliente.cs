﻿using System.ComponentModel;
using System.Data;
using System.Runtime.CompilerServices;

namespace Parking.Models
{
    public class ResumenPlanesCliente: INotifyPropertyChanged
    {
        private int _totalClientes;
        private int _totalVehiculos;
        private int _totalVehiculosVIP;
        private int _totalMembresia;
        private int _totalMensualidad;

        public int TotalClientes
        {
            get => _totalClientes;
            set { _totalClientes = value; OnPropertyChanged(); }
        }
        public int TotalVehiculos
        {
            get => _totalVehiculos;
            set { _totalVehiculos = value; OnPropertyChanged(); }
        }
        public int TotalVehiculosVIP
        {
            get => _totalVehiculosVIP;
            set { _totalVehiculosVIP = value; OnPropertyChanged(); }
        }
        public int TotalMembresia
        {
            get => _totalMembresia;
            set { _totalMembresia = value; OnPropertyChanged(); }
        }
        public int TotalMensualidad
        {
            get => _totalMensualidad;
            set { _totalMensualidad = value; OnPropertyChanged(); }
        }
        public void CargarDatosResumen(DataTable dtTotalClientes, DataTable dtTotalVehiculos, DataTable dtTotalVehiculosVIP, DataTable dtTotalMembresia, DataTable dtTotalMensualidad)
        {
            TotalClientes = dtTotalClientes?.Rows.Count ?? 0;
            TotalVehiculos = dtTotalVehiculos?.Rows.Count ?? 0;
            TotalVehiculosVIP = dtTotalVehiculosVIP?.Rows.Count ?? 0;
            TotalMembresia = dtTotalMembresia?.Rows.Count ?? 0;
            TotalMensualidad = dtTotalMensualidad?.Rows.Count ?? 0;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}