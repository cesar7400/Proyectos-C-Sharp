﻿using Parking.Controller;
using Parking.Views;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using static System.Net.Mime.MediaTypeNames;

namespace Parking.Models
{
    public class TicketVistaPrevia
    {
        FlowDocument nuevoDoc;
        
        readonly Ticket ticket = new Ticket();
        private string Placa = "";
        public async Task<FlowDocument> PreviewTicket(string IdTicket, DataSet datosTicket)
        {
            nuevoDoc = ticket.Doc_();
            var datos = await CargarConfiguracion(IdTicket, datosTicket);

            foreach (var data in datos)
            {
                if (data.Tipo == "Texto")
                {
                    // Si data.Fuente es nulo o vacío, usa "Arial" por defecto
                    FontFamily fuente = new FontFamily(string.IsNullOrEmpty(data.Fuente) ? "Arial" : data.Fuente);
                    if (data.InformacionEmpresa == 0)
                    {
                        ticket.AgregarTexto(
                                nuevoDoc,
                                data.TextoUno,
                                (FontWeight)new FontWeightConverter().ConvertFromString(string.IsNullOrEmpty(data.Peso) ? "Normal" : data.Peso),
                                data.TamanioFuente,
                                (Enum.TryParse<TextAlignment>(data.AlineacionTexto, true, out var alineacionParsed) ? alineacionParsed : TextAlignment.Left),
                                fuente,
                                data.Interlineado,
                                data.EspacioVertical,
                                data.EspacioHorizontal
                        // Aquí podrías pasar también el interlineado si lo añadiste a AgregarTexto
                        );
                    }
                    else
                    {
                        foreach (KeyValuePair<string, string> par in Configuracion.DicEmpresa)
                        {
                            ticket.AgregarTexto(
                                nuevoDoc,
                                par.Value.ToString(),
                                par.Key == "razon_social" ? FontWeights.Bold : (FontWeight)new FontWeightConverter().ConvertFromString(string.IsNullOrEmpty(data.Peso) ? "Normal" : data.Peso),
                                data.TamanioFuente,
                                (Enum.TryParse<TextAlignment>(data.AlineacionTexto, true, out var alineacionParsed) ? alineacionParsed : TextAlignment.Left),
                                fuente,
                                data.Interlineado,
                                data.EspacioVertical,
                                data.EspacioHorizontal
                            );
                        }
                    }
                }
                else if (data.Tipo == "Parrafo")
                {
                    // Si data.Fuente es nulo o vacío, usa "Arial" por defecto
                    FontFamily fuente = new FontFamily(string.IsNullOrEmpty(data.Fuente) ? "Arial" : data.Fuente);
                    ticket.AgregarTexto(
                                nuevoDoc,
                                data.Parrafo,
                                (FontWeight)new FontWeightConverter().ConvertFromString(string.IsNullOrEmpty(data.Peso) ? "Normal" : data.Peso),
                                data.TamanioFuente,
                                (Enum.TryParse<TextAlignment>(data.AlineacionTexto, true, out var alineacionParsed) ? alineacionParsed : TextAlignment.Left),
                                fuente,
                                data.Interlineado,
                                data.EspacioVertical,
                                data.EspacioHorizontal
                        // Aquí podrías pasar también el interlineado si lo añadiste a AgregarTexto
                        );
                }
                else if (data.Tipo == "Control datos")
                {
                    // Si data.Fuente es nulo o vacío, usa "Arial" por defecto
                    FontFamily fuente = new FontFamily(string.IsNullOrEmpty(data.Fuente) ? "Arial" : data.Fuente);
                    ticket.AgregarMatrizDatos(
                        nuevoDoc,
                        data.MatrizDatos,
                        fuente,
                        (FontWeight)new FontWeightConverter().ConvertFromString(string.IsNullOrEmpty(data.Peso) ? "Normal" : data.Peso),
                        (Enum.TryParse<TextAlignment>(data.AlineacionTexto, true, out var alineacionParsed) ? alineacionParsed : TextAlignment.Left),
                        data.TamanioFuente,
                        data.EspacioVertical,
                        data.EspacioHorizontal,
                        data.Interlineado,
                        data.FilaPintadaIndex,
                        data.ColumnaPintadaIndex
                    );
                    // Aquí podrías pasar también el interlineado si lo añadiste a AgregarTexto
                }
                
                else if (data.Tipo == "Imagen")
                {
                    var Image = new BitmapImage();
                    
                    if (data.RutaImagen == "placa_vehiculo_barcode")
                    {
                        Barcode barcode = new Barcode();
                        // Expresión regular que busca 3 letras, espacios opcionales y los números de la placa
                        Match match = Regex.Match(Placa, @"[A-Za-z]{3}\s*\d+");
                        BitmapImage barcodeBitmap = barcode.ObtenerBarcodeCode39BitmapImage(match.Success ? match.Value : string.Empty);
                        Image = barcodeBitmap;
                    }
                    else
                    {
                        using (var mem = new MemoryStream(data.ImagenBytes))
                        {
                            Image.BeginInit();
                            Image.CacheOption = BitmapCacheOption.OnLoad; // Free stream lock after loading
                            Image.StreamSource = mem;
                            Image.EndInit();
                            Image.Freeze(); // Optional: makes it cross-thread accessible
                        }
                    }
                    TextAlignment alineacionFinal = Enum.TryParse<TextAlignment>(data.AlineacionImagen, true, out var resultado)
                    ? resultado
                    : TextAlignment.Left; // Valor por defecto si la cadena es nula o inválida

                    ticket.AgregarImagen(
                        nuevoDoc,
                        Image,
                        data.Ancho,
                        data.Alto,
                        data.Interlineado, // Usa el interlineado decimal
                        alineacionFinal,
                        data.DesplazamientoX       // NumericUpDown
                    );
                }
            }
            return nuevoDoc;
        }
        // MÉTODO PARA CARGAR TODO
        private async Task<List<TicketItemData>> CargarConfiguracion(string ConfiguracionID, DataSet dsDatosReales)
        {
            ConfiguracionController configuracion = new ConfiguracionController();
            var resultado = await configuracion.CargarConfiguracionTicket(ConfiguracionID);

            try
            {
                string json = resultado.Tables[0].Rows[0]["DatosJson"].ToString();

                DataTable dtInfo = (dsDatosReales.Tables != null && dsDatosReales.Tables.Count > 0) ? dsDatosReales.Tables[0] : null;
                DataTable dtDatos = (dsDatosReales.Tables != null && dsDatosReales.Tables.Count > 1) ? dsDatosReales.Tables[1] : null;

                // Extraemos los valores de ticket y placa del DataTable de información general (si existen)
                string numTicket = (dtInfo != null && dtInfo.Rows.Count > 0 && dtInfo.Columns.Contains("NUMERO TICKET"))
                    ? dtInfo.Rows[0]["NUMERO TICKET"]?.ToString() ?? string.Empty
                    : string.Empty;

                string placaVehiculo = (dtInfo != null && dtInfo.Rows.Count > 0 && dtInfo.Columns.Contains("PLACA VEHICULO"))
                    ? dtInfo.Rows[0]["PLACA VEHICULO"]?.ToString() ?? string.Empty
                    : string.Empty;

                using (MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(json)))
                {
                    var ser = new DataContractJsonSerializer(typeof(List<TicketItemData>));
                    var listaItems = (List<TicketItemData>)ser.ReadObject(ms);

                    foreach (var item in listaItems)
                    {
                        // 1. Reemplazo de etiquetas globales en propiedades de texto comunes (Encabezado, Parrafo, Textos, etc.)
                        if (item.Encabezado != null)
                        {
                            item.Encabezado = item.Encabezado
                                .Replace("{{NUMERO TICKET}}", numTicket)
                                .Replace("{{PLACA VEHICULO}}", placaVehiculo);
                            Placa = placaVehiculo; // Guardamos la placa para uso posterior si es necesario
                        }

                        if (item.Parrafo != null)
                        {
                            item.Parrafo = item.Parrafo
                                .Replace("{{NUMERO TICKET}}", numTicket)
                                .Replace("{{PLACA VEHICULO}}", placaVehiculo);
                            Placa = placaVehiculo; // Guardamos la placa para uso posterior si es necesario
                        }

                        // Si manejas propiedades individuales de texto (TextoUno, TextoDos, etc.), agrégalas aquí:
                        if (item.TextoUno != null)
                        {
                            item.TextoUno = item.TextoUno
                                .Replace("{{NUMERO TICKET}}", numTicket)
                                .Replace("{{PLACA VEHICULO}}", placaVehiculo);
                            Placa = placaVehiculo; // Guardamos la placa para uso posterior si es necesario
                        }

                        // 2. Reemplazo de la matriz de datos dinámicos ({{ITEM}})
                        if (item.Tipo == "Control datos" && item.MatrizDatos != null && dtDatos != null && dtDatos.Rows.Count > 0)
                        {
                            DataRow row = dtDatos.Rows[0]; // Tomamos el primer registro de datos reales

                            for (int i = 0; i < item.MatrizDatos.Count; i++)
                            {
                                var filaMatriz = item.MatrizDatos[i];

                                for (int j = 0; j < filaMatriz.Count; j++)
                                {
                                    if (filaMatriz[j] == "{{ITEM}}")
                                    {
                                        // Obtenemos el nombre de la etiqueta basándonos en la misma fila (columna 0 suele tener el título ej. "Entrada:")
                                        string nombreColumna = (filaMatriz.Count > 0)
                                            ? filaMatriz[0].Replace(":", "").Trim()
                                            : string.Empty;

                                        // Si la celda anterior o la estructura usa el título en la columna 0:
                                        if (!string.IsNullOrEmpty(nombreColumna) && dtDatos.Columns.Contains(nombreColumna))
                                        {
                                            filaMatriz[j] = row[nombreColumna]?.ToString() ?? string.Empty;
                                        }
                                        else if (i < dtDatos.Columns.Count)
                                        {
                                            // Fallback directo por el índice de la fila de la matriz hacia las columnas del DataTable
                                            string colName = dtDatos.Columns[i].ColumnName;
                                            filaMatriz[j] = row[colName]?.ToString() ?? string.Empty;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    return listaItems;
                }
            }
            catch { return new List<TicketItemData>(); }
        }
    }
}