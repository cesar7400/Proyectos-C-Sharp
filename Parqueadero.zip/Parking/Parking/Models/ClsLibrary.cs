﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Parking.Models
{
    public class Library
    {
        public void Letters(object sender, TextCompositionEventArgs e)
        {
            // Regular expression para solo letras
            Regex regex = new Regex("^[a-zA-ZñÑáéíóúÁÉÍÓÚ]+$");
            e.Handled = !regex.IsMatch(e.Text);
        }
        public void Numbers(object sender, TextCompositionEventArgs e)
        {
            // Permitir solo números usando expresiones regulares
            Regex regex = new Regex("^[0-9]+$");
            if (!regex.IsMatch(e.Text))
            {
                e.Handled = true;
                return;
            }

            // Obtener el TextBox
            TextBox txt = sender as TextBox;
            if (txt == null) return;

            // Simular cómo quedaría el texto completo
            string textoActual = txt.Text;
            int seleccionInicio = txt.SelectionStart;
            int seleccionLargo = txt.SelectionLength;

            string textoNuevo = textoActual.Remove(seleccionInicio, seleccionLargo).Insert(seleccionInicio, e.Text);

            // REGLA: Impedir que empiece con ceros múltiples (ej: "00", "005", "010")
            // Permitimos que el texto sea simplemente "0", pero si empieza con "0" y le sigue otro número (ej. "05"), se bloquea.
            if (textoNuevo.Length > 1 && textoNuevo.StartsWith("0"))
            {
                e.Handled = true;
                return;
            }
        }
        public string FormatCelularNumber(string phoneNumber)
        {
            // Declaramos una variable 'val' para almacenar un valor temporal.
            string val;

            // Si el número de teléfono es nulo o vacío, se retorna tal cual.
            if (string.IsNullOrEmpty(phoneNumber))
            {
                return phoneNumber;
            }

            // Si el número empieza con "+" y su longitud es menor o igual a 12, lo retornamos tal cual.
            if (phoneNumber.StartsWith("+") && phoneNumber.Length <= 12)
            {
                return phoneNumber;
            }

            // Se define una expresión regular para validar el formato del número telefónico.
            // La expresión espera un número con un código de país (+XX) y un número de teléfono con paréntesis y guiones.
            Regex regex = new Regex(@"(\+[0-9]{2} )(\(+[0-9]{3}\) )([0-9]{3}\ )([0-9]{2}\ )([0-9]{2})");

            // Si el número no coincide con el patrón de la expresión regular y su longitud no es 10, se elimina caracteres no deseados.
            if (!regex.IsMatch(phoneNumber) && phoneNumber.Length != 10)
            {
                // Se eliminan caracteres como paréntesis, guiones y espacios.
                val = Regex.Replace(phoneNumber, @"(\+[0-9]{2} |)[\\()\\' '\\-]", "");
                // Retornamos el número limpiado.
                return val;
            }

            // Si el número tiene exactamente 10 dígitos (presumiblemente sin el código de país),
            // se lo formatea con el código de país (+57) y el formato típico de teléfono colombiano.
            if (phoneNumber.Length == 10)
            {
                // **Aquí el truco**: partimos en 3–3–2–2, no 4–4–2.
                string parte1 = phoneNumber.Substring(0, 3); // "300"
                string parte2 = phoneNumber.Substring(3, 3); // "000"
                string parte3 = phoneNumber.Substring(6, 2); // "00"
                string parte4 = phoneNumber.Substring(8, 2); // "00"

                return string.Format("+57 ({0}) {1} {2} {3}", parte1, parte2, parte3, parte4);
            }
            else
            {
                // Si el número no cumple con el formato esperado, se retorna tal cual.
                return phoneNumber;
            }
        }
        public string CalcularDigitoVerificacion(string Nit)
        {
            // Variable temporal para almacenar cada dígito
            string Temp;

            // Contador para el bucle
            int Contador;

            // Acumulador para la suma ponderada
            int Acumulador = 0;

            // Array que contiene los factores para el cálculo
            int[] Vector = new int[15]
            {
                3, 7, 13, 17, 19, 23, 29, 37, 41, 43, 47, 53, 59, 67, 71
            };

            // Itera a través de cada dígito del NIT, de atrás hacia adelante
            for (Contador = 0; Contador < Nit.Length; Contador++)
            {
                // Toma el dígito correspondiente, comenzando desde el final
                Temp = Nit[(Nit.Length - 1) - Contador].ToString();

                // Suma el producto del dígito por el factor correspondiente al acumulador
                Acumulador += Convert.ToInt32(Temp) * Vector[Contador];
            }

            // Calcula el residuo de la suma acumulada al dividir entre 11 usando asignación compuesta
            int Residuo = Acumulador % 11;

            // Si el residuo es mayor que 1, calcula el dígito de verificación
            if (Residuo > 1)
                return Convert.ToString(11 - Residuo);

            // Si el residuo es 0 o 1, retorna el residuo como es
            return Residuo.ToString();
        }
        public bool ImageValidacion(string filePath)
        {
            bool valid; // Variable para almacenar el estado de validación de la imagen
            try
            {
                // Comprobamos si el archivo existe en la ruta especificada
                if (File.Exists(filePath))
                {
                    // Intentamos abrir el archivo como una imagen utilizando Bitmap
                    using (Bitmap bitmap = new Bitmap(filePath))
                    {
                        valid = true; // Si se abre correctamente, la imagen es válida
                    }
                }
                else
                {
                    valid = false; // Si el archivo no existe, marcamos como no válido
                }
            }
            catch (ArgumentException error)
            {
                // Capturamos una excepción específica si el archivo no es una imagen válida
                MessageBox.Show("No es una imagen válida.\n" + error.Message + "", "Error imagen", MessageBoxButton.OK, MessageBoxImage.Error);
                valid = false; // Marcamos como no válido
            }
            catch (Exception error)
            {
                // Capturamos cualquier otra excepción que pueda ocurrir
                MessageBox.Show("No es una imagen válida.\n" + error.Message + "", "Error imagen", MessageBoxButton.OK, MessageBoxImage.Error);
                valid = false; // Marcamos como no válido
            }
            return valid; // Retornamos el resultado de la validación
        }
        public byte[] ProcesarImagenDesdeRuta(string rutaImagen)
        {
            using (Bitmap original = new Bitmap(rutaImagen))
            {
                int nuevoAncho;
                int nuevoAlto;

                // Regla: imagen cuadrada
                if (original.Width == original.Height)
                {
                    nuevoAncho = 128;
                    nuevoAlto = 128;
                }
                // Regla: imagen no cuadrada (ticket)
                else
                {
                    nuevoAncho = 290;
                    nuevoAlto = 128;
                }

                using (Bitmap resultado = new Bitmap(nuevoAncho, nuevoAlto))
                {
                    resultado.SetResolution(96, 96);

                    using (Graphics g = Graphics.FromImage(resultado))
                    {
                        g.CompositingQuality = CompositingQuality.HighQuality;
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.SmoothingMode = SmoothingMode.HighQuality;

                        g.DrawImage(original, 0, 0, nuevoAncho, nuevoAlto);
                    }

                    using (MemoryStream ms = new MemoryStream())
                    {
                        resultado.Save(ms, ImageFormat.Png);
                        return ms.ToArray(); // listo para SQL Server
                    }
                }
            }
        }
        // Función auxiliar necesaria para encontrar controles por nombre en Templates
        public T FindChild<T>(DependencyObject parent, string childName) where T : DependencyObject
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T t && child is FrameworkElement fe && fe.Name == childName) return t;

                if (FindChild<T>(child, childName) is T result) return result;
            }
            return null;
        }
        // Método genérico para encontrar un hijo visual de tipo T en un objeto de tipo DependencyObject.
        public T FindVisualChild<T>(DependencyObject obj) where T : DependencyObject
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(obj); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(obj, i);

                if (child is T typedChild)
                {
                    return typedChild;
                }
                else
                {
                    T childOfChild = FindVisualChild<T>(child);
                    if (childOfChild != null)
                        return childOfChild;
                }
            }
            return null;
        }
        // Método genérico que busca un hijo visual en el árbol de dependencias.
        public T FindVisualChild<T>(DependencyObject parent, Func<T, bool> condition) where T : DependencyObject
        {
            // Itera a través de todos los hijos del objeto padre.
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                // Obtiene el hijo en la posición 'i'.
                DependencyObject child = VisualTreeHelper.GetChild(parent, i);

                // Verifica si el hijo es del tipo T y si cumple con la condición dada.
                if (child is T typedChild && condition(typedChild))
                {
                    // Si se cumple, retorna el hijo encontrado.
                    return typedChild;
                }

                // Llama recursivamente a FindVisualChild para buscar en los hijos del hijo actual.
                T childOfChild = FindVisualChild(child, condition);

                // Si se encontró un hijo que cumple con la condición en la búsqueda recursiva, lo retorna.
                if (childOfChild != null)
                {
                    return childOfChild;
                }
            }
            // Si no se encuentra ningún hijo que cumpla con la condición, retorna null.
            return null;
        }
        // ========================================================================
        // FUNCIÓN AUXILIAR: Busca cualquier tipo de control dentro de la fila
        // ========================================================================
        public T BuscarControlVisual<T>(DependencyObject padre) where T : DependencyObject
        {
            if (padre == null) return null;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(padre); i++)
            {
                var hijo = VisualTreeHelper.GetChild(padre, i);

                if (hijo is T controlEncontrado)
                {
                    return controlEncontrado;
                }

                var resultadoSubArbol = BuscarControlVisual<T>(hijo);
                if (resultadoSubArbol != null)
                {
                    return resultadoSubArbol;
                }
            }
            return null;
        }
        public void FormatNumberML(object sender, TextChangedEventArgs e)// Método para formatear números con separadores de miles
        {
            if (sender is TextBox textBox)
            {
                // Guardar la posición actual del cursor
                int cursorPosition = textBox.SelectionStart;

                // Eliminar cualquier símbolo de separación existente
                string text = textBox.Text.Replace(".", "").Replace(",", "");

                // Verificar si el texto es numérico
                if (long.TryParse(text, out long number))
                {
                    // Formatear el número con separadores de miles
                    textBox.Text = number.ToString("N0", new CultureInfo("es-ES"));

                    // Restaurar la posición del cursor
                    if (textBox.Text != "0" && textBox.Text != "")
                    {
                        textBox.SelectionStart = Math.Min(cursorPosition + (textBox.Text.Length - text.Length), textBox.Text.Length);
                    }
                }
            }
        }
        public bool IsValidEmail(string email)
        {
            // Verificamos si el email está vacío o contiene solo espacios en blanco
            if (string.IsNullOrWhiteSpace(email))
            {
                return false; // Retornamos false si el email no es válido
            }

            // Definimos una expresión regular para validar el formato del email
            string pattern = @"^[\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?$";

            // Intentamos hacer coincidir el email con el patrón definido, ignorando mayúsculas y minúsculas
            Match match = Regex.Match(email, pattern, RegexOptions.IgnoreCase);

            // Si no hay coincidencia, el email no es válido
            if (!match.Success)
            {
                return false; // Retornamos false
            }

            // Si el email cumple con el patrón, retornamos true
            return true;
        }
        // Método que valida si un número de teléfono cumple con un formato específico.
        // Retorna verdadero si el número es válido, de lo contrario retorna falso.
        public bool ValidNumberCel(string phoneNumber)
        {
            // Se define una expresión regular para el formato del número de teléfono.
            // El formato esperado es: "+57 (xxx) xxx xx xx", donde 'x' son dígitos.
            Regex regex = new Regex(@"^\+57 \(\d{3}\) \d{3} \d{2} \d{2}$");

            // Se verifica si el número de teléfono coincide con la expresión regular.
            bool isValid = regex.IsMatch(phoneNumber);

            // Si el número es válido, se retorna verdadero.
            if (isValid)
            {
                return true;
            }
            else
            {
                // Si el número no es válido, se retorna falso.
                return false;
            }
        }
        public string FormatPlacaVehiculo(string placa)
        {
            // Retornar tal cual si la entrada es nula o vacía
            if (string.IsNullOrEmpty(placa))
            {
                return placa;
            }

            // Eliminar espacios, guiones o caracteres especiales
            string cleaned = Regex.Replace(placa.ToUpper().Trim(), @"[^A-Z0-9]", "");

            // Regex para placa de vehículo: ABC123
            string regexVehiculo = @"^[A-Z]{3}\d{3}$";

            // Regex para placa de motocicleta: AB123C
            string regexMoto = @"^[A-Z]{2}\d{3}[A-Z]$";

            // Validación y formato para vehículo
            if (Regex.IsMatch(cleaned, regexVehiculo))
            {
                // Formato opcional: separar con guion (ABC-123)
                return cleaned.Substring(0, 3) + " " + cleaned.Substring(3, 3);
            }

            // Validación y formato para motocicleta
            if (Regex.IsMatch(cleaned, regexMoto))
            {
                // Formato opcional: AB-123-C
                return cleaned.Substring(0, 2) + " " + cleaned.Substring(2, 3) + " " + cleaned.Substring(5, 1);
            }

            // Si no coincide con ningún formato conocido, retornar sin cambios
            return placa;
        }
    }
}