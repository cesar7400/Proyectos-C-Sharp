﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Parking.Models
{
    public class EncriptarTexto
    {
        // Variables para almacenar el texto encriptado y desencriptado
        private string strEncrypt = "";
        private string strDecrypt = "";

        // Contraseña única utilizada para la encriptación
        private readonly string passUnique = "Parking";

        // Instancia del proveedor de Triple DES para encriptación
        private readonly TripleDESCryptoServiceProvider descp = new TripleDESCryptoServiceProvider();
        // Instancia del proveedor MD5 para generar hashes
        private readonly MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

        // Método para encriptar un texto
        public string Encriptar(string text)
        {
            // Si el texto está vacío, devolver una cadena vacía
            if (text == "")
            {
                strEncrypt = "";
            }
            else
            {
                // Generar la clave de encriptación usando MD5
                descp.Key = md5.ComputeHash((new UnicodeEncoding()).GetBytes(passUnique));
                descp.Mode = CipherMode.ECB; // Establecer el modo de operación como ECB

                // Crear un transformador para encriptar
                ICryptoTransform cryptoTransform = descp.CreateEncryptor();

                // Convertir el texto a un array de bytes
                byte[] buff = UnicodeEncoding.ASCII.GetBytes(text);

                // Encriptar los datos y convertir el resultado a Base64
                strEncrypt = Convert.ToBase64String(cryptoTransform.TransformFinalBlock(buff, 0, buff.Length));
            }
            // Devolver el texto encriptado
            return strEncrypt;
        }

        // Método para desencriptar un texto
        public string Desencriptar(string text)
        {
            // Si el texto está vacío, devolver una cadena vacía
            if (text == "")
            {
                strDecrypt = "";
            }
            else
            {
                // Generar la clave de desencriptación usando MD5
                descp.Key = md5.ComputeHash((new UnicodeEncoding()).GetBytes(passUnique));
                descp.Mode = CipherMode.ECB; // Establecer el modo de operación como ECB

                // Crear un transformador para desencriptar
                ICryptoTransform decryptoTransform = descp.CreateDecryptor();

                // Convertir el texto Base64 a un array de bytes
                byte[] buff = Convert.FromBase64String(text);

                // Desencriptar los datos y convertir el resultado a una cadena
                strDecrypt = UnicodeEncoding.ASCII.GetString(decryptoTransform.TransformFinalBlock(buff, 0, buff.Length));
            }
            // Devolver el texto desencriptado
            return strDecrypt;
        }
    }
}