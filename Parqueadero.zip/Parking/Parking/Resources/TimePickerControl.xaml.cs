﻿using System;
using System.Windows.Controls;
using System.Windows.Input;

namespace Parking.Resources
{
    /// <summary>
    /// Lógica de interacción para TimePickerControl.xaml
    /// </summary>
    public partial class TimePickerControl : UserControl
    {
        private DateTime _currentTime = DateTime.Now;

        public TimePickerControl()
        {
            InitializeComponent();
            ActualizarTexto();

            btnUp.Click += (s, e) => AjustarParteSeleccionada(1);
            btnDown.Click += (s, e) => AjustarParteSeleccionada(-1);
            txtTime.PreviewKeyDown += TxtTime_PreviewKeyDown;
        }
        public string TextoHora
        {
            get { return txtTime.Text; }
        }
        private void TxtTime_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Up)
            {
                AjustarParteSeleccionada(1);
                e.Handled = true;
            }
            else if (e.Key == Key.Down)
            {
                AjustarParteSeleccionada(-1);
                e.Handled = true;
            }
        }

        private void AjustarParteSeleccionada(int delta)
        {
            int caret = txtTime.CaretIndex;

            // Nuevos rangos de posición para el formato sin segundos ("03 : 56 PM")
            if (caret <= 2)
            {
                // Bloque de Horas
                _currentTime = _currentTime.AddHours(delta);
            }
            else if (caret >= 3 && caret <= 7)
            {
                // Bloque de Minutos
                _currentTime = _currentTime.AddMinutes(delta);
            }
            else
            {
                // Bloque AM / PM
                _currentTime = _currentTime.AddHours(delta > 0 ? 12 : -12);
            }

            ActualizarTexto();
            txtTime.CaretIndex = Math.Min(caret, txtTime.Text.Length);
        }

        private void ActualizarTexto()
        {
            // Forzamos la cultura en-US para evitar que aparezcan puntos ("P. M.")
            var culture = System.Globalization.CultureInfo.GetCultureInfo("en-US");
            txtTime.Text = _currentTime.ToString("hh : mm tt", culture).ToUpper();
        }

        public bool EsHoraValida()
        {
            if (string.IsNullOrWhiteSpace(txtTime.Text))
            {
                return false;
            }

            var culture = System.Globalization.CultureInfo.GetCultureInfo("en-US");
            string formato12H = "hh : mm tt";

            return DateTime.TryParseExact(
                txtTime.Text,
                formato12H,
                culture,
                System.Globalization.DateTimeStyles.None,
                out _
            );
        }

        public DateTime SelectedTime
        {
            get { return _currentTime; }
            set
            {
                _currentTime = value;
                ActualizarTexto();
            }
        }
    }
}