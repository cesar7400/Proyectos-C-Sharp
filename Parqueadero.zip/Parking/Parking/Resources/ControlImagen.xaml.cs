﻿using Microsoft.Win32;
using Parking.Models;
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Parking.Resources
{
    /// <summary>
    /// Lógica de interacción para ControlImagen.xaml
    /// </summary>
    public partial class ControlImagen : UserControl
    {
        public ControlImagen(string titulo)
        {
            InitializeComponent();
            gbGrupoImagen.Header = titulo;
        }
        // Dentro de tus UserControls
        public event EventHandler MoverArriba;
        public event EventHandler MoverAbajo;
        private void BtnSubir_Click(object sender, RoutedEventArgs e)
        {
            // 'this' envía la identidad única de este GroupBox específico
            MoverArriba?.Invoke(this, EventArgs.Empty);
        }

        private void BtnBajar_Click(object sender, RoutedEventArgs e)
        {
            MoverAbajo?.Invoke(this, EventArgs.Empty);
        }
        // El ancho útil suele ser de 300 a 320 dependiendo de los márgenes del FlowDocument
        private const double ANCHO_TICKET = 300.0;
        // Definimos el evento que MainWindow podrá escuchar
        public event EventHandler AjusteCambiadoImagen;
        // Propiedad para el desplazamiento lateral (Eje X)
        public TextAlignment AlineacionSeleccionada
        {
            get
            {
                if (cmbAlineacion == null || cmbAlineacion.SelectedItem == null)
                {
                    return TextAlignment.Left;
                }

                var selectedTag = ((ComboBoxItem)cmbAlineacion.SelectedItem).Tag.ToString();
                return (TextAlignment)Enum.Parse(typeof(TextAlignment), selectedTag);
            }
        }

        // Valor decimal del desplazamiento
        public double DesplazamientoX => nbdesplazar != null ? nbdesplazar.Value : 0.0;
        // Definimos el nuevo evento
        public event EventHandler ControlQuitadoImagen;

        public string textoImagen = "Logotipo";
        // Cambia 'int' por 'double' para permitir precisión decimal
        public double InterlineadoTexto => nbInterlineado != null ? nbInterlineado.Value : 1.0;

        public double Alto => nbAlto.Value;
        public double Ancho => nbAncho.Value;
        public string StrPlacaVehiculo { get; set; } = ""; //Número placa de vehiculo barcode
        public string StrImagen { get; set; } = ""; // Inicializamos vacío
        public byte[] ImagenBytes { get; set; } =  null; // Inicializamos vacío

        public BitmapImage Bitmap
        {
            get
            {
                Library library = new Library();      // Instancia para validar la imagen
                try
                {
                    if (library.ImageValidacion(StrImagen) && StrImagen != "")      // Verifica que la imagen cumpla condiciones (tamaño, tipo)
                    {
                        ImagenBytes = library.ProcesarImagenDesdeRuta(StrImagen);
                        StrImagen = "ruta";
                    }

                    if (StrImagen == "placa_vehiculo_barcode")
                    {
                        Barcode barcode = new Barcode();
                        // Generamos el BitmapImage del código de barras
                        string textoPlaca = (string.IsNullOrEmpty(StrPlacaVehiculo) || StrPlacaVehiculo == "{{PLACA VEHICULO}}") ? "ABC 123" : StrPlacaVehiculo;
                        BitmapImage barcodeBitmap = barcode.ObtenerBarcodeCode39BitmapImage(textoPlaca);
                        // Nos aseguramos de que el BitmapImage esté listo y cargado
                        if (barcodeBitmap != null)
                        {
                            // Convertimos el BitmapImage a byte[] usando PNG (ideal para códigos de barras por la nitidez)
                            PngBitmapEncoder encoder = new PngBitmapEncoder();
                            encoder.Frames.Add(BitmapFrame.Create(barcodeBitmap));

                            using (MemoryStream ms = new MemoryStream())
                            {
                                encoder.Save(ms);
                                ImagenBytes = ms.ToArray();
                            }
                        }
                    }
                    if(StrImagen =="predeterminada" || StrImagen == "")
                    {
                        // Obtenemos el recurso de WPF
                        var infoRecurso = Application.GetResourceStream(new Uri("pack://application:,,,/Icons/parking.png", UriKind.RelativeOrAbsolute));

                        using (MemoryStream ms = new MemoryStream())
                        {
                            infoRecurso.Stream.CopyTo(ms);
                            ImagenBytes = ms.ToArray();
                        }
                    }
                    var Image = new BitmapImage();
                    using (var mem = new MemoryStream(ImagenBytes))
                    {
                        Image.BeginInit();
                        Image.CacheOption = BitmapCacheOption.OnLoad; // Free stream lock after loading
                        Image.StreamSource = mem;
                        Image.EndInit();
                        Image.Freeze(); // Optional: makes it cross-thread accessible
                    }
                    // Intentamos cargar la imagen
                    return Image;
                }
                catch
                {
                    // Obtenemos el recurso de WPF
                    var infoRecurso = Application.GetResourceStream(new Uri("pack://application:,,,/Icons/parking.png", UriKind.RelativeOrAbsolute));

                    BitmapImage Image = new BitmapImage();
                    Image.BeginInit();
                    Image.CacheOption = BitmapCacheOption.OnLoad;
                    Image.StreamSource = infoRecurso.Stream; // Asignamos directamente el stream del recurso
                    Image.EndInit();
                    // No llames a Freeze() todavía si vas a pasarlo al encoder, o hazlo al final.

                    // Codificamos la imagen a bytes correctamente
                    JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(Image));

                    using (MemoryStream ms = new MemoryStream())
                    {
                        encoder.Save(ms);
                        ImagenBytes = ms.ToArray();
                    }
                    return Image;
                }
            }
        }
        // Este método se ejecuta cada vez que CUALQUIER control interno cambie
        private void Control_Changed(object sender, RoutedEventArgs e)
        {
            // 1. Recalcular límites antes de notificar al MainWindow
            ActualizarLimitesDesplazamiento();

            // 2. Notificar cambios para redibujar el ticket
            AjusteCambiadoImagen?.Invoke(this, EventArgs.Empty);
        }

        private void BtnQuitarImagen_Click(object sender, RoutedEventArgs e)
        {
            // 1. Avisamos al MainWindow ANTES de borrar
            ControlQuitadoImagen?.Invoke(this, EventArgs.Empty);

            // 2. Ejecutamos la eliminación del panel
            var parent = VisualTreeHelper.GetParent(this) as Panel;
            parent?.Children.Remove(this);
        }
        private void ActualizarLimitesDesplazamiento()
        {
            if (nbdesplazar == null || nbAncho == null) return;

            double anchoImagen = nbAncho.Value;
            double espacioDisponible;

            // El límite depende de la alineación seleccionada
            switch (AlineacionSeleccionada)
            {
                case TextAlignment.Left:
                    // Si está a la izquierda, puede moverse hasta que el borde derecho toque el final
                    espacioDisponible = ANCHO_TICKET - anchoImagen;
                    nbdesplazar.Minimum = 0;
                    nbdesplazar.Maximum = Math.Max(0, espacioDisponible);
                    break;

                case TextAlignment.Center:
                    // Si está al centro, el margen de maniobra es la mitad del espacio sobrante a cada lado
                    espacioDisponible = (ANCHO_TICKET - anchoImagen) / 2;
                    nbdesplazar.Minimum = 0;
                    nbdesplazar.Maximum = espacioDisponible;
                    break;

                case TextAlignment.Right:
                    // Si está a la derecha, el desplazamiento positivo lo sacaría del ticket
                    //espacioDisponible = ANCHO_TICKET - anchoImagen;
                    nbdesplazar.Minimum = 0;
                    nbdesplazar.Maximum = 0;
                    break;
            }
        }
        private void BtnRestablecer_Click(object sender, RoutedEventArgs e)
        {
            // Restablecer dimensiones originales
            nbAncho.Value = 128;
            nbAlto.Value = 128;

            StrImagen = "";
            // Restablecer interlineado a la base (1.0)
            nbInterlineado.Value = 1.0;

            // Restablecer posición y alineación
            nbdesplazar.Value = 0;
            cmbAlineacion.SelectedIndex = 1; // Centro

            // Actualizar los límites de desplazamiento según los nuevos valores
            ActualizarLimitesDesplazamiento();

            // Notificar al MainWindow para redibujar el ticket inmediatamente
            AjusteCambiadoImagen?.Invoke(this, EventArgs.Empty);
        }

        private void CmbSeleccionarImagen_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Evita bucle infinito. 
            // Si el índice es -1 (limpio), salimos inmediatamente.
            if (cmbSeleccionarImagen.SelectedIndex == -1) return;
            if (cmbSeleccionarImagen.SelectedIndex == 0)
            {
                StrImagen = "predeterminada";
                // 1. Recalcular límites antes de notificar al MainWindow
                ActualizarLimitesDesplazamiento();

                // 2. Notificar cambios para redibujar el ticket
                AjusteCambiadoImagen?.Invoke(this, EventArgs.Empty);

                // 3. Limpiamos el combo inmediatamente
                cmbSeleccionarImagen.SelectedIndex = -1;
                nbAlto.Value = 128;
                nbAncho.Value = 128;
                nbAlto.IsEnabled = true;
                nbAncho.IsEnabled = true;
            }
            else if (cmbSeleccionarImagen.SelectedIndex == 1)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    OpenFileDialog openFileDialog = new OpenFileDialog
                    {
                        Title = "Seleccionar imagen",                 // Título de la ventana de diálogo
                        Filter = "Archivos de imagen|*.bmp;*.jpg;*.jpeg;*.gif;*.png;", // Filtros de imagen
                        Multiselect = false,                          // Solo permite seleccionar un archivo
                        FilterIndex = 1                               // Índice del filtro por defecto
                    };
                    bool? result = openFileDialog.ShowDialog();        // Muestra el diálogo y espera resultado

                    if (result == true)
                    {
                        // Ruta completa del archivo seleccionado
                        StrImagen = openFileDialog.FileName;  // Recalcular límites antes de notificar al MainWindow
                        //bitmap = new BitmapImage(new Uri(openFileDialog.FileName, UriKind.Absolute));
                        ActualizarLimitesDesplazamiento();

                        //  Notificar cambios para redibujar el ticket
                        AjusteCambiadoImagen?.Invoke(this, EventArgs.Empty);

                        // Limpiamos el combo al final del proceso del diálogo
                        // (incluso si el usuario dio "Cancelar")
                        cmbSeleccionarImagen.SelectedIndex = -1;
                        nbAlto.Value = 128;
                        nbAncho.Value = 128;
                        nbAlto.IsEnabled = true;
                        nbAncho.IsEnabled = true;
                    }
                    else
                    {
                        cmbSeleccionarImagen.SelectedIndex = -1;
                    }
                }),
                DispatcherPriority.Background);
            }
            else if (cmbSeleccionarImagen.SelectedIndex == 2)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    StrImagen = "placa_vehiculo_barcode";
                    ActualizarLimitesDesplazamiento();

                    //  Notificar cambios para redibujar el ticket
                    AjusteCambiadoImagen?.Invoke(this, EventArgs.Empty);

                    // Limpiamos el combo al final del proceso del diálogo
                    // (incluso si el usuario dio "Cancelar")
                    cmbSeleccionarImagen.SelectedIndex = -1;
                    nbAlto.Value = 40;
                    nbAlto.IsEnabled = false;
                    nbAncho.Value = 128;
                    nbAncho.IsEnabled = false;
                }),
                DispatcherPriority.Background);
            }
        }
    }
}