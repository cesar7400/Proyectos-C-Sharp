﻿using System.Windows.Controls;

namespace Parking.Resources
{
    /// <summary>
    /// Lógica de interacción para Popup.xaml
    /// </summary>
    public partial class Popup : UserControl
    {
        public Popup()
        {
            InitializeComponent();
        }
    }
}