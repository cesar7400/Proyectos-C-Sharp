﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Parking.Resources
{
    public partial class ControlDatos : UserControl
    {
        public ControlDatos(string titulo)
        {
            InitializeComponent();
            gbControlDatos.Header = titulo;
        }

        public event EventHandler AjusteCambiado;
        public event EventHandler MoverArriba;
        public event EventHandler MoverAbajo;
        public event EventHandler ControlQuitado;

        private CheckBox chkPrimeraFila;
        private CheckBox chkPrimeraColumna;
        private TextBlock TbColor;
        private ComboBox cmbColor;
        private Button BtnQuitarColor;

        readonly private List<List<TextBox>> matrizControles = new List<List<TextBox>>();
        private int cantidadFilas = 1;
        private int cantidadColumnas = 0;
        private List<List<string>> _datosMatriz;

        private int _filaPintadaIndex = -1;
        private int _columnaPintadaIndex = -1;
        private string _strColorSeleccionado;

        public string StrColorSeleccionado
        {
            get => cmbColor?.SelectedItem as string ?? _strColorSeleccionado;
            set
            {
                _strColorSeleccionado = value;
                if (cmbColor != null)
                {
                    if (value == null)
                    {
                        cmbColor.SelectedIndex = -1;
                    }
                    else
                    {
                        cmbColor.SelectedItem = value;
                    }
                }
            }
        }
        public int FilaPintadaIndex => chkPrimeraFila?.IsChecked == true ? _filaPintadaIndex : -1;
        public int ColumnaPintadaIndex => chkPrimeraColumna?.IsChecked == true ? _columnaPintadaIndex : -1;
        public double TamanioFuente => nbTamanioFuente.Value;
        public double InterlineadoTexto => nbInterlineado != null ? nbInterlineado.Value : 1.0;
        public double EspacioHorizontal => nbEspacioHorizontal != null ? nbEspacioHorizontal.Value : 1.0;
        public double EspacioVertical => nbEspacioVertical != null ? nbEspacioVertical.Value : 1.0;
        // Propiedad para la fuente con validación
        public FontFamily FuenteSeleccionada => (cmbTipoFuente?.SelectedItem as FontFamily) ?? new FontFamily("Segoe UI");
        // Propiedad para el peso con validación de nulos
        public  FontWeight PesoFuente => (cmbPesoFuente?.SelectedItem != null) ? (FontWeight)cmbPesoFuente.SelectedItem : FontWeights.Normal;
        // Propiedad para la alineación con validación
        public TextAlignment Alineacion => (cmbAlinearTexto?.SelectedItem is ComboBoxItem item && item.Tag != null) ? (TextAlignment)item.Tag : TextAlignment.Left;
        public bool CheckFilaSeleccionada
        {
            get => chkPrimeraFila?.IsChecked == true;
            set
            {
                if (chkPrimeraFila != null) chkPrimeraFila.IsChecked = value;
            }
        }

        public bool CheckColumnaSeleccionada
        {
            get => chkPrimeraColumna?.IsChecked == true;
            set
            {
                if (chkPrimeraColumna != null) chkPrimeraColumna.IsChecked = value;
            }
        }
        public List<List<string>> DatosMatriz
        {
            get
            {
                bool fChecked = chkPrimeraFila?.IsChecked == true;
                bool cChecked = chkPrimeraColumna?.IsChecked == true;
                var resultado = new List<List<string>>();

                for (int i = 0; i < matrizControles.Count; i++)
                {
                    var filaRes = new List<string>();
                    for (int j = 0; j < matrizControles[i].Count; j++)
                    {
                        // Si aplica la regla del checkbox, devolvemos "{{ITEM}}"; de lo contrario, el texto o "00" si está vacío
                        if ((cChecked && i > 0) || (fChecked && j > 0))
                        {
                            filaRes.Add("{{ITEM}}");
                        }
                        else
                        {
                            string texto = matrizControles[i][j].Text;
                            filaRes.Add(string.IsNullOrWhiteSpace(texto) ? "" : texto);
                        }
                    }
                    resultado.Add(filaRes);
                }
                ActualizarCombosTitulos();
                return resultado;
            }
            set
            {
                _datosMatriz = value;
                if (_datosMatriz != null && _datosMatriz.Count > 0)
                {
                    cantidadFilas = _datosMatriz.Count;
                    cantidadColumnas = _datosMatriz.Max(f => f?.Count ?? 0);
                    cantidadColumnas = cantidadColumnas > 0 ? cantidadColumnas : 1;
                    ActualizarInterfazMatriz();

                    for (int i = 0; i < _datosMatriz.Count && i < matrizControles.Count; i++)
                    {
                        for (int j = 0; j < _datosMatriz[i].Count && j < matrizControles[i].Count; j++)
                        {
                            string valor = _datosMatriz[i][j];
                            // Si al cargar viene como "{{ITEM}}" o "00", lo dejamos vacío en la interfaz
                            matrizControles[i][j].Text = (valor == "{{ITEM}}" || valor == "") ? string.Empty : valor;
                        }
                    }
                }
            }
        }

        public void Control_Changed(object sender, RoutedEventArgs e)
        {
            AjusteCambiado?.Invoke(this, EventArgs.Empty);
        }

        public void Control_Changed(object sender, SelectionChangedEventArgs e)
        {
            AjusteCambiado?.Invoke(this, EventArgs.Empty);
        }

        private void ActualizarInterfazMatriz()
        {
            if (lblNumColumnas == null || lblFilas == null || pnlColumnasDinamicas == null) return;

            var valoresActuales = DatosMatriz;

            lblNumColumnas.Text = cantidadFilas.ToString();
            lblFilas.Text = cantidadColumnas.ToString();
            pnlColumnasDinamicas.Children.Clear();
            matrizControles.Clear();

            // Creamos o mantenemos los CheckBoxes principales
            chkPrimeraFila = new CheckBox
            {
                Content = "Títulos fila",
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5, 5, 0, 5),
                //Si la matriz tiene 1 sola fila, se deshabilita el checkbox de fila
                IsEnabled = cantidadFilas > 1
            };

            chkPrimeraColumna = new CheckBox
            {
                Content = "Títulos columna",
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(15, 5, 0, 5),
                //Si la matriz tiene 1 sola columna, se deshabilita el checkbox de columna
                IsEnabled = cantidadFilas > 1
            };
            TbColor = new TextBlock
            {
                Text = "Cambiar color:",
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(15, 5, 0, 5),
                //Si la matriz tiene 1 sola columna, se deshabilita el checkbox de columna
                IsEnabled = cantidadFilas > 1
            };
            cmbColor = new ComboBox
            {
                Style = (Style)FindResource("CustomComboBoxStyle"),
                Width = 135,
                Height = 25,
                Padding = new Thickness(5, 0, 0, 0),
                VerticalContentAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5, 5, 0, 5),
                VerticalAlignment = VerticalAlignment.Center,
                IsEnabled = cantidadFilas > 1
            };
            BtnQuitarColor = new Button
            {
                Style = (Style)FindResource("buttonStyle"),
                Background = Brushes.Thistle,
                Content = "X",
                Width = 25,
                Height = 25,
                Margin = new Thickness(5, 5, 0, 5),
                VerticalAlignment = VerticalAlignment.Center,
                IsEnabled = cantidadFilas > 1
            };
            // Si se deshabilitan y estaban marcados, los desmarcamos por seguridad
            if (cantidadFilas <= 1)
            {
                if (chkPrimeraFila.IsChecked == true) chkPrimeraFila.IsChecked = false;
                if (chkPrimeraColumna.IsChecked == true) chkPrimeraColumna.IsChecked = false;
            }
            // Regla: No se puede tener ambos al mismo tiempo
            chkPrimeraFila.Checked += (s, e) => {
                if (chkPrimeraColumna.IsChecked == true) chkPrimeraColumna.IsChecked = false;
                AplicarReglasItem();
                // Restaurar selección previa en el ComboBox
                RestaurarSeleccionComboBox(StrColorSeleccionado);
                Control_Changed(s, e);
            };
            chkPrimeraFila.Unchecked += (s, e) => {
                MoverTitulosEntreFilaYColumna(false);
                AplicarReglasItem();
                RestaurarSeleccionComboBox(StrColorSeleccionado);
                Control_Changed(s, e);
            };

            chkPrimeraColumna.Checked += (s, e) => {
                if (chkPrimeraFila.IsChecked == true) chkPrimeraFila.IsChecked = false;
                AplicarReglasItem();
                RestaurarSeleccionComboBox(StrColorSeleccionado);
                Control_Changed(s, e);
            };
            chkPrimeraColumna.Unchecked += (s, e) => {
                MoverTitulosEntreFilaYColumna(true);
                AplicarReglasItem();
                RestaurarSeleccionComboBox(StrColorSeleccionado);
                Control_Changed(s, e);
            };
            cmbColor.SelectionChanged += CmbColor_SelectionChanged;

            BtnQuitarColor.Click += (s, e) => {
                // 1. Limpiamos la selección del ComboBox y los índices de control
                cmbColor.SelectedIndex = -1;
                _filaPintadaIndex = -1;
                _columnaPintadaIndex = -1;

                // 2. Recorremos absolutamente toda la matriz de controles para blanquear el fondo de cada celda
                if (matrizControles != null)
                {
                    for (int i = 0; i < matrizControles.Count; i++)
                    {
                        if (matrizControles[i] == null) continue;

                        for (int j = 0; j < matrizControles[i].Count; j++)
                        {
                            var txt = matrizControles[i][j];
                            if (txt != null)
                            {
                                txt.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#E9ECEF");
                            }
                        }
                    }
                }
                StrColorSeleccionado = "";
                // 3. Notificamos el cambio para actualizar el FlowDocument
                Control_Changed(s, e);
            };

            for (int i = 0; i < cantidadFilas; i++)
            {
                StackPanel filaPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Margin = new Thickness(0, 0, 0, 5)
                };

                List<TextBox> listaFila = new List<TextBox>();

                for (int j = 0; j < cantidadColumnas; j++)
                {
                    TextBox txt = new TextBox
                    {
                        Height = 20,
                        Width = 88,
                        Padding = new Thickness(2, 0, 0, 0),
                        FontSize = 16,
                        Style = (Style)FindResource("TextboxStyle"),
                        Margin = new Thickness(0, 0, 5, 0),
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    txt.TextChanged += (s, e) => Control_Changed(s, new RoutedEventArgs());
                    string etiqueta = (i == 0) ? "Agregar texto" : string.Empty;
                    filaPanel.Children.Add(CrearBloqueControl(etiqueta, txt));
                    listaFila.Add(txt);
                }

                if (i == 0)
                {
                    //filaPanel.Children.Add(chkPrimeraFila);
                }

                pnlColumnasDinamicas.Children.Add(filaPanel);
                matrizControles.Add(listaFila);
            }

            if (cantidadFilas > 0)
            {
                StackPanel filaExtraPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Margin = new Thickness(0, 0, 5, 0)
                };

                filaExtraPanel.Children.Add(chkPrimeraFila);
                filaExtraPanel.Children.Add(chkPrimeraColumna);
                filaExtraPanel.Children.Add(TbColor);
                filaExtraPanel.Children.Add(cmbColor);
                filaExtraPanel.Children.Add(BtnQuitarColor);

                pnlColumnasDinamicas.Children.Add(filaExtraPanel);
            }

            if (valoresActuales != null && valoresActuales.Count > 0)
            {
                for (int i = 0; i < valoresActuales.Count && i < matrizControles.Count; i++)
                {
                    for (int j = 0; j < valoresActuales[i].Count && j < matrizControles[i].Count; j++)
                    {
                        matrizControles[i][j].Text = valoresActuales[i][j];
                    }
                }
            }

            AplicarReglasItem();
        }
        private void MoverTitulosEntreFilaYColumna(bool pasandoAColumna)
        {
            if (matrizControles.Count == 0 || matrizControles[0].Count == 0) return;

            int maxFilas = matrizControles.Count;
            int maxCols = matrizControles[0].Count;

            if (!pasandoAColumna)
            {
                var valoresOrigen = new List<string>();
                for (int i = 0; i < maxFilas; i++)
                {
                    valoresOrigen.Add(matrizControles[i][0].Text);
                    matrizControles[i][0].Text = string.Empty;
                }

                for (int j = 0; j < maxCols && j < valoresOrigen.Count; j++)
                {
                    matrizControles[0][j].Text = valoresOrigen[j];
                }
            }
            else
            {
                var valoresOrigen = new List<string>();
                for (int j = 0; j < maxCols; j++)
                {
                    valoresOrigen.Add(matrizControles[0][j].Text);
                    matrizControles[0][j].Text = string.Empty;
                }

                for (int i = 0; i < maxFilas && i < valoresOrigen.Count; i++)
                {
                    matrizControles[i][0].Text = valoresOrigen[i];
                }
            }
        }
        private void AplicarReglasItem()
        {
            if (matrizControles.Count == 0) return;

            bool fChecked = chkPrimeraFila?.IsChecked == true;
            bool cChecked = chkPrimeraColumna?.IsChecked == true;

            for (int i = 0; i < matrizControles.Count; i++)
            {
                for (int j = 0; j < matrizControles[i].Count; j++)
                {
                    var txt = matrizControles[i][j];

                    if ((cChecked && i > 0) || (fChecked && j > 0))
                    {
                        // Visualmente se limpia el textbox y se deshabilita
                        txt.Text = string.Empty;
                        txt.IsEnabled = false;
                        txt.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#E9ECEF");
                    }
                    else
                    {
                        txt.IsEnabled = true;
                        txt.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#FFFFFF");
                    }
                }
            }
            ActualizarCombosTitulos();
        }
        private void ActualizarCombosTitulos()
        {
            if (cmbColor == null) return;

            cmbColor.Items.Clear();

            bool fChecked = chkPrimeraFila?.IsChecked == true;       // "Títulos fila" (lee la primera columna)
            bool cChecked = chkPrimeraColumna?.IsChecked == true;    // "Títulos columna" (lee la primera fila)

            if (fChecked && matrizControles.Count > 0)
            {
                // Si "Títulos fila" está activo, recorremos las filas de la columna 0 (i)
                for (int i = 0; i < matrizControles.Count; i++)
                {
                    if (matrizControles[i].Count > 0)
                    {
                        string textoCelda = matrizControles[i][0].Text;
                        string etiqueta = string.IsNullOrWhiteSpace(textoCelda) ? $"Fila {i + 1}" : textoCelda;
                        cmbColor.Items.Add(etiqueta);
                    }
                }
            }
            else if (cChecked && matrizControles.Count > 0)
            {
                // Si "Títulos columna" está activo, recorremos las columnas de la fila 0 (j)
                for (int j = 0; j < matrizControles[0].Count; j++)
                {
                    string textoCelda = matrizControles[0][j].Text;
                    string etiqueta = string.IsNullOrWhiteSpace(textoCelda) ? $"Columna {j + 1}" : textoCelda;
                    cmbColor.Items.Add(etiqueta);
                }
            }
        }
        private void RestaurarSeleccionComboBox(string textoPrevio)
        {
            if (cmbColor == null || string.IsNullOrEmpty(textoPrevio)) return;

            for (int i = 0; i < cmbColor.Items.Count; i++)
            {
                if (cmbColor.Items[i]?.ToString() == textoPrevio)
                {
                    cmbColor.SelectedIndex = i;
                    break;
                }
            }
        }
        private void CmbColor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbColor == null || cmbColor.SelectedItem == null) return;

            int indiceSeleccionado = cmbColor.SelectedIndex;
            bool fChecked = chkPrimeraFila?.IsChecked == true;
            bool cChecked = chkPrimeraColumna?.IsChecked == true;

            // Reseteamos índices previos
            _filaPintadaIndex = -1;
            _columnaPintadaIndex = -1;

            // 1. Limpiamos el fondo de absolutamente todos los TextBox de la matriz
            for (int i = 0; i < matrizControles.Count; i++)
            {
                for (int j = 0; j < matrizControles[i].Count; j++)
                {
                    var txt = matrizControles[i][j];
                    if (txt != null)
                    {
                        txt.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#E9ECEF");
                    }
                }
            }

            // 2. Pintamos estrictamente toda la fila horizontal si está activo "Títulos fila"
            if (fChecked && indiceSeleccionado >= 0 && indiceSeleccionado < matrizControles.Count)
            {
                _filaPintadaIndex = indiceSeleccionado;
                var filaSeleccionada = matrizControles[indiceSeleccionado];
                for (int j = 0; j < filaSeleccionada.Count; j++)
                {
                    var txt = filaSeleccionada[j];
                    if (txt != null)
                    {
                        txt.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#D1E7DD");
                    }
                }
            }
            // 3. Pintamos estrictamente toda la columna vertical si está activo "Títulos columna"
            else if (cChecked && indiceSeleccionado >= 0)
            {
                _columnaPintadaIndex = indiceSeleccionado;
                for (int i = 0; i < matrizControles.Count; i++)
                {
                    if (indiceSeleccionado < matrizControles[i].Count)
                    {
                        var txt = matrizControles[i][indiceSeleccionado];
                        if (txt != null)
                        {
                            txt.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#D1E7DD");
                        }
                    }
                }
            }
            StrColorSeleccionado = cmbColor.SelectedItem.ToString();
            Control_Changed(sender, e);
            // Omitimos llamar a Control_Changed aquí dentro para evitar bucles de eventos indeseados al pintar
        }
        private StackPanel CrearBloqueControl(string etiqueta, FrameworkElement control)
        {
            StackPanel bloque = new StackPanel
            {
                Margin = new Thickness(5, 2, 0, 0)
            };

            TextBlock lbl = new TextBlock
            {
                Text = etiqueta,
                Visibility = string.IsNullOrEmpty(etiqueta) ? Visibility.Collapsed : Visibility.Visible,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Left,
                FontFamily = new FontFamily("Arial"),
                FontSize = 12,
                Margin = new Thickness(0, 0, 0, 2)
            };

            bloque.Children.Add(lbl);
            bloque.Children.Add(control);

            return bloque;
        }

        private void BtnAgregarFila_Click(object sender, RoutedEventArgs e)
        {
            if (cantidadFilas < 9)
            {
                var valoresPrevios = DatosMatriz;
                cantidadFilas++;
                ActualizarInterfazMatriz();

                for (int i = 0; i < valoresPrevios.Count && i < matrizControles.Count; i++)
                {
                    for (int j = 0; j < valoresPrevios[i].Count && j < matrizControles[i].Count; j++)
                    {
                        matrizControles[i][j].Text = valoresPrevios[i][j].Replace("{{ITEM}}", "");
                    }
                }

                Control_Changed(sender, e);
            }
        }

        private void BtnQuitarFila_Click(object sender, RoutedEventArgs e)
        {
            if (cantidadFilas > 1)
            {
                var valoresPrevios = DatosMatriz;
                cantidadFilas--;
                ActualizarInterfazMatriz();

                for (int i = 0; i < valoresPrevios.Count && i < matrizControles.Count; i++)
                {
                    for (int j = 0; j < valoresPrevios[i].Count && j < matrizControles[i].Count; j++)
                    {
                        matrizControles[i][j].Text = valoresPrevios[i][j].Replace("{{ITEM}}", "");
                    }
                }

                Control_Changed(sender, e);
            }
        }

        private void BtnAgregarColumna_Click(object sender, RoutedEventArgs e)
        {
            if (cantidadColumnas < 9)
            {
                var valoresPrevios = DatosMatriz;
                cantidadColumnas++;
                ActualizarInterfazMatriz();

                for (int i = 0; i < valoresPrevios.Count && i < matrizControles.Count; i++)
                {
                    for (int j = 0; j < valoresPrevios[i].Count && j < matrizControles[i].Count; j++)
                    {
                        matrizControles[i][j].Text = valoresPrevios[i][j].Replace("{{ITEM}}", "");
                    }
                }

                Control_Changed(sender, e);
            }
        }

        private void BtnQuitarColumna_Click(object sender, RoutedEventArgs e)
        {
            if (cantidadColumnas > 1)
            {
                var valoresPrevios = DatosMatriz;
                cantidadColumnas--;
                ActualizarInterfazMatriz();

                for (int i = 0; i < valoresPrevios.Count && i < matrizControles.Count; i++)
                {
                    for (int j = 0; j < valoresPrevios[i].Count && j < matrizControles[i].Count; j++)
                    {
                        matrizControles[i][j].Text = valoresPrevios[i][j].Replace("{{ITEM}}", "");
                    }
                }

                Control_Changed(sender, e);
            }
        }

        private void BtnSubir_Click(object sender, RoutedEventArgs e) => MoverArriba?.Invoke(this, EventArgs.Empty);
        private void BtnBajar_Click(object sender, RoutedEventArgs e) => MoverAbajo?.Invoke(this, EventArgs.Empty);
        private void BtnQuitar_Click(object sender, RoutedEventArgs e) => ControlQuitado?.Invoke(this, EventArgs.Empty);
    }
}