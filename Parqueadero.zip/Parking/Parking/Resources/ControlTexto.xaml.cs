﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Parking.Resources
{
    /// <summary>
    /// Lógica de interacción para ControlTexto.xaml
    /// </summary>
    public partial class ControlTexto : UserControl
    {
        public ControlTexto(string titulo)
        {
            InitializeComponent();
            gbGrupoTexto.Header = titulo;
        }
        // Definimos el evento que MainWindow podrá escuchar
        public event EventHandler AjusteCambiado;

        // Dentro de tus UserControls
        public event EventHandler MoverArriba;
        public event EventHandler MoverAbajo;

        private void BtnSubir_Click(object sender, RoutedEventArgs e)
        {
            // 'this' envía la identidad única de este GroupBox específico
            MoverArriba?.Invoke(this, EventArgs.Empty);
        }

        private void BtnBajar_Click(object sender, RoutedEventArgs e)
        {
            MoverAbajo?.Invoke(this, EventArgs.Empty);
        }
        // Definimos el nuevo evento
        public event EventHandler ControlQuitado;
        // Cambia 'int' por 'double' para permitir precisión decimal
        public double InterlineadoTexto => nbInterlineado != null ? nbInterlineado.Value : 1.0;
        // Propiedad para el contenido de la línea (TextBox nuevo)
        public double EspacioVertical => nbEspacioVertical != null ? nbEspacioVertical.Value : 1.0;
        // Propiedad para el contenido de la línea (TextBox nuevo)
        public double EspacioHorizontal => nbEspacioHorizontal != null ? nbEspacioHorizontal.Value : 1.0;
        // Propiedad para el contenido de la línea (TextBox nuevo)
        public string Texto => txtTexto?.Text ?? "";
        public double TamanioFuente => nbTamanioFuente.Value;
        public double Interlineado => nbInterlineado?.Value ?? 1;
        public int ChkInfo => (ChkIncluirInformacionEmpresa?.IsChecked == true) ? 1 : 0;
        public int ChkPlaca => (ChkPlacaVehiculo?.IsChecked == true) ? 1 : 0;
        public int ChkTicket => (ChkNumeroTicket?.IsChecked == true) ? 1 : 0;
        // Propiedad para la fuente con validación
        public FontFamily FuenteSeleccionada => (cmbTipoFuente?.SelectedItem as FontFamily) ?? new FontFamily("Segoe UI");
        // Propiedad para el peso con validación de nulos
        public FontWeight PesoFuente => (cmbPesoFuente?.SelectedItem != null) ? (FontWeight)cmbPesoFuente.SelectedItem : FontWeights.Normal;

        // Propiedad para la alineación con validación
        public TextAlignment Alineacion => (cmbAlinearTexto?.SelectedItem is ComboBoxItem item && item.Tag != null) ? (TextAlignment)item.Tag : TextAlignment.Left;
        // Este método se ejecuta cada vez que CUALQUIER control interno cambie
        private void Control_Changed(object sender, RoutedEventArgs e)
        {
            // Esto notificará al MainWindow sin errores de firma
            AjusteCambiado?.Invoke(this, EventArgs.Empty);
        }

        private void BtnQuitar_Click(object sender, RoutedEventArgs e)
        {
            // 1. Avisamos al MainWindow ANTES de borrar
            ControlQuitado?.Invoke(this, EventArgs.Empty);

            // 2. Ejecutamos la eliminación del panel
            var parent = VisualTreeHelper.GetParent(this) as Panel;
            parent?.Children.Remove(this);
        }
        private async void ChkIncluirInformacionEmpresa_Click(object sender, RoutedEventArgs e)
        {
            if (ChkIncluirInformacionEmpresa.IsChecked == true)
            {
                ChkPlacaVehiculo.IsChecked = false;
                ChkNumeroTicket.IsChecked = false;
                txtTexto.Text = "";
                txtTexto.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#E9ECEF");
                txtTexto.IsEnabled = false;
            }
            else
            {
                txtTexto.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#FFFFFF");
                txtTexto.IsEnabled = true;
                txtTexto.Focus();
            }
            Control_Changed(sender, e);
        }
        private async void ChkPlacaVehiculo_Click(object sender, RoutedEventArgs e)
        {
            if (ChkPlacaVehiculo.IsChecked == true)
            {
                ChkIncluirInformacionEmpresa.IsChecked = false;
                ChkNumeroTicket.IsChecked = false;
                txtTexto.Text = "";
                txtTexto.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#E9ECEF");
                txtTexto.IsEnabled = false;
            }
            else
            {
                txtTexto.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#FFFFFF");
                txtTexto.IsEnabled = true;
                txtTexto.Focus();
            }
            Control_Changed(sender, e);
        }
        private async void ChkNumeroTicket_Click(object sender, RoutedEventArgs e)
        {
            if (ChkNumeroTicket.IsChecked == true)
            {
                ChkIncluirInformacionEmpresa.IsChecked = false;
                ChkPlacaVehiculo.IsChecked = false;
                txtTexto.Text = "";
                txtTexto.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#E9ECEF");
                txtTexto.IsEnabled = false;
            }
            else
            {
                txtTexto.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#FFFFFF");
                txtTexto.IsEnabled = true;
                txtTexto.Focus();
            }
            Control_Changed(sender, e);
        }
    }
}