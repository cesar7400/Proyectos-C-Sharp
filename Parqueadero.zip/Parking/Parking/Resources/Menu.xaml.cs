﻿using Parking.Controller;
using Parking.Models;
using Parking.Views;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media.Animation;

namespace Parking.Resources
{
    /// <summary>
    /// Lógica de interacción para Menu.xaml
    /// </summary>
    public partial class Menu : UserControl
    {
        public Menu()
        {
            InitializeComponent();
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            Permisos();
        }
        private bool menuExpandido = true;

        private void BtnHamburger_Click(object sender, RoutedEventArgs e)
        {
            if (menuExpandido)
            {
                ((Storyboard)this.Resources["CerrarMenu"]).Begin();
            }
            else
            {
                ((Storyboard)this.Resources["AbrirMenu"]).Begin();
            }
            menuExpandido = !menuExpandido;
        }
        private void Expander_Expanded(object sender, RoutedEventArgs e)
        {
            // Identificamos cuál Expander disparó el evento
            if (sender is Expander currentExpander)
            {
                if (currentExpander != null)
                {
                    // Obtenemos el StackPanel que contiene todos los Expanders
                    if (currentExpander.Parent is StackPanel parentPanel)
                    {
                        if (parentPanel != null)
                        {
                            // Recorremos todos los elementos dentro del StackPanel
                            foreach (UIElement child in parentPanel.Children)
                            {
                                // Si el elemento es un Expander y NO es el que acabamos de abrir
                                if (child is Expander otherExpander && otherExpander != currentExpander)
                                {
                                    // Lo contraemos
                                    otherExpander.IsExpanded = false;
                                }
                            }
                        }
                    }
                }
            }
        }
        private void Menu_Click(object sender, MouseButtonEventArgs e)
        {
            if (sender is RadioButton boton)
            {
                if (boton == null) return;

                // 1. Buscamos el Frame "ContenedorPrincipal" que está en la ventana principal
                var window = Window.GetWindow(this);
                if (window?.FindName("ContenedorPrincipal") is Frame frame)
                {
                    if (frame != null)
                    {
                        // 2. Navegamos según el contenido del botón
                        switch (boton.Content.ToString())
                        {
                            case "Usuarios":
                                // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                if (!(frame.Content is Usuarios))
                                {
                                    // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                    frame.Navigate(new Usuarios());
                                }
                                break;
                            case "Clientes":
                                // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                if (!(frame.Content is Clientes))
                                {
                                    // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                    frame.Navigate(new Clientes());
                                }
                                break;
                            case "Niveles":
                                // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                if (!(frame.Content is Niveles))
                                {
                                    // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                    frame.Navigate(new Niveles());
                                }
                                break;
                            case "Celdas":
                                // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                if (!(frame.Content is InformacionCeldas))
                                {
                                    // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                    frame.Navigate(new InformacionCeldas());
                                }
                                break;
                            case "Planes":
                                // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                if (!(frame.Content is Planes))
                                {
                                    // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                    frame.Navigate(new Planes());
                                }
                                break;
                            case "Auditoría":
                                // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                if (!(frame.Content is Auditoria))
                                {
                                    // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                    frame.Navigate(new Auditoria());
                                }
                                break;
                            case "Configuración":
                                // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                if (!(frame.Content is Configuracion))
                                {
                                    // Siempre creamos una instancia nueva para que "vuelva a abrir"
                                    frame.Navigate(new Configuracion());
                                }
                                break;
                        }

                        // 3. Forzamos que el botón se vea como seleccionado
                        boton.IsChecked = true;
                    }
                }
            }
        }

        private void Expander_MouseEnter(object sender, MouseEventArgs e)
        {
            if (sender is Expander boton)
            {
                if (menuExpandido) return;

                // Obtenemos la posición del Expander relativa al MenuLateral para calcular la altura exacta
                Point posicion = boton.TransformToAncestor(MenuLateral).Transform(new Point(0, 0));

                // Configuramos el Popup tomando el MenuLateral como referencia fija
                Popup.PlacementTarget = MenuLateral;
                Popup.Placement = PlacementMode.Right;

                // Ajustamos el desplazamiento vertical exacto donde se encuentra el mouse/expander
                Popup.VerticalOffset = posicion.Y;
                Popup.HorizontalOffset = 2; // Pequeño margen de separación

                switch (boton.Name)
                {
                    case "ExpanderUsuarios":
                        Popup.IsOpen = true;
                        Header.PopupText.Text = "Usuarios";
                        break;
                    case "ExpanderClientes":
                        Popup.IsOpen = true;
                        Header.PopupText.Text = "Clientes";
                        break;
                    case "ExpanderNiveles":
                        Popup.IsOpen = true;
                        Header.PopupText.Text = "Niveles";
                        break;
                    case "ExpanderCeldas":
                        Popup.IsOpen = true;
                        Header.PopupText.Text = "Celdas";
                        break;
                    case "ExpanderPlanesVehiculos":
                        Popup.IsOpen = true;
                        Header.PopupText.Text = "Planes";
                        break;
                    case "ExpanderAuditoria":
                        Popup.IsOpen = true;
                        Header.PopupText.Text = "Auditoría";
                        break;
                    case "ExpanderConfiguracion":
                        Popup.IsOpen = true;
                        Header.PopupText.Text = "Configuración";
                        break;
                }
            }
        }

        private void Expander_MouseLeave(object sender, MouseEventArgs e)
        {
            if (menuExpandido) return;

            Popup.IsOpen = false;
        }

        private void Permisos()
        {
            Permisos permisos = new Permisos();
            // Consultar si el módulo "Usuarios" tiene permitido
            bool AgregarUsuario = permisos.TienePermiso("Usuarios", "Agregar Usuario");
            bool EditarUsuario = permisos.TienePermiso("Usuarios", "Editar Usuario");
            bool EliminarUsuario = permisos.TienePermiso("Usuarios", "Eliminar Usuario");

            if(!AgregarUsuario && !EditarUsuario && !EliminarUsuario)
            {
                ExpanderUsuarios.Visibility = Visibility.Collapsed;
            }

            // Consultar si el módulo "Niveles" tiene permitido
            bool VerCeldas = permisos.TienePermiso("Niveles", "Ver Celdas");
            bool AgregarNivel = permisos.TienePermiso("Niveles", "Agregar Nivel");
            bool EditarNivel = permisos.TienePermiso("Niveles", "Editar Nivel");
            bool EliminarNivel = permisos.TienePermiso("Niveles", "Eliminar Nivel");
            bool EstadoNivel = permisos.TienePermiso("Niveles", "Activar - Desactivar Nivel");

            if (!VerCeldas && !AgregarNivel && !EditarNivel && !EliminarNivel && !EstadoNivel)
            {
                ExpanderNiveles.Visibility = Visibility.Collapsed;
            }

            // Consultar si el módulo "auditoría" tiene permitido
            bool puedeVerAuditoria = permisos.TienePermiso("Auditoría", "Ver Auditoría");
            ExpanderAuditoria.Visibility = puedeVerAuditoria == true ? Visibility.Visible : Visibility.Collapsed;

            // Consultar si el módulo "Configuración" tiene permitido
            bool puedeActualizarInformacion = permisos.TienePermiso("Configuración", "Actualizar Información");
            bool puedeCrearTicket = permisos.TienePermiso("Configuración", "Nuevo Ticket");
            bool puedeEditarTicket = permisos.TienePermiso("Configuración", "Editar Ticket");
            bool puedeVistaPreviaTicket = permisos.TienePermiso("Configuración", "Vista Previa");
            bool puedeEliminarTicket = permisos.TienePermiso("Configuración", "Eliminar Ticket");
            bool puedeImpresora = permisos.TienePermiso("Configuración", "Seleccionar Impresora");

            if (!puedeActualizarInformacion && !puedeCrearTicket && !puedeEditarTicket && !puedeVistaPreviaTicket && !puedeEliminarTicket && !puedeImpresora)
            {
                ExpanderConfiguracion.Visibility = Visibility.Collapsed;
            }
        }
    }
}