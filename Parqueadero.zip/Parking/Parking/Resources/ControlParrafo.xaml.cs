﻿using Parking.Views;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Parking.Resources
{
    /// <summary>
    /// Lógica de interacción para ControlParrafo.xaml
    /// </summary>
    public partial class ControlParrafo : UserControl
    {
        public ControlParrafo(string titulo)
        {
            InitializeComponent();
            gbParrafo.Header = titulo;
        }
        public string strParrafo = "";
        // Definimos el evento que MainWindow podrá escuchar
        public event EventHandler AjusteCambiado;

        // Dentro de tus UserControls
        public event EventHandler MoverArriba;
        public event EventHandler MoverAbajo;

        private void BtnSubir_Click(object sender, RoutedEventArgs e)
        {
            // 'this' envía la identidad única de este GroupBox específico
            MoverArriba?.Invoke(this, EventArgs.Empty);
        }

        private void BtnBajar_Click(object sender, RoutedEventArgs e)
        {
            MoverAbajo?.Invoke(this, EventArgs.Empty);
        }
        // Definimos el nuevo evento
        public event EventHandler ControlQuitado;
        // Cambia 'int' por 'double' para permitir precisión decimal
        public double InterlineadoTexto => nbInterlineado != null ? nbInterlineado.Value : 1.0;
        public double EspacioVertical => nbEspacioVertical != null ? nbEspacioVertical.Value : 1.0;
        // Propiedad para el contenido de la línea (TextBox nuevo)
        private string _parrafo;
        public string Parrafo
        {
            get => _parrafo ?? "";
            set
            {
                _parrafo = value;
                // Si tienes un Label o TextBlock interno en el UserControl para mostrar el texto:
                // lblVistaPrevia.Text = value; 
            }
        }

        public double TamanioFuente => nbTamanioFuente.Value;

        // Propiedad para la fuente con validación
        public FontFamily FuenteSeleccionada => (cmbTipoFuente?.SelectedItem as FontFamily) ?? new FontFamily("Segoe UI");
        // Propiedad para el peso con validación de nulos
        public FontWeight PesoFuente => (cmbPesoFuente?.SelectedItem != null) ? (FontWeight)cmbPesoFuente.SelectedItem : FontWeights.Normal;

        // Propiedad para la alineación con validación
        public TextAlignment Alineacion => (cmbAlinearTexto?.SelectedItem is ComboBoxItem item && item.Tag != null) ? (TextAlignment)item.Tag : TextAlignment.Left;
        // Este método se ejecuta cada vez que CUALQUIER control interno cambie
        private void Control_Changed(object sender, RoutedEventArgs e)
        {
            // Esto notificará al MainWindow sin errores de firma
            AjusteCambiado?.Invoke(this, EventArgs.Empty);
        }

        private void BtnQuitar_Click(object sender, RoutedEventArgs e)
        {
            // 1. Avisamos al MainWindow ANTES de borrar
            ControlQuitado?.Invoke(this, EventArgs.Empty);

            // 2. Ejecutamos la eliminación del panel
            var parent = VisualTreeHelper.GetParent(this) as Panel;
            parent?.Children.Remove(this);
        }

        private void BtnParrafo_Click(object sender, RoutedEventArgs e)
        {
            Parrafo parrafo = new Parrafo(this);
            parrafo.ShowDialog();
        }
    }
}