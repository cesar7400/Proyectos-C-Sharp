﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Parking.Resources
{
    /// <summary>
    /// Lógica de interacción para NumericUpDownControl.xaml
    /// </summary>
    public partial class NumericUpDownControl : UserControl
    {
        private readonly Regex _numMatch;

        public NumericUpDownControl()
        {
            InitializeComponent();
            // Permite decimales para el interlineado
            _numMatch = new Regex(@"^-?\d*(\.\d*)?$");

            // Valores iniciales por defecto
            Maximum = 100.0;
            Minimum = 0.0;
            Step = 1.0;
            Value = 0.0;
        }

        #region Dependency Properties

        // PROPIEDAD VALUE (Ahora como double para soportar 1.1, 1.2...)
        public double Value
        {
            get { return (double)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(double), typeof(NumericUpDownControl),
                new PropertyMetadata(0.0, OnSomeValuePropertyChanged));

        // PROPIEDAD STEP (Para saltos de 1 o de 0.1)
        public double Step
        {
            get { return (double)GetValue(StepProperty); }
            set { SetValue(StepProperty, value); }
        }

        public static readonly DependencyProperty StepProperty =
            DependencyProperty.Register("Step", typeof(double), typeof(NumericUpDownControl),
                new PropertyMetadata(1.0));

        // PROPIEDAD MAXIMUM
        public double Maximum
        {
            get { return (double)GetValue(MaximumProperty); }
            set { SetValue(MaximumProperty, value); }
        }

        public static readonly DependencyProperty MaximumProperty =
            DependencyProperty.Register("Maximum", typeof(double), typeof(NumericUpDownControl),
                new PropertyMetadata(100.0));

        // PROPIEDAD MINIMUM
        public double Minimum
        {
            get { return (double)GetValue(MinimumProperty); }
            set { SetValue(MinimumProperty, value); }
        }

        public static readonly DependencyProperty MinimumProperty =
            DependencyProperty.Register("Minimum", typeof(double), typeof(NumericUpDownControl),
                new PropertyMetadata(0.0));

        #endregion

        #region Events (Corrigiendo errores XLS0413)

        // Evento ValueChanged
        public static readonly RoutedEvent ValueChangedEvent = EventManager.RegisterRoutedEvent(
            "ValueChanged", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(NumericUpDownControl));

        public event RoutedEventHandler ValueChanged
        {
            add { AddHandler(ValueChangedEvent, value); }
            remove { RemoveHandler(ValueChangedEvent, value); }
        }

        // Eventos de clic que pide tu compilador
        public static readonly RoutedEvent IncreaseClickedEvent = EventManager.RegisterRoutedEvent("IncreaseClicked", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(NumericUpDownControl));
        public event RoutedEventHandler IncreaseClicked { add { AddHandler(IncreaseClickedEvent, value); } remove { RemoveHandler(IncreaseClickedEvent, value); } }

        public static readonly RoutedEvent DecreaseClickedEvent = EventManager.RegisterRoutedEvent("DecreaseClicked", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(NumericUpDownControl));
        public event RoutedEventHandler DecreaseClicked { add { AddHandler(DecreaseClickedEvent, value); } remove { RemoveHandler(DecreaseClickedEvent, value); } }

        #endregion

        private static void OnSomeValuePropertyChanged(DependencyObject target, DependencyPropertyChangedEventArgs e)
        {
            var control = target as NumericUpDownControl;
            if (control?.TextBoxValue != null)
            {
                control.TextBoxValue.Text = ((double)e.NewValue).ToString("G", CultureInfo.InvariantCulture);
            }
        }

        private void Increase_Click(object sender, RoutedEventArgs e)
        {
            if (Value < Maximum)
            {
                Value = Math.Round(Value + Step, 1);
                RaiseEvent(new RoutedEventArgs(IncreaseClickedEvent));
            }
        }

        private void Decrease_Click(object sender, RoutedEventArgs e)
        {
            if (Value > Minimum)
            {
                Value = Math.Round(Value - Step, 1);
                RaiseEvent(new RoutedEventArgs(DecreaseClickedEvent));
            }
        }

        private void Value_TextChanged(object sender, TextChangedEventArgs e)
        {
            var tb = (TextBox)sender;
            if (string.IsNullOrEmpty(tb.Text) || tb.Text == "." || tb.Text == "-") return;

            // IMPORTANTE: Usar CultureInfo.InvariantCulture para que el punto decimal
            // no se ignore y se convierta en un número entero.
            if (double.TryParse(tb.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out double val))
            {
                if (val > Maximum) val = Maximum;
                if (val < Minimum) val = Minimum;

                // Solo actualizamos si el valor es realmente distinto para evitar bucles
                if (Math.Abs(Value - val) > 0.01)
                {
                    Value = val;
                }
            }

            RaiseEvent(new RoutedEventArgs(ValueChangedEvent));
        }
        private void TextBox_CutCopyPaste(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Command == ApplicationCommands.Copy ||
                e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true; // Evita la operación de copiar/cortar/pegar
            }
        }
        private void Value_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            var tb = (TextBox)sender;
            string fullText = tb.Text.Insert(tb.CaretIndex, e.Text);
            e.Handled = !_numMatch.IsMatch(fullText);
        }
        private void Value_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Detecta si se presionó la flecha hacia ARRIBA
            if (e.Key == Key.Up)
            {
                if (Value < Maximum)
                {
                    Value = Math.Round(Value + Step, 1);
                    RaiseEvent(new RoutedEventArgs(IncreaseClickedEvent));
                }
                e.Handled = true; // Evita que el cursor se mueva en el TextBox
            }
            // Detecta si se presionó la flecha hacia ABAJO
            else if (e.Key == Key.Down)
            {
                if (Value > Minimum)
                {
                    Value = Math.Round(Value - Step, 1);
                    RaiseEvent(new RoutedEventArgs(DecreaseClickedEvent));
                }
                e.Handled = true; // Evita que el cursor se mueva en el TextBox
            }
        }
    }
}