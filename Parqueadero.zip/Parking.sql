-- ============================================================
-- BASE DE DATOS
-- ============================================================

USE master;
GO

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'Parking')
BEGIN
    CREATE DATABASE Parking
        COLLATE SQL_Latin1_General_CP1_CI_AS;
    PRINT '>> Base de datos Parking creada.';
END
GO

USE Parking;
GO
SET NOCOUNT ON;
GO

CREATE TABLE Usuarios(
    UsuarioID         INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    Usuario           NVARCHAR(15) NOT NULL UNIQUE,
    NombreCompleto    NVARCHAR(80) NULL,
    PasswordHash      VARBINARY(32) NOT NULL,
    PasswordSalt      VARBINARY(16) NOT NULL,
    DiasPermitidos    TINYINT NOT NULL DEFAULT 0,
    cambioPassword    BIT NOT NULL DEFAULT 0,
    Estado            BIT NOT NULL DEFAULT 1,
    UltimoAcceso      DATETIME NULL,
    Permisos          VARCHAR(max) NULL CHECK(ISJSON(permisos) = 1 AND JSON_VALUE(permisos, '$') IS NULL)
);

--  Creamos una secuencia específica para esta tabla.
-- 'NO CACHE' garantiza que no se salten números tras un reinicio.
CREATE SEQUENCE SecuenciaLog
    AS INT
    START WITH 1
    INCREMENT BY 1
    NO CACHE; -- <--- Esto es lo que evita los saltos solo para esta secuencia
GO

CREATE TABLE AuditoriaLog(
    -- Usamos NEXT VALUE FOR para obtener el ID de la secuencia
    IdLog       INT NOT NULL PRIMARY KEY DEFAULT (NEXT VALUE FOR SecuenciaLog),
    UsuarioID   INT,
    Accion      NVARCHAR(100) NOT NULL,
    Fecha       DATETIME DEFAULT GETDATE(),
    Detalle     NVARCHAR(MAX) NULL,
    -- Llaves foráneas para mantener integridad
    CONSTRAINT FK_AuditoriaLog_Usuarios FOREIGN KEY (UsuarioID) REFERENCES Usuarios(UsuarioID) ON DELETE CASCADE,
);

--reinicia secuencia
ALTER SEQUENCE SecuenciaLog
RESTART WITH 1;

CREATE TABLE Configuracion (
    ConfiguracionID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    Valor NVARCHAR(55) NOT NULL,
    DatosJson NVARCHAR(MAX) CHECK (ISJSON(DatosJson) = 1) NOT NULL,
    FechaRegistro DATETIME DEFAULT GETDATE() NOT NULL,
    
    -- Columna calculada: Extrae el texto entre ':' y '-' o devuelve NULL si no tiene ese formato
    IdentificadorTicket AS (
        CASE 
            WHEN CHARINDEX(':', Valor) > 0 AND CHARINDEX('-', Valor) > CHARINDEX(':', Valor)
            THEN SUBSTRING(Valor, CHARINDEX(':', Valor) + 1, CHARINDEX('-', Valor) - CHARINDEX(':', Valor) - 1)
            ELSE NULL 
        END
    ) PERSISTED,
    
    -- Restricción UNIQUE: Permite múltiples NULL (para registros generales), pero prohíbe duplicados en los tickets
    CONSTRAINT UQ_Configuracion_Identificador UNIQUE (IdentificadorTicket)
);

CREATE TABLE EstadoNivel
(
    IdEstadoNivel TINYINT NOT NULL PRIMARY KEY,
    Nombre NVARCHAR(30) NOT NULL UNIQUE,
    CONSTRAINT CK_IdEstadoNivel CHECK (Nombre IN (1,2)),
    CONSTRAINT CK_Estado_nivel CHECK (Nombre IN ('Disponible','Fuera de servicio'))
);

INSERT INTO EstadoNivel (IdEstadoNivel, Nombre)
VALUES
    (1, N'Disponible'),
    (2, N'Fuera de servicio');
GO

CREATE TABLE Nivel(
    IdNivel       INT IDENTITY(1,1) NOT NULL,
    Nombre        NVARCHAR(50) NOT NULL,
    Descripcion   NVARCHAR(200) NULL,
    IdEstadoNivel TINYINT NOT NULL
    CONSTRAINT DF_Nivel_Estado DEFAULT 1, FechaCreacion DATETIME2(0) NOT NULL
    CONSTRAINT DF_Nivel_FechaCreacion DEFAULT SYSDATETIME(),
    CONSTRAINT PK_Nivel PRIMARY KEY (IdNivel),
    CONSTRAINT UQ_Nivel_Nombre UNIQUE (Nombre),
    CONSTRAINT FK_Nivel_EstadoNivel FOREIGN KEY (IdEstadoNivel)
    REFERENCES EstadoNivel(IdEstadoNivel)
);
GO
--Estados de celda
CREATE TABLE EstadoCelda
(
    IdEstadoCelda TINYINT NOT NULL PRIMARY KEY,
    Nombre        NVARCHAR(30) NOT NULL UNIQUE,
    CONSTRAINT CK_IdEstadoCelda CHECK (Nombre IN (1,2,3)),
    CONSTRAINT CK_Estado_Celda CHECK (Nombre IN ('Libre','Ocupada','No disponible'))
);

INSERT INTO EstadoCelda (IdEstadoCelda, Nombre)
VALUES
    (1, N'Libre'),
    (2, N'Ocupada'),
    (3, N'No disponible');
GO
--Celdas
CREATE TABLE Celda
(
    IdCelda       INT IDENTITY(1,1) NOT NULL,
    IdNivel       INT NOT NULL,
    Codigo        NVARCHAR(20) NOT NULL,
    IdEstadoCelda TINYINT NOT NULL
    CONSTRAINT DF_Celda_Estado DEFAULT 1,
    Observacion   NVARCHAR(250) NULL,
    FechaCreacion DATETIME2(0) NOT NULL
    CONSTRAINT    DF_Celda_FechaCreacion DEFAULT SYSDATETIME(),
    CONSTRAINT PK_Celda PRIMARY KEY (IdCelda),
    CONSTRAINT FK_Celda_Nivel FOREIGN KEY (IdNivel) REFERENCES Nivel(IdNivel),
    CONSTRAINT FK_Celda_EstadoCelda FOREIGN KEY (IdEstadoCelda) REFERENCES EstadoCelda(IdEstadoCelda),
    -- El código no puede repetirse dentro del mismo nivel.
    CONSTRAINT UQ_Celda_Nivel_Codigo UNIQUE (IdNivel, Codigo)
);
GO
------------------------------------------------------------------------------------------------------------------
CREATE TABLE Tipo_Documento(
	Documentoid INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	Tipo        VARCHAR(50) NOT NULL,
	Descripcion VARCHAR(50) NOT NULL
);
GO
insert into Tipo_Documento(tipo, Descripcion) values
('Cédula de Ciudadanía','Para colombianos mayores de 18 años.'),
('Cédula de Extranjería','Para extranjeros residentes legalmente en el país.'),
('Registro Civil','Para menores de 7 años.'),
('Tarjeta de Identidad','Para menores entre 7 y 17 años.'),
('Pasaporte','Para viajar al exterior.'),
('Documento Nacional de Identificación (DNI) digital','Nueva versión electrónica de la cédula.');

CREATE TABLE Cliente
(
    Idcliente INT IDENTITY(1,1) NOT NULL,
    Documentoid INT NOT NULL,
    Nombre VARCHAR(150) NOT NULL,
    Documento VARCHAR(20) NOT NULL,
    Celular VARCHAR(20) NULL,
    email VARCHAR(150) NULL,
    Activo BIT NOT NULL CONSTRAINT DF_Cliente_Activo DEFAULT (1),
    fecha_registro DATETIME NOT NULL CONSTRAINT DF_Cliente_Fecha DEFAULT (GETDATE()),

    CONSTRAINT PK_Cliente PRIMARY KEY CLUSTERED (Idcliente),
    CONSTRAINT FK_Cliente_Tipo_Documento FOREIGN KEY (Documentoid) REFERENCES Tipo_Documento(Documentoid),
    CONSTRAINT UQ_Cliente_Tipo_Documento  UNIQUE (Documentoid, Documento)
);
GO

-- Únicamente los correos que no sean NULL deben ser únicos.
CREATE UNIQUE NONCLUSTERED INDEX UX_Cliente_Email
ON Cliente (email)
WHERE email IS NOT NULL;
GO



GO
CREATE TABLE Vehiculo (
        Idvehiculo          INT         IDENTITY(1,1) NOT NULL,
        idtipovehiculo      INT                       NULL,
        IdCategoriaVehiculo INT                       NULL,
        Idcliente           INT                       NULL,
        Placa               VARCHAR(10)               NOT NULL,
        EsVIP               BIT                       NOT NULL
        CONSTRAINT DF_Vehiculo_EsVIP               DEFAULT 0,
        Activo              BIT                       NOT NULL
        CONSTRAINT DF_Vehiculo_Activo DEFAULT 1, fecha_registro DATETIME NOT NULL
        CONSTRAINT DF_Vehiculo_Fecha  DEFAULT GETDATE(),
        -- Restricción para el formato de la placa: AAA 123
        CONSTRAINT CK_Vehiculo_Placa_Formato 
        CHECK (placa LIKE '[A-Z][A-Z][A-Z] [A-Z0-9][A-Z0-9][A-Z0-9]'),
        CONSTRAINT PK_Vehiculo              PRIMARY KEY CLUSTERED (Idvehiculo),
        CONSTRAINT FK_Vehiculo_TipoVeh      FOREIGN KEY (idtipovehiculo)
                                            REFERENCES TipoVehiculo(idtipovehiculo)
                                            ON DELETE SET NULL,
        CONSTRAINT FK_Vehiculo_CateVeh      FOREIGN KEY (IdCategoriaVehiculo)
                                            REFERENCES CategoriaVehiculo(IdCategoriaVehiculo)
                                            ON DELETE SET NULL,
        CONSTRAINT FK_Vehiculo_Cliente      FOREIGN KEY (Idcliente)
                                            REFERENCES Cliente(Idcliente),
        CONSTRAINT UQ_Vehiculo_Placa        UNIQUE (placa)
);
----------------------------------------------------------------------------------------------------------------------
GO
CREATE TABLE OcupacionCelda
(
    IdOcupacion BIGINT IDENTITY(1,1) NOT NULL,
    IdCelda    INT NOT NULL,
    IdVehiculo INT NOT NULL,
    FechaEntrada DATETIME2(0) NOT NULL
        CONSTRAINT DF_Ocupacion_FechaEntrada DEFAULT SYSDATETIME(),
    FechaSalida DATETIME2(0) NULL,
    Estado      BIT NOT NULL
        CONSTRAINT DF_Ocupacion_Estado DEFAULT 1,
    Observacion NVARCHAR(250) NULL,

    CONSTRAINT PK_OcupacionCelda
        PRIMARY KEY (IdOcupacion),

    CONSTRAINT FK_OcupacionCelda_Celda
        FOREIGN KEY (IdCelda)
        REFERENCES Celda(IdCelda),

    CONSTRAINT FK_OcupacionCelda_Vehiculo
        FOREIGN KEY (IdVehiculo)
        REFERENCES Vehiculo(IdVehiculo),

    CONSTRAINT CK_OcupacionCelda_Fechas
        CHECK
        (
            FechaSalida IS NULL
            OR FechaSalida >= FechaEntrada
        ),

    CONSTRAINT CK_OcupacionCelda_Estado
        CHECK
        (
            (Estado = 1 AND FechaSalida IS NULL)
            OR
            (Estado = 0 AND FechaSalida IS NOT NULL)
        )
);
GO
--Este índice garantiza que una celda no tenga dos vehículos activos al mismo tiempo:
CREATE UNIQUE INDEX UX_OcupacionCelda_CeldaActiva
ON OcupacionCelda(IdCelda)
WHERE Estado = 1;
GO
--Este índice garantiza que un vehículo no ocupe dos celdas al mismo tiempo:
CREATE UNIQUE INDEX UX_OcupacionCelda_VehiculoActivo
ON OcupacionCelda(IdVehiculo)
WHERE Estado = 1;
GO

/*-PLANES---------------------------------------------------------------------------------------------------------------*/

CREATE TABLE TipoPlan(
    IdTipoPlan  INT IDENTITY(1,1) NOT NULL,
    Nombre      NVARCHAR(50)      NOT NULL,
    Descripcion NVARCHAR(200)     NULL,
    Estado      BIT               NOT NULL
    CONSTRAINT  DF_TipoPlan_Estado DEFAULT 1,

    CONSTRAINT  PK_TipoPlan
    PRIMARY KEY (IdTipoPlan),

    CONSTRAINT UQ_TipoPlan_Nombre
    UNIQUE     (Nombre),

    CONSTRAINT CK_Id_plan CHECK (IdTipoPlan IN (1,2,3)),
    CONSTRAINT CK_Nombre_plan CHECK (Nombre IN ('Membresía','Mensualidad','Tiempo por demanda'))
);
/*
SET IDENTITY_INSERT TipoPlan ON;
GO

INSERT INTO TipoPlan(IdTipoPlan, Nombre, Descripcion)
VALUES        (1,N'Membresía', N'Plan contratado por días o meses.'),        
              (2,N'Mensualidad', N'Plan de permanencia por 30 días o mes calendario.'),        
              (3,N'Tiempo por demanda', N'Cobro según el tiempo de permanencia del vehículo.');
GO

SET IDENTITY_INSERT TipoPlan OFF;
GO
*/
CREATE TABLE [Plan](
    IdPlan              INT IDENTITY(1,1) NOT NULL,
    IdTipoPlan          INT               NOT NULL,
    IdTipoVehiculo      INT               NOT NULL,
    IdCategoriaVehiculo INT               NOT NULL,
    Nombre              NVARCHAR(100)     NOT NULL,
    Descripcion         NVARCHAR(300)     NULL,
    FechaInicioVigencia DATE              NULL,
    FechaFinVigencia    DATE              NULL,
    Estado              BIT               NOT NULL
    
    CONSTRAINT DF_Plan_Estado DEFAULT 1,
    FechaCreacion DATETIME2(0) NOT NULL CONSTRAINT DF_Plan_FechaCreacion DEFAULT SYSDATETIME(),
    CONSTRAINT PK_Plan PRIMARY KEY (IdPlan),
    CONSTRAINT FK_Plan_TipoPlan FOREIGN KEY (IdTipoPlan)
    REFERENCES TipoPlan(IdTipoPlan),
        CONSTRAINT FK_PlanTarifa_TipoVehiculo
        FOREIGN KEY (IdTipoVehiculo)
        REFERENCES TipoVehiculo(IdTipoVehiculo),

    CONSTRAINT FK_PlanTarifa_CategoriaVehiculo
        FOREIGN KEY (IdCategoriaVehiculo)
        REFERENCES CategoriaVehiculo(IdCategoriaVehiculo),
    CONSTRAINT UQ_Plan_Nombre UNIQUE (Nombre),
    CONSTRAINT CK_Plan_Vigencia
    CHECK(
        FechaFinVigencia IS NULL
        OR FechaInicioVigencia IS NULL
        OR FechaFinVigencia >= FechaInicioVigencia
     )
);

CREATE TABLE PlanVigencia(
    IdPlanVigencia INT IDENTITY(1,1) NOT NULL,
    IdPlanTarifa   INT               NOT NULL,
    Unidad         NVARCHAR(20)      NOT NULL,
    Cantidad       INT               NOT NULL,

    CONSTRAINT PK_PlanVigencia PRIMARY KEY (IdPlanVigencia),
    CONSTRAINT FK_PlanVigencia_Plan FOREIGN KEY (IdPlanTarifa) REFERENCES PlanTarifa(IdPlanTarifa),
    CONSTRAINT CK_PlanVigencia_Unidad CHECK (Unidad IN (N'Día', N'Mes', N'Calendario')),
    CONSTRAINT CK_PlanVigencia_Cantidad CHECK (Cantidad > 0)
);

CREATE TABLE TipoVehiculo (
        IdTipoVehiculo INT          IDENTITY(1,1) NOT NULL,
        Nombre         VARCHAR(60)                NOT NULL,
        Descripcion    VARCHAR(250)               NULL,
        Fecha_creacion DATETIME                   NOT NULL
        CONSTRAINT DF_TipoVehiculo_Fecha  DEFAULT GETDATE(),
        CONSTRAINT PK_TipoVehiculo PRIMARY KEY (IdTipoVehiculo),
        CONSTRAINT UQ_TipoVehiculo_Nombre  UNIQUE (nombre)
);

CREATE TABLE CategoriaVehiculo (
        IdCategoriaVehiculo INT IDENTITY(1,1) NOT NULL,
        Nombre              VARCHAR(60)       NOT NULL,
        Descripcion         VARCHAR(250)      NULL,
        Fecha_creacion      DATETIME          NOT NULL
        CONSTRAINT DF_CategoriaVehiculo_Fecha  DEFAULT GETDATE(),
        CONSTRAINT PK_CategoriaVehiculo PRIMARY KEY (IdCategoriaVehiculo),
        CONSTRAINT UQ_CategoriaVehiculo_Nombre  UNIQUE (nombre)
);

CREATE TABLE PlanTarifa(
    IdPlanTarifa        INT IDENTITY(1,1) NOT NULL,
    IdPlan              INT               NOT NULL,
    ValorTarifa         DECIMAL(18,2)     NULL, --NUEVO
    ValorMinuto         DECIMAL(18,2)     NULL,
    ValorHora           DECIMAL(18,2)     NULL,
    Valor12Horas        DECIMAL(18,2)     NULL,
    Valor24Horas        DECIMAL(18,2)     NULL,
    FechaInicioVigencia DATE              NOT NULL,
    FechaFinVigencia    DATE              NULL,
    Estado              BIT               NOT NULL
    
    CONSTRAINT PK_PlanTarifa
        PRIMARY KEY (IdPlanTarifa),

    CONSTRAINT FK_PlanTarifa_Plan
        FOREIGN KEY (IdPlan)
        REFERENCES [Plan](IdPlan),
);

CREATE TABLE PlanReglaCobro(
    IdPlanReglaCobro INT IDENTITY(1,1) NOT NULL,
    IdPlan           INT               NOT NULL,
    UnidadCobro      NVARCHAR(20)      NOT NULL,
    MinutosFraccion  INT               NULL,
    MinutosGracia    INT               NOT NULL
               
    CONSTRAINT DF_PlanReglaCobro_MinutosGracia DEFAULT 0,
    CONSTRAINT PK_PlanReglaCobro PRIMARY KEY (IdPlanReglaCobro),
    CONSTRAINT FK_PlanReglaCobro_Plan FOREIGN KEY (IdPlan) REFERENCES [Plan](IdPlan),
    CONSTRAINT CK_PlanReglaCobro_Unidad CHECK (UnidadCobro IN (N'HORA', N'MINUTO')),
    CONSTRAINT CK_PlanReglaCobro_MinutosFraccion
    CHECK
         (
            MinutosFraccion IS NULL
            OR MinutosFraccion > 0
         ),
    CONSTRAINT CK_PlanReglaCobro_MinutosGracia CHECK (MinutosGracia >= 0)
);

CREATE TABLE PlanHorario(
    IdPlanHorario   INT IDENTITY(1,1) NOT NULL,
    IdPlan          INT NOT NULL,
    Nombre          NVARCHAR(100) NULL,
    HoraInicio      TIME(0) NOT NULL,
    HoraFin         TIME(0) NOT NULL,
    CruzaMedianoche BIT NOT NULL
    
    CONSTRAINT DF_PlanHorario_CruzaMedianoche DEFAULT 0,
    Estado BIT NOT NULL CONSTRAINT DF_PlanHorario_Estado DEFAULT 1,
    CONSTRAINT PK_PlanHorario PRIMARY KEY (IdPlanHorario),
    CONSTRAINT FK_PlanHorario_Plan FOREIGN KEY (IdPlan) REFERENCES [Plan](IdPlan)
);

CREATE TABLE PlanHorarioDia(
    IdPlanHorario INT     NOT NULL,
    DiaSemana     TINYINT NOT NULL,

    CONSTRAINT PK_PlanHorarioDia PRIMARY KEY (IdPlanHorario, DiaSemana),
    CONSTRAINT FK_PlanHorarioDia_PlanHorario FOREIGN KEY (IdPlanHorario) REFERENCES PlanHorario(IdPlanHorario),
    CONSTRAINT CK_PlanHorarioDia_Dia CHECK (DiaSemana BETWEEN 1 AND 7)
);

CREATE TABLE VehiculoPlan
(
    IdVehiculoPlan   INT  IDENTITY(1,1) NOT NULL,
    IdVehiculo       INT  NOT NULL,
    IdPlanTarifa     INT  NOT NULL,
    FechaInicio      DATE NOT NULL,
    FechaFin         DATE NOT NULL,
    PrecioContratado DECIMAL(18,2) NOT NULL,
    EstadoContrato   VARCHAR(20) NOT NULL
        
    CONSTRAINT DF_VehiculoPlan_EstadoContrato
        DEFAULT 'Programada',

    EstadoPago VARCHAR(20) NOT NULL
        CONSTRAINT DF_VehiculoPlan_EstadoPago
        DEFAULT 'Pendiente',

    FechaPago DATETIME2(0) NULL,

    FechaRegistro DATETIME2(0) NOT NULL
        CONSTRAINT DF_VehiculoPlan_FechaRegistro
        DEFAULT SYSDATETIME(),

    CONSTRAINT PK_VehiculoPlan 
        PRIMARY KEY (IdVehiculoPlan),

    CONSTRAINT FK_VehiculoPlan_Vehiculo
        FOREIGN KEY (IdVehiculo)
        REFERENCES Vehiculo(Idvehiculo),

    CONSTRAINT FK_VehiculoPlan_PlanTarifa
        FOREIGN KEY (IdPlanTarifa)
        REFERENCES PlanTarifa(IdPlanTarifa),

    CONSTRAINT CK_VehiculoPlan_Fecha
        CHECK (FechaFin >= FechaInicio),

    CONSTRAINT CK_VehiculoPlan_Precio
        CHECK (PrecioContratado >= 0),

    CONSTRAINT CK_VehiculoPlan_EstadoContrato
        CHECK
        (
            EstadoContrato IN
            (
                'Programada',
                'Activa',
                'Vencida',
                'Cancelada'
            )
        ),

    CONSTRAINT CK_VehiculoPlan_EstadoPago
        CHECK
        (
            EstadoPago IN
            (
                'Pendiente',
                'Pagado',
                'Anulado'
            )
        )
);

CREATE TABLE Cobro
(
    IdCobro        INT IDENTITY(1,1) NOT NULL,
    IdVehiculo     INT NOT NULL,
    IdVehiculoPlan INT NOT NULL,
    FechaCobro     DATETIME2(0) NOT NULL

    CONSTRAINT DF_Cobro_Fecha
        DEFAULT SYSDATETIME(),

    Subtotal  DECIMAL(18,2) NOT NULL,
    Descuento DECIMAL(18,2) NOT NULL DEFAULT 0,
    Total     DECIMAL(18,2) NOT NULL,

    Estado VARCHAR(20) NOT NULL
        CONSTRAINT DF_Cobro_Estado
        DEFAULT 'Pendiente',

    UsuarioID INT NULL,

    CONSTRAINT PK_Cobro
        PRIMARY KEY (IdCobro),

    CONSTRAINT CK_Cobro_Estado
        CHECK
        (
            Estado IN
            (
                'Pendiente',
                'Pagado',
                'Anulado'
            )
        )
);

CREATE TABLE CobroDetalle
(
    IdCobroDetalle  INT IDENTITY(1,1) NOT NULL,
    IdCobro         INT NOT NULL,
    Concepto        VARCHAR(30) NOT NULL,
    IdPlanTarifa    INT NULL,
    FechaHoraInicio DATETIME2(0) NULL,
    FechaHoraFin    DATETIME2(0) NULL,
    Minutos         INT NULL,
    Cantidad        DECIMAL(18,4) NULL,
    PrecioUnitario  DECIMAL(18,2) NULL,
    Total           DECIMAL(18,2) NOT NULL,

    CONSTRAINT PK_CobroDetalle
        PRIMARY KEY (IdCobroDetalle),

    CONSTRAINT FK_CobroDetalle_Cobro
        FOREIGN KEY (IdCobro)
        REFERENCES Cobro(IdCobro),

    CONSTRAINT CK_CobroDetalle_Concepto
        CHECK
        (
            Concepto IN
            (
                'Membresia',
                'Mensualidad',
                'TiempoDemanda',
                'Overstay',
                'VIP'
            )
        )
);

CREATE TABLE MetodoPago
(
    IdMetodoPago INT IDENTITY(1,1) NOT NULL,
    Nombre       VARCHAR(50)       NOT NULL,
    Descripcion  VARCHAR(150) NULL,

    Estado BIT NOT NULL
        CONSTRAINT DF_MetodoPago_Estado DEFAULT 1,

    FechaRegistro DATETIME NOT NULL
        CONSTRAINT DF_MetodoPago_FechaRegistro DEFAULT GETDATE(),

    CONSTRAINT PK_MetodoPago
        PRIMARY KEY CLUSTERED (IdMetodoPago),

    CONSTRAINT UQ_MetodoPago_Nombre
        UNIQUE (Nombre), 
    CONSTRAINT CK_TipoMetodoPago
        CHECK
        (
            Nombre IN
            (
                'Efectivo',
                'Otro'
            )
        )
);

INSERT INTO MetodoPago
(
    Nombre,
    Descripcion,
    Estado
)
VALUES
(
    'Efectivo',
    'Pago realizado en efectivo.',
    1
),
(
    'Otro',
    'Pago realizado con otro medio de pago.',
    1
)

GO
CREATE TABLE Pago
(
    IdPago         INT IDENTITY(1,1) NOT NULL,
    IdCobro        INT               NOT NULL,
    IdVehiculoPlan INT               NULL,
    FechaPago      DATETIME2(0)      NOT NULL

    CONSTRAINT DF_Pago_Fecha
        DEFAULT SYSDATETIME(),

    IdMetodoPago INT NOT NULL,
    ValorPagado  DECIMAL(18,2) NOT NULL,

    Estado VARCHAR(20) NOT NULL
        CONSTRAINT DF_Pago_Estado
        DEFAULT 'Pagado',

    UsuarioID INT NULL,

    CONSTRAINT PK_Pago
        PRIMARY KEY (IdPago),

    CONSTRAINT FK_Pago_Cobro
        FOREIGN KEY (IdCobro)
        REFERENCES Cobro(IdCobro),

    CONSTRAINT FK_Pago_VehiculoPlan
        FOREIGN KEY (IdVehiculoPlan)
        REFERENCES VehiculoPlan(IdVehiculoPlan),

    CONSTRAINT CK_Pago_Estado
        CHECK
        (
            Estado IN
            (
                'Pagado',
                'Anulado'
            )
        ),

    CONSTRAINT CK_Pago_Valor
        CHECK (ValorPagado >= 0)
);

CREATE TABLE MovimientoParqueadero
(
    IdMovimiento INT IDENTITY(1,1) NOT NULL,

    IdVehiculo INT NOT NULL,

    IdCelda INT NOT NULL,

    FechaHoraEntrada DATETIME2(0) NOT NULL,

    FechaHoraSalida DATETIME2(0) NULL,

    Estado VARCHAR(20) NOT NULL
        CONSTRAINT DF_MovimientoParqueadero_Estado
        DEFAULT 'Dentro',

    TipoCobro VARCHAR(20) NOT NULL,

    IdVehiculoPlan INT NULL,

    IdPlanTarifa INT NULL,

    MinutosPermanencia INT NULL,

    MinutosCobrados INT NULL,

    ValorCalculado DECIMAL(18,2) NULL,

    ValorPagado DECIMAL(18,2) NULL,

    IdUsuarioEntrada INT NOT NULL,

    IdUsuarioSalida INT NULL,

    FechaRegistro DATETIME2(0) NOT NULL
        CONSTRAINT DF_MovimientoParqueadero_FechaRegistro
        DEFAULT SYSDATETIME(),

    CONSTRAINT PK_MovimientoParqueadero
        PRIMARY KEY CLUSTERED (IdMovimiento),

    CONSTRAINT FK_MovimientoParqueadero_Vehiculo
        FOREIGN KEY (IdVehiculo)
        REFERENCES Vehiculo(Idvehiculo),

    CONSTRAINT FK_MovimientoParqueadero_Celda
        FOREIGN KEY (IdCelda)
        REFERENCES Celda(IdCelda),

    CONSTRAINT FK_MovimientoParqueadero_VehiculoPlan
        FOREIGN KEY (IdVehiculoPlan)
        REFERENCES VehiculoPlan(IdVehiculoPlan),

    CONSTRAINT FK_MovimientoParqueadero_PlanTarifa
        FOREIGN KEY (IdPlanTarifa)
        REFERENCES PlanTarifa(IdPlanTarifa),

    CONSTRAINT FK_MovimientoParqueadero_UsuarioEntrada
        FOREIGN KEY (IdUsuarioEntrada)
        REFERENCES Usuarios(UsuarioID),

    CONSTRAINT FK_MovimientoParqueadero_UsuarioSalida
        FOREIGN KEY (IdUsuarioSalida)
        REFERENCES Usuarios(UsuarioID),

    CONSTRAINT CK_MovimientoParqueadero_Estado
        CHECK
        (
            Estado IN
            (
                'Dentro',
                'Finalizado',
                'Anulado'
            )
        ),

    CONSTRAINT CK_MovimientoParqueadero_TipoCobro
        CHECK
        (
            TipoCobro IN
            (
                'VIP',
                'Membresia',
                'Mensualidad',
                'TiempoDemanda'
            )
        )
);
GO